﻿# Zig RAG Implementation

A Retrieval-Augmented Generation system written in Zig 0.13, backed by Turso (vector database) and Ollama (local LLM + embeddings).

## Requirements

- **Zig 0.13+** — download from https://ziglang.org/download/
- **Ollama** running locally at `http://127.0.0.1:11434`
- Models pulled: `ollama pull nomic-embed-text && ollama pull gemma3:1b`
- A Turso account and database (see Configuration below)

## Configuration

Edit `src/config.zig` and set your Turso token:

```zig
.turso_token = "your-actual-turso-token",
```

The Turso URL is already set to `https://your-db-name.turso.io`.

## Build

```bash
zig build
```

Binaries are written to `zig-out/bin/`.

For a release build:

```bash
zig build -Doptimize=ReleaseSafe
```

## Usage

### 1. Ingest documents

Place `.txt` files in the `docs/` directory (create it first), then run:

```bash
./zig-out/bin/ingest
```

This creates the `chunks` table in Turso, reads every file in `docs/`,
splits each into contextualised chunks, embeds them with `nomic-embed-text`,
and stores them in the database.  Re-running is safe (table uses IF NOT EXISTS).

### 2. Query — diagnostic similarity search

```bash
./zig-out/bin/query "What is the refund policy?"
```

Embeds the question and prints the top-5 nearest chunks with their cosine
distance scores.  Useful for verifying that ingestion worked before running
the full RAG pipeline.

### 3. RAG — single-shot question answering

```bash
./zig-out/bin/rag "How do I reset my password?"
```

Retrieves relevant chunks and streams a grounded answer from `gemma3:1b`.
Each invocation is stateless — no conversation history is maintained.

### 4. Chatbot — interactive multi-turn conversation

```bash
./zig-out/bin/chatbot
```

Opens an interactive REPL.  Type your question and press Enter.  The chatbot
retrieves fresh context for every turn and maintains full conversation history
so the model can refer back to earlier exchanges.  Type `exit` or `quit` to end.

## Architecture

```
src/
  config.zig   — All configuration constants in one place
  http.zig     — std.http.Client wrapper: post() and postStream()
  turso.zig    — Turso HTTP API client: execute() and fetchAll()
  ollama.zig   — Ollama client: embed() and chatStream()
  chunker.zig  — Paragraph-based text splitter with heading detection
  ingest.zig   — Binary: walk docs/, chunk, embed, store
  query.zig    — Binary: embed query, similarity search, print results
  rag.zig      — Binary: retrieve context, build prompt, stream answer
  chatbot.zig  — Binary: interactive loop with history and retrieval
build.zig      — Zig build script (no external C dependencies)
```

## No External Dependencies

This implementation uses only Zig's standard library.  All HTTP is handled by
`std.http.Client`; all JSON parsing by `std.json`.  There are no C libraries,
no pkg-config, no system dependencies beyond Zig itself.

## Build steps available

```bash
zig build run-ingest              # Run the ingestor directly
zig build run-query -- "question" # Run a similarity query
zig build run-rag -- "question"   # Run a single RAG answer
zig build run-chatbot             # Start the chatbot
```
