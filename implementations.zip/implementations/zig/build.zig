/// build.zig — The blueprint that tells the Zig build system what to compile.
///
/// Four binaries share the same library modules (config, http, turso, ollama,
/// chunker) but each has its own `main` entry point:
///
///   ingest  — reads docs/, chunks them, embeds, stores in Turso
///   query   — embeds a question and prints the nearest chunks (diagnostic)
///   rag     — full single-shot RAG: retrieve + answer in one invocation
///   chatbot — interactive multi-turn conversation with retrieval
///
/// We link against the Zig standard library only — no libc, no external C
/// deps.  All HTTP is handled by `std.http.Client` which is pure Zig.
///
/// Build with:   zig build
/// Run ingest:   ./zig-out/bin/ingest
/// Run chatbot:  ./zig-out/bin/chatbot

const std = @import("std");

pub fn build(b: *std.Build) void {
    // Allow the user to pick a target with `-Dtarget=` and optimisation level
    // with `-Doptimize=`.  Defaults to native target and Debug mode.
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    // ── Shared source modules ─────────────────────────────────────────────────
    //
    // Each module is a single .zig file.  We declare them once here and add
    // them to every executable that needs them, letting the build system
    // deduplicate compilation.

    const config_mod = b.createModule(.{
        .root_source_file = b.path("src/config.zig"),
    });

    const http_mod = b.createModule(.{
        .root_source_file = b.path("src/http.zig"),
    });

    const turso_mod = b.createModule(.{
        .root_source_file = b.path("src/turso.zig"),
        .imports = &.{
            .{ .name = "http", .module = http_mod },
            .{ .name = "config", .module = config_mod },
        },
    });

    const ollama_mod = b.createModule(.{
        .root_source_file = b.path("src/ollama.zig"),
        .imports = &.{
            .{ .name = "http", .module = http_mod },
            .{ .name = "config", .module = config_mod },
        },
    });

    const chunker_mod = b.createModule(.{
        .root_source_file = b.path("src/chunker.zig"),
    });

    // ── Helper: add shared imports to an executable ───────────────────────────

    // ── ingest binary ─────────────────────────────────────────────────────────

    const exe_ingest = b.addExecutable(.{
        .name = "ingest",
        .root_source_file = b.path("src/ingest.zig"),
        .target = target,
        .optimize = optimize,
    });
    exe_ingest.root_module.addImport("config", config_mod);
    exe_ingest.root_module.addImport("http", http_mod);
    exe_ingest.root_module.addImport("turso", turso_mod);
    exe_ingest.root_module.addImport("ollama", ollama_mod);
    exe_ingest.root_module.addImport("chunker", chunker_mod);
    b.installArtifact(exe_ingest);

    // ── query binary ──────────────────────────────────────────────────────────

    const exe_query = b.addExecutable(.{
        .name = "query",
        .root_source_file = b.path("src/query.zig"),
        .target = target,
        .optimize = optimize,
    });
    exe_query.root_module.addImport("config", config_mod);
    exe_query.root_module.addImport("http", http_mod);
    exe_query.root_module.addImport("turso", turso_mod);
    exe_query.root_module.addImport("ollama", ollama_mod);
    b.installArtifact(exe_query);

    // ── rag binary ────────────────────────────────────────────────────────────

    const exe_rag = b.addExecutable(.{
        .name = "rag",
        .root_source_file = b.path("src/rag.zig"),
        .target = target,
        .optimize = optimize,
    });
    exe_rag.root_module.addImport("config", config_mod);
    exe_rag.root_module.addImport("http", http_mod);
    exe_rag.root_module.addImport("turso", turso_mod);
    exe_rag.root_module.addImport("ollama", ollama_mod);
    b.installArtifact(exe_rag);

    // ── chatbot binary ────────────────────────────────────────────────────────

    const exe_chatbot = b.addExecutable(.{
        .name = "chatbot",
        .root_source_file = b.path("src/chatbot.zig"),
        .target = target,
        .optimize = optimize,
    });
    exe_chatbot.root_module.addImport("config", config_mod);
    exe_chatbot.root_module.addImport("http", http_mod);
    exe_chatbot.root_module.addImport("turso", turso_mod);
    exe_chatbot.root_module.addImport("ollama", ollama_mod);
    b.installArtifact(exe_chatbot);

    // ── Run steps (zig build run-ingest, zig build run-chatbot, …) ────────────

    const run_ingest = b.addRunArtifact(exe_ingest);
    run_ingest.step.dependOn(b.getInstallStep());
    const run_ingest_step = b.step("run-ingest", "Run the ingestor");
    run_ingest_step.dependOn(&run_ingest.step);

    const run_query = b.addRunArtifact(exe_query);
    run_query.step.dependOn(b.getInstallStep());
    if (b.args) |args| run_query.addArgs(args);
    const run_query_step = b.step("run-query", "Run a similarity query");
    run_query_step.dependOn(&run_query.step);

    const run_rag = b.addRunArtifact(exe_rag);
    run_rag.step.dependOn(b.getInstallStep());
    if (b.args) |args| run_rag.addArgs(args);
    const run_rag_step = b.step("run-rag", "Run a single RAG question");
    run_rag_step.dependOn(&run_rag.step);

    const run_chatbot = b.addRunArtifact(exe_chatbot);
    run_chatbot.step.dependOn(b.getInstallStep());
    const run_chatbot_step = b.step("run-chatbot", "Start the interactive chatbot");
    run_chatbot_step.dependOn(&run_chatbot.step);
}
