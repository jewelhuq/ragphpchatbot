/// rag.zig — The retrieval-augmented answering machine.
///
/// This is the core of the RAG pipeline in its simplest form:
///   1. Take a question from the command line.
///   2. Embed the question and retrieve the top-K most similar chunks.
///   3. Build a prompt that gives the LLM the retrieved context + the question.
///   4. Stream the LLM's answer token by token to stdout.
///
/// Unlike `chatbot`, this binary does not maintain conversation history —
/// every invocation is stateless.  It is ideal for scripting and quick tests.
///
/// Usage:
///   ./zig-out/bin/rag "What is the return policy?"
///
/// Design note on prompt construction:
///   We keep the system prompt short and factual: "Answer using only the
///   provided context."  This reduces hallucination without being so
///   restrictive that the model refuses to answer partial matches.

const std = @import("std");
const config_mod = @import("config");
const turso = @import("turso");
const ollama = @import("ollama");

/// Entry point for the `rag` binary.
pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();

    const stdout = std.io.getStdOut().writer();
    const stderr = std.io.getStdErr().writer();

    // ── Parse command-line argument ───────────────────────────────────────────

    const args = try std.process.argsAlloc(allocator);
    defer std.process.argsFree(allocator, args);

    if (args.len < 2) {
        try stderr.print("Usage: rag <question>\n", .{});
        std.process.exit(1);
    }

    const question = args[1];

    const cfg = config_mod.Config.default();
    const db = turso.TursoClient.init(allocator, cfg);
    const ai = ollama.OllamaClient.init(cfg);

    // ── Embed the question ─────────────────────────────────────────────────────

    const embedding = ai.embed(allocator, question) catch |err| {
        try stderr.print("Embedding failed: {}\n", .{err});
        std.process.exit(1);
    };
    defer allocator.free(embedding);

    // ── Retrieve relevant chunks ───────────────────────────────────────────────

    const vec_str = try encodeVector(allocator, embedding);
    defer allocator.free(vec_str);

    const search_sql =
        \\SELECT content, source,
        \\       vector_distance_cos(embedding, ?) as distance
        \\FROM chunks
        \\ORDER BY distance ASC
        \\LIMIT ?
    ;

    const params = try buildSearchParams(allocator, vec_str, @intCast(cfg.top_k));
    defer allocator.free(params);

    var arena = std.heap.ArenaAllocator.init(allocator);
    defer arena.deinit();

    const rows = db.fetchAll(arena.allocator(), search_sql, params) catch |err| {
        try stderr.print("Search failed: {}\n", .{err});
        std.process.exit(1);
    };

    if (rows.len == 0) {
        try stdout.print("No relevant context found.  Run `ingest` first.\n", .{});
        return;
    }

    // ── Build the prompt ──────────────────────────────────────────────────────
    //
    // We concatenate the retrieved chunks into a single "Context:" block.
    // Each chunk is separated by a horizontal rule so the LLM can distinguish
    // where one chunk ends and the next begins.

    var context_buf = std.ArrayList(u8).init(allocator);
    defer context_buf.deinit();

    for (rows, 0..) |row, i| {
        if (i > 0) try context_buf.appendSlice("\n---\n");
        const content = row.get("content") orelse continue;
        try context_buf.appendSlice(content);
    }

    const system_prompt =
        \\You are a helpful assistant.  Answer the question using ONLY the context provided below.
        \\If the context does not contain enough information, say so honestly.
        \\Do not invent facts.
    ;

    const user_message = try std.fmt.allocPrint(
        allocator,
        "Context:\n{s}\n\nQuestion: {s}",
        .{ context_buf.items, question },
    );
    defer allocator.free(user_message);

    // ── Stream the answer ─────────────────────────────────────────────────────

    const messages = [_]ollama.Message{
        .{ .role = "system", .content = system_prompt },
        .{ .role = "user", .content = user_message },
    };

    const messages_json = try ollama.buildMessages(allocator, &messages);
    defer allocator.free(messages_json);

    try stdout.print("\n", .{});

    // The stream callback writes each token directly to stdout.
    // We pass the stdout writer via the ctx pointer.
    var print_ctx = PrintCtx{ .writer = stdout };

    try ai.chatStream(allocator, messages_json, printChunk, &print_ctx);

    try stdout.print("\n", .{});
}

/// Context carried through the stream callback.
const PrintCtx = struct {
    writer: std.fs.File.Writer,
};

/// Token-by-token callback: write each chunk straight to stdout without buffering.
fn printChunk(token: []const u8, ctx: ?*anyopaque) void {
    const print_ctx: *PrintCtx = @ptrCast(@alignCast(ctx.?));
    print_ctx.writer.writeAll(token) catch {};
}

/// Encode a float slice as a JSON array string for Turso's vector functions.
fn encodeVector(allocator: std.mem.Allocator, v: []const f64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();
    try buf.appendSlice("[");
    for (v, 0..) |f, i| {
        if (i > 0) try buf.appendSlice(",");
        try std.fmt.format(buf.writer(), "{d}", .{f});
    }
    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}

/// Build a Turso params array for the similarity search.
fn buildSearchParams(allocator: std.mem.Allocator, vec_str: []const u8, top_k: i64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("[");

    try buf.appendSlice("{\"type\":\"text\",\"value\":\"");
    for (vec_str) |c| {
        switch (c) {
            '"' => try buf.appendSlice("\\\""),
            '\\' => try buf.appendSlice("\\\\"),
            else => try buf.append(c),
        }
    }
    try buf.appendSlice("\"},");

    try std.fmt.format(buf.writer(), "{{\"type\":\"integer\",\"value\":\"{d}\"}}", .{top_k});

    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}
