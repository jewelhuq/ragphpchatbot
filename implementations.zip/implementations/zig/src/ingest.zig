/// ingest.zig — The librarian who reads documents and files them in the database.
///
/// Ingestion is the first step in every RAG pipeline:
///   1. Ensure the `chunks` table exists in Turso.
///   2. Walk the `docs/` directory, reading every file.
///   3. Split each file into contextualised chunks (via chunker.zig).
///   4. Embed each chunk with Ollama's nomic-embed-text model.
///   5. Insert the chunk text and its embedding into Turso.
///
/// Run this once (or whenever documents change) before using `rag` or `chatbot`.
///
/// Design notes:
///   - We use a `std.heap.GeneralPurposeAllocator` for the outer loop and an
///     `ArenaAllocator` per file so that all per-file allocations are freed
///     in one shot when we move to the next file.  This keeps peak memory low.
///   - Vector embeddings are stored as text-encoded float arrays for simplicity.
///     Turso's vector_distance_cos() function accepts this format directly.

const std = @import("std");
const config_mod = @import("config");
const turso = @import("turso");
const ollama = @import("ollama");
const chunker = @import("chunker");

/// Entry point for the `ingest` binary.
pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();

    const cfg = config_mod.Config.default();
    const db = turso.TursoClient.init(allocator, cfg);
    const ai = ollama.OllamaClient.init(cfg);

    const stdout = std.io.getStdOut().writer();

    // ── Step 1: Create the table if it doesn't exist ──────────────────────────
    //
    // We use IF NOT EXISTS so re-running ingest is idempotent.
    // The embedding column uses TEXT to store a JSON float array; Turso's
    // vector search functions accept this encoding directly.
    const create_sql =
        \\CREATE TABLE IF NOT EXISTS chunks (
        \\    id        INTEGER PRIMARY KEY AUTOINCREMENT,
        \\    source    TEXT NOT NULL,
        \\    content   TEXT NOT NULL,
        \\    embedding TEXT NOT NULL
        \\)
    ;

    try stdout.print("Creating chunks table...\n", .{});
    try db.execute(allocator, create_sql, "[]");
    try stdout.print("Table ready.\n", .{});

    // ── Step 2: Walk the docs directory ───────────────────────────────────────

    const docs_dir_path = cfg.docs_dir;
    var docs_dir = std.fs.cwd().openDir(docs_dir_path, .{ .iterate = true }) catch |err| {
        try stdout.print("Error opening docs dir '{s}': {}\n", .{ docs_dir_path, err });
        try stdout.print("Create a 'docs/' directory with .txt files and try again.\n", .{});
        return;
    };
    defer docs_dir.close();

    var total_chunks: usize = 0;
    var file_count: usize = 0;

    var iter = docs_dir.iterate();
    while (try iter.next()) |entry| {
        if (entry.kind != .file) continue;

        // Use an arena per file so all allocations are freed together.
        var arena = std.heap.ArenaAllocator.init(allocator);
        defer arena.deinit();
        const arena_alloc = arena.allocator();

        try stdout.print("\nIngesting: {s}\n", .{entry.name});

        // ── Step 3: Read the file ──────────────────────────────────────────
        const file = docs_dir.openFile(entry.name, .{}) catch |err| {
            try stdout.print("  Could not open {s}: {}\n", .{ entry.name, err });
            continue;
        };
        defer file.close();

        const file_content = file.readToEndAlloc(arena_alloc, 10 * 1024 * 1024) catch |err| {
            try stdout.print("  Could not read {s}: {}\n", .{ entry.name, err });
            continue;
        };

        if (file_content.len == 0) {
            try stdout.print("  Skipping empty file.\n", .{});
            continue;
        }

        // ── Step 4: Chunk the text ─────────────────────────────────────────
        const chunks = chunker.chunk(arena_alloc, file_content, entry.name) catch |err| {
            try stdout.print("  Chunking failed: {}\n", .{err});
            continue;
        };

        try stdout.print("  Produced {d} chunks.\n", .{chunks.len});

        // ── Step 5: Embed and insert each chunk ────────────────────────────
        for (chunks, 0..) |chunk_text, ci| {
            try stdout.print("  [{d}/{d}] Embedding...\r", .{ ci + 1, chunks.len });

            const embedding = ai.embed(arena_alloc, chunk_text) catch |err| {
                try stdout.print("\n  Embedding failed for chunk {d}: {}\n", .{ ci, err });
                continue;
            };

            // Encode the embedding as a JSON float array string.
            const vec_str = try encodeVector(arena_alloc, embedding);

            // Build the params array: [content_text, source_text, embedding_text]
            const params = try buildInsertParams(arena_alloc, chunk_text, entry.name, vec_str);

            db.execute(
                arena_alloc,
                "INSERT INTO chunks (content, source, embedding) VALUES (?, ?, ?)",
                params,
            ) catch |err| {
                try stdout.print("\n  Insert failed for chunk {d}: {}\n", .{ ci, err });
                continue;
            };

            total_chunks += 1;
        }

        try stdout.print("\n  Done ({d} chunks inserted).\n", .{chunks.len});
        file_count += 1;
    }

    try stdout.print(
        "\nIngestion complete: {d} file(s), {d} total chunks.\n",
        .{ file_count, total_chunks },
    );
}

/// Encode a float slice as a JSON array string, e.g. "[0.1,0.2,0.3]".
fn encodeVector(allocator: std.mem.Allocator, v: []const f64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    errdefer buf.deinit();
    try buf.appendSlice("[");
    for (v, 0..) |f, i| {
        if (i > 0) try buf.appendSlice(",");
        try std.fmt.format(buf.writer(), "{d}", .{f});
    }
    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}

/// Build a Turso params JSON array for the INSERT statement.
/// Three positional params: content (text), source (text), embedding (text).
fn buildInsertParams(
    allocator: std.mem.Allocator,
    content: []const u8,
    source: []const u8,
    embedding: []const u8,
) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    errdefer buf.deinit();
    try buf.appendSlice("[");

    // content param
    try buf.appendSlice("{\"type\":\"text\",\"value\":\"");
    try appendJsonEscaped(&buf, content);
    try buf.appendSlice("\"},");

    // source param
    try buf.appendSlice("{\"type\":\"text\",\"value\":\"");
    try appendJsonEscaped(&buf, source);
    try buf.appendSlice("\"},");

    // embedding param
    try buf.appendSlice("{\"type\":\"text\",\"value\":\"");
    try appendJsonEscaped(&buf, embedding);
    try buf.appendSlice("\"}");

    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}

/// Append `s` to `buf` with JSON string escaping.
fn appendJsonEscaped(buf: *std.ArrayList(u8), s: []const u8) !void {
    for (s) |c| {
        switch (c) {
            '"' => try buf.appendSlice("\\\""),
            '\\' => try buf.appendSlice("\\\\"),
            '\n' => try buf.appendSlice("\\n"),
            '\r' => try buf.appendSlice("\\r"),
            '\t' => try buf.appendSlice("\\t"),
            else => try buf.append(c),
        }
    }
}
