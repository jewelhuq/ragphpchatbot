/// chunker.zig — The editor who breaks raw documents into digestible pieces.
///
/// A RAG system lives or dies by its chunking strategy.  Chunks that are too
/// large swamp the LLM's context window; chunks that are too small lose the
/// surrounding sentences that give a fragment its meaning.  This chunker
/// takes a middle path:
///
///   1. Split on blank lines (`\n\n`), which are the natural paragraph
///      boundaries in plain-text and Markdown documents.
///
///   2. Detect section headings: a paragraph that is ALL UPPERCASE (after
///      trimming) is treated as a heading that labels the next chunk.
///      This lets us prefix each chunk with its section context so the
///      LLM always knows where a chunk came from.
///
///   3. Enforce a minimum of 100 characters.  Chunks shorter than that
///      are merged with the next paragraph rather than emitted as standalone
///      noise embeddings.
///
///   4. Prefix every chunk with "Source: <source>\nSection: <heading>\n\n"
///      so the LLM sees provenance metadata baked into the chunk text itself.
///
/// The caller passes a `source` label (typically the filename) and receives
/// a `[][]u8` of chunks.  All memory is owned by the caller.

const std = @import("std");

/// Minimum chunk length in characters.  Paragraphs shorter than this are
/// merged into the accumulating chunk rather than emitted separately.
const MIN_CHUNK_CHARS: usize = 100;

/// Split `text` into contextualised chunks.
///
/// `source` is a human-readable label for the document (e.g. "manual.txt").
/// Returns a slice of heap-allocated strings; the caller must free each string
/// and then the slice itself, or use an ArenaAllocator.
pub fn chunk(
    allocator: std.mem.Allocator,
    text: []const u8,
    source: []const u8,
) ![][]u8 {
    var results = std.ArrayList([]u8).init(allocator);

    // Split the document on blank lines.
    var paragraphs = std.ArrayList([]const u8).init(allocator);
    defer paragraphs.deinit();

    var iter = std.mem.splitSequence(u8, text, "\n\n");
    while (iter.next()) |para| {
        const trimmed = std.mem.trim(u8, para, " \r\t\n");
        if (trimmed.len > 0) {
            try paragraphs.append(trimmed);
        }
    }

    // Walk the paragraphs, tracking the current section heading and
    // accumulating content until we have enough characters to emit a chunk.
    var current_heading: []const u8 = "Introduction";
    var accumulator = std.ArrayList(u8).init(allocator);
    defer accumulator.deinit();

    for (paragraphs.items) |para| {
        if (isHeading(para)) {
            // Flush the accumulator before starting a new section.
            if (accumulator.items.len >= MIN_CHUNK_CHARS) {
                const c = try buildChunk(allocator, source, current_heading, accumulator.items);
                try results.append(c);
                accumulator.clearRetainingCapacity();
            }
            current_heading = para;
            continue;
        }

        // Append the paragraph to the accumulator.
        if (accumulator.items.len > 0) {
            try accumulator.appendSlice("\n\n");
        }
        try accumulator.appendSlice(para);

        // Once the accumulator crosses the minimum threshold, emit a chunk.
        // We don't enforce a hard maximum here: better to have a slightly long
        // chunk than to split a coherent paragraph mid-thought.
        if (accumulator.items.len >= MIN_CHUNK_CHARS) {
            const c = try buildChunk(allocator, source, current_heading, accumulator.items);
            try results.append(c);
            accumulator.clearRetainingCapacity();
        }
    }

    // Flush any remaining content that didn't reach MIN_CHUNK_CHARS.
    if (accumulator.items.len > 0) {
        const c = try buildChunk(allocator, source, current_heading, accumulator.items);
        try results.append(c);
    }

    return results.toOwnedSlice();
}

/// Decide whether a paragraph is a section heading.
///
/// Heuristic: a non-empty paragraph is a heading if every alphabetic character
/// in it is uppercase.  This catches "INTRODUCTION", "CHAPTER 1: SETUP", and
/// "WHY ZIG?" while ignoring normal prose that happens to have a capital
/// at the start.
fn isHeading(para: []const u8) bool {
    var has_alpha = false;
    for (para) |c| {
        if (std.ascii.isAlphabetic(c)) {
            has_alpha = true;
            if (std.ascii.isLower(c)) return false;
        }
    }
    return has_alpha;
}

/// Assemble the final chunk string with source/section prefix.
/// Returns a heap-allocated string the caller owns.
fn buildChunk(
    allocator: std.mem.Allocator,
    source: []const u8,
    heading: []const u8,
    content: []const u8,
) ![]u8 {
    return std.fmt.allocPrint(
        allocator,
        "Source: {s}\nSection: {s}\n\n{s}",
        .{ source, heading, content },
    );
}
