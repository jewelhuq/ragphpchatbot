/// query.zig — The index searcher who finds relevant chunks for a given question.
///
/// This binary is a diagnostic tool: given a question on the command line it
/// embeds the question and returns the top-K most similar chunks from Turso,
/// printing each with its similarity score.
///
/// Useful for tuning the chunking strategy and verifying that ingestion
/// produced sensible embeddings before hooking up the full RAG pipeline.
///
/// Usage:
///   ./zig-out/bin/query "What is the refund policy?"
///
/// Design note: we use cosine distance for similarity, which Turso exposes as
/// `vector_distance_cos(embedding, ?)`.  Lower scores mean more similar —
/// distance 0 means identical vectors, distance 2 means maximally opposite.
/// We display the score as-is so users can see the raw signal.

const std = @import("std");
const config_mod = @import("config");
const turso = @import("turso");
const ollama = @import("ollama");

/// Entry point for the `query` binary.
pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();

    const stdout = std.io.getStdOut().writer();
    const stderr = std.io.getStdErr().writer();

    // ── Parse the command-line argument ───────────────────────────────────────

    const args = try std.process.argsAlloc(allocator);
    defer std.process.argsFree(allocator, args);

    if (args.len < 2) {
        try stderr.print("Usage: query <question>\n", .{});
        try stderr.print("Example: query \"What is the refund policy?\"\n", .{});
        std.process.exit(1);
    }

    const question = args[1];

    const cfg = config_mod.Config.default();
    const db = turso.TursoClient.init(allocator, cfg);
    const ai = ollama.OllamaClient.init(cfg);

    try stdout.print("Question: {s}\n\n", .{question});

    // ── Embed the question ─────────────────────────────────────────────────────

    try stdout.print("Embedding question...\n", .{});
    const embedding = ai.embed(allocator, question) catch |err| {
        try stderr.print("Failed to embed question: {}\n", .{err});
        std.process.exit(1);
    };
    defer allocator.free(embedding);

    try stdout.print("Embedding dimensions: {d}\n\n", .{embedding.len});

    // ── Build the vector search query ─────────────────────────────────────────
    //
    // Turso's vector_distance_cos() expects a text-encoded float array.
    // We pass the embedding as "[0.1,0.2,...]" via a text parameter.
    // The ORDER BY distance ASC + LIMIT gives us the K nearest neighbours.

    const vec_str = try encodeVector(allocator, embedding);
    defer allocator.free(vec_str);

    const search_sql =
        \\SELECT id, source, content,
        \\       vector_distance_cos(embedding, ?) as distance
        \\FROM chunks
        \\ORDER BY distance ASC
        \\LIMIT ?
    ;

    const params = try buildSearchParams(allocator, vec_str, @intCast(cfg.top_k));
    defer allocator.free(params);

    // ── Execute and display results ───────────────────────────────────────────

    try stdout.print("Searching top {d} chunks...\n\n", .{cfg.top_k});

    var arena = std.heap.ArenaAllocator.init(allocator);
    defer arena.deinit();

    const rows = db.fetchAll(arena.allocator(), search_sql, params) catch |err| {
        try stderr.print("Search failed: {}\n", .{err});
        std.process.exit(1);
    };

    if (rows.len == 0) {
        try stdout.print("No results found.  Have you run `ingest` yet?\n", .{});
        return;
    }

    for (rows, 0..) |row, i| {
        const source = row.get("source") orelse "(unknown)";
        const content = row.get("content") orelse "";
        const distance = row.get("distance") orelse "?";

        try stdout.print("── Result {d} ────────────────────────────────────\n", .{i + 1});
        try stdout.print("Source  : {s}\n", .{source});
        try stdout.print("Distance: {s}\n", .{distance});
        try stdout.print("Content :\n{s}\n\n", .{content});
    }
}

/// Encode a float slice as a JSON array string for Turso's vector functions.
fn encodeVector(allocator: std.mem.Allocator, v: []const f64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();
    try buf.appendSlice("[");
    for (v, 0..) |f, i| {
        if (i > 0) try buf.appendSlice(",");
        try std.fmt.format(buf.writer(), "{d}", .{f});
    }
    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}

/// Build a Turso params array with two positional params:
///   1. embedding text  (for vector_distance_cos)
///   2. top_k integer   (for LIMIT)
fn buildSearchParams(allocator: std.mem.Allocator, vec_str: []const u8, top_k: i64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("[");

    // First param: the vector as a text string.
    try buf.appendSlice("{\"type\":\"text\",\"value\":\"");
    for (vec_str) |c| {
        switch (c) {
            '"' => try buf.appendSlice("\\\""),
            '\\' => try buf.appendSlice("\\\\"),
            else => try buf.append(c),
        }
    }
    try buf.appendSlice("\"},");

    // Second param: top_k as an integer.
    try std.fmt.format(buf.writer(), "{{\"type\":\"integer\",\"value\":\"{d}\"}}", .{top_k});

    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}
