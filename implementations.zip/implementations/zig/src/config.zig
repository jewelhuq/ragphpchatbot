﻿/// config.zig — The single source of truth for every knob in the system.
///
/// Rather than scattering magic strings across multiple files, we centralise
/// every tunable parameter here.  Each binary calls `Config.default()` and
/// is immediately ready to run against the real deployment — no environment
/// variables required for a quick experiment.
///
/// Design decision: all fields are `[]const u8` slices (pointing into static
/// string literals returned by `default()`) or `i32` integers.  This keeps
/// the struct simple and avoids heap allocation for configuration data that
/// never changes at runtime.  If you need runtime overrides, replace the
/// slice with a heap-allocated copy via `allocator.dupe(u8, value)`.

const std = @import("std");

/// Config bundles every parameter the RAG system needs.
/// Fields are grouped by concern: storage, inference, retrieval, ingestion.
pub const Config = struct {
    /// The HTTP base URL of the Turso database, e.g.
    /// "https://my-db-org.aws-us-east-1.turso.io".
    turso_url: []const u8,

    /// The Bearer token that authenticates requests to Turso.
    /// Never log this value — treat it like a password.
    turso_token: []const u8,

    /// The base URL of the local Ollama server.
    /// Defaults to the standard loopback address Ollama uses out of the box.
    ollama_url: []const u8,

    /// The Ollama model name used to generate conversational answers.
    /// Kept small (gemma3:1b) so the system runs on modest consumer hardware.
    chat_model: []const u8,

    /// The Ollama model name used to produce embedding vectors.
    /// Must be "nomic-embed-text" or another model that emits exactly
    /// `embedding_dims` floats — a mismatch silently corrupts similarity scores.
    embedding_model: []const u8,

    /// The number of dimensions the embedding model produces.
    /// nomic-embed-text outputs 768 dimensions; the Turso vector column
    /// F32_BLOB(768) must match this value exactly.
    embedding_dims: i32,

    /// How many nearest-neighbour chunks to retrieve for each user query.
    /// Higher values give the LLM more context but inflate the prompt and
    /// increase latency.
    top_k: i32,

    /// The directory the ingestor scans for source documents.
    /// Relative paths are resolved from the working directory of the binary.
    docs_dir: []const u8,

    /// Target character count for each text chunk produced by the chunker.
    /// Chunks may exceed this when a paragraph falls just beyond the limit.
    /// The chunker enforces a minimum of 100 characters to avoid noise.
    chunk_size: i32,

    /// Returns a Config pre-populated with the real deployment values.
    ///
    /// Why bake the values in rather than reading env vars?
    /// Because for a local RAG demo, zero configuration is better UX than
    /// "set 5 environment variables before it works".  Operators who need
    /// different values can override individual fields after calling this.
    pub fn default() Config {
        return Config{
            .turso_url = "https://your-db-name.turso.io",
            .turso_token = "YOUR_TURSO_TOKEN_HERE",
            .ollama_url = "http://127.0.0.1:11434",
            .chat_model = "gemma3:1b",
            .embedding_model = "nomic-embed-text",
            .embedding_dims = 768,
            .top_k = 5,
            .docs_dir = "docs",
            .chunk_size = 1000,
        };
    }
};
