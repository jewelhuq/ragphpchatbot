/// turso.zig — The librarian who reads and writes to our vector database.
///
/// Turso exposes a stateless HTTP API at `/v2/pipeline`.  Each request is a
/// JSON envelope containing one or more SQL statements; each statement can
/// carry typed positional parameters.  The response mirrors that structure,
/// with rows encoded as arrays of `{"type":"…","value":"…"}` objects.
///
/// We wrap all of that in two simple methods:
///   - `execute`  — fire-and-forget DDL / DML (CREATE TABLE, INSERT, …)
///   - `fetchAll` — SELECT queries that hand back rows as key/value maps
///
/// Design decisions:
///
/// 1. Every Row is an ArrayList of Field structs rather than a HashMap.
///    We avoid the HashMap because it requires a hash function and more
///    bookkeeping.  For the column counts we deal with (< 10), a linear
///    scan to find a field by name is imperceptible.
///
/// 2. All returned slices are arena-friendly: callers may use an ArenaAllocator
///    and free everything in one shot when done.

const std = @import("std");
const http = @import("http");
const config = @import("config");

/// A single column value inside a result row.
pub const Field = struct {
    /// The column name as returned by Turso.
    name: []const u8,
    /// The value coerced to a string.  NULL becomes an empty string.
    value: []const u8,
};

/// One result row — a list of Fields in the order the columns were SELECTed.
pub const Row = struct {
    fields: std.ArrayList(Field),

    /// Look up a field by column name.  Returns null if not found.
    /// Linear scan is fine for the small column counts in this system.
    pub fn get(self: Row, name: []const u8) ?[]const u8 {
        for (self.fields.items) |f| {
            if (std.mem.eql(u8, f.name, name)) return f.value;
        }
        return null;
    }
};

/// TursoClient holds the credentials and base URL needed to reach Turso.
/// Create one per program; it is cheap and has no internal connection pool.
pub const TursoClient = struct {
    allocator: std.mem.Allocator,
    base_url: []const u8,
    token: []const u8,

    /// Build a TursoClient from a Config.
    /// The client borrows `cfg`'s string slices — it does not copy them —
    /// so the Config must outlive the client.
    pub fn init(allocator: std.mem.Allocator, cfg: config.Config) TursoClient {
        return TursoClient{
            .allocator = allocator,
            .base_url = cfg.turso_url,
            .token = cfg.turso_token,
        };
    }

    /// Build the full pipeline URL by appending `/v2/pipeline` to the base URL.
    fn pipelineUrl(self: TursoClient, allocator: std.mem.Allocator) ![]u8 {
        return std.fmt.allocPrint(allocator, "{s}/v2/pipeline", .{self.base_url});
    }

    /// Build the Authorization header value string.
    fn authHeader(self: TursoClient, allocator: std.mem.Allocator) ![]u8 {
        return std.fmt.allocPrint(allocator, "Bearer {s}", .{self.token});
    }

    /// Send a single SQL statement that produces no rows (DDL or DML).
    ///
    /// `sql`    — the SQL text, with `?` placeholders for parameters.
    /// `params` — a JSON array fragment of typed args (see `buildParam*` helpers).
    ///
    /// Any SQL-level error reported by Turso is surfaced as `error.TursoSqlError`.
    pub fn execute(
        self: TursoClient,
        allocator: std.mem.Allocator,
        sql: []const u8,
        params: []const u8,
    ) !void {
        const url = try self.pipelineUrl(allocator);
        defer allocator.free(url);

        const auth = try self.authHeader(allocator);
        defer allocator.free(auth);

        // Compose the request body as a JSON string.
        // We JSON-encode `sql` first into a temporary buffer, then interpolate
        // it into the full request body.  The temp buffer is freed after use.
        const sql_json = try jsonString(allocator, sql);
        defer allocator.free(sql_json);

        const body = try std.fmt.allocPrint(allocator,
            \\{{"requests":[{{"type":"execute","stmt":{{"sql":{s},"args":{s}}}}},{{"type":"close"}}]}}
        , .{ sql_json, params });
        defer allocator.free(body);

        const headers = [_]http.Header{
            .{ .name = "Authorization", .value = auth },
        };

        const resp_bytes = try http.post(allocator, url, &headers, body);
        defer allocator.free(resp_bytes);

        // Parse just enough of the response to check for errors.
        try checkTursoErrors(allocator, resp_bytes);
    }

    /// Send a SELECT statement and return all rows.
    ///
    /// The caller owns the returned slice and each Row inside it.
    /// Use an ArenaAllocator to free everything in one call:
    ///
    ///   var arena = std.heap.ArenaAllocator.init(allocator);
    ///   defer arena.deinit();
    ///   const rows = try turso.fetchAll(arena.allocator(), sql, params);
    ///   // rows and their fields are freed when arena.deinit() runs.
    pub fn fetchAll(
        self: TursoClient,
        allocator: std.mem.Allocator,
        sql: []const u8,
        params: []const u8,
    ) ![]Row {
        const url = try self.pipelineUrl(allocator);
        defer allocator.free(url);

        const auth = try self.authHeader(allocator);
        defer allocator.free(auth);

        const sql_json = try jsonString(allocator, sql);
        defer allocator.free(sql_json);

        const body = try std.fmt.allocPrint(allocator,
            \\{{"requests":[{{"type":"execute","stmt":{{"sql":{s},"args":{s}}}}},{{"type":"close"}}]}}
        , .{ sql_json, params });
        defer allocator.free(body);

        const headers = [_]http.Header{
            .{ .name = "Authorization", .value = auth },
        };

        const resp_bytes = try http.post(allocator, url, &headers, body);
        defer allocator.free(resp_bytes);

        return parseRows(allocator, resp_bytes);
    }
};

/// Wrap a plain string in JSON double-quotes, escaping internal quotes.
/// Returns a heap-allocated slice the caller must free.
fn jsonString(allocator: std.mem.Allocator, s: []const u8) ![]u8 {
    // Count quotes to size the output buffer.
    var n_quotes: usize = 0;
    for (s) |c| {
        if (c == '"' or c == '\\') n_quotes += 1;
    }

    const out = try allocator.alloc(u8, s.len + n_quotes + 2);
    var i: usize = 0;
    out[i] = '"';
    i += 1;
    for (s) |c| {
        if (c == '"' or c == '\\') {
            out[i] = '\\';
            i += 1;
        }
        out[i] = c;
        i += 1;
    }
    out[i] = '"';
    return out;
}

/// Scan the Turso pipeline response for error objects and return an error
/// if any are found.  Turso can return HTTP 200 but still report SQL errors
/// inside the results array.
fn checkTursoErrors(allocator: std.mem.Allocator, resp_bytes: []const u8) !void {
    const parsed = std.json.parseFromSlice(
        std.json.Value,
        allocator,
        resp_bytes,
        .{ .duplicate_field_behavior = .use_last },
    ) catch return; // If we can't parse, assume success to avoid false positives.
    defer parsed.deinit();

    const results = parsed.value.object.get("results") orelse return;
    for (results.array.items) |result| {
        const t = result.object.get("type") orelse continue;
        if (std.mem.eql(u8, t.string, "error")) {
            const err_obj = result.object.get("error") orelse continue;
            const msg = err_obj.object.get("message") orelse continue;
            std.log.err("Turso SQL error: {s}", .{msg.string});
            return error.TursoSqlError;
        }
    }
}

/// Parse the `results[0].response.result.{cols,rows}` structure from a Turso
/// pipeline response into a slice of `Row` values.
fn parseRows(allocator: std.mem.Allocator, resp_bytes: []const u8) ![]Row {
    const parsed = try std.json.parseFromSlice(
        std.json.Value,
        allocator,
        resp_bytes,
        .{ .duplicate_field_behavior = .use_last },
    );
    defer parsed.deinit();

    // Navigate: results[0].response.result
    const results = parsed.value.object.get("results") orelse return &[_]Row{};
    if (results.array.items.len == 0) return &[_]Row{};

    const result0 = results.array.items[0];
    const response = result0.object.get("response") orelse return &[_]Row{};
    const result = response.object.get("result") orelse return &[_]Row{};

    // Extract column names.
    const cols_val = result.object.get("cols") orelse return &[_]Row{};
    const cols = cols_val.array.items;

    var col_names = try allocator.alloc([]const u8, cols.len);
    defer allocator.free(col_names);

    for (cols, 0..) |col, i| {
        const name = col.object.get("name") orelse continue;
        col_names[i] = try allocator.dupe(u8, name.string);
    }

    // Extract rows.
    const rows_val = result.object.get("rows") orelse return &[_]Row{};
    const raw_rows = rows_val.array.items;

    var rows = try allocator.alloc(Row, raw_rows.len);

    for (raw_rows, 0..) |raw_row, ri| {
        var fields = std.ArrayList(Field).init(allocator);
        const cells = raw_row.array.items;

        for (cells, 0..) |cell, ci| {
            if (ci >= col_names.len) break;

            const cell_type = cell.object.get("type");
            const is_null = if (cell_type) |t|
                std.mem.eql(u8, t.string, "null")
            else
                false;

            const value_str: []const u8 = if (is_null)
                try allocator.dupe(u8, "")
            else blk: {
                const v = cell.object.get("value") orelse break :blk try allocator.dupe(u8, "");
                break :blk switch (v) {
                    .string => |s| try allocator.dupe(u8, s),
                    .integer => |n| try std.fmt.allocPrint(allocator, "{d}", .{n}),
                    .float => |f| try std.fmt.allocPrint(allocator, "{d}", .{f}),
                    .bool => |b| try allocator.dupe(u8, if (b) "true" else "false"),
                    .null => try allocator.dupe(u8, ""),
                    else => try allocator.dupe(u8, ""),
                };
            };

            try fields.append(Field{
                .name = col_names[ci],
                .value = value_str,
            });
        }

        rows[ri] = Row{ .fields = fields };
    }

    return rows;
}

/// Build a JSON params array containing a single text argument.
/// Usage: const p = try buildParamText(allocator, "hello"); → `[{"type":"text","value":"hello"}]`
pub fn buildParamText(allocator: std.mem.Allocator, value: []const u8) ![]u8 {
    const escaped = try jsonString(allocator, value);
    defer allocator.free(escaped);
    return std.fmt.allocPrint(allocator,
        \\[{{"type":"text","value":{s}}}]
    , .{escaped});
}

/// Build a JSON params array containing a single integer argument.
pub fn buildParamInt(allocator: std.mem.Allocator, value: i64) ![]u8 {
    return std.fmt.allocPrint(allocator,
        \\[{{"type":"integer","value":"{d}"}}]
    , .{value});
}

/// Build a JSON params array for the vector similarity search.
/// Turso expects the blob as a base64-encoded string in a "blob" typed arg,
/// but libSQL vector search also accepts a text-encoded float list.
/// We encode as text for simplicity: `"[0.1,0.2,...]"`.
pub fn buildVectorParam(allocator: std.mem.Allocator, embedding: []const f64) ![]u8 {
    // Encode the float array as a JSON array string, then wrap in a text arg.
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("[");
    for (embedding, 0..) |v, i| {
        if (i > 0) try buf.appendSlice(",");
        try std.fmt.format(buf.writer(), "{d}", .{v});
    }
    try buf.appendSlice("]");

    const vec_str = buf.items;
    const escaped = try jsonString(allocator, vec_str);
    defer allocator.free(escaped);

    return std.fmt.allocPrint(allocator,
        \\[{{"type":"text","value":{s}}}]
    , .{escaped});
}
