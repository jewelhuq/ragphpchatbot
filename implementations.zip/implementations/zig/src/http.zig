/// http.zig — The thin messenger layer between our code and the outside world.
///
/// We wrap Zig's `std.http.Client` in two functions:
///
///   - `post`: fire a request, wait for the full body, return it as a slice.
///   - `postStream`: fire a request, call a callback for every chunk of bytes
///     received, allowing the UI to print tokens the moment they arrive.
///
/// Design decisions:
///
/// 1. We use `std.http.Client` (stdlib only) rather than pulling in a C library.
///    This keeps the build trivially simple and removes a class of FFI bugs.
///
/// 2. The caller owns the returned `[]u8` from `post` and must free it.
///    We document this contract with the allocator parameter rather than hiding
///    it in a struct's deinit.
///
/// 3. Both functions share the same low-level open/send/finish/wait flow so
///    that `postStream` can read the body incrementally without buffering the
///    full response.  `post` simply collects all incremental reads into an
///    ArrayList before returning.
///
/// 4. `postStream` uses a fixed 8 KB read buffer on the stack.  Ollama sends
///    small NDJSON lines (typically < 256 bytes), so 8 KB is generous.

const std = @import("std");

/// A named header key-value pair.
/// Callers build a slice of these and pass it to `post` / `postStream`.
pub const Header = struct {
    name: []const u8,
    value: []const u8,
};

/// Callback signature used by `postStream`.
/// `chunk` is a slice of bytes just read from the response body.
/// `ctx` is an opaque pointer the caller can use to carry state (e.g. a
/// reference to a line buffer or a stdout writer).
pub const StreamCallback = *const fn (chunk: []const u8, ctx: ?*anyopaque) void;

/// Make an HTTP POST to `url`, attaching `headers` and sending `body`.
/// The full response body is read into a freshly-allocated slice and returned.
/// The caller is responsible for freeing it with `allocator.free(result)`.
///
/// Why return the raw bytes rather than parsed JSON?
/// Different callers (Turso, Ollama embed, Ollama chat) parse the response
/// differently, so keeping parsing out of the transport layer respects
/// the single-responsibility principle.
pub fn post(
    allocator: std.mem.Allocator,
    url: []const u8,
    headers: []const Header,
    body: []const u8,
) ![]u8 {
    var client = std.http.Client{ .allocator = allocator };
    defer client.deinit();

    const uri = try std.Uri.parse(url);

    // Build the extra headers list.  Content-Type is always added;
    // callers provide Authorization and any other headers they need.
    var extra_headers = std.ArrayList(std.http.Header).init(allocator);
    defer extra_headers.deinit();

    try extra_headers.append(.{
        .name = "Content-Type",
        .value = "application/json",
    });

    for (headers) |h| {
        try extra_headers.append(.{
            .name = h.name,
            .value = h.value,
        });
    }

    // server_header_buffer receives the raw HTTP response header bytes.
    // 16 KB comfortably accommodates any response header we will encounter.
    var server_header_buffer: [16 * 1024]u8 = undefined;

    // open() establishes the TCP connection and sends the request line + headers.
    var request = try client.open(.POST, uri, .{
        .server_header_buffer = &server_header_buffer,
        .extra_headers = extra_headers.items,
    });
    defer request.deinit();

    // Declare the body length so the server knows when the request ends.
    request.transfer_encoding = .{ .content_length = body.len };
    try request.send();
    try request.writeAll(body);
    try request.finish();
    try request.wait(); // Blocks until response headers are received.

    if (request.response.status.class() != .success) {
        std.log.err("HTTP POST {s} returned status {d}", .{
            url,
            @intFromEnum(request.response.status),
        });
        return error.HttpError;
    }

    // Read the full response body into an ArrayList, then hand ownership
    // to the caller via toOwnedSlice().
    var response_body = std.ArrayList(u8).init(allocator);
    defer response_body.deinit();

    var buf: [8 * 1024]u8 = undefined;
    while (true) {
        const n = try request.reader().read(&buf);
        if (n == 0) break;
        try response_body.appendSlice(buf[0..n]);
    }

    return response_body.toOwnedSlice();
}

/// Make an HTTP POST to `url` and stream the response body, calling `callback`
/// with each chunk of bytes as it arrives from the server.
///
/// This is purpose-built for Ollama's streaming chat endpoint, which sends
/// newline-delimited JSON tokens one at a time.  By delivering chunks as they
/// arrive we can print each token immediately rather than waiting for the
/// complete response — the key to a responsive chatbot UX.
///
/// `ctx` is forwarded unchanged to every `callback` invocation.  Use it to
/// carry a mutable line buffer, a writer, or any state the callback needs.
pub fn postStream(
    allocator: std.mem.Allocator,
    url: []const u8,
    headers: []const Header,
    body: []const u8,
    callback: StreamCallback,
    ctx: ?*anyopaque,
) !void {
    var client = std.http.Client{ .allocator = allocator };
    defer client.deinit();

    const uri = try std.Uri.parse(url);

    var extra_headers = std.ArrayList(std.http.Header).init(allocator);
    defer extra_headers.deinit();

    try extra_headers.append(.{
        .name = "Content-Type",
        .value = "application/json",
    });

    for (headers) |h| {
        try extra_headers.append(.{
            .name = h.name,
            .value = h.value,
        });
    }

    // server_header_buffer holds the raw response headers in memory.
    // 16 KB is plenty for any HTTP response header we'll encounter.
    var server_header_buffer: [16 * 1024]u8 = undefined;

    var request = try client.open(.POST, uri, .{
        .server_header_buffer = &server_header_buffer,
        .extra_headers = extra_headers.items,
    });
    defer request.deinit();

    request.transfer_encoding = .{ .content_length = body.len };
    try request.send();
    try request.writeAll(body);
    try request.finish();
    try request.wait();

    if (request.response.status.class() != .success) {
        std.log.err("HTTP POST stream {s} returned status {d}", .{
            url,
            @intFromEnum(request.response.status),
        });
        return error.HttpError;
    }

    // Read the body in 8 KB increments and forward each chunk to the callback.
    // Stack allocation keeps us off the heap for the hot path.
    var buf: [8 * 1024]u8 = undefined;
    while (true) {
        const n = try request.reader().read(&buf);
        if (n == 0) break;
        callback(buf[0..n], ctx);
    }
}
