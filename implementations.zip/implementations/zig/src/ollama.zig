/// ollama.zig — The oracle who turns words into numbers and numbers into words.
///
/// Two distinct capabilities live here:
///
/// 1. `embed`: Send a string, receive a 768-dimensional float vector.
///    That vector is the mathematical "meaning" of the text, ready to be
///    stored in the vector database and compared against query vectors.
///
/// 2. `chatStream`: Send a conversation history, receive the model's reply
///    token by token via newline-delimited JSON (NDJSON).  Each line is
///    delivered to the caller's callback immediately — no buffering the full
///    response — so the terminal shows text as it's generated.
///
/// Design decisions:
///
/// 1. We parse Ollama's NDJSON by hand rather than using a streaming JSON
///    library.  Each line is a self-contained JSON object, so we accumulate
///    bytes into a line buffer and call `std.json.parseFromSlice` per line.
///    This is simple, zero-dependency, and perfectly fast for our use case.
///
/// 2. `embed` returns a heap-allocated `[]f64`.  The caller frees it.
///    We choose f64 over f32 to match Zig's default float semantics and avoid
///    silent truncation bugs; Ollama returns JSON numbers at full precision.

const std = @import("std");
const http = @import("http");
const config = @import("config");

/// OllamaClient holds the base URL and model names needed to call Ollama.
/// It is a simple value type — no heap allocations in the struct itself.
pub const OllamaClient = struct {
    base_url: []const u8,
    chat_model: []const u8,
    embedding_model: []const u8,

    /// Construct a client from a Config.
    /// The client borrows config's string slices; Config must outlive the client.
    pub fn init(cfg: config.Config) OllamaClient {
        return OllamaClient{
            .base_url = cfg.ollama_url,
            .chat_model = cfg.chat_model,
            .embedding_model = cfg.embedding_model,
        };
    }

    /// Convert `text` into an embedding vector using the configured model.
    ///
    /// Ollama's `/api/embeddings` endpoint accepts `{"model":"…","prompt":"…"}`
    /// and returns `{"embedding":[…]}`.  We extract the float array and return it.
    ///
    /// The caller owns the returned slice and must free it with `allocator.free`.
    pub fn embed(
        self: OllamaClient,
        allocator: std.mem.Allocator,
        text: []const u8,
    ) ![]f64 {
        const url = try std.fmt.allocPrint(allocator, "{s}/api/embeddings", .{self.base_url});
        defer allocator.free(url);

        // Build the request body.  We JSON-encode the text to handle quotes and
        // special characters in document content without a dedicated JSON builder.
        const body = try buildEmbedBody(allocator, self.embedding_model, text);
        defer allocator.free(body);

        const resp_bytes = try http.post(allocator, url, &[_]http.Header{}, body);
        defer allocator.free(resp_bytes);

        return parseEmbedResponse(allocator, resp_bytes);
    }

    /// Stream a chat completion, calling `onChunk` for every token received.
    ///
    /// `messages` is a JSON array string of `{"role":"…","content":"…"}` objects,
    /// exactly as Ollama expects.  Build it with `buildMessages` below.
    ///
    /// Ollama sends one JSON object per newline while `stream: true`:
    ///   {"model":"gemma3:1b","message":{"role":"assistant","content":"Hi"},"done":false}
    ///
    /// We accumulate bytes into a line buffer across multiple stream chunks,
    /// parse each complete line, extract `message.content`, and forward it to
    /// `onChunk`.  When `done` is true we stop reading.
    ///
    /// `ctx` is forwarded unchanged to `onChunk` — use it to pass a writer or
    /// any mutable state the callback needs.
    pub fn chatStream(
        self: OllamaClient,
        allocator: std.mem.Allocator,
        messages_json: []const u8,
        onChunk: *const fn (token: []const u8, ctx: ?*anyopaque) void,
        ctx: ?*anyopaque,
    ) !void {
        const url = try std.fmt.allocPrint(allocator, "{s}/api/chat", .{self.base_url});
        defer allocator.free(url);

        const body = try buildChatBody(allocator, self.chat_model, messages_json);
        defer allocator.free(body);

        // We bridge between `http.postStream`'s `[]const u8` chunk callback
        // and our line-accumulating logic by using a StreamState struct passed
        // through the opaque ctx pointer.
        var state = StreamState{
            .allocator = allocator,
            .line_buf = std.ArrayList(u8).init(allocator),
            .on_chunk = onChunk,
            .user_ctx = ctx,
            .done = false,
            .err = null,
        };
        defer state.line_buf.deinit();

        try http.postStream(
            allocator,
            url,
            &[_]http.Header{},
            body,
            streamChunkCallback,
            &state,
        );

        if (state.err) |e| return e;
    }
};

// ─── Internal helpers ─────────────────────────────────────────────────────────

/// State threaded through the stream callback via the opaque ctx pointer.
const StreamState = struct {
    allocator: std.mem.Allocator,
    line_buf: std.ArrayList(u8),
    on_chunk: *const fn (token: []const u8, ctx: ?*anyopaque) void,
    user_ctx: ?*anyopaque,
    done: bool,
    err: ?anyerror,
};

/// The raw chunk callback handed to `http.postStream`.
/// It accumulates bytes into a line buffer and processes complete lines.
fn streamChunkCallback(chunk: []const u8, raw_ctx: ?*anyopaque) void {
    const state: *StreamState = @ptrCast(@alignCast(raw_ctx.?));
    if (state.done) return;

    for (chunk) |byte| {
        if (byte == '\n') {
            processLine(state);
            state.line_buf.clearRetainingCapacity();
        } else {
            state.line_buf.append(byte) catch |e| {
                state.err = e;
                return;
            };
        }
    }
}

/// Parse one NDJSON line from the Ollama stream.
/// Extracts `message.content` and forwards non-empty tokens to the callback.
fn processLine(state: *StreamState) void {
    const line = std.mem.trim(u8, state.line_buf.items, " \r\t");
    if (line.len == 0) return;

    const parsed = std.json.parseFromSlice(
        std.json.Value,
        state.allocator,
        line,
        .{ .duplicate_field_behavior = .use_last },
    ) catch return; // Skip malformed lines silently — Ollama can send status messages.
    defer parsed.deinit();

    // Extract message.content if present.
    if (parsed.value.object.get("message")) |msg| {
        if (msg.object.get("content")) |content| {
            switch (content) {
                .string => |s| {
                    if (s.len > 0) {
                        state.on_chunk(s, state.user_ctx);
                    }
                },
                else => {},
            }
        }
    }

    // Check the done flag.
    if (parsed.value.object.get("done")) |done_val| {
        switch (done_val) {
            .bool => |b| { if (b) state.done = true; },
            else => {},
        }
    }
}

/// Build the JSON body for /api/embeddings.
fn buildEmbedBody(allocator: std.mem.Allocator, model: []const u8, text: []const u8) ![]u8 {
    // JSON-encode the model and prompt strings to handle special characters.
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("{\"model\":\"");
    try appendJsonEscaped(&buf, model);
    try buf.appendSlice("\",\"prompt\":\"");
    try appendJsonEscaped(&buf, text);
    try buf.appendSlice("\"}");

    return buf.toOwnedSlice();
}

/// Build the JSON body for /api/chat.
fn buildChatBody(allocator: std.mem.Allocator, model: []const u8, messages_json: []const u8) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("{\"model\":\"");
    try appendJsonEscaped(&buf, model);
    try buf.appendSlice("\",\"messages\":");
    try buf.appendSlice(messages_json);
    try buf.appendSlice(",\"stream\":true}");

    return buf.toOwnedSlice();
}

/// Append `s` to `buf` with JSON string escaping (quotes and backslashes).
fn appendJsonEscaped(buf: *std.ArrayList(u8), s: []const u8) !void {
    for (s) |c| {
        switch (c) {
            '"' => try buf.appendSlice("\\\""),
            '\\' => try buf.appendSlice("\\\\"),
            '\n' => try buf.appendSlice("\\n"),
            '\r' => try buf.appendSlice("\\r"),
            '\t' => try buf.appendSlice("\\t"),
            else => try buf.append(c),
        }
    }
}

/// Parse the `/api/embeddings` response and extract the float array.
fn parseEmbedResponse(allocator: std.mem.Allocator, resp_bytes: []const u8) ![]f64 {
    const parsed = try std.json.parseFromSlice(
        std.json.Value,
        allocator,
        resp_bytes,
        .{ .duplicate_field_behavior = .use_last },
    );
    defer parsed.deinit();

    const embedding_val = parsed.value.object.get("embedding") orelse {
        std.log.err("Ollama embed response missing 'embedding' field", .{});
        return error.OllamaMissingEmbedding;
    };

    const arr = embedding_val.array.items;
    const result = try allocator.alloc(f64, arr.len);

    for (arr, 0..) |item, i| {
        result[i] = switch (item) {
            .float => |f| f,
            .integer => |n| @floatFromInt(n),
            else => 0.0,
        };
    }

    return result;
}

// ─── Message builder helpers ──────────────────────────────────────────────────

/// A single chat message.
pub const Message = struct {
    role: []const u8,
    content: []const u8,
};

/// Serialise a slice of Messages into a JSON array string.
/// Returns a heap-allocated string the caller must free.
///
/// Example output: `[{"role":"user","content":"Hello"}]`
pub fn buildMessages(allocator: std.mem.Allocator, messages: []const Message) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("[");
    for (messages, 0..) |msg, i| {
        if (i > 0) try buf.appendSlice(",");
        try buf.appendSlice("{\"role\":\"");
        try appendJsonEscaped(&buf, msg.role);
        try buf.appendSlice("\",\"content\":\"");
        try appendJsonEscaped(&buf, msg.content);
        try buf.appendSlice("\"}");
    }
    try buf.appendSlice("]");

    return buf.toOwnedSlice();
}
