/// chatbot.zig — The conversational face of the RAG system.
///
/// Where `rag` answers single questions, `chatbot` holds a multi-turn dialogue.
/// It maintains a history of messages and sends the full conversation to the
/// LLM on every turn, so the model can refer back to what was said earlier.
///
/// Interaction loop:
///   1. Read a line from stdin.
///   2. Embed the line and retrieve the top-K most similar chunks from Turso.
///   3. Inject the retrieved context as a system message.
///   4. Append the user's question to the history.
///   5. Stream the LLM's response token-by-token to stdout.
///   6. Append the full response to history and go back to step 1.
///
/// Type "exit" or "quit" to end the session.
///
/// Design note on history management:
///   We keep the full message history in an ArrayList of Message structs.
///   Each turn we rebuild the messages_json from scratch — O(n) in the number
///   of turns, but fine for the conversation lengths a local chatbot handles.
///   For very long sessions the context window would overflow anyway.

const std = @import("std");
const config_mod = @import("config");
const turso = @import("turso");
const ollama_mod = @import("ollama");

/// Entry point for the `chatbot` binary.
pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();

    const stdout = std.io.getStdOut().writer();
    const stdin = std.io.getStdIn().reader();

    const cfg = config_mod.Config.default();
    const db = turso.TursoClient.init(allocator, cfg);
    const ai = ollama_mod.OllamaClient.init(cfg);

    try stdout.print("RAG Chatbot (Zig)\n", .{});
    try stdout.print("Model: {s}   Embeddings: {s}\n", .{ cfg.chat_model, cfg.embedding_model });
    try stdout.print("Type your question and press Enter.  Type 'exit' to quit.\n\n", .{});

    // Conversation history — grows with each turn.
    var history = std.ArrayList(ollama_mod.Message).init(allocator);
    defer {
        for (history.items) |msg| {
            allocator.free(msg.content);
        }
        history.deinit();
    }

    // Accumulated response from the current LLM turn.
    var response_buf = std.ArrayList(u8).init(allocator);
    defer response_buf.deinit();

    // ── Main interaction loop ─────────────────────────────────────────────────

    while (true) {
        try stdout.print("You: ", .{});

        // Read a line from stdin, allocating just enough memory for it.
        const raw_line = stdin.readUntilDelimiterAlloc(allocator, '\n', 4096) catch |err| {
            if (err == error.EndOfStream) break;
            return err;
        };
        defer allocator.free(raw_line);

        const line = std.mem.trim(u8, raw_line, " \r\t\n");
        if (line.len == 0) continue;

        // Allow the user to exit gracefully.
        if (std.mem.eql(u8, line, "exit") or std.mem.eql(u8, line, "quit")) {
            try stdout.print("Goodbye!\n", .{});
            break;
        }

        // ── Embed the user's message ───────────────────────────────────────

        const embedding = ai.embed(allocator, line) catch |err| {
            try stdout.print("[Error embedding: {}]\n\n", .{err});
            continue;
        };
        defer allocator.free(embedding);

        // ── Retrieve relevant context ──────────────────────────────────────

        var arena = std.heap.ArenaAllocator.init(allocator);
        defer arena.deinit();

        const vec_str = try encodeVector(arena.allocator(), embedding);
        const search_params = try buildSearchParams(arena.allocator(), vec_str, @intCast(cfg.top_k));

        const search_sql =
            \\SELECT content
            \\FROM chunks
            \\ORDER BY vector_distance_cos(embedding, ?) ASC
            \\LIMIT ?
        ;

        const rows = db.fetchAll(arena.allocator(), search_sql, search_params) catch |err| {
            try stdout.print("[Search error: {}]\n\n", .{err});
            continue;
        };

        // Build a context block from the retrieved chunks.
        var context_buf = std.ArrayList(u8).init(arena.allocator());
        for (rows, 0..) |row, i| {
            if (i > 0) try context_buf.appendSlice("\n---\n");
            if (row.get("content")) |content| {
                try context_buf.appendSlice(content);
            }
        }

        // ── Build the message list ─────────────────────────────────────────
        //
        // The system prompt is regenerated each turn to include fresh context.
        // This is intentional: the retrieved context changes based on what the
        // user just asked, so stale context from a previous turn is replaced.

        var messages = std.ArrayList(ollama_mod.Message).init(arena.allocator());

        const system_content = try std.fmt.allocPrint(
            arena.allocator(),
            "You are a helpful assistant.  Use the following context to answer the user's questions.\n" ++
                "If the context does not contain the answer, say so.\n\nContext:\n{s}",
            .{context_buf.items},
        );

        try messages.append(.{ .role = "system", .content = system_content });

        // Append the existing conversation history.
        for (history.items) |msg| {
            try messages.append(msg);
        }

        // Append the new user message.
        try messages.append(.{ .role = "user", .content = line });

        const messages_json = try ollama_mod.buildMessages(arena.allocator(), messages.items);

        // ── Stream the LLM's response ──────────────────────────────────────

        try stdout.print("\nAssistant: ", .{});

        response_buf.clearRetainingCapacity();

        var stream_ctx = StreamCtx{
            .writer = stdout,
            .buf = &response_buf,
        };

        ai.chatStream(allocator, messages_json, streamCallback, &stream_ctx) catch |err| {
            try stdout.print("[Stream error: {}]", .{err});
        };

        try stdout.print("\n\n", .{});

        // ── Save the turn to history ───────────────────────────────────────

        // User message — dupe because `line` (raw_line) is freed at loop end.
        const user_msg_content = try allocator.dupe(u8, line);
        try history.append(.{ .role = "user", .content = user_msg_content });

        // Assistant message — dupe the response buffer.
        const assistant_content = try allocator.dupe(u8, response_buf.items);
        try history.append(.{ .role = "assistant", .content = assistant_content });
    }
}

/// Context shared between the main loop and the stream callback.
const StreamCtx = struct {
    writer: std.fs.File.Writer,
    buf: *std.ArrayList(u8),
};

/// Stream callback: print each token immediately and accumulate for history.
fn streamCallback(token: []const u8, ctx: ?*anyopaque) void {
    const sc: *StreamCtx = @ptrCast(@alignCast(ctx.?));
    sc.writer.writeAll(token) catch {};
    sc.buf.appendSlice(token) catch {};
}

/// Encode a float slice as a JSON array string for Turso's vector functions.
fn encodeVector(allocator: std.mem.Allocator, v: []const f64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();
    try buf.appendSlice("[");
    for (v, 0..) |f, i| {
        if (i > 0) try buf.appendSlice(",");
        try std.fmt.format(buf.writer(), "{d}", .{f});
    }
    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}

/// Build a Turso params array for the similarity search.
fn buildSearchParams(allocator: std.mem.Allocator, vec_str: []const u8, top_k: i64) ![]u8 {
    var buf = std.ArrayList(u8).init(allocator);
    defer buf.deinit();

    try buf.appendSlice("[");

    try buf.appendSlice("{\"type\":\"text\",\"value\":\"");
    for (vec_str) |c| {
        switch (c) {
            '"' => try buf.appendSlice("\\\""),
            '\\' => try buf.appendSlice("\\\\"),
            else => try buf.append(c),
        }
    }
    try buf.appendSlice("\"},");

    try std.fmt.format(buf.writer(), "{{\"type\":\"integer\",\"value\":\"{d}\"}}", .{top_k});

    try buf.appendSlice("]");
    return buf.toOwnedSlice();
}
