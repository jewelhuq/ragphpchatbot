"""
rag.py — Where retrieval meets generation.

This module is the bridge between the vector database and the language model.
Its job is simple but critical: take a user's question, find the most relevant
chunks of source material, build a carefully structured prompt that tells the
model what it is allowed to say and what it must not invent, then stream the
answer back to the caller.

The system prompt design follows a few deliberate anti-hallucination rules:

  1. Explicit grounding. The model is told in plain language that it must only
     use the provided context and must never draw on its training knowledge
     for factual claims.

  2. Numbered sources. Each context chunk is presented as [1], [2], etc.
     The model is instructed to cite sources by number, which forces it to
     trace each claim back to a specific retrieved chunk.

  3. Honest ignorance. If the retrieved chunks do not contain enough
     information to answer the question, the model is told to say so.
     "I don't know based on the provided documents" is a correct answer;
     a confident hallucination is not.

  4. Short, direct answers. The model is nudged toward concise responses
     rather than padded prose, which suits the limited context window of
     small local models like gemma3:1b.
"""

import sys
from typing import Callable, Optional

from config import load_config, Config
from turso import TursoClient
from ollama import OllamaClient
from query import vector_search


SYSTEM_PROMPT_TEMPLATE = """You are a helpful research assistant with access to a curated document collection.

INSTRUCTIONS:
1. Answer the user's question using ONLY the information in the numbered context chunks below.
2. Do NOT use your training knowledge for any factual claims — only use what is in the context.
3. Cite the source number(s) after each factual statement, e.g. "The sky is blue [1]."
4. If the context does not contain enough information to answer the question, say:
   "I don't have enough information in the provided documents to answer that."
5. Keep your answer concise and direct. Avoid padding or repetition.
6. If multiple chunks support the same point, cite all relevant ones.

CONTEXT:
{context_block}

Remember: only use information from the context above. Do not invent facts."""


def build_context_block(chunks: list[dict]) -> str:
    """
    Format the retrieved chunks into the numbered context block that is
    injected into the system prompt.

    Each chunk is preceded by its citation number [N], followed by its
    source filename for traceability. The content itself follows, separated
    by a horizontal rule so the model can clearly see where one chunk ends
    and the next begins.

    Parameters
    ----------
    chunks : list[dict]
        The ranked retrieval results from vector_search(), each containing
        at least "content" and "source" keys.

    Returns
    -------
    str
        A formatted multi-line string ready to drop into the system prompt.
    """
    import os
    parts = []
    for i, chunk in enumerate(chunks, 1):
        source_display = os.path.basename(chunk.get("source") or "unknown")
        content = chunk.get("content") or "(empty chunk)"
        part = f"[{i}] Source: {source_display}\n{content}"
        parts.append(part)
    return "\n\n---\n\n".join(parts)


def answer(
    question: str,
    db: TursoClient,
    ollama: OllamaClient,
    cfg: Config,
    conversation_history: Optional[list[dict]] = None,
    on_chunk: Optional[Callable[[str], None]] = None,
) -> str:
    """
    The full RAG pipeline: retrieve, prompt, generate, stream.

    This function orchestrates the three-phase RAG cycle:
      Phase 1 — Retrieve: embed the question, search the vector index,
                get the top_k most relevant chunks.
      Phase 2 — Augment: build a system prompt that injects the retrieved
                chunks as numbered sources, with anti-hallucination rules.
      Phase 3 — Generate: send the augmented prompt + conversation history
                to the LLM and stream the response token-by-token.

    Parameters
    ----------
    question : str
        The user's natural language question.
    db : TursoClient
        Authenticated Turso client for vector search.
    ollama : OllamaClient
        Connected Ollama client for embedding and generation.
    cfg : Config
        Runtime configuration (top_k, model names, etc.).
    conversation_history : list[dict], optional
        Prior turns in the conversation, in OpenAI-compatible format.
        If None, the question is treated as a fresh, stateless query.
    on_chunk : callable, optional
        Called with each generated token string as it arrives.
        If None, tokens are printed to stdout directly.

    Returns
    -------
    str
        The full generated response text (useful for appending to history).
    """
    # Phase 1: Retrieve the most relevant chunks
    chunks = vector_search(
        query=question,
        db=db,
        ollama=ollama,
        top_k=cfg.top_k,
    )

    if not chunks:
        no_context_msg = (
            "I don't have enough information in the provided documents to answer that. "
            "Please run ingest.py to populate the knowledge base."
        )
        if on_chunk:
            on_chunk(no_context_msg)
        else:
            print(no_context_msg)
        return no_context_msg

    # Phase 2: Augment — build the system prompt with retrieved context
    context_block = build_context_block(chunks)
    system_prompt = SYSTEM_PROMPT_TEMPLATE.format(context_block=context_block)

    # Build the message list for the LLM
    # We include conversation history so the model remembers the thread,
    # then append the current question as a new user turn.
    messages = list(conversation_history or [])
    messages.append({"role": "user", "content": question})

    # Phase 3: Generate — stream the response
    # If no callback is provided, print tokens to stdout in real time.
    if on_chunk is None:
        def on_chunk(token: str) -> None:
            print(token, end="", flush=True)

    response = ollama.chat_stream(
        messages=messages,
        on_chunk=on_chunk,
        system=system_prompt,
    )

    return response


def main() -> None:
    """
    CLI entry point for one-shot RAG queries (no conversation history).

    Usage:
        python rag.py "What does the document say about X?"

    Prints retrieved chunk sources first (for transparency), then streams
    the generated answer.
    """
    if len(sys.argv) < 2:
        print("Usage: python rag.py <question>")
        sys.exit(1)

    question = " ".join(sys.argv[1:])

    cfg = load_config()
    db = TursoClient(cfg.turso_url, cfg.turso_token)
    ollama = OllamaClient(
        url=cfg.ollama_url,
        embedding_model=cfg.embedding_model,
        chat_model=cfg.chat_model,
    )

    if not ollama.is_available():
        print(
            f"[error] Ollama is not reachable at {cfg.ollama_url}.\n"
            "Please start it with:  ollama serve"
        )
        sys.exit(1)

    print(f"\nQuestion: {question}")
    print("-" * 60)
    print("Retrieving relevant context ...")

    # Peek at the retrieved chunks for transparency
    chunks = vector_search(question, db, ollama, top_k=cfg.top_k)
    if chunks:
        import os
        print(f"Using {len(chunks)} context chunk(s):")
        for i, c in enumerate(chunks, 1):
            src = os.path.basename(c.get("source") or "unknown")
            print(f"  [{i}] {src}  (score: {c['score']:.3f})")
    print()
    print("Answer:")
    print("-" * 60)

    response = answer(
        question=question,
        db=db,
        ollama=ollama,
        cfg=cfg,
    )

    print("\n" + "-" * 60)


if __name__ == "__main__":
    main()
