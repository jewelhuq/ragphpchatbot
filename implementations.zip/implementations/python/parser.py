"""
parser.py — Reading documents regardless of their file format.

The RAG pipeline needs to ingest text from whatever formats users drop
into the docs/ directory. This module handles the three most common ones:

  - .txt  — trivial: open and read
  - .pdf  — requires PyPDF2; gracefully falls back to raw binary read if
            the library is missing (the fallback rarely produces useful text,
            but it prevents the ingestor from crashing on an unmapped format)
  - .docx — requires python-docx; same graceful fallback strategy

The graceful fallback philosophy is deliberate: a RAG system that crashes
on an unsupported file format is far less useful than one that skips the
unreadable parts and keeps going. Users can always install the optional
dependency later and re-run ingest.py.

All parse() calls return a single str containing the extracted text with
normalised line endings. Callers do not need to know which format they got.
"""

import os
from typing import Optional


class DocumentParser:
    """
    Extracts plain text from .txt, .pdf, and .docx files.

    Why a class instead of a module-level function?
    Mostly for extensibility: if you later want to add caching, a logger,
    or per-instance format overrides, a class is much easier to extend than
    a standalone function.

    The class itself holds no state — every call to parse() is independent.
    """

    def parse(self, file_path: str) -> str:
        """
        Extract all readable text from a file.

        Dispatch is purely by file extension (case-insensitive). Unknown
        extensions fall through to a plain text attempt, which works for
        Markdown, reStructuredText, CSV headers, and many other UTF-8 files.

        Parameters
        ----------
        file_path : str
            Absolute or relative path to the document.

        Returns
        -------
        str
            The extracted text. May be empty if the file is unreadable or
            truly contains no text (e.g. a scanned PDF without OCR).

        Raises
        ------
        FileNotFoundError
            If the path does not exist.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Document not found: {file_path}")

        ext = os.path.splitext(file_path)[1].lower()

        if ext == ".pdf":
            return self._parse_pdf(file_path)
        elif ext == ".docx":
            return self._parse_docx(file_path)
        else:
            # Default: read as UTF-8 text. Covers .txt, .md, .rst, .csv, etc.
            return self._parse_text(file_path)

    # ------------------------------------------------------------------
    # Format-specific parsers
    # ------------------------------------------------------------------

    def _parse_text(self, file_path: str) -> str:
        """
        Read a plain text file and return its contents.

        We try UTF-8 first (the universal encoding), then fall back to
        latin-1 which can decode any single-byte value without throwing
        an error. This means we might see garbled characters for files
        in other encodings, but we will never crash.

        Parameters
        ----------
        file_path : str
            Path to the text file.

        Returns
        -------
        str
            The file contents as a Python str.
        """
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except UnicodeDecodeError:
            with open(file_path, "r", encoding="latin-1") as f:
                return f.read()

    def _parse_pdf(self, file_path: str) -> str:
        """
        Extract text from a PDF using PyPDF2.

        PyPDF2 reads the underlying text objects in the PDF page tree. This
        works well for PDFs that were generated from word processors or LaTeX.
        It does NOT perform OCR, so scanned documents will yield empty or
        garbled text.

        If PyPDF2 is not installed, we fall back to reading the raw bytes
        and decoding them with errors='replace'. This occasionally extracts
        fragments of readable text from the PDF stream, which is better than
        nothing for very simple documents.

        Parameters
        ----------
        file_path : str
            Path to the .pdf file.

        Returns
        -------
        str
            Concatenated text from all pages, separated by double newlines.
        """
        try:
            import PyPDF2  # type: ignore

            pages = []
            with open(file_path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page_num, page in enumerate(reader.pages):
                    try:
                        page_text = page.extract_text()
                        if page_text:
                            pages.append(page_text.strip())
                    except Exception as page_err:
                        # A corrupt page should not abort the whole document
                        print(
                            f"  [warn] Skipping page {page_num + 1} of {file_path}: {page_err}"
                        )
                        continue
            return "\n\n".join(pages)

        except ImportError:
            # PyPDF2 is listed in requirements.txt but marked optional.
            # Give a friendly nudge and attempt a raw fallback.
            print(
                f"  [warn] PyPDF2 not installed. "
                f"Install it with: pip install PyPDF2\n"
                f"  Attempting raw byte extraction for {file_path} ..."
            )
            return self._raw_fallback(file_path)

        except Exception as e:
            print(f"  [warn] PDF parse failed for {file_path}: {e}")
            return self._raw_fallback(file_path)

    def _parse_docx(self, file_path: str) -> str:
        """
        Extract text from a Word .docx file using python-docx.

        python-docx reads the XML inside the .docx ZIP archive and exposes
        each paragraph as a Python object. We join all non-empty paragraphs
        with double newlines to preserve the original document structure,
        which the Chunker downstream expects.

        Tables in the document are also extracted: we iterate each row and
        join cell text with tab characters, then separate rows with newlines.
        This gives the LLM a reasonable representation of tabular data.

        Parameters
        ----------
        file_path : str
            Path to the .docx file.

        Returns
        -------
        str
            All paragraph and table text joined into a single string.
        """
        try:
            import docx  # type: ignore  (python-docx installs as 'docx')

            doc = docx.Document(file_path)
            parts = []

            # Extract paragraphs (includes headings, body text, list items)
            for para in doc.paragraphs:
                text = para.text.strip()
                if text:
                    parts.append(text)

            # Extract tables — often contain important structured data
            for table in doc.tables:
                table_rows = []
                for row in table.rows:
                    cells = [cell.text.strip() for cell in row.cells]
                    table_rows.append("\t".join(cells))
                if table_rows:
                    parts.append("\n".join(table_rows))

            return "\n\n".join(parts)

        except ImportError:
            print(
                f"  [warn] python-docx not installed. "
                f"Install it with: pip install python-docx\n"
                f"  Attempting raw byte extraction for {file_path} ..."
            )
            return self._raw_fallback(file_path)

        except Exception as e:
            print(f"  [warn] DOCX parse failed for {file_path}: {e}")
            return self._raw_fallback(file_path)

    def _raw_fallback(self, file_path: str) -> str:
        """
        Last-resort text extraction: read raw bytes and strip non-printable
        characters.

        This produces noisy output for binary formats, but occasionally
        rescues meaningful text from PDF streams or other structured formats
        when the proper library is unavailable. It is far better to surface
        something than to silently ingest nothing.

        Parameters
        ----------
        file_path : str
            Path to the file.

        Returns
        -------
        str
            Best-effort decoded text, or an empty string on failure.
        """
        try:
            with open(file_path, "rb") as f:
                raw = f.read()
            # Decode as latin-1 (every byte is valid) then strip control chars
            text = raw.decode("latin-1", errors="replace")
            # Keep printable ASCII + common whitespace
            cleaned = "".join(
                c if (c.isprintable() or c in "\n\r\t") else " "
                for c in text
            )
            return cleaned
        except Exception as e:
            print(f"  [error] Raw fallback failed for {file_path}: {e}")
            return ""
