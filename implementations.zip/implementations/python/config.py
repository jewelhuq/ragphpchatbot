﻿"""
config.py — The single source of truth for the entire RAG system.

Every knob worth turning lives here. Rather than scattering magic strings
and hard-coded numbers across the codebase, we gather them all in one
dataclass so that changing the Turso endpoint or the chunk size is a
one-line edit, not an archaeological dig through ten files.

The load_config() factory intentionally returns hard-coded defaults so
the system works out-of-the-box without environment variables or config
files, while still being easy to override programmatically.
"""

from dataclasses import dataclass


@dataclass
class Config:
    """
    A blueprint for every runtime decision the RAG pipeline will make.

    Fields are grouped by concern:
      - Turso (database) settings
      - Ollama (LLM/embeddings) settings
      - Retrieval tuning knobs
      - Filesystem paths
      - Text processing parameters

    Why a dataclass? Because we get free __repr__, equality checks, and
    IDE auto-complete without writing boilerplate constructors. It also
    signals to readers that this object is plain data, not behaviour.
    """

    # --- Turso (libSQL / SQLite over HTTP) ---
    turso_url: str = "https://your-db-name.turso.io"
    """The HTTPS base URL of the Turso database instance."""

    turso_token: str = ""
    """Bearer token used for Turso authentication. Never commit real tokens."""

    # --- Ollama (local LLM server) ---
    ollama_url: str = "http://127.0.0.1:11434"
    """Where the Ollama daemon is listening."""

    chat_model: str = "gemma3:1b"
    """The chat/completion model pulled into Ollama. Kept small for speed."""

    embedding_model: str = "nomic-embed-text"
    """The embedding model. nomic-embed-text produces 768-dimensional vectors."""

    embedding_dims: int = 768
    """
    Must match what the embedding model actually produces.
    Turso's vector index is created with this dimensionality at schema time,
    so changing it later requires dropping and recreating the table.
    """

    # --- Retrieval ---
    top_k: int = 5
    """How many chunks to pull back from the vector search during retrieval.
    Higher values give the LLM more context but increase prompt length and cost."""

    # --- Filesystem ---
    docs_dir: str = "docs"
    """
    Directory that ingest.py scans for source documents.
    Relative paths are resolved from wherever ingest.py is invoked.
    """

    # --- Text processing ---
    chunk_size: int = 512
    """
    Soft upper-bound (in characters) for each text chunk.
    Smaller chunks are more precise during retrieval but lose surrounding
    context; larger chunks preserve context but dilute the relevance signal.
    512 characters is a practical sweet spot for short-context local models.
    """


def load_config() -> Config:
    """
    The designated entry-point for obtaining a Config instance.

    Called by every other module so that configuration is never imported
    directly as a module-level constant (which would make testing harder).
    If you later want to read from environment variables or a TOML file,
    this is the one function you need to change.

    Returns
    -------
    Config
        A Config dataclass populated with production-ready defaults.
    """
    return Config(
        turso_url="https://your-db-name.turso.io",
        turso_token="YOUR_TURSO_TOKEN_HERE",  # Replace before running
        ollama_url="http://127.0.0.1:11434",
        chat_model="gemma3:1b",
        embedding_model="nomic-embed-text",
        embedding_dims=768,
        top_k=5,
        docs_dir="docs",
        chunk_size=512,
    )
