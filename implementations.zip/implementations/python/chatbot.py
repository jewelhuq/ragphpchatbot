"""
chatbot.py — The conversational front-end of the RAG system.

This is what users actually interact with. It wraps the RAG pipeline in an
interactive read-eval-print loop (REPL) that feels like chatting with a
knowledgeable colleague who has read all the documents in your docs/ folder.

A few design choices that shape the user experience:

  1. Streaming output. The model's answer appears word by word as it is
     generated, rather than all at once after a long pause. On a local CPU
     running a 1B-parameter model, this makes the system feel responsive
     even when generation takes 10-30 seconds.

  2. Conversation memory. The last 10 turns of the conversation are included
     in every request. This means follow-up questions like "tell me more"
     or "what about the second point?" work correctly — the model remembers
     what it just said.

  3. Per-turn retrieval. We embed and search the knowledge base for every
     user turn, not just the first one. This means a question that pivots
     to a new topic gets fresh context from the vector index, rather than
     being stuck with context from the first question.

  4. Graceful exits. Typing "exit", "quit", or pressing Ctrl-C cleanly
     ends the session without a Python traceback.

  5. Source transparency. Before streaming the answer, the chatbot lists
     which document chunks it is drawing from. Users can immediately see
     if the retrieval found relevant material.

Usage:
    python chatbot.py
"""

import os
import sys

from config import load_config
from turso import TursoClient
from ollama import OllamaClient
from rag import answer
from query import vector_search


# Maximum number of conversation turns (user + assistant pairs) to retain.
# Higher values give the model more history but inflate the prompt length,
# which slows down generation on small local models.
MAX_HISTORY_TURNS = 10


def print_banner() -> None:
    """
    Print a welcome banner that orients the user to the system's capabilities
    and reminds them how to exit.

    The banner is purely cosmetic but significantly improves first-run UX —
    new users immediately understand what they can do and how to stop.
    """
    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║              Python RAG Chatbot                         ║")
    print("║  Powered by Turso (vector search) + Ollama (local LLM) ║")
    print("╠══════════════════════════════════════════════════════════╣")
    print("║  Type your question and press Enter.                    ║")
    print("║  Type 'exit' or 'quit' to end the session.             ║")
    print("║  Type 'clear' to reset conversation history.           ║")
    print("║  Type 'sources' to see the last retrieved chunks.      ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print()


def format_source_list(chunks: list[dict]) -> str:
    """
    Format the retrieved context chunks into a concise source list for
    display above the streamed answer.

    Showing sources before the answer serves two purposes:
      a. Users can immediately judge whether retrieval found relevant material.
      b. If the answer looks wrong, users know which documents to check.

    Parameters
    ----------
    chunks : list[dict]
        The ranked retrieval results from vector_search().

    Returns
    -------
    str
        A multi-line string listing each source with its similarity score.
    """
    if not chunks:
        return "  (no relevant context found)"

    lines = []
    for i, chunk in enumerate(chunks, 1):
        source = os.path.basename(chunk.get("source") or "unknown")
        score = chunk.get("score", 0.0)
        lines.append(f"  [{i}] {source}  (relevance: {score:.2%})")
    return "\n".join(lines)


def trim_history(history: list[dict], max_turns: int) -> list[dict]:
    """
    Keep only the most recent conversation turns to limit prompt size.

    Each "turn" is a user message + assistant response pair, so we keep
    at most max_turns * 2 individual messages. We always discard from the
    oldest end of the list.

    Parameters
    ----------
    history : list[dict]
        Full conversation history in OpenAI message format.
    max_turns : int
        Maximum number of user-assistant pairs to retain.

    Returns
    -------
    list[dict]
        Trimmed history (may be the same list if already within limits).
    """
    max_messages = max_turns * 2
    if len(history) > max_messages:
        return history[-max_messages:]
    return history


def main() -> None:
    """
    Run the interactive chatbot loop.

    Lifecycle:
      1. Load config and initialise clients.
      2. Verify Ollama is reachable (fail fast with a friendly message).
      3. Print the welcome banner.
      4. Loop forever:
           a. Read user input.
           b. Handle special commands (exit, clear, sources).
           c. Retrieve relevant chunks from Turso.
           d. Stream the RAG-grounded answer.
           e. Append turn to conversation history.
           f. Trim history to MAX_HISTORY_TURNS.
    """
    cfg = load_config()

    # Initialise the database and LLM clients
    db = TursoClient(cfg.turso_url, cfg.turso_token)
    ollama = OllamaClient(
        url=cfg.ollama_url,
        embedding_model=cfg.embedding_model,
        chat_model=cfg.chat_model,
    )

    # Fail fast: if Ollama isn't running, tell the user clearly
    print("Checking Ollama availability ...")
    if not ollama.is_available():
        print(
            f"\n[error] Ollama is not reachable at {cfg.ollama_url}.\n"
            "Please start it with:  ollama serve\n"
            "And ensure the models are pulled:\n"
            f"  ollama pull {cfg.embedding_model}\n"
            f"  ollama pull {cfg.chat_model}"
        )
        sys.exit(1)

    print(f"Ollama ready.  Embedding: {cfg.embedding_model}  |  Chat: {cfg.chat_model}")
    print(f"Database: {cfg.turso_url}")

    print_banner()

    # Conversation history: a list of {"role": ..., "content": ...} dicts
    history: list[dict] = []
    # Remember the last retrieved chunks for the 'sources' command
    last_chunks: list[dict] = []

    while True:
        try:
            # Read user input — strip whitespace to avoid empty queries
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            # Ctrl-D or Ctrl-C: exit cleanly
            print("\n\nGoodbye!")
            break

        if not user_input:
            continue

        # --- Special commands ---
        if user_input.lower() in ("exit", "quit", "bye"):
            print("\nGoodbye!")
            break

        if user_input.lower() == "clear":
            history = []
            last_chunks = []
            print("Conversation history cleared.\n")
            continue

        if user_input.lower() == "sources":
            if last_chunks:
                print("\nLast retrieved sources:")
                print(format_source_list(last_chunks))
                print()
            else:
                print("No sources retrieved yet.\n")
            continue

        if user_input.lower() == "history":
            if history:
                print(f"\nConversation history ({len(history) // 2} turn(s)):")
                for msg in history:
                    role = msg["role"].capitalize()
                    preview = msg["content"][:120].replace("\n", " ")
                    ellipsis = "..." if len(msg["content"]) > 120 else ""
                    print(f"  {role}: {preview}{ellipsis}")
                print()
            else:
                print("No conversation history yet.\n")
            continue

        # --- Normal question flow ---
        print()

        # Step 1: Retrieve relevant context (and save it for 'sources' command)
        try:
            last_chunks = vector_search(
                query=user_input,
                db=db,
                ollama=ollama,
                top_k=cfg.top_k,
            )
        except RuntimeError as e:
            print(f"[retrieval error] {e}\n")
            continue

        # Show the source list before streaming the answer
        print("Context sources:")
        print(format_source_list(last_chunks))
        print()
        print("Assistant: ", end="", flush=True)

        # Step 2: Stream the answer, collecting the full text for history
        full_response_parts: list[str] = []

        def collect_and_print(token: str) -> None:
            """Print each token immediately and accumulate for history."""
            print(token, end="", flush=True)
            full_response_parts.append(token)

        try:
            answer(
                question=user_input,
                db=db,
                ollama=ollama,
                cfg=cfg,
                conversation_history=history,
                on_chunk=collect_and_print,
            )
        except RuntimeError as e:
            print(f"\n[generation error] {e}")
            continue

        print("\n")  # Newline after the streamed response

        # Step 3: Append this turn to the conversation history
        full_response = "".join(full_response_parts)
        history.append({"role": "user", "content": user_input})
        history.append({"role": "assistant", "content": full_response})

        # Step 4: Trim history to avoid unbounded prompt growth
        history = trim_history(history, MAX_HISTORY_TURNS)


if __name__ == "__main__":
    main()
