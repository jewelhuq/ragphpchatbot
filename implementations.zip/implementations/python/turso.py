"""
turso.py — The bridge between our Python code and the Turso cloud database.

Turso is a distributed SQLite database that exposes an HTTP API called
the "pipeline" API (v2). A single POST to /v2/pipeline can carry multiple
SQL statements, which Turso executes atomically inside one HTTP round-trip.
This is important for performance: instead of opening a TCP connection per
query, we batch statements together.

This module wraps that HTTP API into a Pythonic client so that the rest of
the codebase can think in terms of SQL + Python dicts, not JSON schemas.

Authentication uses a long-lived Bearer token issued by the Turso platform.
Store yours in config.py (or an environment variable) — never hard-code it.
"""

import requests


class TursoClient:
    """
    A thin, stateless HTTP client for the Turso v2 pipeline API.

    Every public method translates a SQL string (+ optional parameters) into
    the JSON envelope that Turso expects, fires the request, and unpacks the
    response back into plain Python data structures.

    Why not use an ORM or the libSQL Python SDK?
    - The HTTP API needs zero native dependencies — it works in any Python
      environment, including constrained cloud functions.
    - The libSQL Python SDK requires a compiled extension; the HTTP path
      does not.
    - An ORM would hide the SQL, making the educational value of this demo
      harder to see.

    Parameters
    ----------
    url : str
        The HTTPS base URL of your Turso instance, e.g.
        "https://my-db-org.aws-us-east-1.turso.io".
    token : str
        The Bearer authentication token from the Turso dashboard.
    """

    def __init__(self, url: str, token: str) -> None:
        self.url = url.rstrip("/")
        self.token = token
        # Reuse a session for connection pooling — avoids a fresh TCP
        # handshake on every query, which matters when ingesting many chunks.
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            }
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _encode_params(self, params: list) -> list:
        """
        Turso's pipeline API does not accept raw Python values as bind
        parameters — each one must be wrapped in a typed JSON object like
        {"type": "text", "value": "hello"} or {"type": "integer", "value": "42"}.

        This helper converts a plain Python list into that wire format.

        Supported Python -> Turso type mappings:
          str   -> "text"
          int   -> "integer"
          float -> "float"
          None  -> "null"

        Parameters
        ----------
        params : list
            Positional bind parameters in the same order as the SQL's ? placeholders.

        Returns
        -------
        list
            A list of {"type": ..., "value": ...} dicts ready to embed in
            the pipeline request body.
        """
        encoded = []
        for p in params:
            if p is None:
                encoded.append({"type": "null", "value": None})
            elif isinstance(p, bool):
                # bool is a subclass of int in Python, so check it first
                encoded.append({"type": "integer", "value": str(int(p))})
            elif isinstance(p, int):
                encoded.append({"type": "integer", "value": str(p)})
            elif isinstance(p, float):
                encoded.append({"type": "float", "value": str(p)})
            else:
                encoded.append({"type": "text", "value": str(p)})
        return encoded

    def _pipeline(self, statements: list[dict]) -> list[dict]:
        """
        Fire a batch of SQL statements at the /v2/pipeline endpoint and
        return the per-statement result objects.

        The pipeline envelope looks like:
          {"requests": [
              {"type": "execute", "stmt": {"sql": "...", "args": [...]}},
              ...
              {"type": "close"}
          ]}

        The final "close" request tells Turso to release the implicit
        transaction opened by the batch.

        Parameters
        ----------
        statements : list[dict]
            Each dict has keys "sql" and "args" (already encoded).

        Returns
        -------
        list[dict]
            The "results" array from the Turso response body, one entry
            per statement (excluding the trailing "close").

        Raises
        ------
        RuntimeError
            If the HTTP response is not 200 OK, or if Turso reports an
            error inside the response JSON.
        """
        requests_payload = [
            {"type": "execute", "stmt": stmt} for stmt in statements
        ]
        requests_payload.append({"type": "close"})

        response = self._session.post(
            f"{self.url}/v2/pipeline",
            json={"requests": requests_payload},
            timeout=30,
        )

        if response.status_code != 200:
            raise RuntimeError(
                f"Turso HTTP error {response.status_code}: {response.text[:500]}"
            )

        data = response.json()
        results = data.get("results", [])

        # Check each result for an embedded error object
        for i, result in enumerate(results):
            if result.get("type") == "error":
                error_msg = result.get("error", {}).get("message", "unknown error")
                raise RuntimeError(f"Turso SQL error in statement {i}: {error_msg}")

        return results

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def execute(self, sql: str, params: list = []) -> None:
        """
        Run a SQL statement that does not return rows (INSERT, UPDATE,
        DELETE, CREATE TABLE, etc.).

        This is the fire-and-forget method. The caller does not need the
        result set — only confirmation that the statement ran without error.

        Parameters
        ----------
        sql : str
            The SQL statement with ? placeholders for bind parameters.
        params : list, optional
            Values to bind to the ? placeholders, in order.
        """
        stmt = {"sql": sql, "args": self._encode_params(params)}
        self._pipeline([stmt])

    def fetch_all(self, sql: str, params: list = []) -> list[dict]:
        """
        Run a SELECT statement and return every row as a dict.

        Turso returns rows in a column-major format:
          {
            "cols": [{"name": "id"}, {"name": "content"}, ...],
            "rows": [[{"type": "text", "value": "abc"}, ...], ...]
          }

        This method stitches columns to row values so callers receive the
        more natural row-major format:
          [{"id": "abc", ...}, ...]

        Parameters
        ----------
        sql : str
            A SELECT statement with ? placeholders.
        params : list, optional
            Values to bind to the ? placeholders, in order.

        Returns
        -------
        list[dict]
            Zero or more rows, each represented as a column-name -> value dict.
            Turso null values become Python None; everything else becomes a str
            (numeric columns can be cast by callers if needed).
        """
        stmt = {"sql": sql, "args": self._encode_params(params)}
        results = self._pipeline([stmt])

        # The first result corresponds to our single SELECT statement
        result = results[0]
        if result.get("type") == "error":
            error_msg = result.get("error", {}).get("message", "unknown error")
            raise RuntimeError(f"Turso fetch error: {error_msg}")

        # Navigate into the nested response structure
        response_obj = result.get("response", {})
        result_obj = response_obj.get("result", {})
        cols = [col["name"] for col in result_obj.get("cols", [])]
        raw_rows = result_obj.get("rows", [])

        rows = []
        for raw_row in raw_rows:
            row = {}
            for col_name, cell in zip(cols, raw_row):
                # Cells are {"type": "...", "value": "..."} or {"type": "null"}
                if cell.get("type") == "null":
                    row[col_name] = None
                else:
                    row[col_name] = cell.get("value")
            rows.append(row)

        return rows

    def execute_many(self, statements: list[tuple]) -> None:
        """
        Run multiple SQL statements in a single HTTP round-trip.

        This is a performance optimisation for bulk operations like ingestion,
        where we want to insert dozens of chunks without paying per-insert
        network latency.

        Parameters
        ----------
        statements : list[tuple]
            Each tuple is (sql_string, params_list). All statements are
            bundled into one pipeline request.
        """
        encoded_stmts = []
        for sql, params in statements:
            encoded_stmts.append(
                {"sql": sql, "args": self._encode_params(params)}
            )
        self._pipeline(encoded_stmts)
