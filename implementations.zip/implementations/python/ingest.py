"""
ingest.py — The pipeline that turns raw documents into searchable knowledge.

Running this script is the first step before any queries can be answered.
It walks the docs/ directory, reads every supported file, slices the text
into chunks, converts each chunk into a vector embedding, and writes
everything to Turso so the retrieval step can find it later.

The key design choices that make this pipeline reliable:

  1. Content hashing (MD5). We record the MD5 of each file on ingestion.
     On subsequent runs we re-compute the hash and skip the file if it has
     not changed. This makes re-running ingest.py safe and fast — only new
     or modified files are processed.

  2. Atomic update. If a file's content has changed, we delete all its old
     chunks before inserting new ones. This prevents stale chunks from
     contaminating retrieval results.

  3. Vector storage in Turso. Turso/libSQL supports a vector32() type and
     a vector_top_k() table-valued function for approximate nearest-neighbour
     search. This lets us do embedding similarity search without a separate
     vector database.

Usage:
    python ingest.py [docs_dir]

    docs_dir defaults to the value in config.py.
"""

import hashlib
import os
import sys
import time

from config import load_config
from turso import TursoClient
from ollama import OllamaClient
from parser import DocumentParser
from chunker import Chunker


# ---------------------------------------------------------------------------
# Schema management
# ---------------------------------------------------------------------------

CREATE_FILES_TABLE = """
CREATE TABLE IF NOT EXISTS rag_files (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    path     TEXT    NOT NULL UNIQUE,
    md5      TEXT    NOT NULL,
    ingested INTEGER NOT NULL DEFAULT 0
)
"""

CREATE_CHUNKS_TABLE = """
CREATE TABLE IF NOT EXISTS rag_chunks (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id   INTEGER NOT NULL REFERENCES rag_files(id),
    chunk_idx INTEGER NOT NULL,
    content   TEXT    NOT NULL,
    embedding F32_BLOB(768)
)
"""

CREATE_VECTOR_INDEX = """
CREATE INDEX IF NOT EXISTS rag_chunks_vec
ON rag_chunks (libsql_vector_idx(embedding))
"""


def ensure_schema(db: TursoClient) -> None:
    """
    Create the database tables and vector index if they do not yet exist.

    We use CREATE TABLE IF NOT EXISTS so this function is safe to call on
    every run — it is a no-op when the schema is already in place.

    The vector index uses Turso's libsql_vector_idx() extension which
    builds a HNSW (Hierarchical Navigable Small World) index. HNSW gives
    sub-linear query time at the cost of approximate (not exact) results,
    which is the right trade-off for RAG workloads.

    Parameters
    ----------
    db : TursoClient
        An authenticated Turso client.
    """
    print("Ensuring database schema ...")
    db.execute(CREATE_FILES_TABLE)
    db.execute(CREATE_CHUNKS_TABLE)
    try:
        db.execute(CREATE_VECTOR_INDEX)
    except RuntimeError as e:
        # The index may already exist with a slightly different definition;
        # Turso raises an error in that case but it is safe to continue.
        print(f"  [warn] Vector index: {e}")
    print("Schema ready.")


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------

SUPPORTED_EXTENSIONS = {".txt", ".pdf", ".docx", ".md", ".rst"}


def discover_files(docs_dir: str) -> list[str]:
    """
    Walk a directory tree and collect all supported document files.

    We walk recursively so that documents can be organised into subdirectories
    without needing to flatten them first.

    Parameters
    ----------
    docs_dir : str
        Root directory to scan.

    Returns
    -------
    list[str]
        Sorted list of absolute file paths with supported extensions.
    """
    if not os.path.isdir(docs_dir):
        print(f"[warn] docs_dir '{docs_dir}' does not exist. Creating it ...")
        os.makedirs(docs_dir, exist_ok=True)
        return []

    found = []
    for dirpath, _, filenames in os.walk(docs_dir):
        for name in filenames:
            ext = os.path.splitext(name)[1].lower()
            if ext in SUPPORTED_EXTENSIONS:
                found.append(os.path.join(dirpath, name))

    return sorted(found)


def md5_file(path: str) -> str:
    """
    Compute the MD5 hash of a file's contents.

    MD5 is not cryptographically secure, but that is irrelevant here — we
    are using it purely as a fast change-detection fingerprint. Two identical
    files will always produce the same hash; any byte-level change produces
    a different hash.

    Parameters
    ----------
    path : str
        Path to the file.

    Returns
    -------
    str
        32-character hex digest.
    """
    h = hashlib.md5()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Ingestion logic
# ---------------------------------------------------------------------------

def embed_vector_literal(embedding: list[float]) -> str:
    """
    Format a list of floats as the string literal that Turso's vector32()
    function expects.

    Turso stores embeddings as binary blobs created by vector32('[1.0, 2.0, ...]').
    The argument must be a JSON array of floats formatted as a string.

    Parameters
    ----------
    embedding : list[float]
        The raw embedding values from Ollama.

    Returns
    -------
    str
        E.g. "[0.123, 0.456, ...]"
    """
    return "[" + ",".join(f"{v:.6f}" for v in embedding) + "]"


def ingest_file(
    file_path: str,
    db: TursoClient,
    ollama: OllamaClient,
    parser: DocumentParser,
    chunker: Chunker,
    chunk_size: int,
) -> None:
    """
    Parse, chunk, embed, and store a single document.

    This function is the inner loop of the ingestion pipeline. It handles
    the full lifecycle of one document: hashing, change detection, deletion
    of stale chunks, parsing, chunking, embedding each chunk, and inserting
    the results into Turso.

    Parameters
    ----------
    file_path : str
        Absolute path to the document file.
    db : TursoClient
        Authenticated database client.
    ollama : OllamaClient
        Connected embedding/chat client.
    parser : DocumentParser
        Format-aware text extractor.
    chunker : Chunker
        Text splitter configured with the target chunk_size.
    chunk_size : int
        Passed through for display purposes only.
    """
    filename = os.path.basename(file_path)
    print(f"\n  Processing: {filename}")

    # Step 1: Hash the file to detect changes
    current_md5 = md5_file(file_path)

    # Step 2: Look up this file in the database
    existing = db.fetch_all(
        "SELECT id, md5 FROM rag_files WHERE path = ?", [file_path]
    )

    if existing:
        file_id = existing[0]["id"]
        stored_md5 = existing[0]["md5"]

        if stored_md5 == current_md5:
            print(f"  [skip] {filename} — unchanged (MD5 matches)")
            return

        # File has changed: delete all its old chunks before re-ingesting
        print(f"  [update] {filename} — content changed, re-ingesting ...")
        db.execute("DELETE FROM rag_chunks WHERE file_id = ?", [file_id])
        db.execute(
            "UPDATE rag_files SET md5 = ?, ingested = 0 WHERE id = ?",
            [current_md5, file_id],
        )
    else:
        # Brand new file: create a record
        db.execute(
            "INSERT INTO rag_files (path, md5, ingested) VALUES (?, ?, 0)",
            [file_path, current_md5],
        )
        rows = db.fetch_all(
            "SELECT id FROM rag_files WHERE path = ?", [file_path]
        )
        file_id = rows[0]["id"]
        print(f"  [new] {filename} — ingesting for the first time ...")

    # Step 3: Parse the document into text
    try:
        text = parser.parse(file_path)
    except Exception as e:
        print(f"  [error] Could not parse {filename}: {e}")
        return

    if not text or not text.strip():
        print(f"  [warn] {filename} produced no text — skipping")
        return

    print(f"  Parsed {len(text):,} characters")

    # Step 4: Split text into chunks
    source_label = os.path.splitext(filename)[0]  # filename without extension
    chunks = chunker.chunk(text, source=source_label)
    print(f"  Split into {len(chunks)} chunks")

    if not chunks:
        print(f"  [warn] No chunks produced for {filename}")
        return

    # Step 5: Embed each chunk and insert into Turso
    inserted = 0
    for idx, chunk_text in enumerate(chunks):
        try:
            embedding = ollama.embed(chunk_text)
        except RuntimeError as e:
            print(f"  [error] Embedding failed for chunk {idx}: {e}")
            continue

        vec_literal = embed_vector_literal(embedding)

        # Turso's vector32() takes the JSON array string and stores it
        # as a compact binary blob optimised for distance calculations.
        db.execute(
            "INSERT INTO rag_chunks (file_id, chunk_idx, content, embedding) "
            "VALUES (?, ?, ?, vector32(?))",
            [file_id, idx, chunk_text, vec_literal],
        )
        inserted += 1

        # Progress indicator for long documents
        if (idx + 1) % 10 == 0 or (idx + 1) == len(chunks):
            print(f"  Embedded {idx + 1}/{len(chunks)} chunks ...", end="\r")

    print()  # newline after the progress line

    # Mark the file as fully ingested
    db.execute("UPDATE rag_files SET ingested = 1 WHERE id = ?", [file_id])
    print(f"  Done: inserted {inserted} chunks for {filename}")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Orchestrate the full ingestion pipeline from CLI invocation.

    Steps:
      1. Load configuration
      2. Verify Ollama is running
      3. Connect to Turso
      4. Ensure schema exists
      5. Discover documents in docs_dir
      6. Ingest each document (with hash-based skip logic)
      7. Print a summary
    """
    cfg = load_config()

    # Allow overriding docs_dir from the command line
    docs_dir = sys.argv[1] if len(sys.argv) > 1 else cfg.docs_dir
    docs_dir = os.path.abspath(docs_dir)

    print("=" * 60)
    print("RAG Ingestion Pipeline")
    print("=" * 60)
    print(f"Docs directory : {docs_dir}")
    print(f"Turso URL      : {cfg.turso_url}")
    print(f"Ollama URL     : {cfg.ollama_url}")
    print(f"Embed model    : {cfg.embedding_model}")
    print(f"Chunk size     : {cfg.chunk_size} chars")
    print()

    # Initialise clients
    db = TursoClient(cfg.turso_url, cfg.turso_token)
    ollama = OllamaClient(
        url=cfg.ollama_url,
        embedding_model=cfg.embedding_model,
        chat_model=cfg.chat_model,
    )

    # Verify Ollama is reachable before touching the DB
    if not ollama.is_available():
        print(
            f"[error] Ollama is not reachable at {cfg.ollama_url}.\n"
            "Please start it with:  ollama serve\n"
            "And ensure the model is pulled:  ollama pull nomic-embed-text"
        )
        sys.exit(1)

    # Ensure the database schema is in place
    ensure_schema(db)

    # Discover documents
    files = discover_files(docs_dir)
    if not files:
        print(f"\nNo supported documents found in {docs_dir}")
        print(f"Supported formats: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")
        print("Add some documents and re-run ingest.py")
        return

    print(f"Found {len(files)} document(s) to process")

    parser = DocumentParser()
    chunker = Chunker(chunk_size=cfg.chunk_size)

    start_time = time.time()
    for file_path in files:
        ingest_file(
            file_path=file_path,
            db=db,
            ollama=ollama,
            parser=parser,
            chunker=chunker,
            chunk_size=cfg.chunk_size,
        )

    elapsed = time.time() - start_time
    print("\n" + "=" * 60)
    print(f"Ingestion complete in {elapsed:.1f}s")
    print("=" * 60)
    print("You can now run:  python chatbot.py")


if __name__ == "__main__":
    main()
