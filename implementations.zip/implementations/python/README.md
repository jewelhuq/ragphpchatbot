# Python RAG Implementation

A complete Retrieval-Augmented Generation (RAG) system built with:

- **Turso** (libSQL cloud database) for vector storage and similarity search
- **Ollama** (local inference server) for embeddings and chat generation
- **Python** with minimal dependencies (just `requests` for the core pipeline)

---

## Architecture Overview

```
docs/                    ← Drop your documents here (.txt, .pdf, .docx, .md)
  │
  ▼
ingest.py               ← Parse → Chunk → Embed → Store in Turso
  │
  ▼
Turso DB                ← Vector index (HNSW via libsql_vector_idx)
  │
  ▼
query.py / rag.py       ← Embed query → Vector search → LLM generation
  │
  ▼
chatbot.py              ← Interactive conversational interface
```

---

## Prerequisites

1. **Python 3.10+** (uses `list[str]` type hints without `from __future__ import annotations`)

2. **Ollama** installed and running:
   ```bash
   # Install from https://ollama.com
   ollama serve

   # Pull the required models
   ollama pull nomic-embed-text   # 768-dim embeddings
   ollama pull gemma3:1b          # chat model (~800 MB)
   ```

3. **Turso account** with a database instance:
   - Sign up at https://turso.tech
   - Create a database
   - Copy the database URL and a Bearer auth token

---

## Installation

```bash
cd implementations/python

# Install all dependencies (core + optional document formats)
pip install -r requirements.txt

# Or install core only (txt/md files will still work)
pip install requests
```

---

## Configuration

Edit `config.py` and update `load_config()` with your credentials:

```python
def load_config() -> Config:
    return Config(
        turso_url="https://your-db-org.aws-us-east-1.turso.io",
        turso_token="YOUR_TURSO_BEARER_TOKEN",   # ← change this
        ollama_url="http://127.0.0.1:11434",
        chat_model="gemma3:1b",
        embedding_model="nomic-embed-text",
        embedding_dims=768,
        top_k=5,
        docs_dir="docs",
        chunk_size=512,
    )
```

| Setting | Default | Description |
|---|---|---|
| `turso_url` | — | HTTPS URL of your Turso database |
| `turso_token` | — | Bearer auth token from Turso dashboard |
| `ollama_url` | `http://127.0.0.1:11434` | Ollama server address |
| `chat_model` | `gemma3:1b` | Model for generating answers |
| `embedding_model` | `nomic-embed-text` | Model for creating embeddings |
| `embedding_dims` | `768` | Must match the embedding model output |
| `top_k` | `5` | Number of chunks to retrieve per query |
| `docs_dir` | `docs` | Directory to scan for documents |
| `chunk_size` | `512` | Soft character limit per chunk |

---

## Usage

### Step 1: Add documents

```bash
mkdir -p docs
cp /path/to/your/documents/* docs/
# Supports: .txt, .pdf, .docx, .md, .rst
```

### Step 2: Ingest documents

```bash
python ingest.py
# Or specify a custom docs directory:
python ingest.py /path/to/custom/docs
```

The ingestor:
- Creates the database schema on first run (safe to re-run)
- Computes MD5 hashes to skip unchanged files
- Deletes and re-ingests chunks for changed files
- Prints progress as it processes each document

### Step 3: Start the chatbot

```bash
python chatbot.py
```

Special commands in the chatbot:
- `exit` / `quit` — end the session
- `clear` — reset conversation history
- `sources` — show the chunks retrieved for the last question
- `history` — show a summary of the conversation so far

### One-shot query (no conversation)

```bash
python rag.py "What does the document say about X?"
```

### Inspect raw retrieval results

```bash
python query.py "your question here"
python query.py "your question here" 10    # retrieve top 10 chunks
```

---

## File Structure

```
implementations/python/
├── config.py          # All configuration in one dataclass
├── turso.py           # Turso HTTP API client (v2 pipeline)
├── ollama.py          # Ollama embedding + streaming chat client
├── chunker.py         # Paragraph-aware text splitter with overlap
├── parser.py          # .txt / .pdf / .docx text extractor
├── ingest.py          # Document ingestion pipeline (standalone script)
├── query.py           # Vector search debugging tool (standalone script)
├── rag.py             # Retrieval + LLM generation pipeline
├── chatbot.py         # Interactive conversational interface
├── requirements.txt   # Python dependencies
└── README.md          # This file
```

---

## How It Works

### Ingestion (`ingest.py`)

1. Scan `docs/` for supported files
2. Compute MD5 hash; skip if unchanged since last run
3. Parse the file into plain text (`.txt`, `.pdf`, `.docx`)
4. Split text into overlapping chunks with source/section prefixes
5. Call `POST /api/embeddings` on Ollama for each chunk → 768-float vector
6. Store chunk text + `vector32(embedding)` in Turso's `rag_chunks` table

### Retrieval (`query.py` / `rag.py`)

1. Embed the user's question using the same `nomic-embed-text` model
2. Call Turso's `vector_top_k('rag_chunks_vec', query_vector, k)` — an
   approximate nearest-neighbour search over the HNSW index
3. Join the result IDs back to `rag_chunks` and `rag_files` to get text + provenance

### Generation (`rag.py`)

1. Format the top-k chunks as a numbered context block
2. Build a system prompt with anti-hallucination rules (cite sources, say "I don't know" if unsure)
3. Stream `POST /api/chat` from Ollama, printing each token as it arrives

---

## Troubleshooting

**"Cannot connect to Ollama"**
- Run `ollama serve` in a separate terminal
- Check `ollama ps` to see running models

**"Turso HTTP error 401"**
- Your `turso_token` is missing or expired — generate a new one in the Turso dashboard

**"No results found"**
- Run `python ingest.py` first to populate the database
- Check that your docs are in the `docs/` directory

**Poor answer quality**
- Run `python query.py "your question"` to inspect raw retrieval results
- If retrieved chunks are irrelevant, try adjusting `chunk_size` (smaller = more precise)
- If no chunks are retrieved, the vocabulary may differ — try rephrasing the question

**PDF produces empty text**
- The PDF is likely scanned (image-only). RAG requires text-layer PDFs.
- Use an OCR tool (e.g. `tesseract`) to add a text layer before ingesting.

---

## Token Security Note

Never commit your `turso_token` to version control. Consider reading it from
an environment variable instead:

```python
import os

def load_config() -> Config:
    return Config(
        turso_token=os.environ.get("TURSO_TOKEN", ""),
        ...
    )
```

Then set it before running:
```bash
export TURSO_TOKEN="your-token-here"
python chatbot.py
```
