"""
ollama.py — The voice and mind of the RAG system.

Ollama is a local inference server that downloads and runs open-weight
models on your own hardware. It exposes a clean HTTP API, which means we
don't need Ollama's Python SDK — raw requests work fine and keep
dependencies minimal.

Two capabilities live here:
  1. Embedding  — turning a chunk of text into a 768-dimensional float
     vector so that "meaning" becomes a point in geometric space.
  2. Streaming chat — asking the model a question and printing each word
     as it is generated, rather than waiting for the full response.

The streaming path is the UX secret ingredient: users can start reading
the answer before the model finishes generating it, which makes a local
1-billion-parameter model feel much more responsive than it really is.
"""

import json
import requests
from typing import Callable


class OllamaClient:
    """
    A lightweight HTTP client for the Ollama inference server.

    Ollama's API is intentionally simple:
      POST /api/embeddings  -> { "embedding": [float, ...] }
      POST /api/chat        -> NDJSON stream of token chunks

    This class is deliberately thin — it does not cache embeddings, manage
    model downloads, or handle retries. Those concerns belong in the layers
    above it.

    Parameters
    ----------
    url : str
        The base URL of the running Ollama server.
        Default: "http://127.0.0.1:11434"
    embedding_model : str
        The model name to use for /api/embeddings calls.
    chat_model : str
        The model name to use for /api/chat calls.
    """

    def __init__(
        self,
        url: str = "http://127.0.0.1:11434",
        embedding_model: str = "nomic-embed-text",
        chat_model: str = "gemma3:1b",
    ) -> None:
        self.url = url.rstrip("/")
        self.embedding_model = embedding_model
        self.chat_model = chat_model
        # A reused session avoids re-establishing TCP connections between
        # rapid sequential embedding calls during ingestion.
        self._session = requests.Session()

    def embed(self, text: str) -> list[float]:
        """
        Convert a string into a dense vector representation.

        This is the mathematical heart of the retrieval step. Two pieces of
        text with similar meaning end up close together in the 768-dimensional
        vector space produced by nomic-embed-text, which is what makes the
        "find the most relevant chunks" search work.

        The endpoint is synchronous: Ollama waits until the full embedding
        is computed before responding, so there is no streaming here.

        Parameters
        ----------
        text : str
            The string to embed. For best results, keep it under the model's
            context window (nomic-embed-text supports up to 8192 tokens).

        Returns
        -------
        list[float]
            A list of 768 floats. The length is determined by the model and
            must match the dimensionality used when creating the vector index.

        Raises
        ------
        RuntimeError
            If Ollama is not running, the model is not pulled, or the server
            returns an unexpected response.
        """
        payload = {
            "model": self.embedding_model,
            "prompt": text,
        }
        try:
            response = self._session.post(
                f"{self.url}/api/embeddings",
                json=payload,
                timeout=60,  # Embedding a long chunk can take a few seconds on CPU
            )
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to Ollama at {self.url}. "
                "Is the server running? Try: ollama serve"
            )

        if response.status_code != 200:
            raise RuntimeError(
                f"Ollama embedding error {response.status_code}: {response.text[:300]}"
            )

        data = response.json()
        embedding = data.get("embedding")
        if not embedding:
            raise RuntimeError(
                f"Ollama returned no embedding. Response: {data}"
            )

        return embedding

    def chat_stream(
        self,
        messages: list[dict],
        on_chunk: Callable[[str], None],
        system: str = "",
    ) -> str:
        """
        Send a conversation to the model and receive the reply token-by-token.

        Ollama's streaming chat endpoint responds with Newline-Delimited JSON
        (NDJSON): each line is a self-contained JSON object describing one
        generated token (or a final summary object). We parse each line as it
        arrives and hand the token text to the caller's on_chunk callback.

        Why a callback instead of a generator?
        A callback makes it trivial for chatbot.py to print tokens to stdout
        in real time while still accumulating the full response in a string
        for history. A generator would force the caller into a for-loop that
        mingles printing and accumulation logic.

        Parameters
        ----------
        messages : list[dict]
            The conversation history in OpenAI-compatible format:
            [{"role": "user", "content": "..."}, {"role": "assistant", ...}]
        on_chunk : callable
            A function that accepts a single str (one token or partial token).
            Called once per NDJSON line while the model is generating.
        system : str, optional
            A system prompt injected before the first user message.
            If empty, no system message is prepended.

        Returns
        -------
        str
            The full concatenated response text, useful for appending to
            conversation history after streaming completes.

        Raises
        ------
        RuntimeError
            If Ollama is unreachable or returns a non-200 status.
        """
        all_messages = []
        if system:
            all_messages.append({"role": "system", "content": system})
        all_messages.extend(messages)

        payload = {
            "model": self.chat_model,
            "messages": all_messages,
            "stream": True,
        }

        try:
            response = self._session.post(
                f"{self.url}/api/chat",
                json=payload,
                stream=True,  # Ask requests not to buffer the whole response
                timeout=120,  # Generation can be slow on CPU
            )
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to Ollama at {self.url}. "
                "Is the server running? Try: ollama serve"
            )

        if response.status_code != 200:
            raise RuntimeError(
                f"Ollama chat error {response.status_code}: {response.text[:300]}"
            )

        full_response = []

        # iter_lines() yields one NDJSON line at a time, blocking between
        # chunks just long enough for the model to generate the next token.
        for line in response.iter_lines():
            if not line:
                continue  # blank lines are valid NDJSON separators

            try:
                chunk = json.loads(line)
            except json.JSONDecodeError:
                # Malformed line — skip rather than crash
                continue

            # Each streaming chunk looks like:
            # {"model": "...", "message": {"role": "assistant", "content": "word"}, "done": false}
            message_obj = chunk.get("message", {})
            token = message_obj.get("content", "")
            if token:
                on_chunk(token)
                full_response.append(token)

            # When done=true the final object contains timing statistics
            if chunk.get("done"):
                break

        return "".join(full_response)

    def is_available(self) -> bool:
        """
        Quick health check — returns True if Ollama is reachable.

        Useful for showing a friendly error at startup rather than letting
        the first embed() or chat_stream() call fail with a confusing
        ConnectionError.
        """
        try:
            response = self._session.get(f"{self.url}/", timeout=5)
            return response.status_code == 200
        except requests.exceptions.ConnectionError:
            return False
