"""
chunker.py — The art of slicing documents into bite-sized pieces.

Retrieval-Augmented Generation lives or dies by the quality of its chunks.
A chunk that is too large dilutes the relevance signal — the embedding
vector averages over too many ideas, so semantically distant content blurs
together. A chunk that is too small loses the surrounding sentences that
give individual claims their meaning.

This module's chunker follows a few simple editorial instincts:

  1. Respect paragraph boundaries. Authors already decided where ideas end;
     we should not split mid-thought just because we hit a character limit.

  2. Detect headings. A short, ALL-CAPS line is almost certainly a section
     title. We remember it and prepend it to every chunk in that section,
     so a retrieved chunk carries the section heading even in isolation.

  3. Keep source provenance. Every chunk is prefixed with its filename so
     the LLM and the human reader always know where the text came from.

  4. Overlap via tail sentences. The last sentence of one chunk becomes
     the first sentence of the next. This prevents the retrieval step from
     missing a relevant passage just because the query term happened to land
     on a chunk boundary.

  5. Discard noise. Paragraphs shorter than 100 characters are usually
     headers, footers, or formatting artifacts — we skip them.
"""

import re


class Chunker:
    """
    Splits a long document string into overlapping, context-rich chunks.

    The chunker is deliberately heuristic rather than model-based: it
    works without any LLM calls, runs fast, and is easy to reason about
    when debugging poor retrieval results.

    Parameters
    ----------
    chunk_size : int
        Soft character limit per chunk (default 512). A chunk may exceed
        this if a single paragraph is longer — we never split mid-paragraph.
    min_chars : int
        Paragraphs shorter than this are ignored as noise (default 100).
    """

    def __init__(self, chunk_size: int = 512, min_chars: int = 100) -> None:
        self.chunk_size = chunk_size
        self.min_chars = min_chars

    def _is_heading(self, paragraph: str) -> bool:
        """
        Decide whether a paragraph looks like a section heading.

        Our heuristic: a heading is a single line that is entirely uppercase
        (allowing punctuation and spaces), shorter than 120 characters, and
        does not end with a period (headings are titles, not sentences).

        This catches typical document headings like:
          "INTRODUCTION"
          "1. BACKGROUND AND MOTIVATION"
          "CHAPTER 3: RELATED WORK"

        But not an all-caps sentence like:
          "THIS IS IMPORTANT. READ CAREFULLY."

        Parameters
        ----------
        paragraph : str
            A paragraph of text (may contain newlines, but typically short).

        Returns
        -------
        bool
            True if the paragraph matches our heading heuristic.
        """
        stripped = paragraph.strip()
        if len(stripped) > 120:
            return False
        if "\n" in stripped:
            # Real headings rarely span multiple lines
            return False
        if stripped.endswith("."):
            return False
        # Check if removing punctuation and spaces leaves only uppercase
        letters = re.sub(r"[^a-zA-Z]", "", stripped)
        return len(letters) > 0 and letters == letters.upper()

    def _split_sentences(self, text: str) -> list[str]:
        """
        Roughly split a text block into individual sentences.

        We use a simple regex rather than a full NLP tokenizer because
        the chunker should work with zero additional dependencies. The
        heuristic covers the common cases: period/question/exclamation
        followed by whitespace and a capital letter.

        Parameters
        ----------
        text : str
            Arbitrary prose.

        Returns
        -------
        list[str]
            A list of sentence strings (may include trailing spaces).
        """
        # Split on sentence-ending punctuation followed by whitespace + capital
        sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z])", text)
        return [s.strip() for s in sentences if s.strip()]

    def chunk(self, text: str, source: str = "") -> list[str]:
        """
        Split a document into overlapping, context-prefixed chunks.

        The algorithm:
          1. Split the full text on blank lines to get paragraphs.
          2. Walk the paragraphs in order, tracking the current section heading.
          3. Accumulate paragraphs into a buffer until the buffer exceeds
             chunk_size characters.
          4. When the buffer overflows, finalise a chunk (with source/heading
             prefix and an overlap tail from the previous chunk) and start
             a new buffer carrying the last sentence of the old buffer.
          5. Flush any remaining buffer as the final chunk.

        The source + heading prefix is NOT counted toward chunk_size because
        it is metadata overhead, not document content.

        Parameters
        ----------
        text : str
            The full document text to chunk.
        source : str, optional
            A human-readable label for the document (usually the filename).
            Embedded in every chunk's prefix for provenance tracking.

        Returns
        -------
        list[str]
            A list of chunk strings, each beginning with a "Source: / Section:"
            prefix line and ending with the document content for that window.
        """
        if not text or not text.strip():
            return []

        # Step 1: Split into paragraphs on blank lines
        raw_paragraphs = re.split(r"\n\n+", text)
        paragraphs = [p.strip() for p in raw_paragraphs if p.strip()]

        chunks = []
        current_heading = "General"
        buffer_parts: list[str] = []   # Paragraphs accumulating in this chunk
        buffer_chars = 0
        overlap_tail = ""              # Last sentence from the previous chunk

        def _build_chunk(parts: list[str], heading: str, tail: str) -> str:
            """
            Assemble a finished chunk string with provenance prefix.

            The tail (overlap from the prior chunk) is prepended to the
            content so that concepts at chunk boundaries are not siloed.
            """
            prefix = f"Source: {source}\nSection: {heading}\n\n"
            body_parts = []
            if tail:
                body_parts.append(tail)
            body_parts.extend(parts)
            body = "\n\n".join(body_parts)
            return prefix + body

        def _extract_tail(parts: list[str]) -> str:
            """
            Pull the last sentence out of the buffer to use as overlap.

            If the last paragraph has multiple sentences, we take just the
            final sentence. If parsing fails or the result is trivially short,
            we return an empty string.
            """
            if not parts:
                return ""
            last_para = parts[-1]
            sentences = self._split_sentences(last_para)
            if not sentences:
                return ""
            tail = sentences[-1]
            return tail if len(tail) >= 40 else ""

        for para in paragraphs:
            # Detect headings and update section label
            if self._is_heading(para):
                # If we have accumulated content, flush it as a chunk before
                # the new section begins — section breaks are natural boundaries
                if buffer_parts:
                    tail = _extract_tail(buffer_parts)
                    chunks.append(_build_chunk(buffer_parts, current_heading, overlap_tail))
                    overlap_tail = tail
                    buffer_parts = []
                    buffer_chars = 0
                current_heading = para
                continue

            # Skip paragraphs that are too short to carry meaning
            if len(para) < self.min_chars:
                continue

            # Would adding this paragraph overflow our target chunk size?
            if buffer_chars + len(para) > self.chunk_size and buffer_parts:
                # Finalise the current chunk and start a new one
                tail = _extract_tail(buffer_parts)
                chunks.append(_build_chunk(buffer_parts, current_heading, overlap_tail))
                overlap_tail = tail
                buffer_parts = []
                buffer_chars = 0

            buffer_parts.append(para)
            buffer_chars += len(para)

        # Flush any remaining content as the last chunk
        if buffer_parts:
            chunks.append(_build_chunk(buffer_parts, current_heading, overlap_tail))

        return chunks
