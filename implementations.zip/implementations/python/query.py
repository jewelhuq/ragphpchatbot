"""
query.py — A command-line tool for inspecting what the retrieval step sees.

Before trusting the chatbot's answers, it is enormously valuable to look at
the raw chunks that the vector search returns. If the retrieved chunks are
irrelevant or duplicated, the problem lives in the chunking or embedding
stage — not in the LLM's reasoning.

This script takes a single query string, embeds it, runs the vector search,
and prints the ranked results with their cosine similarity scores. It is
intentionally a developer/debugging tool rather than a user-facing interface.

Usage:
    python query.py "What is the capital of France?"
    python query.py "how does the authentication work" --top 10
"""

import sys

from config import load_config
from turso import TursoClient
from ollama import OllamaClient


def vector_search(
    query: str,
    db: TursoClient,
    ollama: OllamaClient,
    top_k: int = 5,
) -> list[dict]:
    """
    Embed the query and find the most semantically similar chunks in Turso.

    The search uses Turso's vector_top_k() table-valued function, which
    performs an approximate nearest-neighbour (ANN) search over the HNSW
    index we created during ingestion. The results are ordered by distance
    (ascending), where smaller distance means higher similarity.

    We JOIN back to rag_chunks to recover the original chunk text and to
    rag_files to recover the source filename — both of which are needed
    for display and for building the LLM prompt.

    Parameters
    ----------
    query : str
        The natural language question or search phrase.
    db : TursoClient
        Authenticated Turso client.
    ollama : OllamaClient
        Connected Ollama client for embedding the query.
    top_k : int
        How many chunks to retrieve. Higher values give more context but
        dilute precision.

    Returns
    -------
    list[dict]
        Ranked list of result dicts, each containing:
          - "chunk_id"  : int
          - "content"   : str
          - "source"    : str (file path)
          - "chunk_idx" : int
          - "distance"  : float (lower = more similar)
          - "score"     : float (1 - distance, higher = more similar)
    """
    # Embed the query using the same model that was used during ingestion.
    # Using a different model would produce vectors in a different space,
    # making the distances meaningless.
    print(f"Embedding query: '{query}' ...")
    embedding = ollama.embed(query)
    vec_literal = "[" + ",".join(f"{v:.6f}" for v in embedding) + "]"

    # vector_top_k(table_name, query_vector, k) returns rows ordered by
    # distance from the query vector. We JOIN to get the chunk content
    # and the source file path.
    sql = """
        SELECT
            c.id         AS chunk_id,
            c.content    AS content,
            f.path       AS source,
            c.chunk_idx  AS chunk_idx,
            vt.distance  AS distance
        FROM vector_top_k('rag_chunks_vec', vector32(?), ?) AS vt
        JOIN rag_chunks c ON c.id = vt.id
        JOIN rag_files  f ON f.id = c.file_id
        ORDER BY vt.distance ASC
    """

    rows = db.fetch_all(sql, [vec_literal, str(top_k)])

    # Add a human-friendly similarity score (1 - cosine_distance is
    # bounded [0, 1] for unit-normalised vectors; nomic-embed-text
    # does L2-normalise, so this approximation holds well in practice)
    results = []
    for row in rows:
        distance = float(row["distance"]) if row["distance"] is not None else 1.0
        score = max(0.0, 1.0 - distance)
        results.append(
            {
                "chunk_id": row["chunk_id"],
                "content": row["content"],
                "source": row["source"],
                "chunk_idx": row["chunk_idx"],
                "distance": distance,
                "score": score,
            }
        )

    return results


def print_results(results: list[dict]) -> None:
    """
    Print ranked retrieval results in a readable format for developer inspection.

    Each result is shown with its rank, similarity score, source file,
    and a truncated preview of the chunk content. The full content is
    shown if it is short enough to display without truncation.

    Parameters
    ----------
    results : list[dict]
        The ranked result dicts from vector_search().
    """
    if not results:
        print("\nNo results found. Have you run ingest.py?")
        return

    print(f"\nTop {len(results)} result(s):\n")
    print("=" * 70)

    for i, result in enumerate(results, 1):
        source = result["source"] or "(unknown)"
        # Show just the filename, not the full path, for readability
        import os
        source_display = os.path.basename(source)

        score_bar = "█" * int(result["score"] * 20) + "░" * (20 - int(result["score"] * 20))

        print(f"  Rank {i:>2}  |  Score: {result['score']:.4f}  [{score_bar}]")
        print(f"  Source: {source_display}  (chunk #{result['chunk_idx']})")
        print(f"  Distance: {result['distance']:.6f}")
        print()

        content = result["content"] or ""
        # Truncate long chunks for display; the full text is what the LLM gets
        if len(content) > 400:
            preview = content[:400] + " ... [truncated]"
        else:
            preview = content

        # Indent content lines for visual grouping
        for line in preview.splitlines():
            print(f"  {line}")
        print()
        print("-" * 70)

    print()


def main() -> None:
    """
    CLI entry point for the query debugging tool.

    Reads the query from sys.argv[1], runs the vector search, and prints
    results. Exits with a non-zero status code if required arguments are
    missing.
    """
    if len(sys.argv) < 2:
        print("Usage: python query.py <query> [top_k]")
        print('Example: python query.py "What is machine learning?"')
        sys.exit(1)

    query = sys.argv[1]
    top_k = int(sys.argv[2]) if len(sys.argv) > 2 else None

    cfg = load_config()
    if top_k is None:
        top_k = cfg.top_k

    db = TursoClient(cfg.turso_url, cfg.turso_token)
    ollama = OllamaClient(
        url=cfg.ollama_url,
        embedding_model=cfg.embedding_model,
        chat_model=cfg.chat_model,
    )

    if not ollama.is_available():
        print(
            f"[error] Ollama is not reachable at {cfg.ollama_url}.\n"
            "Please start it with:  ollama serve"
        )
        sys.exit(1)

    results = vector_search(query, db, ollama, top_k=top_k)
    print_results(results)


if __name__ == "__main__":
    main()
