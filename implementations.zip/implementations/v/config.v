﻿// config.v — The single source of truth for every knob in this RAG system.
// Change values here and every other module picks them up automatically.
// Think of RagConfig as the blueprint pinned to the wall of a workshop:
// all workers consult it before they pick up a tool.

module main

// RagConfig holds all tunable parameters for the RAG pipeline.
// Fields are grouped by concern: storage, model, retrieval, ingestion.
struct RagConfig {
	// --- Turso (libSQL) HTTP API ---
	turso_url   string // Base HTTP endpoint for the Turso database
	turso_token string // Bearer token used in the Authorization header

	// --- Ollama local inference ---
	ollama_url       string // Where Ollama listens (usually localhost)
	chat_model       string // The model used to generate final answers
	embedding_model  string // The model used to turn text into vectors
	embedding_dims   int    // Dimensionality output by the embedding model

	// --- Retrieval ---
	top_k int // How many nearest-neighbour chunks to pull per query

	// --- Ingestion ---
	docs_dir   string // Directory the ingestor walks looking for documents
	chunk_size int    // Soft target size (in chars) for each text chunk
}

// default_config returns a ready-to-use RagConfig wired to the shared
// Turso instance and the locally-running Ollama server.
// Callers that need different values can clone the struct and override fields.
fn default_config() RagConfig {
	return RagConfig{
		turso_url: 'https://your-db-name.turso.io'
		turso_token: 'your-turso-token-here'
		ollama_url: 'http://127.0.0.1:11434'
		chat_model: 'gemma3:1b'
		embedding_model: 'nomic-embed-text'
		embedding_dims: 768
		top_k: 5
		docs_dir: './docs'
		chunk_size: 512
	}
}
