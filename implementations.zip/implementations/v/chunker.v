// chunker.v — Slices long documents into bite-sized pieces that fit inside
// an embedding model's context window.
// Good chunking is the unsung hero of RAG: chunks that are too large blur
// meaning, while chunks that are too small lose context.  This chunker
// tries to respect the natural paragraph structure of a document and uses
// ALL-CAPS lines as section-boundary hints, the way an editor might use
// headings to break a manuscript into chapters.

module main

// Chunker holds the configuration that controls how text is split.
struct Chunker {
	chunk_size int // Soft maximum character count per chunk
	min_size   int // Minimum characters before a chunk is worth keeping
}

// new_chunker returns a Chunker configured from a RagConfig.
fn new_chunker(cfg RagConfig) Chunker {
	return Chunker{
		chunk_size: cfg.chunk_size
		min_size:   100
	}
}

// is_heading returns true when a trimmed line looks like an ALL-CAPS heading.
// We require at least three uppercase letters and no lowercase letters,
// which catches headings like "INTRODUCTION" or "CHAPTER ONE" while
// ignoring abbreviations inside a sentence.
fn is_heading(line string) bool {
	trimmed := line.trim_space()
	if trimmed.len < 3 {
		return false
	}
	mut upper_count := 0
	for ch in trimmed {
		// Presence of any lowercase letter disqualifies the line.
		if ch >= `a` && ch <= `z` {
			return false
		}
		if ch >= `A` && ch <= `Z` {
			upper_count++
		}
	}
	return upper_count >= 3
}

// chunk splits document text into overlapping-context chunks and attaches
// a source prefix so each chunk is self-contained when retrieved later.
// The splitting logic is:
//   1. Split on blank lines (\n\n) to get natural paragraphs.
//   2. Treat ALL-CAPS lines as hard section boundaries.
//   3. Accumulate paragraphs until the soft chunk_size limit is reached.
//   4. Discard any accumulated text shorter than min_size.
// source is the file path or document title that gets prepended to every chunk.
fn (c Chunker) chunk(text string, source string) []string {
	// Step 1 — split on double newlines to extract paragraphs.
	raw_paragraphs := text.split('\n\n')

	// Step 2 — further split at ALL-CAPS headings so they start fresh chunks.
	mut paragraphs := []string{}
	for para in raw_paragraphs {
		lines := para.split('\n')
		mut current_block := []string{}
		for line in lines {
			if is_heading(line) && current_block.len > 0 {
				// Flush the block accumulated before the heading.
				joined := current_block.join('\n').trim_space()
				if joined.len > 0 {
					paragraphs << joined
				}
				current_block = []string{}
			}
			current_block << line
		}
		if current_block.len > 0 {
			joined := current_block.join('\n').trim_space()
			if joined.len > 0 {
				paragraphs << joined
			}
		}
	}

	// Step 3 — accumulate paragraphs into chunks up to chunk_size chars.
	mut chunks := []string{}
	mut current := ''

	for para in paragraphs {
		if para.trim_space().len == 0 {
			continue
		}

		// If adding this paragraph would overflow, flush the current chunk first.
		if current.len > 0 && current.len + para.len + 2 > c.chunk_size {
			trimmed := current.trim_space()
			if trimmed.len >= c.min_size {
				// Prepend the source path so the chunk is self-describing.
				chunks << 'Source: ${source}\n\n${trimmed}'
			}
			current = ''
		}

		if current.len == 0 {
			current = para
		} else {
			current = '${current}\n\n${para}'
		}
	}

	// Flush whatever remains after the loop.
	if current.trim_space().len >= c.min_size {
		chunks << 'Source: ${source}\n\n${current.trim_space()}'
	}

	return chunks
}

// chunk_with_overlap works like chunk but carries the last sentence of
// each chunk into the beginning of the next, preventing retrieval from
// missing answers that span a chunk boundary.
// overlap_chars controls how many trailing characters of the previous
// chunk become the leading context for the next.
fn (c Chunker) chunk_with_overlap(text string, source string, overlap_chars int) []string {
	base_chunks := c.chunk(text, source)
	if base_chunks.len <= 1 {
		return base_chunks
	}

	mut overlapped := []string{}
	for i, ch in base_chunks {
		if i == 0 {
			overlapped << ch
			continue
		}
		// Grab the tail of the previous chunk (minus its "Source:" prefix line)
		// and prepend it as context.
		prev := base_chunks[i - 1]
		tail := if prev.len > overlap_chars {
			prev[prev.len - overlap_chars..]
		} else {
			prev
		}
		// Find a clean sentence boundary in the tail (period + space).
		mut boundary := 0
		idx := tail.index('. ')
		if idx != -1 {
			boundary = idx + 2
		}
		context_tail := tail[boundary..].trim_space()

		if context_tail.len > 0 {
			overlapped << '${ch}\n\n[continued: ${context_tail}]'
		} else {
			overlapped << ch
		}
	}

	return overlapped
}
