Module {
	name: 'rag'
	description: 'RAG system in V — Retrieval-Augmented Generation using Turso vector DB and Ollama'
	version: '0.1.0'
	license: 'MIT'
}
