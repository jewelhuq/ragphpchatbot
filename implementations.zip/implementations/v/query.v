﻿// query.v — Self-contained similarity search tool.
// Embeds a command-line question and retrieves the nearest chunks from Turso.
// No LLM is invoked — useful for inspecting what the retrieval stage would
// pass to the model.
//
// Run: v run query.v "your question here"
// Build: v -o query query.v

module main

import os
import net.http
import json

// ============================================================
// CONFIG
// ============================================================

struct RagConfig {
	turso_url        string
	turso_token      string
	ollama_url       string
	chat_model       string
	embedding_model  string
	embedding_dims   int
	top_k            int
	docs_dir         string
	chunk_size       int
}

fn default_config() RagConfig {
	return RagConfig{
		turso_url:       'https://your-db-name.turso.io'
		turso_token:     'your-turso-token-here'
		ollama_url:      'http://127.0.0.1:11434'
		chat_model:      'gemma3:1b'
		embedding_model: 'nomic-embed-text'
		embedding_dims:  768
		top_k:           5
		docs_dir:        './docs'
		chunk_size:      512
	}
}

// ============================================================
// TURSO CLIENT
// ============================================================

struct TursoArg {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoStatement {
	q      string     @[json: 'q']
	params []TursoArg @[json: 'params']
}

struct TursoRequestBody {
	requests []TursoStatement @[json: 'requests']
}

struct TursoCol {
	name string @[json: 'name']
}

struct TursoRowValue {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoResult {
	columns []TursoCol        @[json: 'columns']
	rows    [][]TursoRowValue @[json: 'rows']
}

struct TursoResponseItem {
	type_    string      @[json: 'type']
	response TursoResult @[json: 'response']
}

struct TursoResponse {
	results []TursoResponseItem @[json: 'results']
}

struct TursoClient {
	url   string
	token string
}

fn new_turso_client(cfg RagConfig) TursoClient {
	return TursoClient{ url: cfg.turso_url, token: cfg.turso_token }
}

fn (c TursoClient) pipeline_url() string {
	return '${c.url}/v2/pipeline'
}

fn (c TursoClient) build_body(sql string, params []string) string {
	mut args := []TursoArg{}
	for p in params { args << TursoArg{ type_: 'text', value: p } }
	return json.encode(TursoRequestBody{
		requests: [TursoStatement{ q: sql, params: args }]
	})
}

fn (c TursoClient) fetch_all(sql string, params []string) ![]map[string]string {
	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   c.build_body(sql, params)
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}
	resp := req.do() or { return error('Turso HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Turso status ${resp.status_code}: ${resp.body}')
	}
	parsed := json.decode(TursoResponse, resp.body) or {
		return error('Decode: ${err}')
	}
	if parsed.results.len == 0 { return []map[string]string{} }
	result := parsed.results[0].response
	mut rows := []map[string]string{}
	for row in result.rows {
		mut record := map[string]string{}
		for i, col in result.columns {
			if i < row.len { record[col.name] = row[i].value }
		}
		rows << record
	}
	return rows
}

fn (c TursoClient) vector_search(embedding []f64, top_k int) ![]map[string]string {
	mut parts := []string{}
	for v in embedding { parts << '${v:.8f}' }
	vec_json := '[${parts.join(',')}]'
	return c.fetch_all('
		SELECT source, chunk,
		       vector_distance_cos(embedding, vector32(?)) AS distance
		FROM   documents
		ORDER  BY vector_distance_cos(embedding, vector32(?)) ASC
		LIMIT  ?
	', [vec_json, vec_json, top_k.str()])
}

// ============================================================
// OLLAMA CLIENT
// ============================================================

struct EmbedRequest {
	model string @[json: 'model']
	input string @[json: 'input']
}

struct EmbedResponse {
	embeddings [][]f64 @[json: 'embeddings']
}

struct OllamaClient {
	url             string
	embedding_model string
}

fn new_ollama_client(cfg RagConfig) OllamaClient {
	return OllamaClient{ url: cfg.ollama_url, embedding_model: cfg.embedding_model }
}

fn (c OllamaClient) embed(text string) ![]f64 {
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/embed'
		data:   json.encode(EmbedRequest{ model: c.embedding_model, input: text })
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}
	resp := req.do() or { return error('Ollama HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Ollama status ${resp.status_code}')
	}
	parsed := json.decode(EmbedResponse, resp.body) or {
		return error('Decode: ${err}')
	}
	if parsed.embeddings.len == 0 { return error('Empty embeddings') }
	return parsed.embeddings[0]
}

// ============================================================
// MAIN
// ============================================================

// excerpt trims text to max_len chars, appending "..." if truncated.
fn excerpt(text string, max_len int) string {
	clean := text.trim_space()
	if clean.len <= max_len { return clean }
	return '${clean[..max_len]}...'
}

fn main() {
	if os.args.len < 2 {
		eprintln('Usage: query <question>')
		exit(1)
	}
	question := os.args[1..].join(' ')

	cfg    := default_config()
	ollama := new_ollama_client(cfg)
	db     := new_turso_client(cfg)

	println('=== RAG Similarity Search ===')
	println('Query: ${question}')
	println('Top-K: ${cfg.top_k}')
	println('')

	print('Embedding...')
	flush_stdout()
	embedding := ollama.embed(question) or {
		eprintln('\nFatal: ${err}')
		exit(1)
	}
	println(' done (${embedding.len} dims).')

	print('Searching...')
	flush_stdout()
	results := db.vector_search(embedding, cfg.top_k) or {
		eprintln('\nFatal: ${err}')
		exit(1)
	}
	println(' done.')
	println('')

	if results.len == 0 {
		println('No results. Run: v run ingest.v')
		exit(0)
	}

	println('--- Results (closest first) ---')
	println('')
	for i, row in results {
		source   := row['source'] or { 'unknown' }
		chunk    := row['chunk'] or { '' }
		distance := row['distance'] or { '?' }
		println('${i + 1}. Source  : ${source}')
		println('   Distance: ${distance}')
		println('   Excerpt : ${excerpt(chunk, 300)}')
		println('')
	}
}
