// cmd/query/main.v — A standalone similarity search tool.
// Given a question on the command line, this program embeds it,
// asks Turso for the nearest-neighbour chunks, and prints them ranked
// by cosine distance.  No language model is involved: you see the raw
// retrieved evidence, which is useful for debugging the knowledge base.
// Think of it as shining a torch into the index drawer and reading the
// cards the librarian filed.
//
// Usage:
//   v run cmd/query/main.v "What is the capital of France?"
//   ./query "What is the capital of France?"

module main

import os
import rag

fn main() {
	if os.args.len < 2 {
		eprintln('Usage: query <question>')
		eprintln('Example: ./query "What is retrieval-augmented generation?"')
		exit(1)
	}

	// Join all trailing arguments so the user does not have to quote spaces.
	question := os.args[1..].join(' ')

	cfg    := rag.default_config()
	ollama := rag.new_ollama_client(cfg)
	db     := rag.new_turso_client(cfg)

	println('=== RAG Similarity Search ===')
	println('Query : ${question}')
	println('Top-K : ${cfg.top_k}')
	println('')

	// Embed the question using the same model as the stored chunks.
	// A mismatch here (e.g. different model for query vs. index)
	// is the single most common cause of poor retrieval quality.
	print('Embedding query...')
	flush_stdout()

	embedding := ollama.embed(question) or {
		eprintln('\nFatal: could not embed query: ${err}')
		exit(1)
	}

	println(' done (${embedding.len} dims).')
	println('')

	// Run the vector search against the Turso ANN index.
	print('Searching...')
	flush_stdout()

	results := db.vector_search(embedding, cfg.top_k) or {
		eprintln('\nFatal: vector search failed: ${err}')
		exit(1)
	}

	println(' done.')
	println('')

	if results.len == 0 {
		println('No results found. Have you run the ingestor yet?')
		println('  v run cmd/ingest/main.v')
		exit(0)
	}

	// Display the results in a readable format.
	println('--- Results (closest first) ---')
	println('')

	for i, row in results {
		source   := row['source'] or { 'unknown' }
		chunk    := row['chunk'] or { '' }
		distance := row['distance'] or { '?' }

		println('${i + 1}. Source  : ${source}')
		println('   Distance: ${distance}')
		println('   Excerpt : ${excerpt(chunk, 300)}')
		println('')
	}
}

// excerpt trims a string to at most max_len characters and appends "..."
// if it was truncated, so long chunks do not flood the terminal.
fn excerpt(text string, max_len int) string {
	clean := text.trim_space()
	if clean.len <= max_len {
		return clean
	}
	return '${clean[..max_len]}...'
}
