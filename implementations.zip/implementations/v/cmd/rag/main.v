// cmd/rag/main.v — The full Retrieval-Augmented Generation pipeline in one shot.
// This program takes a question, retrieves the most relevant chunks from
// Turso, builds a grounded prompt, and streams the language model's answer
// to stdout token-by-token.
// It is the simplest possible end-to-end demo: one question in, one
// streamed answer out, no history, no conversation.
// Think of it as asking a well-read assistant a single question and
// watching them compose the answer live on a typewriter.
//
// Usage:
//   v run cmd/rag/main.v "What is retrieval-augmented generation?"
//   ./rag "How does the chunker split paragraphs?"

module main

import os
import rag

fn main() {
	if os.args.len < 2 {
		eprintln('Usage: rag <question>')
		eprintln('Example: ./rag "What is retrieval-augmented generation?"')
		exit(1)
	}

	question := os.args[1..].join(' ')

	cfg    := rag.default_config()
	ollama := rag.new_ollama_client(cfg)
	db     := rag.new_turso_client(cfg)

	println('=== RAG Pipeline ===')
	println('Question: ${question}')
	println('')

	// --- Retrieve ---
	print('[1/3] Embedding query...')
	flush_stdout()

	query_vec := ollama.embed(question) or {
		eprintln('\nFatal: embed failed: ${err}')
		exit(1)
	}
	println(' done.')

	print('[2/3] Searching knowledge base...')
	flush_stdout()

	results := db.vector_search(query_vec, cfg.top_k) or {
		eprintln('\nFatal: search failed: ${err}')
		exit(1)
	}
	println(' found ${results.len} chunk(s).')
	println('')

	if results.len == 0 {
		println('No relevant documents found. Run "v run cmd/ingest/main.v" first.')
		exit(0)
	}

	// --- Augment ---
	// Assemble a context block from the retrieved chunks.
	// The model will be instructed to answer only from this context,
	// reducing hallucination and grounding the answer in our documents.
	mut context_parts := []string{}
	for i, row in results {
		chunk  := row['chunk'] or { '' }
		source := row['source'] or { 'unknown' }
		context_parts << '[${i + 1}] (from ${source})\n${chunk}'
	}
	context_block := context_parts.join('\n\n---\n\n')

	system_prompt := "You are a helpful assistant.  Answer the user's question " +
		'using ONLY the information in the context sections below.  ' +
		'If the context does not contain the answer, say so honestly.\n\n' +
		'CONTEXT:\n${context_block}'

	messages := [
		rag.Message{
			role:    'system'
			content: system_prompt
		},
		rag.Message{
			role:    'user'
			content: question
		},
	]

	// --- Generate ---
	println('[3/3] Generating answer (streaming)...')
	println('─'.repeat(60))
	println('')

	ollama.chat_stream(messages, fn (chunk string) {
		print(chunk)
		flush_stdout()
	}) or {
		eprintln('\nFatal: generation failed: ${err}')
		exit(1)
	}

	// Ensure the final line ends cleanly.
	println('')
	println('')
	println('─'.repeat(60))
	println('Sources consulted:')
	for i, row in results {
		source   := row['source'] or { 'unknown' }
		distance := row['distance'] or { '?' }
		println('  ${i + 1}. ${source} (distance: ${distance})')
	}
}
