// cmd/ingest/main.v — The document ingestion pipeline entry point.
// This program walks a directory of documents, converts them to plain text,
// slices them into chunks, embeds each chunk with Ollama, and stores
// everything in Turso so the retrieval step can find them later.
// Think of it as the librarian who reads every new book, writes a summary
// card for each chapter, and files the cards in the index drawer.
//
// Usage:
//   v run cmd/ingest/main.v [docs_dir]
//   ./ingest [docs_dir]

module main

import os
import crypto.md5
import rag

fn main() {
	// Allow overriding the docs directory from the command line.
	cfg := rag.default_config()
	docs_dir := if os.args.len > 1 { os.args[1] } else { cfg.docs_dir }

	println('=== RAG Ingestor ===')
	println('Documents directory : ${docs_dir}')
	println('Turso               : ${cfg.turso_url}')
	println('Embedding model     : ${cfg.embedding_model} (${cfg.embedding_dims} dims)')
	println('')

	// --- Step 1: Ensure the database schema exists ---
	db := rag.new_turso_client(cfg)

	println('[1/4] Ensuring database schema...')
	db.create_table_if_not_exists(cfg.embedding_dims) or {
		eprintln('Fatal: could not create table: ${err}')
		exit(1)
	}
	db.create_vector_index_if_not_exists() or {
		// The index may already exist; log but do not abort.
		eprintln('Warning: could not create vector index: ${err}')
	}
	println('    Schema ready.')

	// --- Step 2: Discover documents ---
	println('[2/4] Scanning "${docs_dir}" for documents...')

	if !os.exists(docs_dir) {
		eprintln('Fatal: docs directory does not exist: ${docs_dir}')
		eprintln('Create the directory and place .txt / .md files inside it.')
		exit(1)
	}

	mut doc_paths := []string{}
	os.walk(docs_dir, fn [mut doc_paths] (path string) {
		if rag.is_supported_extension(path) {
			doc_paths << path
		}
	})

	if doc_paths.len == 0 {
		println('No supported documents found in "${docs_dir}".')
		println('Supported extensions: .txt .md .markdown .rst .log .pdf .docx')
		exit(0)
	}

	println('    Found ${doc_paths.len} document(s).')

	// --- Step 3: Parse, chunk, embed, store ---
	println('[3/4] Processing documents...')

	parser  := rag.new_document_parser()
	chunker := rag.new_chunker(cfg)
	ollama  := rag.new_ollama_client(cfg)

	mut total_chunks    := 0
	mut skipped_chunks  := 0
	mut inserted_chunks := 0
	mut failed_files    := 0

	for file_path in doc_paths {
		println('  Processing: ${file_path}')

		// Parse the file into plain text.
		text := parser.parse(file_path) or {
			eprintln('    Skipping (parse error): ${err}')
			failed_files++
			continue
		}

		// Slice into chunks.
		chunks := chunker.chunk(text, file_path)
		total_chunks += chunks.len

		for i, chunk_text in chunks {
			// Hash the chunk content to detect and skip duplicates.
			hash := md5.hexhash(chunk_text)

			already_exists := db.hash_exists(hash) or {
				eprintln('    Warning: hash check failed for chunk ${i}: ${err}')
				false
			}

			if already_exists {
				skipped_chunks++
				continue
			}

			// Embed the chunk — one Ollama call per chunk.
			embedding := ollama.embed(chunk_text) or {
				eprintln('    Warning: embedding failed for chunk ${i}: ${err}')
				continue
			}

			// Persist to Turso.
			db.insert_document(file_path, chunk_text, hash, embedding) or {
				eprintln('    Warning: insert failed for chunk ${i}: ${err}')
				continue
			}

			inserted_chunks++

			// Progress tick every 10 insertions.
			if inserted_chunks % 10 == 0 {
				print('    ... ${inserted_chunks} chunks inserted\r')
				flush_stdout()
			}
		}

		println('    Done: ${chunks.len} chunks (file complete).')
	}

	// --- Step 4: Summary report ---
	println('')
	println('[4/4] Ingestion complete.')
	println('    Total chunks    : ${total_chunks}')
	println('    Inserted        : ${inserted_chunks}')
	println('    Skipped (dupe)  : ${skipped_chunks}')
	println('    Failed files    : ${failed_files}')
	println('')
	println('Run "v run cmd/query/main.v <question>" to search the knowledge base.')
}
