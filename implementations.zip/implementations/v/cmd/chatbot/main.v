// cmd/chatbot/main.v — An interactive RAG-powered chatbot with conversation memory.
// Every user turn is embedded and used to retrieve fresh context from Turso;
// that context is injected into the system prompt alongside the full
// conversation history so the model can refer to earlier turns.
// The assistant's replies stream to the terminal as they are generated.
// Think of it as a reading-room librarian who remembers everything said
// in the session, fetches the right shelf of books before answering,
// and speaks one word at a time so you never wonder if they fell asleep.
//
// Usage:
//   v run cmd/chatbot/main.v
//   ./chatbot
// Type "exit" or "quit" to end the session.

module main

import os
import rag

// system_base is the fixed part of the system prompt that never changes.
// Retrieved context is appended to it before each turn.
const system_base = 'You are a knowledgeable assistant with access to a curated ' +
	'knowledge base.  Answer questions using ONLY the provided context. ' +
	'If you cannot answer from the context, say so clearly. ' +
	'Be concise but thorough.  Refer to previous messages when relevant.'

fn main() {
	cfg    := rag.default_config()
	ollama := rag.new_ollama_client(cfg)
	db     := rag.new_turso_client(cfg)

	println('=== RAG Chatbot ===')
	println('Model    : ${cfg.chat_model}')
	println('Embedder : ${cfg.embedding_model}')
	println('Top-K    : ${cfg.top_k}')
	println('Type "exit" or "quit" to end the session.')
	println('─'.repeat(60))
	println('')

	// history holds the full conversation so the model has multi-turn context.
	// The system message is rebuilt each turn (not stored here) because its
	// context section changes with every retrieval.
	mut history := []rag.Message{}

	// Main interaction loop — each iteration is one user/assistant exchange.
	for {
		// --- Prompt the user ---
		print('You: ')
		flush_stdout()

		user_input := os.input('').trim_space()

		if user_input.len == 0 {
			continue
		}

		if user_input.to_lower() in ['exit', 'quit', 'q', 'bye'] {
			println('\nGoodbye!')
			break
		}

		// --- Retrieve relevant context for this specific turn ---
		query_vec := ollama.embed(user_input) or {
			eprintln('Warning: could not embed question: ${err}')
			// Fall back to answering without retrieval rather than crashing.
			[]f64{}
		}

		mut context_block := ''
		if query_vec.len > 0 {
			results := db.vector_search(query_vec, cfg.top_k) or {
				eprintln('Warning: vector search failed: ${err}')
				[]map[string]string{}
			}

			if results.len > 0 {
				mut parts := []string{}
				for i, row in results {
					chunk  := row['chunk'] or { '' }
					source := row['source'] or { 'unknown' }
					parts << '[${i + 1}] (${source})\n${chunk}'
				}
				context_block = parts.join('\n\n---\n\n')
			}
		}

		// --- Build the message list for this turn ---
		// The system message is always first and carries the fresh context.
		system_content := if context_block.len > 0 {
			'${system_base}\n\nCONTEXT FOR THIS TURN:\n${context_block}'
		} else {
			system_base + '\n\n(No relevant context found for this question.)'
		}

		// Assemble: system + all prior history + the new user message.
		mut messages := []rag.Message{}
		messages << rag.Message{ role: 'system', content: system_content }
		messages << history
		messages << rag.Message{ role: 'user', content: user_input }

		// --- Stream the reply ---
		println('')
		print('Assistant: ')
		flush_stdout()

		mut full_reply := ''

		ollama.chat_stream(messages, fn [mut full_reply] (chunk string) {
			print(chunk)
			flush_stdout()
			full_reply += chunk
		}) or {
			eprintln('\nError during generation: ${err}')
			println('')
			continue
		}

		// Newline after the streamed reply.
		println('')
		println('')

		// --- Append this exchange to history ---
		// We store only the user/assistant pair, not the system message,
		// because the system message is rebuilt fresh each turn.
		history << rag.Message{ role: 'user',      content: user_input }
		history << rag.Message{ role: 'assistant', content: full_reply }

		// Cap history length to avoid overflowing the model's context window.
		// Keeping the last 20 messages (10 exchanges) is usually enough.
		if history.len > 20 {
			history = history[history.len - 20..]
		}
	}
}
