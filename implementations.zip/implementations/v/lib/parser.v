// parser.v — Reads documents from the filesystem and returns plain text
// that the chunker can work with.
// Different file formats require different extraction strategies.
// Right now plain text and Markdown are fully supported; PDF and DOCX
// stubs are provided so the module compiles and can be extended later
// without touching any other file.

module rag

import os

// DocumentParser knows how to open files and extract their textual content.
// Add new file-format handlers by extending the parse() match block below.
pub struct DocumentParser {}

// new_document_parser returns a fresh DocumentParser.
// There is no per-instance state; this is essentially a namespace.
pub fn new_document_parser() DocumentParser {
	return DocumentParser{}
}

// parse opens the file at file_path, detects its format by extension,
// and returns the full plain-text content as a string.
// Unsupported file types return an error rather than silently empty text,
// so the ingestor can log a warning and move on.
pub fn (p DocumentParser) parse(file_path string) !string {
	ext := os.file_ext(file_path).to_lower()

	match ext {
		'.txt', '.md', '.markdown', '.rst', '.log' {
			return p.parse_plain_text(file_path)
		}
		'.pdf' {
			return p.parse_pdf(file_path)
		}
		'.docx' {
			return p.parse_docx(file_path)
		}
		else {
			return error('Unsupported file type: ${ext} (file: ${file_path})')
		}
	}
}

// parse_plain_text reads the entire file content verbatim.
// This is the workhorse handler used for .txt, .md, and any other
// format that stores human-readable UTF-8 text directly on disk.
fn (p DocumentParser) parse_plain_text(file_path string) !string {
	content := os.read_file(file_path) or {
		return error('Could not read file "${file_path}": ${err}')
	}

	if content.trim_space().len == 0 {
		return error('File is empty: ${file_path}')
	}

	return content
}

// parse_pdf is a stub for PDF extraction.
// A full implementation would shell out to pdftotext (poppler-utils)
// or link against a PDF library.  For now it guides the operator toward
// the right tool rather than silently producing garbage.
fn (p DocumentParser) parse_pdf(file_path string) !string {
	// TODO: integrate pdftotext by calling os.execute() and capturing stdout.
	// result := os.execute('pdftotext "${file_path}" -')
	// if result.exit_code != 0 {
	//     return error('pdftotext failed: ${result.output}')
	// }
	// return result.output
	return error('PDF parsing not yet implemented. Install pdftotext (poppler-utils) ' +
		'and uncomment the implementation in parser.v. File: ${file_path}')
}

// parse_docx is a stub for Word document extraction.
// A full implementation would use docx2txt or unzip + XML parsing.
fn (p DocumentParser) parse_docx(file_path string) !string {
	// TODO: unzip the .docx, locate word/document.xml, strip XML tags.
	// result := os.execute('docx2txt "${file_path}" -')
	// if result.exit_code != 0 {
	//     return error('docx2txt failed: ${result.output}')
	// }
	// return result.output
	return error('DOCX parsing not yet implemented. Install docx2txt ' +
		'and uncomment the implementation in parser.v. File: ${file_path}')
}

// is_supported_extension returns true if the ingestor should attempt to
// parse this file, preventing needless error logs for binaries and images.
pub fn is_supported_extension(file_path string) bool {
	ext := os.file_ext(file_path).to_lower()
	supported := ['.txt', '.md', '.markdown', '.rst', '.log', '.pdf', '.docx']
	return ext in supported
}
