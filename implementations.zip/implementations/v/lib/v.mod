Module {
	name: 'rag'
	description: 'Shared library for the RAG system — config, Turso client, Ollama client, chunker, parser'
	version: '0.1.0'
	license: 'MIT'
}
