﻿// ingest.v — Self-contained document ingestion pipeline.
// This single file contains ALL code needed to walk a docs directory,
// parse files, chunk text, embed with Ollama, and store in Turso.
// Run it with: v run ingest.v [docs_dir]
// Or build:    v -o ingest ingest.v
//
// All shared types and helpers are inlined here so this file compiles
// standalone without needing the lib/ module on the module path.
// For the modular version, see cmd/ingest/main.v + lib/*.v

module main

import os
import net.http
import json
import crypto.md5

// ============================================================
// CONFIG
// ============================================================

struct RagConfig {
	turso_url        string
	turso_token      string
	ollama_url       string
	chat_model       string
	embedding_model  string
	embedding_dims   int
	top_k            int
	docs_dir         string
	chunk_size       int
}

fn default_config() RagConfig {
	return RagConfig{
		turso_url:       'https://your-db-name.turso.io'
		turso_token:     'your-turso-token-here'
		ollama_url:      'http://127.0.0.1:11434'
		chat_model:      'gemma3:1b'
		embedding_model: 'nomic-embed-text'
		embedding_dims:  768
		top_k:           5
		docs_dir:        './docs'
		chunk_size:      512
	}
}

// ============================================================
// TURSO CLIENT
// ============================================================

struct TursoArg {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoStatement {
	q      string     @[json: 'q']
	params []TursoArg @[json: 'params']
}

struct TursoRequestBody {
	requests []TursoStatement @[json: 'requests']
}

struct TursoCol {
	name string @[json: 'name']
}

struct TursoRowValue {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoResult {
	columns []TursoCol        @[json: 'columns']
	rows    [][]TursoRowValue @[json: 'rows']
}

struct TursoResponseItem {
	type_    string      @[json: 'type']
	response TursoResult @[json: 'response']
}

struct TursoResponse {
	results []TursoResponseItem @[json: 'results']
}

struct TursoClient {
	url   string
	token string
}

fn new_turso_client(cfg RagConfig) TursoClient {
	return TursoClient{ url: cfg.turso_url, token: cfg.turso_token }
}

fn (c TursoClient) pipeline_url() string {
	return '${c.url}/v2/pipeline'
}

fn (c TursoClient) build_body(sql string, params []string) string {
	mut args := []TursoArg{}
	for p in params {
		args << TursoArg{ type_: 'text', value: p }
	}
	return json.encode(TursoRequestBody{
		requests: [TursoStatement{ q: sql, params: args }]
	})
}

// execute sends any SQL statement that does not return rows.
fn (c TursoClient) execute(sql string, params []string) ! {
	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   c.build_body(sql, params)
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}
	resp := req.do() or { return error('Turso HTTP error: ${err}') }
	if resp.status_code != 200 {
		return error('Turso status ${resp.status_code}: ${resp.body}')
	}
}

// fetch_all runs a SELECT and returns rows as string maps.
fn (c TursoClient) fetch_all(sql string, params []string) ![]map[string]string {
	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   c.build_body(sql, params)
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}
	resp := req.do() or { return error('Turso HTTP error: ${err}') }
	if resp.status_code != 200 {
		return error('Turso status ${resp.status_code}: ${resp.body}')
	}
	parsed := json.decode(TursoResponse, resp.body) or {
		return error('Decode error: ${err}')
	}
	if parsed.results.len == 0 {
		return []map[string]string{}
	}
	result := parsed.results[0].response
	mut rows := []map[string]string{}
	for row in result.rows {
		mut record := map[string]string{}
		for i, col in result.columns {
			if i < row.len { record[col.name] = row[i].value }
		}
		rows << record
	}
	return rows
}

fn (c TursoClient) create_table(dims int) ! {
	c.execute('CREATE TABLE IF NOT EXISTS documents (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		source TEXT NOT NULL,
		chunk TEXT NOT NULL,
		hash TEXT NOT NULL UNIQUE,
		embedding F32_BLOB(${dims})
	)', []) or { return error('Create table: ${err}') }
}

fn (c TursoClient) create_index() ! {
	c.execute('CREATE INDEX IF NOT EXISTS documents_embedding_idx
		ON documents (libsql_vector_idx(embedding))', []) or {
		return error('Create index: ${err}')
	}
}

fn (c TursoClient) hash_exists(hash string) !bool {
	rows := c.fetch_all('SELECT id FROM documents WHERE hash = ? LIMIT 1', [hash]) or {
		return error('Hash check: ${err}')
	}
	return rows.len > 0
}

fn (c TursoClient) insert_document(source string, chunk string, hash string, embedding []f64) ! {
	mut parts := []string{}
	for v in embedding { parts << '${v:.8f}' }
	vec_json := '[${parts.join(',')}]'
	c.execute("INSERT OR IGNORE INTO documents (source, chunk, hash, embedding)
		VALUES (?, ?, ?, vector32(?))", [source, chunk, hash, vec_json]) or {
		return error('Insert: ${err}')
	}
}

// ============================================================
// OLLAMA CLIENT
// ============================================================

struct EmbedRequest {
	model string @[json: 'model']
	input string @[json: 'input']
}

struct EmbedResponse {
	embeddings [][]f64 @[json: 'embeddings']
}

struct OllamaClient {
	url             string
	embedding_model string
	chat_model      string
}

fn new_ollama_client(cfg RagConfig) OllamaClient {
	return OllamaClient{
		url:             cfg.ollama_url
		embedding_model: cfg.embedding_model
		chat_model:      cfg.chat_model
	}
}

// embed sends text to /api/embed and returns the float vector.
fn (c OllamaClient) embed(text string) ![]f64 {
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/embed'
		data:   json.encode(EmbedRequest{ model: c.embedding_model, input: text })
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}
	resp := req.do() or { return error('Ollama embed HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Ollama embed status ${resp.status_code}: ${resp.body}')
	}
	parsed := json.decode(EmbedResponse, resp.body) or {
		return error('Decode embed: ${err}')
	}
	if parsed.embeddings.len == 0 {
		return error('Empty embeddings')
	}
	return parsed.embeddings[0]
}

// ============================================================
// CHUNKER
// ============================================================

struct Chunker {
	chunk_size int
	min_size   int
}

fn new_chunker(cfg RagConfig) Chunker {
	return Chunker{ chunk_size: cfg.chunk_size, min_size: 100 }
}

// is_heading detects ALL-CAPS heading lines (at least 3 uppercase, no lowercase).
fn is_heading(line string) bool {
	t := line.trim_space()
	if t.len < 3 { return false }
	mut uc := 0
	for ch in t {
		if ch >= `a` && ch <= `z` { return false }
		if ch >= `A` && ch <= `Z` { uc++ }
	}
	return uc >= 3
}

// chunk splits text into source-prefixed chunks respecting paragraph boundaries.
fn (c Chunker) chunk(text string, source string) []string {
	raw := text.split('\n\n')
	mut paragraphs := []string{}
	for para in raw {
		lines := para.split('\n')
		mut block := []string{}
		for line in lines {
			if is_heading(line) && block.len > 0 {
				j := block.join('\n').trim_space()
				if j.len > 0 { paragraphs << j }
				block = []string{}
			}
			block << line
		}
		if block.len > 0 {
			j := block.join('\n').trim_space()
			if j.len > 0 { paragraphs << j }
		}
	}

	mut chunks := []string{}
	mut current := ''
	for para in paragraphs {
		if para.trim_space().len == 0 { continue }
		if current.len > 0 && current.len + para.len + 2 > c.chunk_size {
			t := current.trim_space()
			if t.len >= c.min_size { chunks << 'Source: ${source}\n\n${t}' }
			current = ''
		}
		current = if current.len == 0 { para } else { '${current}\n\n${para}' }
	}
	t := current.trim_space()
	if t.len >= c.min_size { chunks << 'Source: ${source}\n\n${t}' }
	return chunks
}

// ============================================================
// PARSER
// ============================================================

// is_supported_extension returns true for text-based file types.
fn is_supported_extension(path string) bool {
	ext := os.file_ext(path).to_lower()
	return ext in ['.txt', '.md', '.markdown', '.rst', '.log']
}

// parse_file reads a supported text file and returns its content.
fn parse_file(file_path string) !string {
	ext := os.file_ext(file_path).to_lower()
	match ext {
		'.txt', '.md', '.markdown', '.rst', '.log' {
			content := os.read_file(file_path) or {
				return error('Cannot read "${file_path}": ${err}')
			}
			if content.trim_space().len == 0 {
				return error('Empty file: ${file_path}')
			}
			return content
		}
		else {
			return error('Unsupported type: ${ext}')
		}
	}
}

// ============================================================
// MAIN
// ============================================================

// The ingestion pipeline: schema setup → document discovery → chunk → embed → store.
fn main() {
	cfg      := default_config()
	docs_dir := if os.args.len > 1 { os.args[1] } else { cfg.docs_dir }

	println('=== RAG Ingestor ===')
	println('Docs dir  : ${docs_dir}')
	println('Turso     : ${cfg.turso_url}')
	println('Embedder  : ${cfg.embedding_model} (${cfg.embedding_dims} dims)')
	println('')

	db     := new_turso_client(cfg)
	ollama := new_ollama_client(cfg)

	// --- 1. Schema ---
	println('[1/4] Ensuring schema...')
	db.create_table(cfg.embedding_dims) or {
		eprintln('Fatal: ${err}')
		exit(1)
	}
	db.create_index() or {
		eprintln('Warning (index): ${err}')
	}
	println('    Ready.')

	// --- 2. Discover documents ---
	println('[2/4] Scanning "${docs_dir}"...')
	if !os.exists(docs_dir) {
		eprintln('Fatal: directory not found: ${docs_dir}')
		exit(1)
	}
	mut doc_paths := []string{}
	os.walk(docs_dir, fn [mut doc_paths] (path string) {
		if is_supported_extension(path) { doc_paths << path }
	})
	if doc_paths.len == 0 {
		println('No supported documents found (.txt .md .rst .log).')
		exit(0)
	}
	println('    Found ${doc_paths.len} file(s).')

	// --- 3. Process ---
	println('[3/4] Processing...')
	chunker := new_chunker(cfg)
	mut total := 0
	mut inserted := 0
	mut skipped := 0
	mut failed := 0

	for file_path in doc_paths {
		println('  File: ${file_path}')
		text := parse_file(file_path) or {
			eprintln('    Skip: ${err}')
			failed++
			continue
		}
		chunks := chunker.chunk(text, file_path)
		total += chunks.len

		for i, chunk_text in chunks {
			hash := md5.hexhash(chunk_text)
			exists := db.hash_exists(hash) or { false }
			if exists { skipped++; continue }

			embedding := ollama.embed(chunk_text) or {
				eprintln('    Embed error chunk ${i}: ${err}')
				continue
			}
			db.insert_document(file_path, chunk_text, hash, embedding) or {
				eprintln('    Insert error chunk ${i}: ${err}')
				continue
			}
			inserted++
			if inserted % 10 == 0 {
				print('    ${inserted} inserted...\r')
				flush_stdout()
			}
		}
		println('    ${chunks.len} chunks processed.')
	}

	// --- 4. Summary ---
	println('')
	println('[4/4] Done.')
	println('    Total   : ${total}')
	println('    Inserted: ${inserted}')
	println('    Skipped : ${skipped}')
	println('    Failed  : ${failed}')

}
