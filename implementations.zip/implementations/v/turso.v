// turso.v — A thin HTTP client for Turso's libSQL REST API.
// Turso speaks HTTP/JSON: you POST a batch of SQL statements and receive
// a JSON envelope containing rows, affected counts, and any errors.
// This file encapsulates the wire protocol so the rest of the codebase
// can think in plain SQL without worrying about JSON envelopes.

module main

import net.http
import json

// --- Wire-format structs (what Turso actually sends back) ---

// TursoArg represents a single bound parameter in a SQL statement.
// Turso uses typed values; we always send strings and let SQLite coerce.
struct TursoArg {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

// TursoStatement is one SQL statement in the pipeline request body.
struct TursoStatement {
	q      string      @[json: 'q']
	params []TursoArg  @[json: 'params']
}

// TursoRequestBody is the top-level object POSTed to /pipeline.
struct TursoRequestBody {
	requests []TursoStatement @[json: 'requests']
}

// TursoCol describes a column header returned by Turso.
struct TursoCol {
	name string @[json: 'name']
}

// TursoRowValue is a single cell value in a result row.
struct TursoRowValue {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

// TursoResult holds the payload for one statement in the response batch.
struct TursoResult {
	columns []TursoCol      @[json: 'columns']
	rows    [][]TursoRowValue @[json: 'rows']
}

// TursoResponseItem wraps one result or error from the pipeline response.
struct TursoResponseItem {
	type_   string      @[json: 'type']
	response TursoResult @[json: 'response']
}

// TursoResponse is the full JSON body returned by /pipeline.
struct TursoResponse {
	results []TursoResponseItem @[json: 'results']
}

// --- Client ---

// TursoClient holds the credentials and base URL needed to talk to Turso.
// Create one via new_turso_client() and reuse it across the whole session.
struct TursoClient {
	url   string // e.g. https://my-db.turso.io
	token string // Bearer JWT issued by Turso
}

// new_turso_client is the preferred constructor for TursoClient.
// It wires the URL and token from a RagConfig in one call.
fn new_turso_client(cfg RagConfig) TursoClient {
	return TursoClient{
		url:   cfg.turso_url
		token: cfg.turso_token
	}
}

// pipeline_url returns the full endpoint for the libSQL pipeline API.
// Every request, whether a DDL statement or a SELECT, goes here.
fn (c TursoClient) pipeline_url() string {
	return '${c.url}/v2/pipeline'
}

// build_request_body serialises a SQL statement and its positional params
// into the JSON envelope that Turso expects.
// All params are sent as text; SQLite's flexible typing handles coercion.
fn (c TursoClient) build_request_body(sql string, params []string) string {
	mut args := []TursoArg{}
	for p in params {
		args << TursoArg{
			type_: 'text'
			value: p
		}
	}
	body := TursoRequestBody{
		requests: [TursoStatement{
			q:      sql
			params: args
		}]
	}
	return json.encode(body)
}

// execute sends a write statement (INSERT / CREATE / UPDATE / DELETE) to
// Turso and returns nothing on success, or an error if the HTTP call
// or the server response indicates a problem.
// Use this for any SQL that does not return rows.
fn (c TursoClient) execute(sql string, params []string) ! {
	body := c.build_request_body(sql, params)

	// Build the request manually so we can attach the Authorization header.
	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   body
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}

	resp := req.do() or { return error('Turso HTTP error: ${err}') }

	if resp.status_code != 200 {
		return error('Turso returned status ${resp.status_code}: ${resp.body}')
	}

	// A 200 with an error payload is still a failure — check for it.
	if resp.body.contains('"error"') && resp.body.contains('"message"') {
		return error('Turso SQL error: ${resp.body}')
	}
}

// fetch_all sends a SELECT statement and returns every row as a map from
// column name to cell value (both as strings).  The caller can then cast
// values as needed.
// Returns an empty slice if the query matched no rows.
fn (c TursoClient) fetch_all(sql string, params []string) ![]map[string]string {
	body := c.build_request_body(sql, params)

	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   body
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}

	resp := req.do() or { return error('Turso HTTP error: ${err}') }

	if resp.status_code != 200 {
		return error('Turso returned status ${resp.status_code}: ${resp.body}')
	}

	// Parse the outer envelope.
	turso_resp := json.decode(TursoResponse, resp.body) or {
		return error('Failed to decode Turso response: ${err}')
	}

	if turso_resp.results.len == 0 {
		return []map[string]string{}
	}

	result := turso_resp.results[0].response

	// Stitch columns and rows together into friendly maps.
	mut rows := []map[string]string{}
	for row in result.rows {
		mut record := map[string]string{}
		for i, col in result.columns {
			if i < row.len {
				record[col.name] = row[i].value
			}
		}
		rows << record
	}

	return rows
}

// create_table_if_not_exists ensures the documents table with a
// vector32 column exists.  Safe to call on every startup.
fn (c TursoClient) create_table_if_not_exists(dims int) ! {
	// The embedding column uses Turso's vector32() type which stores
	// a fixed-length float32 array and supports ANN index creation.
	c.execute('
		CREATE TABLE IF NOT EXISTS documents (
			id        INTEGER PRIMARY KEY AUTOINCREMENT,
			source    TEXT    NOT NULL,
			chunk     TEXT    NOT NULL,
			hash      TEXT    NOT NULL UNIQUE,
			embedding F32_BLOB(${dims})
		)
	', []) or { return error('Failed to create table: ${err}') }
}

// create_vector_index_if_not_exists builds the libsql_vector_idx that
// powers nearest-neighbour search.  The IGNORE clause makes it idempotent.
fn (c TursoClient) create_vector_index_if_not_exists() ! {
	c.execute("
		CREATE INDEX IF NOT EXISTS documents_embedding_idx
		ON documents (libsql_vector_idx(embedding))
	", []) or { return error('Failed to create vector index: ${err}') }
}

// hash_exists returns true if a chunk with the given MD5 hash is already
// stored in the database, allowing the ingestor to skip duplicates.
fn (c TursoClient) hash_exists(hash string) !bool {
	rows := c.fetch_all('SELECT id FROM documents WHERE hash = ? LIMIT 1', [hash]) or {
		return error('Hash check failed: ${err}')
	}
	return rows.len > 0
}

// insert_document stores a chunk together with its embedding vector.
// The vector is serialised as a JSON float array wrapped in vector32().
fn (c TursoClient) insert_document(source string, chunk string, hash string, embedding []f64) ! {
	// Build the compact JSON float array that vector32() expects.
	mut parts := []string{}
	for v in embedding {
		// Format each float with enough precision to round-trip faithfully.
		parts << '${v:.8f}'
	}
	vec_json := '[${parts.join(',')}]'

	c.execute("
		INSERT OR IGNORE INTO documents (source, chunk, hash, embedding)
		VALUES (?, ?, ?, vector32(?))
	", [source, chunk, hash, vec_json]) or {
		return error('Insert failed: ${err}')
	}
}

// vector_search runs an ANN lookup against the stored embeddings and
// returns the top-k most similar chunks together with their source paths.
// The query vector must be the same dimensionality as the stored ones.
fn (c TursoClient) vector_search(embedding []f64, top_k int) ![]map[string]string {
	mut parts := []string{}
	for v in embedding {
		parts << '${v:.8f}'
	}
	vec_json := '[${parts.join(',')}]'

	rows := c.fetch_all("
		SELECT source, chunk,
		       vector_distance_cos(embedding, vector32(?)) AS distance
		FROM   documents
		ORDER  BY vector_distance_cos(embedding, vector32(?)) ASC
		LIMIT  ?
	", [vec_json, vec_json, top_k.str()]) or {
		return error('Vector search failed: ${err}')
	}

	return rows
}
