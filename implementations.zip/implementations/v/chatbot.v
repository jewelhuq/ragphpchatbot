﻿// chatbot.v — Self-contained interactive RAG chatbot with streaming output.
// Maintains conversation history across turns; retrieves fresh context per
// question; streams each reply token-by-token.
//
// Run: v run chatbot.v
// Build: v -o chatbot chatbot.v
// Type "exit" or "quit" to leave.

module main

import os
import net.http
import json
import strings

// ============================================================
// CONFIG
// ============================================================

struct RagConfig {
	turso_url        string
	turso_token      string
	ollama_url       string
	chat_model       string
	embedding_model  string
	embedding_dims   int
	top_k            int
	docs_dir         string
	chunk_size       int
}

fn default_config() RagConfig {
	return RagConfig{
		turso_url:       'https://your-db-name.turso.io'
		turso_token:     'your-turso-token-here'
		ollama_url:      'http://127.0.0.1:11434'
		chat_model:      'gemma3:1b'
		embedding_model: 'nomic-embed-text'
		embedding_dims:  768
		top_k:           5
		docs_dir:        './docs'
		chunk_size:      512
	}
}

// ============================================================
// TURSO CLIENT
// ============================================================

struct TursoArg {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoStatement {
	q      string     @[json: 'q']
	params []TursoArg @[json: 'params']
}

struct TursoRequestBody {
	requests []TursoStatement @[json: 'requests']
}

struct TursoCol {
	name string @[json: 'name']
}

struct TursoRowValue {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoResult {
	columns []TursoCol        @[json: 'columns']
	rows    [][]TursoRowValue @[json: 'rows']
}

struct TursoResponseItem {
	type_    string      @[json: 'type']
	response TursoResult @[json: 'response']
}

struct TursoResponse {
	results []TursoResponseItem @[json: 'results']
}

struct TursoClient {
	url   string
	token string
}

fn new_turso_client(cfg RagConfig) TursoClient {
	return TursoClient{ url: cfg.turso_url, token: cfg.turso_token }
}

fn (c TursoClient) pipeline_url() string {
	return '${c.url}/v2/pipeline'
}

fn (c TursoClient) build_body(sql string, params []string) string {
	mut args := []TursoArg{}
	for p in params { args << TursoArg{ type_: 'text', value: p } }
	return json.encode(TursoRequestBody{
		requests: [TursoStatement{ q: sql, params: args }]
	})
}

fn (c TursoClient) fetch_all(sql string, params []string) ![]map[string]string {
	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   c.build_body(sql, params)
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}
	resp := req.do() or { return error('Turso HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Turso status ${resp.status_code}: ${resp.body}')
	}
	parsed := json.decode(TursoResponse, resp.body) or {
		return error('Decode: ${err}')
	}
	if parsed.results.len == 0 { return []map[string]string{} }
	result := parsed.results[0].response
	mut rows := []map[string]string{}
	for row in result.rows {
		mut record := map[string]string{}
		for i, col in result.columns {
			if i < row.len { record[col.name] = row[i].value }
		}
		rows << record
	}
	return rows
}

fn (c TursoClient) vector_search(embedding []f64, top_k int) ![]map[string]string {
	mut parts := []string{}
	for v in embedding { parts << '${v:.8f}' }
	vec_json := '[${parts.join(',')}]'
	return c.fetch_all('
		SELECT source, chunk,
		       vector_distance_cos(embedding, vector32(?)) AS distance
		FROM   documents
		ORDER  BY vector_distance_cos(embedding, vector32(?)) ASC
		LIMIT  ?
	', [vec_json, vec_json, top_k.str()])
}

// ============================================================
// OLLAMA CLIENT
// ============================================================

struct EmbedRequest {
	model string @[json: 'model']
	input string @[json: 'input']
}

struct EmbedResponse {
	embeddings [][]f64 @[json: 'embeddings']
}

// Message is one turn in the conversation (role: system / user / assistant).
struct Message {
	role    string @[json: 'role']
	content string @[json: 'content']
}

struct ChatRequest {
	model    string    @[json: 'model']
	messages []Message @[json: 'messages']
	stream   bool      @[json: 'stream']
}

struct ChatChunkMessage {
	content string @[json: 'content']
}

struct ChatChunk {
	message ChatChunkMessage @[json: 'message']
	done    bool              @[json: 'done']
}

struct OllamaClient {
	url             string
	embedding_model string
	chat_model      string
}

fn new_ollama_client(cfg RagConfig) OllamaClient {
	return OllamaClient{
		url:             cfg.ollama_url
		embedding_model: cfg.embedding_model
		chat_model:      cfg.chat_model
	}
}

fn (c OllamaClient) embed(text string) ![]f64 {
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/embed'
		data:   json.encode(EmbedRequest{ model: c.embedding_model, input: text })
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}
	resp := req.do() or { return error('Ollama embed: ${err}') }
	if resp.status_code != 200 {
		return error('Ollama status ${resp.status_code}')
	}
	parsed := json.decode(EmbedResponse, resp.body) or {
		return error('Decode embed: ${err}')
	}
	if parsed.embeddings.len == 0 { return error('Empty embeddings') }
	return parsed.embeddings[0]
}

// chat_stream calls on_chunk for each token and accumulates the full reply.
fn (c OllamaClient) chat_stream(messages []Message, on_chunk fn (string)) !string {
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/chat'
		data:   json.encode(ChatRequest{ model: c.chat_model, messages: messages, stream: true })
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}
	resp := req.do() or { return error('Ollama chat: ${err}') }
	if resp.status_code != 200 {
		return error('Ollama status ${resp.status_code}: ${resp.body}')
	}
	mut builder := strings.new_builder(512)
	for line in resp.body.split('\n') {
		t := line.trim_space()
		if t.len == 0 { continue }
		chunk := json.decode(ChatChunk, t) or { continue }
		content := chunk.message.content
		if content.len > 0 {
			on_chunk(content)
			builder.write_string(content)
		}
		if chunk.done { break }
	}
	return builder.str()
}

// ============================================================
// MAIN
// ============================================================

// system_base is the constant instruction part of the system prompt.
// The retrieved context section is appended fresh each turn.
const system_base = 'You are a knowledgeable assistant with access to a curated ' +
	'knowledge base.  Answer questions using ONLY the provided context. ' +
	'If you cannot answer from the context, say so clearly. ' +
	'Be concise but thorough.  Refer to previous messages when relevant.'

fn main() {
	cfg    := default_config()
	ollama := new_ollama_client(cfg)
	db     := new_turso_client(cfg)

	println('=== RAG Chatbot ===')
	println('Model    : ${cfg.chat_model}')
	println('Embedder : ${cfg.embedding_model}')
	println('Top-K    : ${cfg.top_k}')
	println('Type "exit" or "quit" to leave.')
	println('─'.repeat(60))
	println('')

	// history stores all prior user/assistant turns for multi-turn context.
	// The system message is NOT stored here — it is rebuilt each turn.
	mut history := []Message{}

	for {
		print('You: ')
		flush_stdout()

		user_input := os.input('').trim_space()
		if user_input.len == 0 { continue }
		if user_input.to_lower() in ['exit', 'quit', 'q', 'bye'] {
			println('\nGoodbye!')
			break
		}

		// --- Retrieve context for this question ---
		query_vec := ollama.embed(user_input) or {
			eprintln('Warning: embed failed: ${err}')
			[]f64{}
		}

		mut context_block := ''
		if query_vec.len > 0 {
			results := db.vector_search(query_vec, cfg.top_k) or {
				eprintln('Warning: search failed: ${err}')
				[]map[string]string{}
			}
			if results.len > 0 {
				mut parts := []string{}
				for i, row in results {
					chunk  := row['chunk'] or { '' }
					source := row['source'] or { 'unknown' }
					parts << '[${i + 1}] (${source})\n${chunk}'
				}
				context_block = parts.join('\n\n---\n\n')
			}
		}

		// --- Build this turn's message list ---
		system_content := if context_block.len > 0 {
			'${system_base}\n\nCONTEXT FOR THIS TURN:\n${context_block}'
		} else {
			system_base + '\n\n(No relevant context found.)'
		}

		mut messages := []Message{}
		messages << Message{ role: 'system', content: system_content }
		messages << history
		messages << Message{ role: 'user', content: user_input }

		// --- Stream reply ---
		println('')
		print('Assistant: ')
		flush_stdout()

		full_reply := ollama.chat_stream(messages, fn (chunk string) {
			print(chunk)
			flush_stdout()
		}) or {
			eprintln('\nError: ${err}')
			println('')
			continue
		}

		println('')
		println('')

		// --- Extend history, cap at 20 messages (10 exchanges) ---
		history << Message{ role: 'user',      content: user_input }
		history << Message{ role: 'assistant', content: full_reply }
		if history.len > 20 {
			history = history[history.len - 20..]
		}
	}
}
