// ollama.v — Speaks the Ollama REST API on behalf of the whole RAG system.
// Two responsibilities live here: turning text into embedding vectors for
// retrieval, and streaming chat completions token-by-token so the user
// sees output as it is generated rather than waiting for the whole answer.
// Think of OllamaClient as the switchboard operator who routes every AI
// request to the right Ollama endpoint and relays the reply back.

module main

import net.http
import json
import strings

// --- Wire-format structs ---

// EmbedRequest is the JSON body sent to /api/embed.
struct EmbedRequest {
	model  string   @[json: 'model']
	input  string   @[json: 'input']
}

// EmbedResponse is the JSON body returned by /api/embed.
// Ollama nests the vectors under an "embeddings" key (plural, 2-D array).
struct EmbedResponse {
	embeddings [][]f64 @[json: 'embeddings']
}

// Message represents one turn in a conversation history.
// Ollama chat uses role/content pairs compatible with OpenAI's format.
struct Message {
	role    string @[json: 'role']
	content string @[json: 'content']
}

// ChatRequest is the JSON body sent to /api/chat.
// Setting stream to true makes Ollama return newline-delimited JSON chunks.
struct ChatRequest {
	model    string    @[json: 'model']
	messages []Message @[json: 'messages']
	stream   bool      @[json: 'stream']
}

// ChatChunk is one newline-delimited JSON object in the streaming response.
// Ollama emits many of these; the last one has done == true.
struct ChatChunkMessage {
	content string @[json: 'content']
}

struct ChatChunk {
	message ChatChunkMessage @[json: 'message']
	done    bool              @[json: 'done']
}

// --- Client ---

// OllamaClient holds everything needed to reach a running Ollama instance.
// Create one via new_ollama_client() and reuse it throughout a session.
struct OllamaClient {
	url             string // Base URL, e.g. http://127.0.0.1:11434
	embedding_model string // Model name for /api/embed
	chat_model      string // Model name for /api/chat
}

// new_ollama_client constructs an OllamaClient from the shared RagConfig.
fn new_ollama_client(cfg RagConfig) OllamaClient {
	return OllamaClient{
		url:             cfg.ollama_url
		embedding_model: cfg.embedding_model
		chat_model:      cfg.chat_model
	}
}

// embed sends text to Ollama's embedding endpoint and returns the
// resulting float64 vector.  The vector dimension is fixed by the model
// (768 for nomic-embed-text).  Returns an error if the network call fails
// or the response cannot be decoded.
fn (c OllamaClient) embed(text string) ![]f64 {
	req_body := json.encode(EmbedRequest{
		model: c.embedding_model
		input: text
	})

	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/embed'
		data:   req_body
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}

	resp := req.do() or { return error('Ollama embed HTTP error: ${err}') }

	if resp.status_code != 200 {
		return error('Ollama embed returned status ${resp.status_code}: ${resp.body}')
	}

	embed_resp := json.decode(EmbedResponse, resp.body) or {
		return error('Failed to decode embed response: ${err}')
	}

	if embed_resp.embeddings.len == 0 {
		return error('Ollama returned empty embeddings array')
	}

	// Ollama returns a 2-D array; we always send one string so index 0 is ours.
	return embed_resp.embeddings[0]
}

// chat_stream sends a full conversation history to Ollama in streaming mode
// and calls on_chunk for each token fragment as it arrives.
// This gives the user a typewriter effect instead of a long wait.
// The function blocks until the stream is complete or an error occurs.
fn (c OllamaClient) chat_stream(messages []Message, on_chunk fn (string)) ! {
	req_body := json.encode(ChatRequest{
		model:    c.chat_model
		messages: messages
		stream:   true
	})

	// We use http.fetch with the raw response body so we can read it
	// line-by-line ourselves — V's http module does not yet expose a
	// true streaming reader, so we collect the full body and split on \n.
	// For very long responses this is still fast because we process each
	// line as soon as we have the whole body, and Ollama is local.
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/chat'
		data:   req_body
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}

	resp := req.do() or { return error('Ollama chat HTTP error: ${err}') }

	if resp.status_code != 200 {
		return error('Ollama chat returned status ${resp.status_code}: ${resp.body}')
	}

	// Walk each newline-delimited JSON chunk and call the callback.
	lines := resp.body.split('\n')
	for line in lines {
		trimmed := line.trim_space()
		if trimmed.len == 0 {
			continue
		}

		chunk := json.decode(ChatChunk, trimmed) or {
			// Some lines may be non-JSON status messages; skip them gracefully.
			continue
		}

		content := chunk.message.content
		if content.len > 0 {
			on_chunk(content)
		}

		if chunk.done {
			break
		}
	}
}

// chat returns the complete assistant reply as a single string by
// accumulating all streaming chunks internally.
// Useful when the caller needs the full text before proceeding.
fn (c OllamaClient) chat(messages []Message) !string {
	mut builder := strings.new_builder(512)

	c.chat_stream(messages, fn [mut builder] (chunk string) {
		builder.write_string(chunk)
	}) or { return error('Chat failed: ${err}') }

	return builder.str()
}
