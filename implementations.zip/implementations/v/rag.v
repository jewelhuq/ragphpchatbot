﻿// rag.v — Self-contained one-shot RAG pipeline.
// Takes a question, retrieves relevant chunks, augments a prompt with them,
// and streams the LLM's grounded answer to stdout.
//
// Run: v run rag.v "your question"
// Build: v -o rag rag.v

module main

import os
import net.http
import json

// ============================================================
// CONFIG
// ============================================================

struct RagConfig {
	turso_url        string
	turso_token      string
	ollama_url       string
	chat_model       string
	embedding_model  string
	embedding_dims   int
	top_k            int
	docs_dir         string
	chunk_size       int
}

fn default_config() RagConfig {
	return RagConfig{
		turso_url:       'https://your-db-name.turso.io'
		turso_token:     'your-turso-token-here'
		ollama_url:      'http://127.0.0.1:11434'
		chat_model:      'gemma3:1b'
		embedding_model: 'nomic-embed-text'
		embedding_dims:  768
		top_k:           5
		docs_dir:        './docs'
		chunk_size:      512
	}
}

// ============================================================
// TURSO CLIENT
// ============================================================

struct TursoArg {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoStatement {
	q      string     @[json: 'q']
	params []TursoArg @[json: 'params']
}

struct TursoRequestBody {
	requests []TursoStatement @[json: 'requests']
}

struct TursoCol {
	name string @[json: 'name']
}

struct TursoRowValue {
	type_  string @[json: 'type']
	value  string @[json: 'value']
}

struct TursoResult {
	columns []TursoCol        @[json: 'columns']
	rows    [][]TursoRowValue @[json: 'rows']
}

struct TursoResponseItem {
	type_    string      @[json: 'type']
	response TursoResult @[json: 'response']
}

struct TursoResponse {
	results []TursoResponseItem @[json: 'results']
}

struct TursoClient {
	url   string
	token string
}

fn new_turso_client(cfg RagConfig) TursoClient {
	return TursoClient{ url: cfg.turso_url, token: cfg.turso_token }
}

fn (c TursoClient) pipeline_url() string {
	return '${c.url}/v2/pipeline'
}

fn (c TursoClient) build_body(sql string, params []string) string {
	mut args := []TursoArg{}
	for p in params { args << TursoArg{ type_: 'text', value: p } }
	return json.encode(TursoRequestBody{
		requests: [TursoStatement{ q: sql, params: args }]
	})
}

fn (c TursoClient) fetch_all(sql string, params []string) ![]map[string]string {
	mut req := http.Request{
		method: .post
		url:    c.pipeline_url()
		data:   c.build_body(sql, params)
		header: http.new_header_from_map({
			http.CommonHeader.content_type:  'application/json'
			http.CommonHeader.authorization: 'Bearer ${c.token}'
		})
	}
	resp := req.do() or { return error('Turso HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Turso status ${resp.status_code}: ${resp.body}')
	}
	parsed := json.decode(TursoResponse, resp.body) or {
		return error('Decode: ${err}')
	}
	if parsed.results.len == 0 { return []map[string]string{} }
	result := parsed.results[0].response
	mut rows := []map[string]string{}
	for row in result.rows {
		mut record := map[string]string{}
		for i, col in result.columns {
			if i < row.len { record[col.name] = row[i].value }
		}
		rows << record
	}
	return rows
}

fn (c TursoClient) vector_search(embedding []f64, top_k int) ![]map[string]string {
	mut parts := []string{}
	for v in embedding { parts << '${v:.8f}' }
	vec_json := '[${parts.join(',')}]'
	return c.fetch_all('
		SELECT source, chunk,
		       vector_distance_cos(embedding, vector32(?)) AS distance
		FROM   documents
		ORDER  BY vector_distance_cos(embedding, vector32(?)) ASC
		LIMIT  ?
	', [vec_json, vec_json, top_k.str()])
}

// ============================================================
// OLLAMA CLIENT
// ============================================================

struct EmbedRequest {
	model string @[json: 'model']
	input string @[json: 'input']
}

struct EmbedResponse {
	embeddings [][]f64 @[json: 'embeddings']
}

struct Message {
	role    string @[json: 'role']
	content string @[json: 'content']
}

struct ChatRequest {
	model    string    @[json: 'model']
	messages []Message @[json: 'messages']
	stream   bool      @[json: 'stream']
}

struct ChatChunkMessage {
	content string @[json: 'content']
}

struct ChatChunk {
	message ChatChunkMessage @[json: 'message']
	done    bool              @[json: 'done']
}

struct OllamaClient {
	url             string
	embedding_model string
	chat_model      string
}

fn new_ollama_client(cfg RagConfig) OllamaClient {
	return OllamaClient{
		url:             cfg.ollama_url
		embedding_model: cfg.embedding_model
		chat_model:      cfg.chat_model
	}
}

fn (c OllamaClient) embed(text string) ![]f64 {
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/embed'
		data:   json.encode(EmbedRequest{ model: c.embedding_model, input: text })
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}
	resp := req.do() or { return error('Ollama embed HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Ollama embed status ${resp.status_code}')
	}
	parsed := json.decode(EmbedResponse, resp.body) or {
		return error('Decode embed: ${err}')
	}
	if parsed.embeddings.len == 0 { return error('Empty embeddings') }
	return parsed.embeddings[0]
}

// chat_stream POSTs to /api/chat with stream=true and calls on_chunk per token.
fn (c OllamaClient) chat_stream(messages []Message, on_chunk fn (string)) ! {
	mut req := http.Request{
		method: .post
		url:    '${c.url}/api/chat'
		data:   json.encode(ChatRequest{ model: c.chat_model, messages: messages, stream: true })
		header: http.new_header_from_map({
			http.CommonHeader.content_type: 'application/json'
		})
	}
	resp := req.do() or { return error('Ollama chat HTTP: ${err}') }
	if resp.status_code != 200 {
		return error('Ollama chat status ${resp.status_code}: ${resp.body}')
	}
	for line in resp.body.split('\n') {
		t := line.trim_space()
		if t.len == 0 { continue }
		chunk := json.decode(ChatChunk, t) or { continue }
		if chunk.message.content.len > 0 { on_chunk(chunk.message.content) }
		if chunk.done { break }
	}
}

// ============================================================
// MAIN
// ============================================================

fn main() {
	if os.args.len < 2 {
		eprintln('Usage: rag <question>')
		exit(1)
	}
	question := os.args[1..].join(' ')

	cfg    := default_config()
	ollama := new_ollama_client(cfg)
	db     := new_turso_client(cfg)

	println('=== RAG Pipeline ===')
	println('Question: ${question}')
	println('')

	// --- 1. Embed question ---
	print('[1/3] Embedding query...')
	flush_stdout()
	query_vec := ollama.embed(question) or {
		eprintln('\nFatal: ${err}')
		exit(1)
	}
	println(' done.')

	// --- 2. Retrieve chunks ---
	print('[2/3] Searching knowledge base...')
	flush_stdout()
	results := db.vector_search(query_vec, cfg.top_k) or {
		eprintln('\nFatal: ${err}')
		exit(1)
	}
	println(' ${results.len} chunk(s).')
	println('')

	if results.len == 0 {
		println('No relevant documents. Run: v run ingest.v')
		exit(0)
	}

	// --- 3. Augment prompt ---
	mut context_parts := []string{}
	for i, row in results {
		chunk  := row['chunk'] or { '' }
		source := row['source'] or { 'unknown' }
		context_parts << '[${i + 1}] (from ${source})\n${chunk}'
	}
	context_block := context_parts.join('\n\n---\n\n')

	system_prompt := "You are a helpful assistant.  Answer the user's question " +
		'using ONLY the information in the context sections below.  ' +
		'If the context does not contain the answer, say so honestly.\n\n' +
		'CONTEXT:\n${context_block}'

	messages := [
		Message{ role: 'system', content: system_prompt },
		Message{ role: 'user',   content: question },
	]

	// --- 4. Stream answer ---
	println('[3/3] Generating answer (streaming)...')
	println('─'.repeat(60))
	println('')

	ollama.chat_stream(messages, fn (chunk string) {
		print(chunk)
		flush_stdout()
	}) or {
		eprintln('\nFatal: ${err}')
		exit(1)
	}

	println('')
	println('')
	println('─'.repeat(60))
	println('Sources:')
	for i, row in results {
		source   := row['source'] or { 'unknown' }
		distance := row['distance'] or { '?' }
		println('  ${i + 1}. ${source} (distance: ${distance})')
	}
}
