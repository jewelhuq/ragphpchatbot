# TypeScript RAG System

A fully local, zero-cloud Retrieval-Augmented Generation (RAG) system built with TypeScript.  
Documents are stored as vector embeddings in [Turso](https://turso.tech/) (a distributed SQLite 
service), and all AI inference runs locally via [Ollama](https://ollama.com/) — no OpenAI key required.

---

## Architecture

```
docs/                  ← drop your .txt and .md files here
  └─ ...

src/
  ├─ config.ts         ← central configuration (env vars + defaults)
  ├─ turso.ts          ← Turso HTTP API client (execute + fetchAll)
  ├─ ollama.ts         ← Ollama HTTP client (embed + chatStream)
  ├─ chunker.ts        ← paragraph splitter with heading-context prefix
  ├─ parser.ts         ← file → plain text (txt/md; pdf/docx stubs)
  ├─ ingest.ts         ← document ingestion pipeline (hash + embed + store)
  ├─ query.ts          ← one-shot semantic search (embed + vector_top_k)
  ├─ rag.ts            ← single-turn RAG (retrieve + augment + stream)
  └─ chatbot.ts        ← interactive multi-turn RAG chatbot (readline REPL)
```

---

## Prerequisites

| Requirement | Notes |
|-------------|-------|
| **Node.js ≥ 18** | Built-in `fetch` is required; no polyfills needed |
| **Ollama**  | Running locally at `http://127.0.0.1:11434` |
| **Turso account** | Free tier is sufficient |

### Pull the required Ollama models

```bash
ollama pull nomic-embed-text   # 768-dim embedding model
ollama pull gemma3:1b          # 1-billion-param chat model (fast, small)
```

---

## Setup

### 1. Install dependencies

```bash
cd implementations/typescript
npm install
```

No external HTTP libraries are needed — the system uses Node's built-in `fetch`.

### 2. Configure environment variables (optional)

The system ships with sensible defaults.  Override any value with environment variables:

```bash
# Turso
export TURSO_URL="https://your-db-name.turso.io"
export TURSO_TOKEN="your-bearer-token"

# Ollama
export OLLAMA_URL="http://127.0.0.1:11434"
export EMBED_MODEL="nomic-embed-text"
export CHAT_MODEL="gemma3:1b"

# RAG behaviour
export DOCS_DIR="./docs"          # where your source documents live
export TABLE_NAME="rag_chunks"    # Turso table name
export TOP_K="5"                  # how many chunks to retrieve per query
export MIN_CHUNK_LEN="100"        # minimum chunk character length
```

### 3. Add documents

Place `.txt` or `.md` files anywhere inside the `docs/` directory.  
Subdirectories are scanned recursively.

```bash
mkdir -p docs
echo "The mitochondria is the powerhouse of the cell." > docs/biology.txt
```

---

## Usage

### Ingest documents

Parses every file in `docs/`, chunks it, embeds each chunk, and stores it in Turso.  
Re-running is safe — unchanged files are skipped via MD5 hash comparison.

```bash
npm run ingest
```

### Semantic search (no LLM)

Embeds your query and returns the K most relevant passages directly from the vector index.

```bash
npm run query -- "What is the role of mitochondria?"
```

### Single-turn RAG

Retrieves the top-K chunks, builds a grounded prompt, and streams a single answer.

```bash
npm run rag -- "Explain how cells produce energy."
```

### Interactive chatbot

An interactive multi-turn conversation.  Each question triggers a fresh retrieval so 
the context always matches the current question, while full conversation history is 
maintained so you can ask follow-ups naturally.

```bash
npm run chatbot
```

Type `exit` or press `Ctrl-D` to quit.

---

## Compiled output (optional)

If you prefer to run compiled JavaScript instead of ts-node:

```bash
npm run build               # compiles src/ → dist/
node dist/ingest.js
node dist/query.js "query here"
node dist/rag.js "question here"
node dist/chatbot.js
```

---

## Enabling PDF and DOCX support

The `parser.ts` file contains stubs for `.pdf` and `.docx` parsing.  
To activate them:

**PDF** — install [pdf-parse](https://www.npmjs.com/package/pdf-parse):

```bash
npm install pdf-parse
```

Then follow the instructions in the `parsePdf()` stub inside `src/parser.ts`.

**DOCX** — install [mammoth](https://www.npmjs.com/package/mammoth):

```bash
npm install mammoth
```

Then follow the instructions in the `parseDocx()` stub inside `src/parser.ts`.

---

## Database schema

```sql
CREATE TABLE rag_chunks (
  id          TEXT PRIMARY KEY,   -- "<source>::<chunk_index>"
  source      TEXT NOT NULL,      -- relative path of the source file
  hash        TEXT NOT NULL,      -- MD5 of file content at ingest time
  chunk_index INTEGER NOT NULL,   -- ordinal position within the document
  content     TEXT NOT NULL,      -- the chunk text (with context prefix)
  embedding   F32_BLOB(768)       -- the embedding vector
);

CREATE INDEX rag_chunks_vec_idx ON rag_chunks (libsql_vector_idx(embedding));
```

Vector search is performed with Turso's `vector_top_k()` table-valued function, which 
uses the index for approximate nearest-neighbour search in O(log n) time.
