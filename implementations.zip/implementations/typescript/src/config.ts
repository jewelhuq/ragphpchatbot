﻿/**
 * config.ts
 *
 * The configuration module is the foundation of our RAG system — think of it
 * as the blueprint that every other component reads before doing any work.
 * Rather than scattering magic strings throughout the codebase, we gather all
 * tunable knobs here so a single glance tells you exactly where the system
 * points and how it behaves.
 *
 * Values are resolved in priority order:
 *   1. Environment variables (useful for CI / Docker)
 *   2. Hard-coded defaults (sensible out-of-the-box for local dev)
 */

/**
 * Config describes every runtime parameter the RAG system needs.
 * Add new fields here whenever a new component needs a tunable value.
 */
export interface Config {
  /** Turso database HTTP endpoint, e.g. https://your-db.turso.io */
  tursoUrl: string;
  /** Bearer token used to authenticate with the Turso HTTP API */
  tursoToken: string;
  /** Base URL for the local Ollama server */
  ollamaUrl: string;
  /** Name of the Ollama model used to produce text embeddings */
  embedModel: string;
  /** Dimensionality of the embedding vectors produced by embedModel */
  embedDims: number;
  /** Name of the Ollama model used for chat / generation */
  chatModel: string;
  /** Directory that ingest.ts will scan for source documents */
  docsDir: string;
  /** Database table name where chunks and their embeddings are stored */
  tableName: string;
  /** How many nearest-neighbour chunks to retrieve for each query */
  topK: number;
  /** Minimum character length a chunk must reach before it is kept */
  minChunkLen: number;
}

/**
 * loadConfig reads environment variables and falls back to safe defaults,
 * returning a fully-populated Config object.
 *
 * Call this once at application startup; the returned object is immutable
 * by convention — never mutate it at runtime.
 */
export function loadConfig(): Config {
  return {
    tursoUrl:
      process.env.TURSO_URL ??
      "https://your-db-name.turso.io",
    tursoToken: process.env.TURSO_TOKEN ?? "",
    ollamaUrl: process.env.OLLAMA_URL ?? "http://127.0.0.1:11434",
    embedModel: process.env.EMBED_MODEL ?? "nomic-embed-text",
    embedDims: parseInt(process.env.EMBED_DIMS ?? "768", 10),
    chatModel: process.env.CHAT_MODEL ?? "gemma3:1b",
    docsDir: process.env.DOCS_DIR ?? "./docs",
    tableName: process.env.TABLE_NAME ?? "rag_chunks",
    topK: parseInt(process.env.TOP_K ?? "5", 10),
    minChunkLen: parseInt(process.env.MIN_CHUNK_LEN ?? "100", 10),
  };
}

/**
 * config is the singleton Config instance used throughout the application.
 * Import this directly instead of calling loadConfig() in every module.
 *
 * @example
 * import { config } from "./config";
 * console.log(config.tursoUrl);
 */
export const config: Config = loadConfig();
