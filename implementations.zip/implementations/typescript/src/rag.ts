/**
 * rag.ts
 *
 * This is the centrepiece of the whole system — Retrieval-Augmented
 * Generation in its most direct form.
 *
 * The classic RAG loop has three acts:
 *   1. Retrieve  — find the passages most relevant to the user's question
 *   2. Augment   — weave those passages into a prompt that gives the model
 *                  the context it needs to answer accurately
 *   3. Generate  — stream the model's answer token by token
 *
 * By grounding the language model in retrieved facts rather than relying
 * solely on its parametric memory, we dramatically reduce hallucination and
 * keep answers tied to your actual documents.
 *
 * Run with:
 *   npm run rag -- "What does the manual say about installation?"
 */

import { config } from "./config";
import { TursoClient } from "./turso";
import { OllamaClient } from "./ollama";
import type { ChatMessage } from "./ollama";

// ---------------------------------------------------------------------------
// Prompt construction
// ---------------------------------------------------------------------------

/**
 * buildSystemPrompt creates the system-level instruction that tells the model
 * how to behave: answer only from the provided context, cite sources, and
 * admit uncertainty when the context doesn't cover the question.
 *
 * This prompt is sent once at the start of every RAG conversation.
 */
function buildSystemPrompt(): string {
  return (
    "You are a precise and helpful assistant that answers questions using " +
    "only the context passages provided below. " +
    "If the context does not contain enough information to answer the " +
    "question confidently, say so clearly — do not invent facts. " +
    "When you cite information, mention the source label shown in brackets " +
    "at the start of each passage. " +
    "Be concise, accurate, and direct."
  );
}

/**
 * buildUserPrompt assembles the final user message that the model sees.
 *
 * It concatenates the retrieved chunks into a numbered context block and
 * appends the user's original question at the bottom.  Numbering the
 * chunks makes it easy for the model to reference specific passages in its
 * reply.
 *
 * @param question - The user's original question
 * @param chunks   - Array of retrieved chunk strings (content column values)
 * @returns The fully-assembled prompt string
 */
function buildUserPrompt(question: string, chunks: string[]): string {
  const contextBlock = chunks
    .map((chunk, i) => `[${i + 1}] ${chunk}`)
    .join("\n\n");

  return (
    `Context passages:\n` +
    `─────────────────\n` +
    `${contextBlock}\n` +
    `─────────────────\n\n` +
    `Question: ${question}`
  );
}

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

/**
 * main runs a single RAG turn:
 *   embed question → retrieve chunks → build prompt → stream answer.
 *
 * The streamed answer is written to stdout token by token so the user sees
 * text appear immediately rather than waiting for the full response.
 */
async function main(): Promise<void> {
  const question = process.argv[2];

  if (!question || question.trim() === "") {
    console.error(
      'Usage: npm run rag -- "<your question>"\n' +
        'Example: npm run rag -- "How do I configure the system?"'
    );
    process.exit(1);
  }

  console.log(`=== RAG — Retrieval-Augmented Generation ===`);
  console.log(`Question : "${question}"`);
  console.log(`Top-K    : ${config.topK}`);
  console.log(`Chat     : ${config.chatModel}`);
  console.log("");

  const db = new TursoClient();
  const ollama = new OllamaClient();

  // ------------------------------------------------------------------
  // Step 1: Retrieve — embed the question and find nearest chunks
  // ------------------------------------------------------------------
  console.log(`[rag] Embedding question…`);
  let questionEmbedding: number[];
  try {
    questionEmbedding = await ollama.embed(question);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[rag] Embedding failed: ${msg}`);
    process.exit(1);
  }

  const queryVectorJson = JSON.stringify(questionEmbedding);

  console.log(`[rag] Searching for relevant chunks…`);
  let rows: Record<string, string>[];
  try {
    rows = await db.fetchAll(
      `SELECT
         c.content,
         c.source,
         v.distance
       FROM vector_top_k('${config.tableName}_vec_idx', vector32(?), ?) AS v
       JOIN ${config.tableName} AS c ON c.id = v.id
       ORDER BY v.distance ASC`,
      [queryVectorJson, config.topK]
    );
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[rag] Vector search failed: ${msg}`);
    process.exit(1);
  }

  if (rows.length === 0) {
    console.log(
      "[rag] No relevant chunks found. " +
        "Run `npm run ingest` first to populate the knowledge base."
    );
    return;
  }

  console.log(`[rag] Retrieved ${rows.length} chunk(s) from the knowledge base.`);
  rows.forEach((r, i) => {
    const dist = parseFloat(r.distance ?? "0").toFixed(4);
    console.log(`  ${i + 1}. ${r.source} (distance: ${dist})`);
  });
  console.log("");

  // ------------------------------------------------------------------
  // Step 2: Augment — build the grounded prompt
  // ------------------------------------------------------------------
  const chunkTexts = rows.map((r) => r.content);
  const systemPrompt = buildSystemPrompt();
  const userPrompt = buildUserPrompt(question, chunkTexts);

  const messages: ChatMessage[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ];

  // ------------------------------------------------------------------
  // Step 3: Generate — stream the answer
  // ------------------------------------------------------------------
  console.log(`[rag] Generating answer (streaming)…\n`);
  console.log("─".repeat(72));

  try {
    await ollama.chatStream(messages, (token) => {
      process.stdout.write(token);
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`\n[rag] Generation failed: ${msg}`);
    process.exit(1);
  }

  // Ensure the cursor ends on a fresh line after the streamed answer
  process.stdout.write("\n");
  console.log("─".repeat(72));
  console.log("\n[rag] Done.");
}

// ---------------------------------------------------------------------------
// Entry
// ---------------------------------------------------------------------------

main().catch((err) => {
  console.error("[rag] Fatal error:", err);
  process.exit(1);
});
