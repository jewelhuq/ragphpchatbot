/**
 * query.ts
 *
 * Once the knowledge base is populated, the query script lets you
 * interrogate it directly — without language model generation.
 * Think of it as running a pure semantic search: you describe what you're
 * looking for in plain English and the system returns the passages whose
 * *meaning* most closely matches, even if the exact words differ.
 *
 * Under the hood:
 *   1. Embed the user's query using the same model used at ingest time.
 *   2. Send the embedding to Turso's vector_top_k() function, which uses
 *      the pre-built vector index to find the nearest neighbours in
 *      O(log n) time rather than scanning every row.
 *   3. Print each matching chunk with its distance score and source label.
 *
 * Run with:
 *   npm run query -- "your search question here"
 *
 * Or directly:
 *   npx ts-node src/query.ts "your search question here"
 */

import { config } from "./config";
import { TursoClient } from "./turso";
import { OllamaClient } from "./ollama";

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

/**
 * main reads the query from the command-line, embeds it, runs the vector
 * nearest-neighbour search against Turso, and prints the top-K results.
 *
 * The output is intentionally plain-text — pipe it, redirect it, or just
 * read it directly in the terminal.
 */
async function main(): Promise<void> {
  // Grab the query from the first CLI argument
  const query = process.argv[2];

  if (!query || query.trim() === "") {
    console.error(
      'Usage: npm run query -- "<your search question>"\n' +
        "Example: npm run query -- \"What is retrieval-augmented generation?\""
    );
    process.exit(1);
  }

  console.log(`=== RAG Vector Search ===`);
  console.log(`Query : "${query}"`);
  console.log(`Top-K : ${config.topK}`);
  console.log(`Table : ${config.tableName}`);
  console.log("");

  const db = new TursoClient();
  const ollama = new OllamaClient();

  // 1. Embed the query using the same model that was used at ingest time
  console.log(`[query] Embedding query with "${config.embedModel}"…`);
  let queryEmbedding: number[];
  try {
    queryEmbedding = await ollama.embed(query);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[query] Failed to embed query: ${msg}`);
    console.error("[query] Is Ollama running? Try: ollama serve");
    process.exit(1);
  }
  console.log(`[query] Embedding produced (${queryEmbedding.length} dims).`);

  // Serialise the query vector for Turso's vector32() function
  const queryVectorJson = JSON.stringify(queryEmbedding);

  // 2. Run the vector nearest-neighbour search
  // vector_top_k(indexName, queryVector, k) returns (id, distance) pairs
  // sorted by ascending distance (closest first).
  console.log(`[query] Searching vector index…`);
  let results: Record<string, string>[];
  try {
    results = await db.fetchAll(
      `SELECT
         c.id,
         c.source,
         c.chunk_index,
         c.content,
         v.distance
       FROM vector_top_k('${config.tableName}_vec_idx', vector32(?), ?) AS v
       JOIN ${config.tableName} AS c ON c.id = v.id
       ORDER BY v.distance ASC`,
      [queryVectorJson, config.topK]
    );
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[query] Vector search failed: ${msg}`);
    process.exit(1);
  }

  // 3. Print the results
  if (results.length === 0) {
    console.log("\n[query] No results found. Have you run `npm run ingest` yet?");
    return;
  }

  console.log(`\n[query] Found ${results.length} result(s):\n`);
  console.log("─".repeat(72));

  for (let i = 0; i < results.length; i++) {
    const row = results[i];
    const distance = parseFloat(row.distance ?? "0").toFixed(4);

    console.log(`Result ${i + 1}  |  source: ${row.source}  |  distance: ${distance}`);
    console.log("─".repeat(72));

    // Print up to 400 characters of the chunk content to keep output scannable
    const preview =
      row.content.length > 400
        ? row.content.slice(0, 400) + "…"
        : row.content;
    console.log(preview);
    console.log("─".repeat(72));
    console.log("");
  }
}

// ---------------------------------------------------------------------------
// Entry
// ---------------------------------------------------------------------------

main().catch((err) => {
  console.error("[query] Fatal error:", err);
  process.exit(1);
});
