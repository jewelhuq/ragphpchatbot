/**
 * turso.ts
 *
 * Picture Turso as the long-term memory of our RAG system — a distributed
 * SQLite database that lives in the cloud and speaks a tidy HTTP API.
 * This module wraps that API in a small, ergonomic client so the rest of
 * the code never has to think about HTTP verbs, JSON envelopes, or bearer
 * tokens.
 *
 * Turso's /v2/pipeline endpoint accepts a batch of SQL statements and
 * returns their results in a single round-trip, which keeps network
 * overhead minimal even when we need to run several queries in sequence.
 *
 * Docs: https://docs.turso.tech/sdk/http/reference
 */

import { config } from "./config";

// ---------------------------------------------------------------------------
// Types that mirror the Turso HTTP API response shape
// ---------------------------------------------------------------------------

/** A single typed parameter value the Turso API understands. */
interface TursoParam {
  type: "text" | "integer" | "real" | "blob" | "null";
  value: string | null;
}

/** One statement inside a pipeline request. */
interface PipelineRequest {
  type: "execute";
  stmt: {
    sql: string;
    args?: TursoParam[];
  };
}

/** Column metadata returned for every result set. */
interface TursoCol {
  name: string;
  decltype: string | null;
}

/** A single result set from one pipeline statement. */
interface TursoResult {
  type: "ok" | "error";
  response?: {
    type: "execute";
    result: {
      cols: TursoCol[];
      rows: Array<Array<{ type: string; value: string | null }>>;
      affected_row_count: number;
      last_insert_rowid: string | null;
    };
  };
  error?: { message: string; code: string };
}

/** Top-level envelope returned by POST /v2/pipeline. */
interface PipelineResponse {
  baton: string | null;
  base_url: string | null;
  results: TursoResult[];
}

// ---------------------------------------------------------------------------
// Helper: map a JavaScript value to a Turso typed parameter
// ---------------------------------------------------------------------------

/**
 * toTursoParam converts a raw JavaScript value into the typed parameter
 * object the Turso HTTP API requires.
 *
 * The mapping is intentionally simple:
 *  - null / undefined  → { type: "null",    value: null }
 *  - number (integer)  → { type: "integer",  value: String(v) }
 *  - number (float)    → { type: "real",     value: String(v) }
 *  - everything else   → { type: "text",     value: String(v) }
 */
function toTursoParam(value: unknown): TursoParam {
  if (value === null || value === undefined) {
    return { type: "null", value: null };
  }
  if (typeof value === "number") {
    return Number.isInteger(value)
      ? { type: "integer", value: String(value) }
      : { type: "real", value: String(value) };
  }
  return { type: "text", value: String(value) };
}

// ---------------------------------------------------------------------------
// TursoClient
// ---------------------------------------------------------------------------

/**
 * TursoClient is the single gateway between our application and the Turso
 * cloud database.  Every database interaction — creating tables, inserting
 * chunks, running vector searches — flows through this class.
 *
 * Under the hood it uses the Node.js built-in `fetch` (available since
 * Node 18) so there are zero third-party HTTP dependencies.
 *
 * @example
 * const db = new TursoClient();
 * await db.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, body TEXT)");
 * const rows = await db.fetchAll("SELECT * FROM notes");
 */
export class TursoClient {
  private readonly url: string;
  private readonly token: string;

  /**
   * Creates a new TursoClient.
   *
   * @param url   - Turso database HTTP endpoint (defaults to config.tursoUrl)
   * @param token - Bearer auth token         (defaults to config.tursoToken)
   */
  constructor(url: string = config.tursoUrl, token: string = config.tursoToken) {
    this.url = url.replace(/\/$/, ""); // strip trailing slash
    this.token = token;
  }

  // -------------------------------------------------------------------------
  // Private: pipeline transport
  // -------------------------------------------------------------------------

  /**
   * pipeline sends one or more SQL statements to the Turso /v2/pipeline
   * endpoint in a single HTTP request and returns the raw result array.
   *
   * This is the lowest-level method — callers typically use execute() or
   * fetchAll() instead.
   *
   * @param requests - Array of pipeline request objects
   * @throws Error if the HTTP request fails or Turso reports an error
   */
  private async pipeline(requests: PipelineRequest[]): Promise<TursoResult[]> {
    const endpoint = `${this.url}/v2/pipeline`;

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.token}`,
      },
      body: JSON.stringify({ requests }),
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(
        `Turso HTTP error ${response.status} ${response.statusText}: ${body}`
      );
    }

    const envelope: PipelineResponse = await response.json();

    // Surface any per-statement errors so callers see a meaningful message
    for (const result of envelope.results) {
      if (result.type === "error") {
        throw new Error(
          `Turso statement error [${result.error?.code}]: ${result.error?.message}`
        );
      }
    }

    return envelope.results;
  }

  // -------------------------------------------------------------------------
  // Public API
  // -------------------------------------------------------------------------

  /**
   * execute runs a single SQL statement (INSERT, UPDATE, DELETE, DDL) and
   * returns the number of rows affected.
   *
   * Parameters are passed as a plain JavaScript array; toTursoParam() handles
   * the type annotation that the API requires.
   *
   * @param sql    - The SQL statement to execute
   * @param params - Optional positional parameter values (? placeholders)
   * @returns Number of rows affected by the statement
   *
   * @example
   * await db.execute(
   *   "INSERT INTO rag_chunks (id, content) VALUES (?, ?)",
   *   ["abc123", "Hello world"]
   * );
   */
  async execute(sql: string, params: unknown[] = []): Promise<number> {
    const results = await this.pipeline([
      {
        type: "execute",
        stmt: {
          sql,
          args: params.map(toTursoParam),
        },
      },
    ]);

    const result = results[0];
    return result.response?.result.affected_row_count ?? 0;
  }

  /**
   * fetchAll runs a SELECT statement and returns every row as a plain
   * key→value record using the column names from the result set.
   *
   * All values are returned as strings (matching Turso's wire format); the
   * caller is responsible for parsing numbers or booleans where needed.
   *
   * @param sql    - The SELECT statement to run
   * @param params - Optional positional parameter values (? placeholders)
   * @returns Array of row objects, one per result row
   *
   * @example
   * const chunks = await db.fetchAll(
   *   "SELECT id, content FROM rag_chunks WHERE source = ?",
   *   ["manual.pdf"]
   * );
   * chunks.forEach(row => console.log(row.content));
   */
  async fetchAll(
    sql: string,
    params: unknown[] = []
  ): Promise<Record<string, string>[]> {
    const results = await this.pipeline([
      {
        type: "execute",
        stmt: {
          sql,
          args: params.map(toTursoParam),
        },
      },
    ]);

    const result = results[0];
    const { cols, rows } = result.response!.result;

    // Zip column names onto each row's cell array
    return rows.map((row) => {
      const record: Record<string, string> = {};
      cols.forEach((col, i) => {
        record[col.name] = row[i]?.value ?? "";
      });
      return record;
    });
  }
}
