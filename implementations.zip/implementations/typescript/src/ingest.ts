/**
 * ingest.ts
 *
 * Ingestion is the process of turning raw documents on disk into searchable
 * knowledge inside the vector database.  Think of it as shelving books in a
 * library: you read each book, write an index card for every key passage,
 * and file the cards in a way that makes retrieval lightning-fast later.
 *
 * This script does exactly that:
 *
 *   1. Ensures the Turso database table and vector index exist.
 *   2. Recursively scans the docs directory for supported files.
 *   3. Computes an MD5 hash of each file's content.
 *   4. Skips files that haven't changed since the last ingest run.
 *   5. Deletes chunks belonging to files that have changed or been removed.
 *   6. Parses each new/changed file → chunks it → embeds each chunk →
 *      inserts the chunk + embedding into the database.
 *
 * Run with:
 *   npm run ingest
 */

import * as fs from "fs/promises";
import * as path from "path";
import * as crypto from "crypto";
import { config } from "./config";
import { TursoClient } from "./turso";
import { OllamaClient } from "./ollama";
import { Chunker } from "./chunker";
import { DocumentParser } from "./parser";

// ---------------------------------------------------------------------------
// Supported file extensions
// ---------------------------------------------------------------------------

const SUPPORTED_EXTENSIONS = new Set([".txt", ".md"]);
// Add ".pdf" or ".docx" here once the respective parser stubs are enabled.

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * md5 computes the MD5 hex digest of a string.
 *
 * We use MD5 purely as a fast change-detection hash — not for security —
 * so its cryptographic weaknesses are irrelevant here.
 *
 * @param content - The string to hash
 * @returns 32-character lowercase hex string
 */
function md5(content: string): string {
  return crypto.createHash("md5").update(content, "utf-8").digest("hex");
}

/**
 * walkDir recursively collects every file path under a directory,
 * following subdirectories depth-first.
 *
 * @param dir - Absolute path of the directory to scan
 * @returns Array of absolute file paths (not directory paths)
 */
async function walkDir(dir: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: string[] = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const nested = await walkDir(fullPath);
      files.push(...nested);
    } else if (entry.isFile()) {
      files.push(fullPath);
    }
  }

  return files;
}

/**
 * ensureSchema creates the chunks table and its vector index inside Turso
 * if they don't already exist.
 *
 * The table schema stores:
 *  - id          : stable identifier built from source + chunk position
 *  - source      : path of the originating file (relative to docsDir)
 *  - hash        : MD5 of the source file at ingest time (change detection)
 *  - chunk_index : ordinal position of this chunk within the document
 *  - content     : the raw text of the chunk
 *  - embedding   : serialised float32 vector (JSON array string)
 *
 * The libsql vector index (vector_top_k) accelerates nearest-neighbour
 * search at query time without a full table scan.
 *
 * @param db        - An open TursoClient
 * @param tableName - Name of the table to create
 * @param dims      - Dimensionality of the embedding vectors
 */
async function ensureSchema(
  db: TursoClient,
  tableName: string,
  dims: number
): Promise<void> {
  console.log(`[ingest] Ensuring table "${tableName}" exists…`);

  // Main chunks table
  await db.execute(`
    CREATE TABLE IF NOT EXISTS ${tableName} (
      id          TEXT PRIMARY KEY,
      source      TEXT NOT NULL,
      hash        TEXT NOT NULL,
      chunk_index INTEGER NOT NULL,
      content     TEXT NOT NULL,
      embedding   F32_BLOB(${dims})
    )
  `);

  // Vector index for fast approximate nearest-neighbour search
  await db.execute(`
    CREATE INDEX IF NOT EXISTS ${tableName}_vec_idx
    ON ${tableName} (libsql_vector_idx(embedding))
  `);

  console.log("[ingest] Schema ready.");
}

/**
 * deleteChunksForSource removes all rows that belong to a given source file.
 *
 * Called before re-ingesting a file that has changed, so we don't
 * accumulate stale chunks from old versions.
 *
 * @param db        - An open TursoClient
 * @param tableName - Name of the chunks table
 * @param source    - Source identifier (relative file path)
 */
async function deleteChunksForSource(
  db: TursoClient,
  tableName: string,
  source: string
): Promise<void> {
  const affected = await db.execute(
    `DELETE FROM ${tableName} WHERE source = ?`,
    [source]
  );
  if (affected > 0) {
    console.log(`  [ingest] Deleted ${affected} stale chunks for "${source}".`);
  }
}

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

/**
 * main orchestrates the full ingestion pipeline:
 *
 *   schema setup → file discovery → change detection →
 *   stale deletion → parse → chunk → embed → insert
 *
 * It is idempotent: running it multiple times on unchanged files is safe and
 * fast because hash comparison skips files that haven't changed.
 */
async function main(): Promise<void> {
  console.log("=== RAG Ingest ===");
  console.log(`Docs directory : ${config.docsDir}`);
  console.log(`Table          : ${config.tableName}`);
  console.log(`Embed model    : ${config.embedModel} (${config.embedDims} dims)`);
  console.log("");

  const db = new TursoClient();
  const ollama = new OllamaClient();
  const chunker = new Chunker();
  const parser = new DocumentParser();

  // 1. Ensure the database table and vector index exist
  await ensureSchema(db, config.tableName, config.embedDims);

  // 2. Discover all files under the docs directory
  let allFiles: string[];
  try {
    allFiles = await walkDir(path.resolve(config.docsDir));
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[ingest] Cannot read docs directory "${config.docsDir}": ${msg}`);
    console.error(`[ingest] Create the directory and add some .txt or .md files, then re-run.`);
    process.exit(1);
  }

  // Filter to supported extensions only
  const docFiles = allFiles.filter((f) =>
    SUPPORTED_EXTENSIONS.has(path.extname(f).toLowerCase())
  );

  if (docFiles.length === 0) {
    console.log("[ingest] No supported documents found. Nothing to do.");
    return;
  }

  console.log(`[ingest] Found ${docFiles.length} document(s) to process.\n`);

  // 3. Load existing hashes from the database for change detection
  const existingRows = await db.fetchAll(
    `SELECT DISTINCT source, hash FROM ${config.tableName}`
  );
  const existingHashes = new Map<string, string>(
    existingRows.map((r) => [r.source, r.hash])
  );

  // 4. Detect stale sources (files that have been deleted from disk)
  const diskSources = new Set(
    docFiles.map((f) => path.relative(path.resolve(config.docsDir), f))
  );
  for (const [source] of existingHashes) {
    if (!diskSources.has(source)) {
      console.log(`[ingest] Source removed from disk: "${source}" — deleting chunks.`);
      await deleteChunksForSource(db, config.tableName, source);
    }
  }

  // 5. Process each document
  let inserted = 0;
  let skipped = 0;

  for (const filePath of docFiles) {
    const source = path.relative(path.resolve(config.docsDir), filePath);
    console.log(`[ingest] Processing: ${source}`);

    // Read content and compute hash
    let content: string;
    try {
      content = await fs.readFile(filePath, "utf-8");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(`  [ingest] Could not read "${source}": ${msg} — skipping.`);
      continue;
    }

    const hash = md5(content);
    const existingHash = existingHashes.get(source);

    if (existingHash === hash) {
      console.log(`  [ingest] Unchanged (hash match) — skipping.`);
      skipped++;
      continue;
    }

    // File is new or changed — delete any existing chunks and re-ingest
    if (existingHash !== undefined) {
      console.log(`  [ingest] File changed — replacing chunks.`);
      await deleteChunksForSource(db, config.tableName, source);
    }

    // Parse the file into plain text
    let text: string;
    try {
      text = await parser.parse(filePath);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(`  [ingest] Parse failed for "${source}": ${msg} — skipping.`);
      continue;
    }

    // Split into chunks
    const chunks = chunker.chunk(text, source);
    console.log(`  [ingest] ${chunks.length} chunk(s) generated.`);

    if (chunks.length === 0) {
      console.warn(`  [ingest] No usable chunks — file may be too short or empty.`);
      continue;
    }

    // Embed and insert each chunk
    for (let i = 0; i < chunks.length; i++) {
      const chunkText = chunks[i];
      const chunkId = `${source}::${i}`;

      process.stdout.write(`  [ingest] Embedding chunk ${i + 1}/${chunks.length}…\r`);

      // Embed the chunk text
      let embedding: number[];
      try {
        embedding = await ollama.embed(chunkText);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        console.error(`\n  [ingest] Embed failed for chunk ${i}: ${msg}`);
        continue;
      }

      // Serialise the embedding vector as a JSON array for F32_BLOB storage
      const embeddingJson = JSON.stringify(embedding);

      // Insert the chunk into Turso
      await db.execute(
        `INSERT OR REPLACE INTO ${config.tableName}
           (id, source, hash, chunk_index, content, embedding)
         VALUES (?, ?, ?, ?, ?, vector32(?))`,
        [chunkId, source, hash, i, chunkText, embeddingJson]
      );

      inserted++;
    }

    process.stdout.write("\n"); // finish the \r line
    console.log(`  [ingest] Done — ${chunks.length} chunk(s) stored.`);
  }

  console.log(`\n=== Ingest complete ===`);
  console.log(`  Inserted : ${inserted} chunk(s)`);
  console.log(`  Skipped  : ${skipped} file(s) unchanged`);
}

// ---------------------------------------------------------------------------
// Entry
// ---------------------------------------------------------------------------

main().catch((err) => {
  console.error("[ingest] Fatal error:", err);
  process.exit(1);
});
