/**
 * chunker.ts
 *
 * Imagine you have a massive textbook you want to feed to an AI.  You
 * can't hand it the whole thing at once — the model's context window would
 * overflow.  Instead, you slice it into meaningful, self-contained passages
 * so each one can stand on its own when retrieved later.
 *
 * That slicing is exactly what the Chunker does.
 *
 * Strategy
 * --------
 * 1. Split the document on paragraph boundaries (two or more newlines).
 * 2. Detect headings (lines starting with "#" or ALL-CAPS short lines) and
 *    use the most-recent heading as a context prefix for subsequent chunks.
 *    This way a retrieved chunk always carries its section title, making it
 *    far more useful to the language model.
 * 3. Discard any chunk shorter than minChunkLen characters — those are
 *    typically page numbers, figure captions, or other noise.
 * 4. Prepend an optional source label so the model knows which document a
 *    chunk came from.
 */

import { config } from "./config";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * isHeading returns true if the given paragraph looks like a section heading.
 *
 * We recognise two heading styles:
 *  - Markdown headings: lines that start with one or more "#" characters
 *  - ALL-CAPS headings: short lines (≤ 80 chars) written entirely in uppercase
 *
 * @param paragraph - A single trimmed paragraph string
 */
function isHeading(paragraph: string): boolean {
  // Markdown-style heading
  if (/^#{1,6}\s/.test(paragraph)) return true;

  // ALL-CAPS heading (short line, no lowercase letters)
  const firstLine = paragraph.split("\n")[0].trim();
  if (
    firstLine.length <= 80 &&
    firstLine.length > 0 &&
    firstLine === firstLine.toUpperCase() &&
    /[A-Z]/.test(firstLine) // must contain at least one letter
  ) {
    return true;
  }

  return false;
}

/**
 * extractHeadingText strips Markdown "#" prefixes from a heading paragraph
 * and returns the bare title text.
 *
 * @param paragraph - A heading paragraph (possibly starting with "#")
 */
function extractHeadingText(paragraph: string): string {
  return paragraph
    .split("\n")[0]      // take only the first line
    .replace(/^#+\s*/, "") // remove leading hashes
    .trim();
}

// ---------------------------------------------------------------------------
// Chunker
// ---------------------------------------------------------------------------

/**
 * Chunker slices raw document text into bite-sized passages suitable for
 * embedding and vector storage.
 *
 * Each chunk is a self-contained unit of meaning: it carries its section
 * heading as a prefix (so context is never lost after retrieval) and meets
 * a minimum length threshold (so noise never pollutes the vector index).
 *
 * @example
 * const chunker = new Chunker();
 * const chunks = chunker.chunk(documentText, "user-guide.pdf");
 * console.log(chunks.length); // e.g. 42
 */
export class Chunker {
  private readonly minChunkLen: number;

  /**
   * Creates a new Chunker.
   *
   * @param minChunkLen - Minimum character count a chunk must reach to be kept.
   *                      Defaults to config.minChunkLen (typically 100).
   */
  constructor(minChunkLen: number = config.minChunkLen) {
    this.minChunkLen = minChunkLen;
  }

  /**
   * chunk splits a document into an array of contextual text passages.
   *
   * The algorithm walks the document paragraph by paragraph.  Whenever it
   * encounters a heading it updates the "current section" label.  Every
   * non-heading paragraph that passes the minimum length check is emitted
   * as a chunk, prefixed with "[source] [Section: heading]" metadata so
   * that retrieval results are self-explanatory.
   *
   * @param text   - The full document text to split
   * @param source - An optional human-readable label for the document
   *                 (e.g. a file name).  Included as a prefix on each chunk.
   * @returns Array of chunk strings ready to be embedded
   *
   * @example
   * const chunks = chunker.chunk("# Introduction\n\nRAG stands for...", "intro.md");
   * // chunks[0] === "[intro.md] [Section: Introduction]\nRAG stands for..."
   */
  chunk(text: string, source = ""): string[] {
    // Normalise line endings and split into paragraphs
    const normalised = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const paragraphs = normalised
      .split(/\n{2,}/)      // split on blank lines
      .map((p) => p.trim())
      .filter((p) => p.length > 0);

    const chunks: string[] = [];
    let currentHeading = "";

    for (const paragraph of paragraphs) {
      if (isHeading(paragraph)) {
        // Update the running section context but don't emit the heading itself
        currentHeading = extractHeadingText(paragraph);
        continue;
      }

      // Build the context prefix
      const parts: string[] = [];
      if (source) parts.push(`[${source}]`);
      if (currentHeading) parts.push(`[Section: ${currentHeading}]`);

      const prefix = parts.length > 0 ? parts.join(" ") + "\n" : "";
      const chunk = prefix + paragraph;

      // Only keep chunks that meet the minimum length requirement
      if (chunk.length >= this.minChunkLen) {
        chunks.push(chunk);
      }
    }

    return chunks;
  }
}
