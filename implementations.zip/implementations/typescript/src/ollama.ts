/**
 * ollama.ts
 *
 * Ollama is the local AI brain of our RAG system — it runs entirely on your
 * machine, keeping your data private and your inference costs at zero.
 * This module provides a thin, zero-dependency wrapper around two of its
 * HTTP endpoints:
 *
 *   POST /api/embeddings  — converts text into a float vector
 *   POST /api/chat        — streams a conversational reply token by token
 *
 * Both methods use the Node.js built-in fetch API (Node 18+), so no
 * additional HTTP libraries are required.
 *
 * Docs: https://github.com/ollama/ollama/blob/main/docs/api.md
 */

import { config } from "./config";

// ---------------------------------------------------------------------------
// Types mirroring the Ollama API wire format
// ---------------------------------------------------------------------------

/** A single message in the chat history understood by /api/chat. */
export interface ChatMessage {
  /** Who sent the message: the human user or the AI assistant */
  role: "user" | "assistant" | "system";
  /** The raw text of the message */
  content: string;
}

/** Shape of one NDJSON line emitted by /api/chat in streaming mode. */
interface ChatStreamChunk {
  model: string;
  created_at: string;
  message?: { role: string; content: string };
  done: boolean;
  done_reason?: string;
}

/** Shape of the /api/embeddings response body. */
interface EmbedResponse {
  embedding: number[];
}

// ---------------------------------------------------------------------------
// OllamaClient
// ---------------------------------------------------------------------------

/**
 * OllamaClient is the bridge between our application and the locally-running
 * Ollama server.  All AI inference — whether turning text into numbers or
 * turning a prompt into a flowing answer — goes through here.
 *
 * @example
 * const ollama = new OllamaClient();
 * const vector = await ollama.embed("What is retrieval-augmented generation?");
 * console.log(vector.length); // 768
 */
export class OllamaClient {
  private readonly baseUrl: string;
  private readonly embedModel: string;
  private readonly chatModel: string;

  /**
   * Creates a new OllamaClient.
   *
   * @param baseUrl    - Base URL of the Ollama server (defaults to config.ollamaUrl)
   * @param embedModel - Model name for embeddings    (defaults to config.embedModel)
   * @param chatModel  - Model name for chat          (defaults to config.chatModel)
   */
  constructor(
    baseUrl: string = config.ollamaUrl,
    embedModel: string = config.embedModel,
    chatModel: string = config.chatModel
  ) {
    this.baseUrl = baseUrl.replace(/\/$/, "");
    this.embedModel = embedModel;
    this.chatModel = chatModel;
  }

  // -------------------------------------------------------------------------
  // embed
  // -------------------------------------------------------------------------

  /**
   * embed converts a piece of text into a dense float vector using the
   * configured embedding model.
   *
   * The resulting vector can be stored in a vector database and later used to
   * find semantically similar passages via cosine or Euclidean distance.
   *
   * @param text - The raw text to embed (typically a chunk or a query)
   * @returns A number array of length config.embedDims (default 768)
   * @throws Error if Ollama is unreachable or returns a non-OK status
   *
   * @example
   * const vec = await ollama.embed("The mitochondria is the powerhouse of the cell.");
   */
  async embed(text: string): Promise<number[]> {
    const response = await fetch(`${this.baseUrl}/api/embeddings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: this.embedModel,
        prompt: text,
      }),
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(
        `Ollama embed error ${response.status} ${response.statusText}: ${body}`
      );
    }

    const data: EmbedResponse = await response.json();
    return data.embedding;
  }

  // -------------------------------------------------------------------------
  // chatStream
  // -------------------------------------------------------------------------

  /**
   * chatStream sends a multi-turn conversation to the chat model and streams
   * the reply back token by token.
   *
   * Ollama emits newline-delimited JSON (NDJSON) — one small JSON object per
   * generated token.  We read the response body as an async byte iterator,
   * accumulate bytes into lines, parse each line, and immediately forward the
   * token text to the caller via the onChunk callback.
   *
   * This approach lets the UI begin printing before the model has finished
   * generating, giving the user a much snappier experience.
   *
   * @param messages - Full conversation history (system + prior turns + new user message)
   * @param onChunk  - Callback invoked with each newly generated token string
   * @returns Resolves when the model signals it is done (done: true in the stream)
   * @throws Error if Ollama is unreachable, returns a non-OK status, or the
   *         response body cannot be read as an async iterator
   *
   * @example
   * await ollama.chatStream(
   *   [{ role: "user", content: "Explain RAG in one sentence." }],
   *   (token) => process.stdout.write(token)
   * );
   */
  async chatStream(
    messages: ChatMessage[],
    onChunk: (token: string) => void
  ): Promise<void> {
    const response = await fetch(`${this.baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: this.chatModel,
        messages,
        stream: true,
      }),
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(
        `Ollama chat error ${response.status} ${response.statusText}: ${body}`
      );
    }

    if (!response.body) {
      throw new Error("Ollama chat response has no body — cannot stream.");
    }

    // Node 18+ exposes response.body as a Web Streams ReadableStream.
    // We convert it to an async iterator for clean line-by-line parsing.
    const decoder = new TextDecoder();
    let buffer = "";

    // @ts-expect-error — Node's fetch body supports Symbol.asyncIterator
    for await (const rawChunk of response.body) {
      // rawChunk is a Uint8Array; decode it and append to our line buffer
      buffer += decoder.decode(rawChunk as Uint8Array, { stream: true });

      // Process every complete line in the buffer
      const lines = buffer.split("\n");
      // The last element may be an incomplete line — keep it for the next iteration
      buffer = lines.pop() ?? "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue; // skip blank separator lines

        try {
          const chunk: ChatStreamChunk = JSON.parse(trimmed);
          const token = chunk.message?.content ?? "";
          if (token) {
            onChunk(token);
          }
          // When done is true the model has finished; no more tokens follow
          if (chunk.done) return;
        } catch {
          // Malformed JSON line — log and continue rather than crashing
          console.error("[ollama] Failed to parse stream line:", trimmed);
        }
      }
    }

    // Flush any remaining bytes left in the buffer after the stream closes
    if (buffer.trim()) {
      try {
        const chunk: ChatStreamChunk = JSON.parse(buffer.trim());
        const token = chunk.message?.content ?? "";
        if (token) onChunk(token);
      } catch {
        // Best-effort; ignore parse errors on the final fragment
      }
    }
  }
}
