/**
 * parser.ts
 *
 * Before we can chunk and embed a document we need to extract its raw text.
 * The DocumentParser is the first door every file walks through on its way
 * into the knowledge base.
 *
 * Currently supported formats
 * ---------------------------
 *  .txt  — read directly with Node's built-in fs module (no dependencies)
 *  .md   — same as .txt; Markdown is plain text, headings are kept for the
 *           Chunker to detect
 *
 * Planned (stubs provided below)
 * --------------------------------
 *  .pdf  — requires the `pdf-parse` npm package
 *           Install: npm install pdf-parse @types/pdf-parse
 *           Uncomment the stub code and import { default as pdfParse } from "pdf-parse";
 *
 *  .docx — requires the `mammoth` npm package
 *           Install: npm install mammoth
 *           Uncomment the stub code and import mammoth from "mammoth";
 *
 * Adding a new format is as simple as adding another case to the switch
 * statement in parse() and writing a small extraction helper.
 */

import * as fs from "fs/promises";
import * as path from "path";

// ---------------------------------------------------------------------------
// DocumentParser
// ---------------------------------------------------------------------------

/**
 * DocumentParser turns files on disk into plain strings that the Chunker can
 * split and the embedding model can understand.
 *
 * Think of it as the librarian who opens every book, strips away the binding
 * and formatting, and hands you the raw words inside.
 *
 * @example
 * const parser = new DocumentParser();
 * const text = await parser.parse("/home/user/docs/manual.txt");
 * console.log(text.slice(0, 80));
 */
export class DocumentParser {
  /**
   * parse reads a file from disk and extracts its text content.
   *
   * The method dispatches on the file extension, calling an appropriate
   * extraction routine for each supported format.  Unsupported extensions
   * throw a descriptive error so the caller can decide to skip or abort.
   *
   * @param filePath - Absolute or relative path to the file to parse
   * @returns The full extracted text of the document
   * @throws Error for unsupported file formats or IO failures
   *
   * @example
   * const text = await parser.parse("./docs/overview.txt");
   */
  async parse(filePath: string): Promise<string> {
    const ext = path.extname(filePath).toLowerCase();

    switch (ext) {
      case ".txt":
      case ".md":
        return this.parsePlainText(filePath);

      case ".pdf":
        return this.parsePdf(filePath);

      case ".docx":
        return this.parseDocx(filePath);

      default:
        throw new Error(
          `DocumentParser: unsupported file extension "${ext}" for file "${filePath}". ` +
            `Supported: .txt, .md, .pdf, .docx`
        );
    }
  }

  // -------------------------------------------------------------------------
  // Plain-text extraction (.txt, .md)
  // -------------------------------------------------------------------------

  /**
   * parsePlainText reads the file verbatim using UTF-8 encoding.
   *
   * Because Markdown and plain text are already human-readable strings,
   * no transformation is needed — we hand the content straight to the caller.
   *
   * @param filePath - Path to a .txt or .md file
   */
  private async parsePlainText(filePath: string): Promise<string> {
    const buffer = await fs.readFile(filePath, { encoding: "utf-8" });
    return buffer;
  }

  // -------------------------------------------------------------------------
  // PDF extraction (.pdf)
  // -------------------------------------------------------------------------

  /**
   * parsePdf extracts text from a PDF document.
   *
   * --- STUB ---
   * This method requires the `pdf-parse` npm package to work.
   *
   * To enable PDF support:
   *   1. Run: npm install pdf-parse
   *   2. Add to tsconfig.json compilerOptions: "esModuleInterop": true
   *   3. Replace the stub body with:
   *
   *      import pdfParse from "pdf-parse";
   *      const buffer = await fs.readFile(filePath);
   *      const data = await pdfParse(buffer);
   *      return data.text;
   *
   * @param filePath - Path to a .pdf file
   */
  private async parsePdf(filePath: string): Promise<string> {
    // STUB: install pdf-parse and replace this body.
    // Example:
    //   import pdfParse from "pdf-parse";
    //   const buffer = await fs.readFile(filePath);
    //   const data = await pdfParse(buffer);
    //   return data.text;
    throw new Error(
      `PDF parsing is not yet enabled. ` +
        `Install the 'pdf-parse' package and update parsePdf() in parser.ts. ` +
        `File: ${filePath}`
    );
  }

  // -------------------------------------------------------------------------
  // DOCX extraction (.docx)
  // -------------------------------------------------------------------------

  /**
   * parseDocx extracts text from a Microsoft Word .docx document.
   *
   * --- STUB ---
   * This method requires the `mammoth` npm package to work.
   *
   * To enable DOCX support:
   *   1. Run: npm install mammoth
   *   2. Replace the stub body with:
   *
   *      import mammoth from "mammoth";
   *      const result = await mammoth.extractRawText({ path: filePath });
   *      return result.value;
   *
   * @param filePath - Path to a .docx file
   */
  private async parseDocx(filePath: string): Promise<string> {
    // STUB: install mammoth and replace this body.
    // Example:
    //   import mammoth from "mammoth";
    //   const result = await mammoth.extractRawText({ path: filePath });
    //   return result.value;
    throw new Error(
      `DOCX parsing is not yet enabled. ` +
        `Install the 'mammoth' package and update parseDocx() in parser.ts. ` +
        `File: ${filePath}`
    );
  }
}
