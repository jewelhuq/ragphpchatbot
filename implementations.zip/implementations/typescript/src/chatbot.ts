/**
 * chatbot.ts
 *
 * The chatbot is the most human face of our RAG system — an interactive
 * terminal session where you can hold a multi-turn conversation, asking
 * follow-up questions and receiving answers grounded in your document
 * collection.
 *
 * Each turn follows the full RAG loop:
 *   retrieve → augment → generate
 *
 * But unlike the one-shot rag.ts script, the chatbot accumulates a growing
 * conversation history so the model can refer back to earlier exchanges.
 * This lets you ask follow-up questions naturally:
 *   "What did you just say about X?"
 *   "Can you elaborate on the second point?"
 *
 * Architecture
 * ------------
 * - readline provides the REPL prompt and handles Ctrl-C / Ctrl-D cleanly.
 * - For every user message we embed it, retrieve top-K chunks, inject them
 *   into the next user turn, and stream the model's reply token by token
 *   via process.stdout.write — so text appears as it's generated.
 * - The full assistant reply is collected and appended to the history array
 *   so subsequent turns have access to it.
 *
 * Run with:
 *   npm run chatbot
 */

import * as readline from "readline";
import { config } from "./config";
import { TursoClient } from "./turso";
import { OllamaClient } from "./ollama";
import type { ChatMessage } from "./ollama";

// ---------------------------------------------------------------------------
// Prompt construction (mirrors rag.ts, kept local to avoid coupling)
// ---------------------------------------------------------------------------

/**
 * buildSystemMessage returns the opening system instruction.
 *
 * Sent once at conversation start, it shapes the model's persona and
 * tells it to stay grounded in the retrieved context.
 */
function buildSystemMessage(): ChatMessage {
  return {
    role: "system",
    content:
      "You are a knowledgeable and friendly assistant that answers questions " +
      "using the context passages provided in each user message. " +
      "If the context is insufficient, say so honestly rather than guessing. " +
      "When referencing a source, mention the label shown in brackets. " +
      "Keep answers concise and well-structured.",
  };
}

/**
 * buildAugmentedUserMessage wraps the user's raw question in a context block
 * containing the freshly-retrieved chunks.
 *
 * By re-retrieving for every turn we ensure the context is always relevant
 * to the *current* question even as the conversation topic shifts.
 *
 * @param question - The raw text the user typed
 * @param chunks   - Retrieved chunk strings from the vector search
 */
function buildAugmentedUserMessage(question: string, chunks: string[]): ChatMessage {
  if (chunks.length === 0) {
    // No relevant chunks — ask the model to answer from general knowledge
    // and make clear that the knowledge base had nothing.
    return {
      role: "user",
      content:
        `(No relevant context was found in the knowledge base for this question.)\n\n` +
        `Question: ${question}`,
    };
  }

  const contextBlock = chunks
    .map((chunk, i) => `[${i + 1}] ${chunk}`)
    .join("\n\n");

  return {
    role: "user",
    content:
      `Context passages:\n` +
      `─────────────────\n` +
      `${contextBlock}\n` +
      `─────────────────\n\n` +
      `Question: ${question}`,
  };
}

// ---------------------------------------------------------------------------
// Vector retrieval
// ---------------------------------------------------------------------------

/**
 * retrieveChunks embeds the user's question and queries the vector index,
 * returning the content strings of the top-K nearest chunks.
 *
 * Returns an empty array (rather than throwing) if the knowledge base is
 * empty or the search fails, so the chatbot can gracefully inform the user
 * instead of crashing.
 *
 * @param ollama   - OllamaClient for embedding the question
 * @param db       - TursoClient for running the vector search
 * @param question - The user's question text
 */
async function retrieveChunks(
  ollama: OllamaClient,
  db: TursoClient,
  question: string
): Promise<string[]> {
  let embedding: number[];
  try {
    embedding = await ollama.embed(question);
  } catch {
    return []; // Ollama may be temporarily unavailable
  }

  const queryVectorJson = JSON.stringify(embedding);

  try {
    const rows = await db.fetchAll(
      `SELECT c.content
       FROM vector_top_k('${config.tableName}_vec_idx', vector32(?), ?) AS v
       JOIN ${config.tableName} AS c ON c.id = v.id
       ORDER BY v.distance ASC`,
      [queryVectorJson, config.topK]
    );
    return rows.map((r) => r.content);
  } catch {
    return [];
  }
}

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

/**
 * main starts the interactive chatbot REPL.
 *
 * The conversation loop:
 *   1. Print a "> " prompt and wait for user input.
 *   2. Retrieve relevant chunks for the question.
 *   3. Append an augmented user message to the history.
 *   4. Stream the model's reply, writing each token directly to stdout.
 *   5. Collect the full reply and append it to the history as an assistant
 *      message so future turns have context.
 *   6. Repeat until the user types "exit", "quit", or presses Ctrl-D.
 */
async function main(): Promise<void> {
  console.log("═".repeat(60));
  console.log("  RAG Chatbot");
  console.log(`  Model  : ${config.chatModel}`);
  console.log(`  Embed  : ${config.embedModel}`);
  console.log(`  Top-K  : ${config.topK}`);
  console.log("  Type 'exit' or press Ctrl-D to quit.");
  console.log("═".repeat(60));
  console.log("");

  const db = new TursoClient();
  const ollama = new OllamaClient();

  // Conversation history — grows with each turn
  const history: ChatMessage[] = [buildSystemMessage()];

  // readline interface for terminal I/O
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: true,
  });

  // Wrap readline.question in a Promise for cleaner async flow
  const askUser = (): Promise<string | null> =>
    new Promise((resolve) => {
      rl.question("\nYou > ", (answer) => resolve(answer));
      rl.once("close", () => resolve(null)); // Ctrl-D
    });

  // Main conversation loop
  while (true) {
    const input = await askUser();

    // null means the stream was closed (Ctrl-D)
    if (input === null) {
      console.log("\n\nGoodbye!");
      break;
    }

    const trimmed = input.trim();

    if (!trimmed) continue; // blank line — just re-prompt

    if (["exit", "quit", "bye"].includes(trimmed.toLowerCase())) {
      console.log("Goodbye!");
      rl.close();
      break;
    }

    // ---- Retrieve -------------------------------------------------------
    process.stdout.write("\n[Retrieving context…]\n");
    const chunks = await retrieveChunks(ollama, db, trimmed);

    if (chunks.length === 0) {
      process.stdout.write(
        "[No relevant chunks found in knowledge base — answering from model knowledge.]\n"
      );
    } else {
      process.stdout.write(`[${chunks.length} chunk(s) retrieved.]\n`);
    }

    // ---- Augment --------------------------------------------------------
    const userMsg = buildAugmentedUserMessage(trimmed, chunks);
    history.push(userMsg);

    // ---- Generate (streaming) -------------------------------------------
    process.stdout.write("\nAssistant > ");

    let fullReply = "";

    try {
      await ollama.chatStream([...history], (token) => {
        process.stdout.write(token);
        fullReply += token;
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      process.stdout.write(`\n[Generation error: ${msg}]\n`);
      // Remove the user message we just appended so history stays consistent
      history.pop();
      continue;
    }

    // Ensure cursor lands on a new line after the streamed reply
    process.stdout.write("\n");

    // ---- Update history -------------------------------------------------
    history.push({ role: "assistant", content: fullReply });
  }
}

// ---------------------------------------------------------------------------
// Entry
// ---------------------------------------------------------------------------

main().catch((err) => {
  console.error("[chatbot] Fatal error:", err);
  process.exit(1);
});
