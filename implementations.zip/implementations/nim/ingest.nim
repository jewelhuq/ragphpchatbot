## ingest.nim
## Document ingestion pipeline for the Nim RAG system.
##
## Walk order:
##   1. Create the `documents` table and its vector index if they don't exist.
##   2. Recursively walk `config.docsDir` for supported file extensions.
##   3. Compute an MD5 fingerprint of each file's content.
##   4. Skip the file if an identical fingerprint already exists in the DB.
##   5. Parse the file to plain text, split it into chunks, embed each chunk.
##   6. Insert the chunk, its embedding, and its metadata into Turso.
##
## Run with:
##   nim c -r --gc:arc ingest.nim
##   nim c -r --gc:arc ingest.nim /path/to/custom/docs

import os, strutils, sequtils, md5, json
import src/config, src/turso, src/ollama, src/chunker, src/parser

# ---------------------------------------------------------------------------
# Schema helpers
# ---------------------------------------------------------------------------

proc ensureSchema(db: TursoClient) =
  ## Creates the documents table and its vector similarity index when they do
  ## not already exist.  Safe to call repeatedly — uses IF NOT EXISTS guards.
  ##
  ## The `embedding` column uses libSQL's F32_BLOB type, which stores a
  ## compact binary representation of 32-bit floats compatible with the
  ## vector_top_k() table-valued function.
  let cfg = defaultConfig()
  let dims = cfg.embeddingDims

  db.execute("""
    CREATE TABLE IF NOT EXISTS documents (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      source    TEXT NOT NULL,
      chunk_idx INTEGER NOT NULL,
      content   TEXT NOT NULL,
      md5hash   TEXT NOT NULL,
      embedding F32_BLOB(""" & $dims & """)
    )
  """)

  db.execute("""
    CREATE INDEX IF NOT EXISTS documents_vec_idx
    ON documents (libsql_vector_idx(embedding))
  """)

  echo "Schema ready."

# ---------------------------------------------------------------------------
# Ingestion helpers
# ---------------------------------------------------------------------------

proc hashExists(db: TursoClient, fingerprint: string): bool =
  ## Returns true when at least one row with this MD5 fingerprint exists,
  ## meaning the file has already been ingested and can be skipped.
  let rows = db.fetchAll(
    "SELECT id FROM documents WHERE md5hash = ? LIMIT 1",
    @[%fingerprint]
  )
  return rows.len > 0

proc ingestFile(db: TursoClient, olla: OllamaClient,
                filePath: string, cfg: RagConfig) =
  ## Parses `filePath`, splits it into chunks, embeds each chunk, and inserts
  ## the results into Turso.  Files whose MD5 fingerprint is already present
  ## in the database are silently skipped to allow incremental re-runs.
  let rawText = parser.parse(filePath)
  if rawText.strip().len == 0:
    echo "  Skipping empty file: ", filePath
    return

  let fingerprint = $toMD5(rawText)
  if hashExists(db, fingerprint):
    echo "  Already ingested (MD5 match): ", filePath
    return

  echo "  Chunking: ", filePath
  let source = filePath.extractFilename()
  let chunks  = chunker.chunk(rawText, source, cfg.chunkSize)
  echo "  ", chunks.len, " chunks"

  for idx, chunkText in chunks:
    stdout.write("    chunk " & $(idx + 1) & "/" & $chunks.len & " embedding... ")
    stdout.flushFile()

    let vec = olla.embed(chunkText)
    let vecStr = buildVectorParam(vec)

    # vector32() is the libSQL function that parses the bracket notation
    db.execute(
      """INSERT INTO documents (source, chunk_idx, content, md5hash, embedding)
         VALUES (?, ?, ?, ?, vector32(?))""",
      @[%source, %idx, %chunkText, %fingerprint, %vecStr]
    )
    echo "done"

  echo "  Ingested ", chunks.len, " chunks from ", filePath

# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

proc main() =
  ## Entry point: sets up clients, ensures the schema exists, then walks the
  ## documents directory and ingests every supported file.
  let cfg = defaultConfig()

  # Allow overriding the docs directory via a command-line argument
  let docsDir = if paramCount() >= 1: paramStr(1) else: cfg.docsDir

  if not dirExists(docsDir):
    echo "Documents directory not found: ", docsDir
    echo "Create it and add .txt / .md files, then re-run ingest."
    quit(1)

  let db   = newTursoClient(cfg.tursoUrl, cfg.tursoToken)
  let olla = newOllamaClient(cfg.ollamaUrl, cfg.embeddingModel, cfg.chatModel)

  ensureSchema(db)

  let supported = [".txt", ".md", ".rst", ".text", ".pdf", ".docx"]
  var total = 0

  echo "Walking: ", docsDir
  for kind, path in walkDirRec(docsDir):
    if kind != pcFile:
      continue
    let ext = path.splitFile().ext.toLowerAscii()
    if ext notin supported:
      continue
    echo "Processing: ", path
    ingestFile(db, olla, path, cfg)
    inc total

  echo ""
  echo "Ingestion complete. Files processed: ", total

main()
