# Nim RAG System

A Retrieval-Augmented Generation (RAG) implementation in Nim that connects to Turso DB for vector storage and Ollama for embeddings and chat generation.

## Architecture

```
docs/           <- Source documents (.txt, .md)
src/
  config.nim    <- RagConfig type and defaultConfig()
  turso.nim     <- Turso libSQL HTTP client
  ollama.nim    <- Ollama embed + chatStream client
  chunker.nim   <- Paragraph/heading-aware text splitter
  parser.nim    <- File-to-text extractor
ingest.nim      <- Walk docs, embed, insert into Turso
query.nim       <- One-shot semantic search CLI
rag.nim         <- Retrieve + prompt + stream pipeline
chatbot.nim     <- Interactive multi-turn chatbot
rag.nimble      <- Nimble package + task definitions
```

## Prerequisites

- **Nim >= 2.0.0** — https://nim-lang.org/install.html
- **Ollama** running locally on port 11434 — https://ollama.com
- **Turso account** with the endpoint and token already configured in `src/config.nim`

Pull the required Ollama models:

```sh
ollama pull nomic-embed-text
ollama pull gemma3:1b
```

## Setup

1. Clone or copy this directory.
2. Create a `docs/` folder and add `.txt` or `.md` files:

```sh
mkdir docs
echo "Your document content here." > docs/example.txt
```

3. (Optional) Edit `src/config.nim` to change the Turso URL/token, model names, or `docsDir`.

## Running

All commands use `--gc:arc` for deterministic, zero-overhead memory management.

### Ingest documents

```sh
nim c -r --gc:arc ingest.nim
# or with a custom docs path:
nim c -r --gc:arc ingest.nim /path/to/my/docs
```

Re-running ingest is safe — files are fingerprinted with MD5 and skipped if already present.

### Interactive chatbot

```sh
nim c -r --gc:arc chatbot.nim
```

Type your question and press Enter. Type `exit` or `quit` to leave.

### One-shot semantic search

```sh
nim c -r --gc:arc query.nim "What is the refund policy?"
```

### One-shot RAG answer

```sh
nim c -r --gc:arc rag.nim "Explain how embeddings work"
```

## Build all binaries at once

```sh
nimble build_all
./ingest
./chatbot
./query "search text"
./rag_cli "question"
```

## Performance tips

- Always compile with `--gc:arc` (or `--gc:orc`) for deterministic memory management and minimal runtime overhead.
- Add `-d:release` for optimised builds:

```sh
nim c -r --gc:arc -d:release chatbot.nim
```

- Add `-d:strip --opt:size` if binary size matters.

## Configuration reference

All settings live in `src/config.nim` in `defaultConfig()`:

| Field            | Default                    | Description                          |
|------------------|----------------------------|--------------------------------------|
| `tursoUrl`       | (your Turso endpoint)      | Turso HTTPS database URL             |
| `tursoToken`     | (your JWT)                 | Bearer token for Turso auth          |
| `ollamaUrl`      | `http://127.0.0.1:11434`   | Ollama base URL                      |
| `chatModel`      | `gemma3:1b`                | Model used for answer generation     |
| `embeddingModel` | `nomic-embed-text`         | Model used for embeddings            |
| `embeddingDims`  | `768`                      | Vector dimensionality                |
| `topK`           | `5`                        | Chunks retrieved per query           |
| `docsDir`        | `docs`                     | Directory walked by ingest.nim       |
| `chunkSize`      | `1500`                     | Soft character limit per chunk       |

## Extending

- **PDF support**: implement the stub in `src/parser.nim` using `execCmdEx("pdftotext ...")`.
- **DOCX support**: implement the stub in `src/parser.nim` using `execCmdEx("docx2txt ...")`.
- **Async streaming**: replace `newHttpClient` with `newAsyncHttpClient` in `src/ollama.nim` and propagate `async`/`await` through the call chain.
- **Different embedding model**: change `embeddingModel` and `embeddingDims` in `defaultConfig()`, then re-run `ingest.nim` on a fresh database.
