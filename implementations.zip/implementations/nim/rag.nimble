# Package

name        = "rag"
version     = "0.1.0"
author      = "Engi"
description = "Retrieval-Augmented Generation system using Turso DB and Ollama"
license     = "MIT"
srcDir      = "."

# Dependencies

requires "nim >= 2.0.0"

# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

task ingest, "Ingest documents into Turso":
  ## Compile and run the ingestion pipeline.
  ## Pass a custom docs directory as an argument:
  ##   nimble ingest -- /path/to/docs
  exec "nim c -r --gc:arc ingest.nim"

task chat, "Start the interactive RAG chatbot":
  ## Compile and launch the interactive chatbot.
  exec "nim c -r --gc:arc chatbot.nim"

task query, "Run a one-shot semantic search":
  ## Compile and run a single query.
  ## Example: nimble query -- "What is RAG?"
  exec "nim c -r --gc:arc query.nim"

task rag, "Run a single RAG question and stream the answer":
  ## Compile and run a single RAG question.
  ## Example: nimble rag -- "Explain the refund policy"
  exec "nim c -r --gc:arc rag.nim"

task build_all, "Compile all executables (no run)":
  ## Produces: ingest, query, rag, chatbot binaries in the current directory.
  exec "nim c --gc:arc -o:ingest   ingest.nim"
  exec "nim c --gc:arc -o:query    query.nim"
  exec "nim c --gc:arc -o:rag_cli  rag.nim"
  exec "nim c --gc:arc -o:chatbot  chatbot.nim"
