## chatbot.nim
## Interactive command-line chatbot powered by the RAG pipeline.
##
## Maintains a rolling conversation history so the model can reference
## earlier turns.  Type "exit" or "quit" (or press Ctrl-C) to leave.
##
## Run with:
##   nim c -r --gc:arc chatbot.nim
##
## The history window is capped at MAX_HISTORY_TURNS pairs to keep the
## context length manageable.  Oldest turns are dropped first.

import os, strutils, terminal
import src/config, src/turso, src/ollama
import rag

const MAX_HISTORY_TURNS = 10  ## Maximum user+assistant pairs retained in memory

proc printBanner() =
  ## Prints a welcome message and usage instructions at startup.
  echo "============================================"
  echo "  Nim RAG Chatbot"
  echo "  Model : ", defaultConfig().chatModel
  echo "  Type 'exit' or 'quit' to leave."
  echo "============================================"
  echo ""

proc trimHistory(history: var seq[ChatMessage]) =
  ## Removes the oldest user/assistant pair when the history exceeds the cap.
  ## Always trims in pairs so the system-prompt position stays stable.
  while history.len > MAX_HISTORY_TURNS * 2:
    history.delete(0)
    if history.len > 0:
      history.delete(0)

proc main() =
  ## Interactive REPL: reads a line, runs the RAG pipeline, streams the
  ## response to stdout, then loops.  History is maintained across turns.
  printBanner()

  let cfg  = defaultConfig()
  let db   = newTursoClient(cfg.tursoUrl, cfg.tursoToken)
  let olla = newOllamaClient(cfg.ollamaUrl, cfg.embeddingModel, cfg.chatModel)

  var history: seq[ChatMessage] = @[]

  while true:
    stdout.write("You: ")
    stdout.flushFile()

    var line: string
    try:
      line = stdin.readLine()
    except EOFError:
      echo ""
      echo "Goodbye!"
      break

    let trimmedLine = line.strip()
    if trimmedLine.len == 0:
      continue

    if trimmedLine.toLowerAscii() in ["exit", "quit", "bye", "q"]:
      echo "Goodbye!"
      break

    # Collect the full assistant reply so it can be added to history
    var assistantReply = ""

    stdout.write("Assistant: ")
    stdout.flushFile()

    askStream(db, olla, trimmedLine, history, cfg, proc(chunk: string) =
      stdout.write(chunk)
      stdout.flushFile()
      assistantReply &= chunk
    )

    echo ""   # newline after the streamed response
    echo ""

    # Update conversation history with this turn
    history.add(newMessage("user",      trimmedLine))
    history.add(newMessage("assistant", assistantReply))
    trimHistory(history)

main()
