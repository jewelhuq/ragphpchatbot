## query.nim
## One-shot semantic search CLI tool.
##
## Embeds the query string provided as the first command-line argument,
## runs a vector_top_k similarity search against Turso, and prints the
## matching chunks with their sources and similarity ranks.
##
## Usage:
##   nim c -r --gc:arc query.nim "What is the refund policy?"

import os, strutils, json
import src/config, src/turso, src/ollama

proc main() =
  ## Embeds the CLI query, retrieves the top-K chunks from Turso, and
  ## prints each result's rank, source file, and content preview.
  if paramCount() < 1:
    echo "Usage: query <search text>"
    echo "Example: query \"What is retrieval-augmented generation?\""
    quit(1)

  let queryText = paramStr(1)
  let cfg  = defaultConfig()
  let db   = newTursoClient(cfg.tursoUrl, cfg.tursoToken)
  let olla = newOllamaClient(cfg.ollamaUrl, cfg.embeddingModel, cfg.chatModel)

  echo "Embedding query..."
  let vec    = olla.embed(queryText)
  let vecStr = buildVectorParam(vec)

  echo "Searching top ", cfg.topK, " chunks..."
  # vector_top_k returns (id, distance) pairs; JOIN to get content
  let sql = """
    SELECT d.id, d.source, d.content,
           v.distance
    FROM vector_top_k('documents_vec_idx', vector32(?), ?) AS v
    JOIN documents AS d ON d.id = v.id
    ORDER BY v.distance ASC
  """
  let rows = db.fetchAll(sql, @[%vecStr, %cfg.topK])

  if rows.len == 0:
    echo "No results found. Have you run ingest.nim yet?"
    quit(0)

  echo ""
  echo "=== Top ", rows.len, " Results ==="
  echo ""

  for i, row in rows:
    let source   = row.getOrDefault("source",   "(unknown)")
    let content  = row.getOrDefault("content",  "")
    let distance = row.getOrDefault("distance", "?")

    echo "--- Result ", i + 1, " ---"
    echo "Source:   ", source
    echo "Distance: ", distance
    echo ""

    # Print up to the first 400 characters of the chunk as a preview
    let preview = if content.len > 400: content[0 .. 399] & "..." else: content
    echo preview
    echo ""

main()
