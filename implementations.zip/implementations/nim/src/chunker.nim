## chunker.nim
## Splits a document string into overlapping, context-enriched chunks
## suitable for embedding and retrieval.
##
## Strategy:
##   1. Split on blank lines (\n\n) to respect natural paragraph breaks.
##   2. Detect ALL-CAPS headings (lines shorter than 120 chars where every
##      alphabetic character is uppercase) and track the current section.
##   3. Prepend "Source: <source>\nSection: <heading>\n" to every chunk so
##      the retriever can surface provenance alongside the text.
##   4. Accumulate paragraphs until the chunk would exceed chunkSize, then
##      flush and start a new chunk.  Chunks shorter than 100 characters
##      are merged with the next paragraph rather than emitted alone.

import strutils, sequtils

func isAllCapsHeading(line: string): bool =
  ## Returns true when `line` looks like an ALL-CAPS section heading:
  ## non-empty, shorter than 120 characters, and every ASCII letter is
  ## uppercase.  Numbers, punctuation, and spaces are ignored.
  let stripped = line.strip()
  if stripped.len == 0 or stripped.len >= 120:
    return false
  var hasLetter = false
  for ch in stripped:
    if ch.isAlphaAscii():
      if ch.isLowerAscii():
        return false
      hasLetter = true
  return hasLetter

proc chunk*(text, source: string, chunkSize: int = 1500): seq[string] =
  ## Splits `text` (the full content of a document identified by `source`)
  ## into a sequence of context-enriched chunk strings.
  ##
  ## Each returned string begins with a two-line prefix:
  ##   Source: <source>
  ##   Section: <heading>
  ##
  ## followed by the accumulated paragraph text.  The `chunkSize` parameter
  ## controls the soft upper limit on chunk length (in characters).
  result = @[]

  let paragraphs = text.split("\n\n")
  var currentHeading = "Introduction"
  var buffer = ""

  proc flush(buf, src, heading: string): string =
    ## Wraps buffered paragraph text with its provenance prefix.
    "Source: " & src & "\nSection: " & heading & "\n\n" & buf.strip()

  for para in paragraphs:
    let trimmed = para.strip()
    if trimmed.len == 0:
      continue

    # Check whether this paragraph is itself a heading
    let firstLine = trimmed.splitLines()[0]
    if isAllCapsHeading(firstLine):
      # Flush whatever we have before starting the new section
      if buffer.strip().len >= 100:
        result.add(flush(buffer, source, currentHeading))
        buffer = ""
      currentHeading = firstLine.strip()
      # The heading text itself goes into the next chunk's body only if
      # there is additional content beyond the heading line
      let rest = trimmed[firstLine.len .. ^1].strip()
      if rest.len > 0:
        buffer = rest & "\n\n"
      continue

    # Normal paragraph — append to buffer
    if buffer.len + trimmed.len + 2 > chunkSize and buffer.strip().len >= 100:
      result.add(flush(buffer, source, currentHeading))
      buffer = trimmed & "\n\n"
    else:
      buffer &= trimmed & "\n\n"

  # Flush remaining buffer
  let finalBuf = buffer.strip()
  if finalBuf.len >= 100:
    result.add(flush(buffer, source, currentHeading))
  elif finalBuf.len > 0 and result.len > 0:
    # Merge tiny tail into the last chunk
    result[^1] &= "\n\n" & finalBuf
  elif finalBuf.len > 0:
    # Edge case: entire document was below 100 chars — emit it anyway
    result.add(flush(buffer, source, currentHeading))
