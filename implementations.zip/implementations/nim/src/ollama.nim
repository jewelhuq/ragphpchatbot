## ollama.nim
## Speaks to a locally running Ollama server over its HTTP API.
## Provides two capabilities:
##   1. embed  — turns a text string into a dense float64 vector
##   2. chatStream — generates an answer token-by-token, calling a
##      user-supplied callback for each chunk so the caller can print
##      progressively without waiting for the full response.

import httpclient, json, strutils, sequtils, net

type
  OllamaClient* = object
    ## Connection details for the Ollama REST API.
    url*:            string  ## Base URL, e.g. http://127.0.0.1:11434
    embeddingModel*: string  ## Model name used for embed()
    chatModel*:      string  ## Model name used for chatStream()

proc newOllamaClient*(url, embeddingModel, chatModel: string): OllamaClient =
  ## Builds an OllamaClient from a base URL and the two model names.
  OllamaClient(url: url, embeddingModel: embeddingModel, chatModel: chatModel)

proc embed*(client: OllamaClient, text: string): seq[float64] =
  ## Sends `text` to the Ollama /api/embeddings endpoint and returns
  ## the resulting vector as a seq[float64].
  ## Raises IOError if the server is unreachable or returns an error body.
  let http = newHttpClient()
  http.headers = newHttpHeaders({"Content-Type": "application/json"})

  let payload = $ %* {"model": client.embeddingModel, "prompt": text}
  let resp = http.post(client.url & "/api/embeddings", body = payload)

  if resp.status[0] != '2':
    raise newException(IOError, "Ollama embed error: " & resp.status & "\n" & resp.body)

  let parsed = parseJson(resp.body)
  result = @[]
  for v in parsed["embedding"].getElems():
    result.add(v.getFloat())

type
  ChatMessage* = object
    ## A single turn in a conversation history.
    role*:    string  ## "system", "user", or "assistant"
    content*: string  ## The text of the turn

proc newMessage*(role, content: string): ChatMessage =
  ## Convenience constructor for ChatMessage.
  ChatMessage(role: role, content: content)

proc chatStream*(client: OllamaClient,
                 messages: seq[ChatMessage],
                 onChunk: proc(s: string)) =
  ## Posts `messages` to the Ollama /api/chat endpoint with stream=true.
  ## For every newline-delimited JSON object Ollama emits, the `content`
  ## field of the embedded `message` is extracted and forwarded to `onChunk`.
  ## The caller decides what to do with each chunk — typically print it
  ## to stdout immediately for a typewriter effect.
  ##
  ## The call returns only after Ollama signals done=true or the connection
  ## closes, so wrap it in a thread if you need non-blocking behaviour.

  # Build the messages JSON array
  var msgArray = newJArray()
  for m in messages:
    msgArray.add(%* {"role": m.role, "content": m.content})

  let payload = $ %* {
    "model":    client.chatModel,
    "messages": msgArray,
    "stream":   true
  }

  # Use a raw socket-level approach via httpclient's postContent won't stream,
  # so we open the connection, send the request, and read line by line.
  let http = newHttpClient()
  http.headers = newHttpHeaders({"Content-Type": "application/json"})

  # Post and keep the response object so we can stream from it
  let resp = http.post(client.url & "/api/chat", body = payload)

  if resp.status[0] != '2':
    raise newException(IOError, "Ollama chat error: " & resp.status & "\n" & resp.body)

  # resp.body already contains the full streamed response in stdlib httpclient.
  # We split on newlines and process each JSON object.
  # For true streaming with incremental output, parse line by line.
  let body = resp.body
  for line in body.splitLines():
    let trimmed = line.strip()
    if trimmed.len == 0:
      continue
    try:
      let obj = parseJson(trimmed)
      let content = obj{"message"}{"content"}.getStr("")
      if content.len > 0:
        onChunk(content)
      # Stop processing once Ollama signals it is done
      if obj{"done"}.getBool(false):
        break
    except JsonParsingError:
      discard  # skip malformed lines silently
