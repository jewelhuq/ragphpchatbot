## turso.nim
## Thin client for the Turso libSQL HTTP API.
## Sends SQL statements as JSON, parses the column/row response,
## and returns results as sequences of string-keyed tables — a format
## every other module can consume without pulling in extra dependencies.

import httpclient, json, tables, strutils, sequtils

type
  TursoClient* = object
    ## Wraps the HTTP connection details needed to reach a Turso database.
    url*:   string  ## Full HTTPS endpoint, e.g. https://<db>.turso.io
    token*: string  ## JWT bearer token for authentication

proc newTursoClient*(url, token: string): TursoClient =
  ## Constructs a TursoClient from an endpoint URL and a bearer token.
  TursoClient(url: url, token: token)

proc buildPayload(sql: string, params: seq[JsonNode]): string =
  ## Assembles the JSON body expected by the Turso pipeline endpoint.
  ## Turso accepts a "requests" array; each element is either a "execute"
  ## statement or a "close" frame.  We always append a close frame so the
  ## server releases the implicit transaction.
  let argNodes = if params.len > 0: params else: newSeq[JsonNode]()
  let argsArray = %argNodes
  let payload = %* {
    "requests": [
      {
        "type": "execute",
        "stmt": {
          "sql": sql,
          "args": argsArray
        }
      },
      {"type": "close"}
    ]
  }
  return $payload

proc execute*(client: TursoClient, sql: string, params: seq[JsonNode] = @[]) =
  ## Sends a write statement (INSERT, CREATE, UPDATE, DELETE) to Turso and
  ## discards the response body.  Raises an IOError if the server returns
  ## a non-2xx status code.
  let http = newHttpClient()
  http.headers = newHttpHeaders({
    "Authorization": "Bearer " & client.token,
    "Content-Type":  "application/json"
  })
  let body = buildPayload(sql, params)
  let resp = http.post(client.url & "/v2/pipeline", body = body)
  if resp.status[0] != '2':
    raise newException(IOError, "Turso execute error: " & resp.status & "\n" & resp.body)

proc fetchAll*(client: TursoClient, sql: string,
               params: seq[JsonNode] = @[]): seq[Table[string, string]] =
  ## Executes a SELECT statement and returns every row as a Table mapping
  ## column name to its string value.  NULL cells become the empty string.
  ## Raises an IOError on HTTP failure or a malformed response.
  let http = newHttpClient()
  http.headers = newHttpHeaders({
    "Authorization": "Bearer " & client.token,
    "Content-Type":  "application/json"
  })
  let body = buildPayload(sql, params)
  let resp = http.post(client.url & "/v2/pipeline", body = body)
  if resp.status[0] != '2':
    raise newException(IOError, "Turso fetchAll error: " & resp.status & "\n" & resp.body)

  let parsed = parseJson(resp.body)

  # The pipeline response wraps each request result under "results"
  # Structure: { results: [ { type: "ok", response: { type: "execute", result: { cols: [...], rows: [...] } } } ] }
  result = @[]

  let results = parsed["results"]
  if results.len == 0:
    return result

  let firstResult = results[0]
  if firstResult["type"].getStr() != "ok":
    let errMsg = firstResult{"error"}{"message"}.getStr("unknown error")
    raise newException(IOError, "Turso query error: " & errMsg)

  let queryResult = firstResult["response"]["result"]
  let cols = queryResult["cols"]
  let rows = queryResult["rows"]

  # Build column name list in order
  var colNames: seq[string] = @[]
  for col in cols:
    colNames.add(col["name"].getStr())

  # Zip each row with column names
  for row in rows:
    var rowTable = initTable[string, string]()
    for i, cell in row.getElems():
      let colName = if i < colNames.len: colNames[i] else: "col" & $i
      # Each cell is { type: "text"|"integer"|"null", value: "..." }
      let cellType = cell{"type"}.getStr("null")
      let cellVal  = if cellType == "null": "" else: cell{"value"}.getStr("")
      rowTable[colName] = cellVal
    result.add(rowTable)

proc buildVectorParam*(vec: seq[float64]): string =
  ## Converts a float64 sequence into the compact bracket notation that
  ## Turso's vector32() SQL function expects, e.g. "[0.1,0.2,0.3]".
  var parts: seq[string] = @[]
  for v in vec:
    parts.add($v)
  return "[" & parts.join(",") & "]"
