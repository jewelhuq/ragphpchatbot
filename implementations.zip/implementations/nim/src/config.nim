﻿## config.nim
## Holds all runtime configuration for the Nim RAG system.
## Central place to change URLs, tokens, model names, and tuning knobs
## without touching any other source file.

type
  RagConfig* = object
    ## Everything the system needs to talk to Turso and Ollama.
    tursoUrl*:       string  ## HTTPS endpoint of the Turso libSQL database
    tursoToken*:     string  ## Bearer token for Turso HTTP API authentication
    ollamaUrl*:      string  ## Base URL of the local Ollama instance
    chatModel*:      string  ## Ollama model used for answer generation
    embeddingModel*: string  ## Ollama model used to produce embedding vectors
    embeddingDims*:  int     ## Dimensionality of the embedding (must match DB schema)
    topK*:           int     ## Number of nearest-neighbour chunks to retrieve
    docsDir*:        string  ## Directory that ingest.nim walks for source documents
    chunkSize*:      int     ## Approximate character length of each text chunk

proc defaultConfig*(): RagConfig =
  ## Returns a fully populated RagConfig with the project's real credentials and
  ## sensible defaults.  Override individual fields after calling this proc when
  ## you need environment-specific values (e.g. a different docsDir in tests).
  RagConfig(
    tursoUrl:       "https://your-db-name.turso.io",
    tursoToken:     "your-turso-token-here",
    ollamaUrl:      "http://127.0.0.1:11434",
    chatModel:      "gemma3:1b",
    embeddingModel: "nomic-embed-text",
    embeddingDims:  768,
    topK:           5,
    docsDir:        "docs",
    chunkSize:      1500
  )
