## parser.nim
## Extracts raw text from documents on disk.
## Currently handles plain-text files natively; PDF and DOCX require
## external tools and are documented as stubs to guide future contributors.

import os, strutils

proc parse*(filePath: string): string =
  ## Reads `filePath` and returns its contents as a plain UTF-8 string.
  ##
  ## Supported formats:
  ##   .txt  — read directly with readFile
  ##   .md   — read directly (Markdown is plain text)
  ##   .pdf  — STUB: returns a placeholder string.
  ##           To implement: shell out to `pdftotext -layout <file> -`
  ##           (poppler-utils) and capture stdout.
  ##   .docx — STUB: returns a placeholder string.
  ##           To implement: unzip the docx, parse word/document.xml,
  ##           and strip XML tags, or shell out to `docx2txt`.
  ##   other — returns the raw bytes as a string (best-effort).

  let ext = filePath.splitFile().ext.toLowerAscii()

  case ext
  of ".txt", ".md", ".rst", ".text":
    ## Plain-text formats — just read the file.
    result = readFile(filePath)

  of ".pdf":
    ## PDF extraction stub.
    ## Real implementation would call an external tool such as:
    ##   import osproc
    ##   let (output, exitCode) = execCmdEx("pdftotext -layout \"" & filePath & "\" -")
    ##   if exitCode == 0: result = output
    ##   else: raise newException(IOError, "pdftotext failed for: " & filePath)
    result = "[PDF content not extracted — install poppler-utils and implement the stub in parser.nim]\nFile: " & filePath

  of ".docx":
    ## DOCX extraction stub.
    ## Real implementation would use a ZIP parser to read word/document.xml:
    ##   import zippy   # or shell out to docx2txt
    ##   let (output, exitCode) = execCmdEx("docx2txt \"" & filePath & "\" -")
    ##   if exitCode == 0: result = output
    ##   else: raise newException(IOError, "docx2txt failed for: " & filePath)
    result = "[DOCX content not extracted — install docx2txt and implement the stub in parser.nim]\nFile: " & filePath

  else:
    ## Unknown format — attempt to read as raw text.
    ## Binary files will produce garbage but won't crash the pipeline.
    try:
      result = readFile(filePath)
    except IOError as e:
      raise newException(IOError, "Cannot read file " & filePath & ": " & e.msg)
