## rag.nim
## Core Retrieval-Augmented Generation pipeline.
##
## Given a user question this module:
##   1. Embeds the question.
##   2. Retrieves the most semantically similar document chunks from Turso.
##   3. Assembles a grounded system prompt containing the retrieved context.
##   4. Streams the language-model's answer token by token via Ollama.
##
## This module is designed to be imported by chatbot.nim and other frontends
## rather than run directly, but it also exposes a runOnce() convenience proc
## for scripted single-question usage.

import os, strutils, json
import src/config, src/turso, src/ollama

# ---------------------------------------------------------------------------
# Context retrieval
# ---------------------------------------------------------------------------

proc retrieveChunks*(db: TursoClient, olla: OllamaClient,
                     queryText: string, topK: int): seq[string] =
  ## Embeds `queryText` and returns the `topK` most similar document chunk
  ## strings from Turso, ordered from most to least similar.
  let vec    = olla.embed(queryText)
  let vecStr = buildVectorParam(vec)

  let sql = """
    SELECT d.content
    FROM vector_top_k('documents_vec_idx', vector32(?), ?) AS v
    JOIN documents AS d ON d.id = v.id
    ORDER BY v.distance ASC
  """
  let rows = db.fetchAll(sql, @[%vecStr, %topK])

  result = @[]
  for row in rows:
    let content = row.getOrDefault("content", "")
    if content.len > 0:
      result.add(content)

# ---------------------------------------------------------------------------
# Prompt assembly
# ---------------------------------------------------------------------------

proc buildSystemPrompt(chunks: seq[string]): string =
  ## Weaves the retrieved chunks into a system prompt that instructs the model
  ## to ground its answer in the provided context and admit uncertainty when
  ## the context does not cover the question.
  var ctx = ""
  for i, c in chunks:
    ctx &= "--- Context " & $(i + 1) & " ---\n" & c & "\n\n"

  result = """You are a helpful assistant that answers questions based on the provided context.
Use only the information in the context below to answer the user's question.
If the context does not contain enough information, say so clearly rather than guessing.

""" & ctx.strip()

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

proc askStream*(db: TursoClient, olla: OllamaClient,
                question: string, history: seq[ChatMessage],
                cfg: RagConfig, onChunk: proc(s: string)) =
  ## Full RAG pipeline with streaming output.
  ##
  ## Retrieves relevant chunks, builds the system prompt, prepends the
  ## conversation `history`, appends the current `question` as a user
  ## turn, then calls Ollama's chat endpoint with stream=true.  Each
  ## generated token is forwarded to `onChunk` as it arrives.
  let chunks = retrieveChunks(db, olla, question, cfg.topK)

  let sysPrompt = buildSystemPrompt(chunks)

  var messages: seq[ChatMessage] = @[newMessage("system", sysPrompt)]
  for msg in history:
    messages.add(msg)
  messages.add(newMessage("user", question))

  olla.chatStream(messages, onChunk)

proc runOnce*(question: string) =
  ## Convenience entry point: loads default config, runs one RAG query,
  ## and streams the answer to stdout.  Useful for shell scripting.
  let cfg  = defaultConfig()
  let db   = newTursoClient(cfg.tursoUrl, cfg.tursoToken)
  let olla = newOllamaClient(cfg.ollamaUrl, cfg.embeddingModel, cfg.chatModel)

  echo "Question: ", question
  echo ""
  echo "Answer:"

  askStream(db, olla, question, @[], cfg, proc(chunk: string) =
    stdout.write(chunk)
    stdout.flushFile()
  )
  echo ""  # newline after streamed answer

when isMainModule:
  ## When run directly, expects the question as the first CLI argument.
  if paramCount() < 1:
    echo "Usage: rag <question>"
    quit(1)
  runOnce(paramStr(1))
