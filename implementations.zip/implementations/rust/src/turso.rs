/// Turso client — the librarian who reads and writes to our vector database.
///
/// Turso exposes a stateless HTTP API at `/v2/pipeline`.  Each request is a
/// JSON envelope containing one or more SQL statements; each statement can
/// carry typed positional parameters.  The response mirrors that structure,
/// with rows encoded as arrays of `{"type":"…","value":"…"}` objects.
///
/// We wrap all of that in two simple methods:
/// - `execute` — fire-and-forget DDL / DML (CREATE TABLE, INSERT, …)
/// - `fetch_all` — SELECT queries that hand back rows as string maps

use std::collections::HashMap;
use anyhow::{Context, Result};
use reqwest::Client;
use serde_json::{json, Value};

/// A single positional parameter in a Turso SQL statement.
///
/// Turso expects `{"type": "text"|"integer"|"float"|"blob"|"null", "value": "…"}`.
/// We expose a small helper to build them so callers never have to spell out
/// the JSON by hand.
pub fn param_text(v: &str) -> Value {
    json!({ "type": "text", "value": v })
}

pub fn param_integer(v: i64) -> Value {
    json!({ "type": "integer", "value": v.to_string() })
}

pub fn param_float(v: f64) -> Value {
    json!({ "type": "float", "value": v })
}

pub fn param_null() -> Value {
    json!({ "type": "null", "value": null })
}

/// The client holds the HTTP connection pool and the auth credentials.
/// It is cheap to clone because `reqwest::Client` is already an `Arc` inside.
#[derive(Clone)]
pub struct TursoClient {
    http: Client,
    url: String,
    token: String,
}

impl TursoClient {
    /// Construct a new client pointed at `url`, authenticated with `token`.
    pub fn new(url: impl Into<String>, token: impl Into<String>) -> Self {
        Self {
            http: Client::new(),
            url: url.into(),
            token: token.into(),
        }
    }

    /// Build the full pipeline endpoint URL.
    fn pipeline_url(&self) -> String {
        format!("{}/v2/pipeline", self.url)
    }

    /// The shared request builder — every call goes through here so that
    /// the auth header is never forgotten.
    fn pipeline_request(&self) -> reqwest::RequestBuilder {
        self.http
            .post(self.pipeline_url())
            .bearer_auth(&self.token)
            .header("Content-Type", "application/json")
    }

    /// Send one SQL statement and ignore the rows in the response.
    ///
    /// Perfect for DDL (`CREATE TABLE`) or DML (`INSERT`, `DELETE`) where we
    /// only care whether the statement succeeded.
    pub async fn execute(&self, sql: &str, params: Vec<Value>) -> Result<()> {
        let body = json!({
            "requests": [
                {
                    "type": "execute",
                    "stmt": {
                        "sql": sql,
                        "args": params
                    }
                },
                { "type": "close" }
            ]
        });

        let resp = self
            .pipeline_request()
            .json(&body)
            .send()
            .await
            .context("Failed to reach Turso pipeline endpoint")?;

        let status = resp.status();
        if !status.is_success() {
            let text = resp.text().await.unwrap_or_default();
            anyhow::bail!("Turso execute failed ({}): {}", status, text);
        }

        // Parse the response to surface any SQL-level errors.
        let json: Value = resp
            .json()
            .await
            .context("Failed to parse Turso execute response")?;

        // The pipeline response wraps each statement result; check for errors.
        if let Some(results) = json["results"].as_array() {
            for result in results {
                if result["type"] == "error" {
                    let msg = result["error"]["message"]
                        .as_str()
                        .unwrap_or("unknown error");
                    anyhow::bail!("Turso SQL error: {}", msg);
                }
            }
        }

        Ok(())
    }

    /// Send one SELECT statement and return all rows as a `Vec<HashMap<String, String>>`.
    ///
    /// Column values are coerced to strings regardless of their SQL type —
    /// simple and predictable for downstream code that just needs to read data.
    pub async fn fetch_all(
        &self,
        sql: &str,
        params: Vec<Value>,
    ) -> Result<Vec<HashMap<String, String>>> {
        let body = json!({
            "requests": [
                {
                    "type": "execute",
                    "stmt": {
                        "sql": sql,
                        "args": params
                    }
                },
                { "type": "close" }
            ]
        });

        let resp = self
            .pipeline_request()
            .json(&body)
            .send()
            .await
            .context("Failed to reach Turso pipeline endpoint")?;

        let status = resp.status();
        if !status.is_success() {
            let text = resp.text().await.unwrap_or_default();
            anyhow::bail!("Turso fetch_all failed ({}): {}", status, text);
        }

        let json: Value = resp
            .json()
            .await
            .context("Failed to parse Turso fetch_all response")?;

        // Navigate the nested structure:
        // results[0].response.result.{cols, rows}
        let result = &json["results"][0]["response"]["result"];

        // Extract column names in order.
        // We use an empty slice default rather than a temporary vec reference
        // to avoid lint warnings and keep borrows simple.
        let empty_array: Vec<Value> = Vec::new();

        let cols: Vec<String> = result["cols"]
            .as_array()
            .unwrap_or(&empty_array)
            .iter()
            .map(|c| c["name"].as_str().unwrap_or("").to_string())
            .collect();

        // Turn each row into a HashMap keyed by column name.
        // We zip column names with cell values so an out-of-bounds cell simply
        // produces an empty string rather than a panic.
        let rows = result["rows"]
            .as_array()
            .unwrap_or(&empty_array)
            .iter()
            .map(|row| {
                let cells: &Vec<Value> = row.as_array().unwrap_or(&empty_array);
                cols.iter()
                    .enumerate()
                    .map(|(i, col_name)| {
                        // Guard against a malformed response where a row has
                        // fewer cells than there are column names.
                        let value = match cells.get(i) {
                            None => String::new(),
                            Some(cell) => {
                                if cell["type"] == "null" {
                                    String::new()
                                } else {
                                    match &cell["value"] {
                                        Value::String(s) => s.clone(),
                                        Value::Number(n) => n.to_string(),
                                        Value::Bool(b) => b.to_string(),
                                        other => other.to_string(),
                                    }
                                }
                            }
                        };
                        (col_name.clone(), value)
                    })
                    .collect::<HashMap<String, String>>()
            })
            .collect();

        Ok(rows)
    }
}
