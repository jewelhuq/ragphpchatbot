/// RAG library — the shared foundation that every binary builds on.
///
/// The library exposes four modules:
///
/// - `config`  — the single source of truth for runtime configuration
/// - `turso`   — the client for the Turso vector database
/// - `ollama`  — the client for the Ollama LLM runtime
/// - `chunker` — the text splitter that prepares documents for embedding
/// - `parser`  — the file reader that turns documents into plain text

pub mod config;
pub mod turso;
pub mod ollama;
pub mod chunker;
pub mod parser;
