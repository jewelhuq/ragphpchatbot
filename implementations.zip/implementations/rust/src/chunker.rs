/// Text chunker — the editor who divides a manuscript into readable passages.
///
/// Raw documents are too large to embed as a whole: the model's context window
/// is finite, and a precise vector for a 50-word paragraph beats a blurry one
/// for a 50-page chapter.  This module splits text into chunks that are:
///
/// - **Paragraph-based**: we break on blank lines, respecting the author's own
///   sense of where one idea ends and another begins.
/// - **Heading-aware**: ALL-CAPS lines shorter than 120 chars are treated as
///   headings.  The current heading is prepended to every chunk beneath it so
///   that a retrieved chunk carries its own context ("Chapter 3 › Safety …").
/// - **Minimum-length filtered**: chunks shorter than 100 characters are too
///   thin to carry meaningful information and are merged forward.
/// - **Source-tagged**: every chunk begins with `[source: <filename>]` so the
///   RAG pipeline can cite its origin without an extra database lookup.

/// The minimum number of characters a chunk must contain to be kept.
const MIN_CHUNK_LEN: usize = 100;

/// Return true when `line` looks like a section heading.
///
/// Headings are ALL-CAPS lines (allowing punctuation and spaces) that are
/// short enough to be a title rather than an acronym-heavy paragraph.
fn is_heading(line: &str) -> bool {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.len() >= 120 {
        return false;
    }
    // A heading must contain at least one alphabetic character.
    let has_alpha = trimmed.chars().any(|c| c.is_alphabetic());
    // Every alphabetic character in a heading is uppercase.
    let all_upper = trimmed.chars().filter(|c| c.is_alphabetic()).all(|c| c.is_uppercase());
    has_alpha && all_upper
}

/// Split `text` into chunks, prefixing each with `[source: <source>]`.
///
/// The algorithm works in two passes:
///
/// **Pass 1 — paragraph assembly**: blank lines are paragraph boundaries.
///   Consecutive non-blank lines are joined with a single space into one
///   paragraph.  Headings are detected and stored as the current context.
///
/// **Pass 2 — size enforcement**: if a paragraph exceeds `max_size` bytes it
///   is split on sentence boundaries (`. `) into smaller pieces, each carrying
///   the same heading prefix.
pub fn chunk(text: &str, source: &str, max_size: usize) -> Vec<String> {
    // --- Pass 1: collect paragraphs and detect headings ---

    // Each entry is (Option<heading>, paragraph_text).
    let mut paragraphs: Vec<(Option<String>, String)> = Vec::new();
    let mut current_heading: Option<String> = None;
    let mut current_para: Vec<&str> = Vec::new();

    for line in text.lines() {
        let trimmed = line.trim();

        if trimmed.is_empty() {
            // Blank line — flush the current paragraph if we have one.
            if !current_para.is_empty() {
                let para = current_para.join(" ");
                paragraphs.push((current_heading.clone(), para));
                current_para.clear();
            }
        } else if is_heading(trimmed) {
            // Flush any pending paragraph before switching context.
            if !current_para.is_empty() {
                let para = current_para.join(" ");
                paragraphs.push((current_heading.clone(), para));
                current_para.clear();
            }
            current_heading = Some(trimmed.to_string());
            // The heading line itself is stored as context, not as a chunk.
        } else {
            current_para.push(trimmed);
        }
    }

    // Flush whatever was left after the last newline.
    if !current_para.is_empty() {
        let para = current_para.join(" ");
        paragraphs.push((current_heading.clone(), para));
    }

    // --- Pass 2: enforce max_size and apply prefixes ---

    let mut chunks: Vec<String> = Vec::new();

    for (heading, para) in paragraphs {
        // Build the context prefix: source tag + optional heading.
        let prefix = match &heading {
            Some(h) => format!("[source: {}] [section: {}] ", source, h),
            None => format!("[source: {}] ", source),
        };

        if para.len() + prefix.len() <= max_size {
            // The whole paragraph fits in one chunk.
            let chunk = format!("{}{}", prefix, para);
            if chunk.len() >= MIN_CHUNK_LEN {
                chunks.push(chunk);
            }
        } else {
            // The paragraph is too long — split it on ". " boundaries.
            // We accumulate sentences until the next one would overflow.
            let mut current = prefix.clone();
            let sentences = split_sentences(&para);

            for sentence in sentences {
                // +2 for the ". " separator we'll add between sentences.
                if current.len() + sentence.len() + 2 > max_size && current.len() > prefix.len() {
                    // Flush the current accumulation.
                    if current.trim_start_matches(&prefix as &str).len() >= MIN_CHUNK_LEN {
                        chunks.push(current.clone());
                    }
                    current = format!("{}{}", prefix, sentence);
                } else {
                    if current.len() > prefix.len() {
                        current.push_str(". ");
                    }
                    current.push_str(&sentence);
                }
            }

            // Flush the last sub-chunk.
            if current.len() > prefix.len()
                && current.trim_start_matches(&prefix as &str).len() >= MIN_CHUNK_LEN
            {
                chunks.push(current);
            }
        }
    }

    chunks
}

/// Break a paragraph into individual sentences on `. ` boundaries.
///
/// This is intentionally naive — we are not building an NLP pipeline, just
/// ensuring chunks stay within a practical size limit.
fn split_sentences(text: &str) -> Vec<String> {
    text.split(". ")
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn heading_detection() {
        assert!(is_heading("INTRODUCTION"));
        assert!(is_heading("CHAPTER ONE"));
        assert!(!is_heading("This is a normal sentence."));
        assert!(!is_heading(""));
    }

    #[test]
    fn basic_chunking() {
        let text = "INTRODUCTION\n\nThis is the first paragraph. It has two sentences.\n\nThis is the second paragraph.";
        let chunks = chunk(text, "test.txt", 1500);
        assert!(!chunks.is_empty());
        // Each chunk should carry the source tag.
        for c in &chunks {
            assert!(c.contains("[source: test.txt]"));
        }
    }
}
