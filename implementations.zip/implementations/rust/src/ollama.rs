/// Ollama client — the oracle who turns words into numbers and numbers into words.
///
/// Two distinct capabilities live here:
///
/// 1. **Embedding** (`embed`): Send a string, receive a 768-dimensional vector.
///    That vector is the mathematical "meaning" of the text, ready to be stored
///    or compared in the vector database.
///
/// 2. **Streaming chat** (`chat_stream`): Send a conversation history, receive
///    the model's reply token by token via newline-delimited JSON (NDJSON).
///    Each token is delivered to the caller through a callback so the UI can
///    print it immediately — no waiting for the full response.

use anyhow::{Context, Result};
use futures_util::StreamExt;
use reqwest::Client;
use serde_json::{json, Value};

/// A reusable HTTP client pointing at a single Ollama instance.
#[derive(Clone)]
pub struct OllamaClient {
    http: Client,
    base_url: String,
}

impl OllamaClient {
    /// Create a client that talks to the Ollama instance at `base_url`.
    pub fn new(base_url: impl Into<String>) -> Self {
        Self {
            http: Client::new(),
            base_url: base_url.into(),
        }
    }

    /// Convert `text` into an embedding vector using the given model.
    ///
    /// Ollama's `/api/embeddings` endpoint accepts a model name and a prompt,
    /// then returns a JSON object with an `"embedding"` array of floats.
    /// We hand that array back as a `Vec<f64>` for use in the database.
    pub async fn embed(&self, model: &str, text: &str) -> Result<Vec<f64>> {
        let url = format!("{}/api/embeddings", self.base_url);

        let body = json!({
            "model": model,
            "prompt": text
        });

        let resp = self
            .http
            .post(&url)
            .json(&body)
            .send()
            .await
            .context("Failed to reach Ollama /api/embeddings")?;

        let status = resp.status();
        if !status.is_success() {
            let text = resp.text().await.unwrap_or_default();
            anyhow::bail!("Ollama embed failed ({}): {}", status, text);
        }

        let json: Value = resp
            .json()
            .await
            .context("Failed to parse Ollama embed response")?;

        let embedding = json["embedding"]
            .as_array()
            .context("Ollama response missing 'embedding' array")?
            .iter()
            .map(|v| v.as_f64().unwrap_or(0.0))
            .collect();

        Ok(embedding)
    }

    /// Stream a chat completion, calling `on_chunk` for every token received.
    ///
    /// The Ollama `/api/chat` endpoint sends one JSON object per line while
    /// `stream: true`.  Each line looks like:
    ///
    /// ```json
    /// {"model":"gemma3:1b","message":{"role":"assistant","content":"Hello"},"done":false}
    /// ```
    ///
    /// We read the response body as a byte stream, accumulate bytes into lines,
    /// parse each line, and extract the `message.content` field.  When `done`
    /// becomes `true` the stream is finished.
    ///
    /// `messages` must be a JSON array of `{"role": "…", "content": "…"}` objects,
    /// exactly as Ollama expects.
    pub async fn chat_stream(
        &self,
        model: &str,
        messages: Vec<Value>,
        mut on_chunk: impl FnMut(String),
    ) -> Result<()> {
        let url = format!("{}/api/chat", self.base_url);

        let body = json!({
            "model": model,
            "messages": messages,
            "stream": true
        });

        let resp = self
            .http
            .post(&url)
            .json(&body)
            .send()
            .await
            .context("Failed to reach Ollama /api/chat")?;

        let status = resp.status();
        if !status.is_success() {
            let text = resp.text().await.unwrap_or_default();
            anyhow::bail!("Ollama chat_stream failed ({}): {}", status, text);
        }

        // The response body arrives as a stream of bytes.  We accumulate them
        // into a line buffer so we can parse complete JSON objects.
        let mut stream = resp.bytes_stream();
        let mut line_buf = String::new();

        while let Some(chunk) = stream.next().await {
            let bytes = chunk.context("Error reading Ollama stream chunk")?;
            let text = String::from_utf8_lossy(&bytes);

            // Ollama sends one JSON object per newline.  A single `bytes` chunk
            // might contain multiple lines, so we split on newlines and handle
            // each piece individually.
            for ch in text.chars() {
                if ch == '\n' {
                    let line = line_buf.trim().to_string();
                    line_buf.clear();

                    if line.is_empty() {
                        continue;
                    }

                    // Try to parse the line as JSON; skip silently if it fails
                    // (Ollama sometimes sends empty lines or status messages).
                    if let Ok(parsed) = serde_json::from_str::<Value>(&line) {
                        // Extract the token from the nested path.
                        if let Some(token) = parsed["message"]["content"].as_str() {
                            if !token.is_empty() {
                                on_chunk(token.to_string());
                            }
                        }

                        // When `done` is true the model has finished.
                        if parsed["done"].as_bool().unwrap_or(false) {
                            return Ok(());
                        }
                    }
                } else {
                    line_buf.push(ch);
                }
            }
        }

        // Handle any remaining bytes in the buffer that arrived without a
        // trailing newline (shouldn't happen with well-behaved Ollama, but
        // defensive code is kind code).
        let line = line_buf.trim().to_string();
        if !line.is_empty() {
            if let Ok(parsed) = serde_json::from_str::<Value>(&line) {
                if let Some(token) = parsed["message"]["content"].as_str() {
                    if !token.is_empty() {
                        on_chunk(token.to_string());
                    }
                }
            }
        }

        Ok(())
    }
}
