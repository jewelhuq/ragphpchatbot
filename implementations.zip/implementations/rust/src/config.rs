﻿/// Configuration — the single source of truth for every moving part.
///
/// Rather than scattering magic strings across the codebase, we keep them
/// here so that changing a URL or a model name is a one-line edit.
/// The `Default` implementation encodes the real deployment values, so
/// any binary can call `Config::default()` and be ready to go immediately.

#[derive(Clone, Debug)]
pub struct Config {
    /// The HTTP endpoint for the Turso libSQL database.
    pub turso_url: String,

    /// The Bearer token that proves we are allowed to talk to Turso.
    pub turso_token: String,

    /// The base URL for the locally-running Ollama instance.
    pub ollama_url: String,

    /// The Ollama model used for generating conversational answers.
    pub chat_model: String,

    /// The Ollama model used to turn text into embedding vectors.
    pub embedding_model: String,

    /// How many dimensions the embedding model produces.
    /// Must match the vector column declaration in the database.
    pub embedding_dims: usize,

    /// How many chunks to retrieve for each query.
    pub top_k: usize,

    /// The directory that `ingest` scans for source documents.
    pub docs_dir: String,

    /// The maximum number of characters per chunk produced by the chunker.
    pub chunk_size: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            turso_url: "https://your-db-name.turso.io".to_string(),
            turso_token: "YOUR_TURSO_TOKEN_HERE".to_string(),
            ollama_url: "http://127.0.0.1:11434".to_string(),
            chat_model: "gemma3:1b".to_string(),
            embedding_model: "nomic-embed-text".to_string(),
            embedding_dims: 768,
            top_k: 5,
            docs_dir: "docs".to_string(),
            chunk_size: 1500,
        }
    }
}

impl Config {
    /// Build a config from environment variables, falling back to defaults.
    ///
    /// This lets operators override any value at runtime without recompiling —
    /// useful for CI, Docker, or simply keeping secrets out of source code.
    pub fn from_env() -> Self {
        let defaults = Self::default();
        Self {
            turso_url: std::env::var("TURSO_URL").unwrap_or(defaults.turso_url),
            turso_token: std::env::var("TURSO_TOKEN").unwrap_or(defaults.turso_token),
            ollama_url: std::env::var("OLLAMA_URL").unwrap_or(defaults.ollama_url),
            chat_model: std::env::var("CHAT_MODEL").unwrap_or(defaults.chat_model),
            embedding_model: std::env::var("EMBEDDING_MODEL").unwrap_or(defaults.embedding_model),
            embedding_dims: std::env::var("EMBEDDING_DIMS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(defaults.embedding_dims),
            top_k: std::env::var("TOP_K")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(defaults.top_k),
            docs_dir: std::env::var("DOCS_DIR").unwrap_or(defaults.docs_dir),
            chunk_size: std::env::var("CHUNK_SIZE")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(defaults.chunk_size),
        }
    }
}
