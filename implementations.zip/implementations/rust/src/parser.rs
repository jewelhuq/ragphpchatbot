/// Document parser — the translator who reads files in various formats and
/// hands back plain text that the chunker can work with.
///
/// Today we fully support `.txt` files and provide stubs for `.pdf` and `.docx`.
/// The stubs are honest: they explain what a production implementation would do
/// and return an error that tells the operator exactly what is missing rather
/// than silently producing empty content.
///
/// To add a real PDF parser, replace the `parse_pdf` stub with a call to the
/// `pdf-extract` or `lopdf` crate.  For DOCX, `docx-rs` or `zip` + XML parsing
/// are common choices.  The function signatures are already wired up — just
/// swap the bodies.

use std::path::Path;
use anyhow::{Context, Result, bail};

/// Read the file at `path` and return its content as a UTF-8 string.
///
/// The file's extension determines which parser is used.  Unsupported formats
/// return an error with the offending extension in the message so the operator
/// knows what to add.
pub fn parse(path: &Path) -> Result<String> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    match ext.as_str() {
        "txt" | "md" => parse_txt(path),
        "pdf" => parse_pdf(path),
        "docx" => parse_docx(path),
        other => bail!(
            "Unsupported file format '.{}' for file '{}'. \
             Add a parser in src/parser.rs to handle this type.",
            other,
            path.display()
        ),
    }
}

/// Read a plain-text or Markdown file.
///
/// We keep this as a simple `read_to_string` rather than stripping Markdown
/// syntax, because the chunker's heading detection works well on ATX-style
/// headings (ALL CAPS) and plain text equally.
fn parse_txt(path: &Path) -> Result<String> {
    std::fs::read_to_string(path)
        .with_context(|| format!("Failed to read text file '{}'", path.display()))
}

/// Parse a PDF file — **stub**.
///
/// # What a real implementation would do
///
/// 1. Open the file with `pdf-extract::extract_text(path)` (crate: `pdf-extract`).
/// 2. Strip ligature artefacts and fix hyphenation across line breaks.
/// 3. Return the cleaned text.
///
/// # Why it is a stub here
///
/// PDF parsing requires either a native C library (pdfium, poppler) via FFI
/// or a pure-Rust implementation that is still maturing.  Adding those
/// dependencies would complicate the build without being necessary for the
/// core RAG logic.  Drop in `pdf-extract = "0.7"` to Cargo.toml and replace
/// this function body when you need PDF support.
#[allow(unused_variables)]
fn parse_pdf(path: &Path) -> Result<String> {
    // STUB: PDF parsing is not implemented.
    // To implement, add `pdf-extract = "0.7"` to Cargo.toml and use:
    //   pdf_extract::extract_text(path)
    bail!(
        "PDF parsing is not yet implemented. \
         File '{}' was skipped. \
         See the comment in src/parser.rs for instructions.",
        path.display()
    )
}

/// Parse a DOCX file — **stub**.
///
/// # What a real implementation would do
///
/// 1. Open the ZIP archive (DOCX is a ZIP of XML files).
/// 2. Extract `word/document.xml`.
/// 3. Walk the XML tree collecting `<w:t>` text nodes.
/// 4. Join them with appropriate spacing and return.
///
/// # Why it is a stub here
///
/// Like PDF, DOCX parsing requires additional dependencies.  The `docx-rs`
/// crate or manual `zip` + `quick-xml` parsing are the typical choices.
/// Add those crates and replace this body when DOCX support is needed.
#[allow(unused_variables)]
fn parse_docx(path: &Path) -> Result<String> {
    // STUB: DOCX parsing is not implemented.
    // To implement, add `zip = "0.6"` and `quick-xml = "0.31"` to Cargo.toml,
    // then open the file as a ZIP archive and parse word/document.xml.
    bail!(
        "DOCX parsing is not yet implemented. \
         File '{}' was skipped. \
         See the comment in src/parser.rs for instructions.",
        path.display()
    )
}
