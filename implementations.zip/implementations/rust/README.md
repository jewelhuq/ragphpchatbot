﻿# RAG — Retrieval-Augmented Generation in Rust

A complete RAG system that connects a Turso vector database to a locally-running
Ollama instance.  Documents are chunked, embedded, and stored; at query time the
most relevant chunks are retrieved and fed to an LLM whose answer streams live to
your terminal.

## Architecture

```
docs/          →  ingest  →  Turso (chunks + embeddings)
                                 ↓
user question  →  query   →  vector_top_k  →  ranked chunks
                                 ↓
                    rag    →  prompt builder  →  Ollama (streaming)
                                 ↓
                 chatbot   →  interactive loop with history
```

## Prerequisites

- **Rust** 1.75+ (`rustup update stable`)
- **Ollama** running locally on `http://127.0.0.1:11434`
- The two required models pulled:
  ```
  ollama pull nomic-embed-text
  ollama pull gemma3:1b
  ```
- A **Turso** database with the URL and token configured (see below)

## Configuration

All settings have sensible defaults (see `src/config.rs`).  Override any of them
with environment variables:

| Variable          | Default                                                    | Description                      |
|-------------------|------------------------------------------------------------|----------------------------------|
| `TURSO_URL`       | `https://your-db-name.turso.io`       | Turso HTTP endpoint              |
| `TURSO_TOKEN`     | *(must be set)*                                            | Bearer token for Turso auth      |
| `OLLAMA_URL`      | `http://127.0.0.1:11434`                                   | Ollama base URL                  |
| `CHAT_MODEL`      | `gemma3:1b`                                                | Model used for answer generation |
| `EMBEDDING_MODEL` | `nomic-embed-text`                                         | Model used for embeddings        |
| `EMBEDDING_DIMS`  | `768`                                                      | Embedding vector dimensions      |
| `TOP_K`           | `5`                                                        | Chunks to retrieve per query     |
| `DOCS_DIR`        | `docs`                                                     | Directory scanned by ingest      |
| `CHUNK_SIZE`      | `1500`                                                     | Max characters per chunk         |

Set the token before running any binary:

```bash
export TURSO_TOKEN="your-token-here"
```

On Windows (PowerShell):

```powershell
$env:TURSO_TOKEN = "your-token-here"
```

## Build

```bash
cargo build --release
```

The compiled binaries will be in `target/release/`.

## Usage

### 1. Ingest documents

Place `.txt` or `.md` files in the `docs/` directory, then run:

```bash
cargo run --bin ingest
```

Or with a custom docs directory:

```bash
DOCS_DIR=/path/to/my/docs cargo run --bin ingest
```

The ingest binary:
- Creates the `chunks` table and vector index if they do not exist.
- Skips files whose MD5 hash has not changed since the last run.
- Deletes and re-inserts chunks for files that have been modified.

### 2. Query the knowledge base

```bash
cargo run --bin query -- "What is the refund policy?"
```

Prints the top-K most relevant chunks with their source files and similarity
distances, so you can verify retrieval quality without invoking the LLM.

### 3. Ask a single question

```bash
cargo run --bin rag -- "Summarise the safety guidelines"
```

Retrieves context, builds a prompt, and streams the model's answer to stdout.

### 4. Start an interactive chatbot

```bash
cargo run --bin chatbot
```

Opens a conversational loop.  The last 10 turns of history are retained so the
model can refer to earlier messages.  Type `exit` or press Ctrl-D to quit.

## Using release binaries

After `cargo build --release` the binaries live in `target/release/`:

```bash
./target/release/ingest
./target/release/query "What is the refund policy?"
./target/release/rag   "Summarise the safety guidelines"
./target/release/chatbot
```

## File layout

```
src/
  lib.rs          — re-exports all shared modules
  config.rs       — Config struct with all tuneable parameters
  turso.rs        — HTTP client for the Turso /v2/pipeline API
  ollama.rs       — Embedding and streaming-chat client for Ollama
  chunker.rs      — Paragraph-based text splitter with heading detection
  parser.rs       — File reader (.txt/.md supported; .pdf/.docx stubs)
  bin/
    ingest.rs     — Scans docs/, embeds, and stores chunks in Turso
    query.rs      — Embeds a query and prints the top-K results
    rag.rs        — Full RAG pipeline: retrieve + generate + stream
    chatbot.rs    — Interactive loop with conversation history
```

## Adding PDF or DOCX support

See the comments in `src/parser.rs`.  Both parsers are stubbed with clear
instructions on which crates to add and which function bodies to replace.

## Troubleshooting

| Symptom | Likely cause |
|---------|--------------|
| `Turso execute failed (401)` | `TURSO_TOKEN` is missing or wrong |
| `Failed to reach Ollama` | Ollama is not running; run `ollama serve` |
| `No results found` | Run `cargo run --bin ingest` first |
| `vector_top_k` SQL error | The vector index was not created; re-run ingest |
| Chunks are too long/short | Adjust `CHUNK_SIZE` and `MIN_CHUNK_LEN` in `chunker.rs` |
