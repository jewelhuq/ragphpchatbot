package main

// chatbot/main.odin
// An interactive REPL-style chatbot that maintains conversation history.
//
// Every user turn:
//   1. Embed the user message.
//   2. Retrieve top-k grounding chunks from Turso.
//   3. Build a new system message from the retrieved context.
//   4. Append the user's message to the conversation history.
//   5. Call Ollama with the full history and stream the response.
//   6. Append the assistant's response to history for the next turn.
//
// Type "quit", "exit", or "q" (case-insensitive) to leave the loop.
// Type "clear" to reset the conversation history without exiting.
//
// Odin note on I/O:
//   Reading a line from stdin in Odin uses os.stdin together with a manual
//   byte-by-byte loop or bufio if available.  We use a simple loop that reads
//   one byte at a time until '\n' — minimal but portable across platforms.

import "core:fmt"
import "core:os"
import "core:strings"

import cfg "../config"
import trs "../turso"
import oll "../ollama"

// _read_line reads one line from stdin, stripping the trailing newline.
// Returns an empty string on EOF.
_read_line :: proc(allocator := context.allocator) -> string {
    b := strings.builder_make(allocator)
    buf: [1]byte
    for {
        n, err := os.read(os.stdin, buf[:])
        if n == 0 || err != 0 do break
        if buf[0] == '\n' do break
        if buf[0] != '\r' {          // skip Windows CR
            strings.write_byte(&b, buf[0])
        }
    }
    return strings.to_string(b)
}

// _retrieve_context embeds the question and returns a formatted context block
// built from the top-k similar chunks.  Returns an empty string when no
// relevant chunks are found, which causes the LLM to fall back to its own
// knowledge rather than crash.
_retrieve_context :: proc(
    ollama: oll.Ollama_Client,
    turso:  trs.Turso_Client,
    question: string,
    top_k: int,
    allocator := context.allocator,
) -> string {
    vec := oll.embed(ollama, question)
    if vec == nil || len(vec) == 0 do return ""

    // Build vector literal
    vb := strings.builder_make(context.temp_allocator)
    strings.write_byte(&vb, '[')
    for val, i in vec {
        if i > 0 do strings.write_byte(&vb, ',')
        fmt.sbprintf(&vb, "%.8f", val)
    }
    strings.write_byte(&vb, ']')
    vec_lit := strings.to_string(vb)

    sql := fmt.tprintf(
        `SELECT source, chunk, vector_distance_cos(embedding, vector('%s')) AS score
         FROM documents ORDER BY score ASC LIMIT %d`,
        vec_lit, top_k,
    )

    rows := trs.fetch_all(turso, sql, nil, allocator)
    if len(rows) == 0 do return ""

    cb := strings.builder_make(allocator)
    for row, i in rows {
        source := row["source"] or_else "unknown"
        chunk  := row["chunk"]  or_else ""
        fmt.sbprintf(&cb, "[%d] (%s)\n%s\n\n", i+1, source, chunk)
    }
    return strings.to_string(cb)
}

// _system_message builds the system prompt for a single turn.
// If context is empty the assistant operates without grounding (useful for
// greetings and meta questions).
_system_message :: proc(context_block: string, allocator := context.allocator) -> string {
    if len(context_block) == 0 {
        return "You are a helpful assistant. Answer the user's questions to the best of your ability."
    }
    return fmt.tprintf(
        `You are a helpful assistant with access to the following document excerpts.
Answer using ONLY the context below.  If the answer is not there, say so.

CONTEXT:
%s`,
        context_block,
    )
}

// main runs the interactive chat loop.
main :: proc() {
    config := cfg.default_config()
    turso  := trs.make_client(config.turso_url, config.turso_token)
    ollama := oll.make_client(
        config.ollama_url,
        config.chat_model,
        config.embedding_model,
    )

    fmt.println("╔══════════════════════════════════════════════════════════╗")
    fmt.println("║          Odin RAG Chatbot  (type 'quit' to exit)        ║")
    fmt.println("╚══════════════════════════════════════════════════════════╝")
    fmt.println()

    // history holds the conversation across turns.
    // We use a dynamic array so it grows as the conversation deepens.
    history := make([dynamic]oll.Message)

    for {
        fmt.print("You: ")

        line := _read_line(context.temp_allocator)
        trimmed := strings.trim_space(line)

        if len(trimmed) == 0 do continue

        // Control commands
        lower := strings.to_lower(trimmed, context.temp_allocator)
        if lower == "quit" || lower == "exit" || lower == "q" {
            fmt.println("\nGoodbye!")
            break
        }
        if lower == "clear" {
            clear(&history)
            fmt.println("[chat history cleared]\n")
            continue
        }

        // Retrieve context for this turn
        fmt.print("[retrieving context...] ")
        ctx_block := _retrieve_context(ollama, turso, trimmed, config.top_k)
        if len(ctx_block) > 0 {
            fmt.printfln("found %d chars of context", len(ctx_block))
        } else {
            fmt.println("no context found, answering from model knowledge")
        }

        // Replace system message each turn with fresh context
        // so the LLM always has the most relevant grounding for the current question.
        sys_msg := _system_message(ctx_block)

        // Build the messages slice: system + history + new user message
        turn_messages := make([dynamic]oll.Message, context.temp_allocator)
        append(&turn_messages, oll.Message{role = "system", content = sys_msg})
        for msg in history {
            append(&turn_messages, msg)
        }
        append(&turn_messages, oll.Message{role = "user", content = trimmed})

        // Stream the assistant's response
        fmt.print("\nAssistant: ")
        ok := oll.chat_stream(ollama, turn_messages[:], proc(token: string) {
            fmt.print(token)
            // Note: accumulating the response for history requires a shared
            // builder.  We use a file-level builder written via a global to
            // keep the proc literal signature compatible with Odin's rules.
            // See _response_accum below.
            strings.write_string(&_response_accum, token)
        })
        fmt.println("\n")

        if ok && len(strings.to_string(_response_accum)) > 0 {
            // Append this turn to the persistent history
            append(&history, oll.Message{role = "user",      content = strings.clone(trimmed)})
            append(&history, oll.Message{role = "assistant", content = strings.clone(strings.to_string(_response_accum))})
        }

        // Reset the accumulator for the next turn
        strings.builder_reset(&_response_accum)

        // Trim history to the last 10 turns (20 messages) to avoid token bloat
        if len(history) > 20 {
            for i in 0 ..< len(history) - 20 {
                history[i] = history[i+20]
            }
            resize(&history, 20)
        }
    }
}

// _response_accum is a package-level builder used to accumulate the streaming
// assistant response across the proc literal callback boundary.
// Odin proc literals cannot capture mut references to local variables, so we
// use a package-level variable as a well-known shared accumulator.
// It is reset after every turn in the main loop.
@(private)
_response_accum: strings.Builder
