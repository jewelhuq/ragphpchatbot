package chunker

// chunker.odin
// Turns a long document string into a slice of overlapping text chunks.
//
// The strategy mirrors what the PHP ingest.php does:
//   1. Split on blank lines (paragraph boundaries).
//   2. Treat lines that start with # / ## / ### as headings; keep the most
//      recent heading as a context prefix so every chunk is self-contained.
//   3. Accumulate paragraphs into a window until the window would exceed
//      chunk_size characters, then emit the window and carry the last
//      chunk_overlap characters into the next one.
//
// The source label is prepended to every chunk so that if two chunks from
// different files end up in the same retrieval result the LLM can tell them
// apart.
//
// Odin note on nested procs:
//   Odin does not support closures — proc literals cannot capture variables
//   from an enclosing scope.  The flush logic is therefore a package-level
//   proc that receives all mutable state via explicit pointer parameters.

import "core:fmt"
import "core:strings"

// _is_heading returns true when a line looks like a Markdown heading.
// We recognise #, ##, and ### prefixes.
_is_heading :: proc(line: string) -> bool {
    return strings.has_prefix(line, "# ")  ||
           strings.has_prefix(line, "## ") ||
           strings.has_prefix(line, "### ")
}

// _heading_text strips the leading '#' characters and trailing space from a
// heading line and returns the bare title text.
_heading_text :: proc(line: string) -> string {
    s := line
    for len(s) > 0 && s[0] == '#' {
        s = s[1:]
    }
    return strings.trim_space(s)
}

// _flush emits the text accumulated in window as a new chunk, then resets
// window and seeds it with the overlap tail so the next chunk begins with
// some trailing context from this one.
//
// Parameters are all pointers so the proc can mutate the caller's state.
// allocator is the destination allocator for the emitted chunk strings.
_flush :: proc(
    chunks:       ^[dynamic]string,
    window:       ^strings.Builder,
    overlap_buf:  ^string,
    source:        string,
    current_head:  string,
    chunk_size:    int,
    allocator      := context.allocator,
) {
    content := strings.trim_space(strings.to_string(window^))
    if len(content) == 0 do return

    // Prepend [source | Heading] or [source] so each chunk is self-contained.
    prefix: string
    if len(current_head) > 0 {
        prefix = fmt.tprintf("[%s | %s]\n", source, current_head)
    } else {
        prefix = fmt.tprintf("[%s]\n", source)
    }

    full := strings.concatenate([]string{prefix, content}, allocator)
    append(chunks, full)

    // Compute the overlap tail (~10% of chunk_size).
    overlap_size := chunk_size / 10
    if overlap_size >= len(content) {
        overlap_buf^ = strings.clone(content, allocator)
    } else {
        overlap_buf^ = strings.clone(content[len(content)-overlap_size:], allocator)
    }

    // Reset the window and seed it with the overlap text.
    strings.builder_reset(window)
    if len(overlap_buf^) > 0 {
        strings.write_string(window, overlap_buf^)
        strings.write_byte(window, '\n')
    }
}

// chunk splits text into overlapping segments of at most chunk_size characters.
// source is a short label (e.g. "docs/guide.txt") prepended to each chunk.
//
// The returned slice is allocated with allocator (default: context.allocator).
// Every chunk string in the slice is independently allocated; the caller owns them.
chunk :: proc(
    text:       string,
    source:     string,
    chunk_size: int,
    allocator   := context.allocator,
) -> []string {
    chunks      := make([dynamic]string, allocator)
    window      := strings.builder_make(context.temp_allocator)
    overlap_buf := ""
    current_head := ""

    lines := strings.split_lines(text, context.temp_allocator)

    for line in lines {
        trimmed := strings.trim_space(line)

        if _is_heading(trimmed) {
            // Heading boundary: flush any accumulated text, then capture the new heading.
            if strings.builder_len(window) > 0 {
                _flush(&chunks, &window, &overlap_buf, source, current_head, chunk_size, allocator)
            }
            current_head = _heading_text(trimmed)
            continue
        }

        // Blank line = soft paragraph boundary.  Only flush when the window is full.
        if len(trimmed) == 0 {
            if strings.builder_len(window) > chunk_size {
                _flush(&chunks, &window, &overlap_buf, source, current_head, chunk_size, allocator)
            }
            continue
        }

        // Ordinary content line: append to the accumulation window.
        strings.write_string(&window, trimmed)
        strings.write_byte(&window, '\n')

        // Hard flush when the window hits the size limit.
        if strings.builder_len(window) >= chunk_size {
            _flush(&chunks, &window, &overlap_buf, source, current_head, chunk_size, allocator)
        }
    }

    // Emit whatever remains in the window after all lines are processed.
    if strings.builder_len(window) > 0 {
        _flush(&chunks, &window, &overlap_buf, source, current_head, chunk_size, allocator)
    }

    return chunks[:]
}
