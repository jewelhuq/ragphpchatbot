package main

// query/main.odin
// The query binary: embed the user's question and return the top-k most
// similar document chunks from Turso.
//
// Usage:
//   ./query "what is retrieval augmented generation?"
//
// Output: the top-k matching chunks, ranked by cosine similarity, printed
// to stdout with their source file and similarity score.
//
// This is the retrieval half of RAG.  The rag binary builds on top of it
// by feeding the retrieved chunks into an LLM to produce a final answer.

import "core:fmt"
import "core:os"
import "core:strings"
import "core:strconv"

import cfg "../config"
import trs "../turso"
import oll "../ollama"

// _embed_query converts the user's question string into a float vector.
// If Ollama is unreachable or returns an empty embedding the program exits
// early with a helpful message rather than silently querying with garbage.
_embed_query :: proc(ollama: oll.Ollama_Client, question: string) -> []f64 {
    fmt.println("[query] embedding question ...")
    vec := oll.embed(ollama, question)
    if vec == nil || len(vec) == 0 {
        fmt.eprintln("[query] failed to embed question — is Ollama running?")
        os.exit(1)
    }
    fmt.printfln("[query] embedding done (%d dims)", len(vec))
    return vec
}

// _vector_literal serialises a []f64 into the SQL vector literal that Turso's
// vector_distance_cos() function expects: '[0.1, -0.2, ...]'.
_vector_literal :: proc(vec: []f64, allocator := context.allocator) -> string {
    b := strings.builder_make(allocator)
    strings.write_byte(&b, '[')
    for val, i in vec {
        if i > 0 do strings.write_byte(&b, ',')
        fmt.sbprintf(&b, "%.8f", val)
    }
    strings.write_byte(&b, ']')
    return strings.to_string(b)
}

// _similarity_search queries Turso for the top-k chunks most similar to the
// query vector using cosine distance.  Turso's vector_distance_cos() returns
// a value in [0, 2]; smaller is closer, so we ORDER BY ASC and LIMIT top_k.
//
// The SQL uses Turso's built-in vector() function to parse our literal into an
// F32_BLOB for comparison against the stored embeddings.
_similarity_search :: proc(
    turso: trs.Turso_Client,
    vec: []f64,
    top_k: int,
    allocator := context.allocator,
) -> []map[string]string {
    vec_lit := _vector_literal(vec, context.temp_allocator)
    sql := fmt.tprintf(
        `SELECT source, chunk, vector_distance_cos(embedding, vector('%s')) AS score
         FROM documents
         ORDER BY score ASC
         LIMIT %d`,
        vec_lit,
        top_k,
    )

    fmt.println("[query] running similarity search ...")
    rows := trs.fetch_all(turso, sql, nil, allocator)
    fmt.printfln("[query] found %d results", len(rows))
    return rows
}

// _print_results writes the retrieved chunks to stdout in a readable format.
// Each chunk is numbered, labelled with its source file and similarity score,
// and separated by a horizontal rule so the human can scan them quickly.
_print_results :: proc(rows: []map[string]string) {
    if len(rows) == 0 {
        fmt.println("[query] no matching documents found.")
        return
    }

    fmt.println("\n" + strings.repeat("=", 60, context.temp_allocator))
    fmt.println("RETRIEVED CHUNKS")
    fmt.println(strings.repeat("=", 60, context.temp_allocator))

    for row, i in rows {
        source := row["source"] or_else "(unknown)"
        score  := row["score"]  or_else "?"
        chunk  := row["chunk"]  or_else ""

        fmt.printfln("\n[%d] source: %s  |  score: %s", i+1, source, score)
        fmt.println(strings.repeat("-", 60, context.temp_allocator))

        // Print at most 400 characters of the chunk to keep output scannable.
        preview := chunk
        if len(preview) > 400 {
            preview = preview[:400]
            fmt.printfln("%s ...(truncated)", preview)
        } else {
            fmt.println(preview)
        }
    }
    fmt.println(strings.repeat("=", 60, context.temp_allocator))
}

// main is the entry point.  It reads the question from command-line args,
// embeds it, queries Turso, and prints the results.
main :: proc() {
    if len(os.args) < 2 {
        fmt.eprintln("Usage: query <question>")
        fmt.eprintln("Example: query \"what is RAG?\"")
        os.exit(1)
    }

    // Join all positional arguments so the user does not need to quote multi-
    // word questions on some shells.
    question := strings.join(os.args[1:], " ", context.temp_allocator)
    fmt.printfln("[query] question: %s", question)

    config := cfg.default_config()
    turso  := trs.make_client(config.turso_url, config.turso_token)
    ollama := oll.make_client(
        config.ollama_url,
        config.chat_model,
        config.embedding_model,
    )

    vec  := _embed_query(ollama, question)
    rows := _similarity_search(turso, vec, config.top_k)
    _print_results(rows)
}
