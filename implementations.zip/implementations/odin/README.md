# Odin RAG Implementation

A complete Retrieval-Augmented Generation system written in [Odin](https://odin-lang.org/), a modern systems language designed as a pragmatic alternative to C.

## Why Odin?

Odin was built around one core idea: **no hidden control flow, no hidden allocations**.  Every allocation you see in the source is one that actually happens.  This makes it easy to reason about memory, write zero-copy paths, and understand exactly why your program is slow — something that is impossible in languages that insert allocations behind your back.

## Prerequisites

| Tool | Purpose | Install |
|------|---------|---------|
| [Odin compiler](https://odin-lang.org/docs/install/) | Compile `.odin` source files | See below |
| [curl](https://curl.se/) | HTTP calls to Turso and Ollama | Pre-installed on macOS/most Linux; `winget install curl` on Windows |
| [Ollama](https://ollama.com/) | Local LLM inference | `ollama pull nomic-embed-text && ollama pull gemma3:1b` |
| pdftotext *(optional)* | PDF text extraction | `apt install poppler-utils` / `brew install poppler` |

### Installing Odin

**Linux / macOS (from source):**
```bash
git clone https://github.com/odin-lang/Odin
cd Odin
make
# Add the Odin directory to your PATH
export PATH="$PATH:$(pwd)"
```

**Windows (pre-built):**
```powershell
# Download the latest release from https://github.com/odin-lang/Odin/releases
# Extract and add to PATH, or use:
winget install odin-lang.Odin
```

Verify:
```bash
odin version
```

## Project Layout

```
odin/
├── config.odin          # All configuration constants (package config)
├── turso.odin           # Turso HTTP client via curl (package turso)
├── ollama.odin          # Ollama embeddings + chat streaming (package ollama)
├── chunker.odin         # Text → overlapping chunks (package chunker)
├── parser.odin          # File → plain text (package parser)
├── ingest/
│   └── main.odin        # Ingest pipeline binary (package main)
├── query/
│   └── main.odin        # Similarity search binary (package main)
├── rag/
│   └── main.odin        # RAG answer binary (package main)
├── chatbot/
│   └── main.odin        # Interactive chatbot binary (package main)
├── build.sh             # Build all four binaries
└── README.md            # This file
```

## Building

```bash
chmod +x build.sh
./build.sh           # builds ingest, query, rag, chatbot
./build.sh ingest    # build only one binary
```

On **Windows** (PowerShell):
```powershell
# Run each build command manually since .sh requires a POSIX shell
odin build ingest/  -o:speed -out:ingest.exe
odin build query/   -o:speed -out:query.exe
odin build rag/     -o:speed -out:rag.exe
odin build chatbot/ -o:speed -out:chatbot.exe
```

## Running

### 1. Ingest documents

Drop `.txt` or `.md` files into a `docs/` directory relative to your working directory, then run:

```bash
./ingest
```

The pipeline:
- Creates the `documents` table in Turso if it does not exist.
- For each file: parses it, splits it into overlapping chunks, embeds each chunk with `nomic-embed-text`, and stores it in Turso.
- Content-hash deduplication means re-running is safe — unchanged files are skipped.

### 2. Vector search (no LLM)

```bash
./query "what is retrieval augmented generation?"
```

Returns the top-5 most similar chunks with their cosine distance scores.  Use this to verify that ingestion worked before involving the LLM.

### 3. One-shot RAG answer

```bash
./rag "how does authentication work in this system?"
```

Retrieves the top-k chunks and feeds them as context into `gemma3:1b`.  The answer is streamed token-by-token so you see it appear as it is generated.

### 4. Interactive chatbot

```bash
./chatbot
```

Starts a REPL loop.  Each turn:
1. Embeds your message.
2. Retrieves fresh context from Turso.
3. Sends the full conversation history + context to Ollama.
4. Streams the response.

Type `clear` to reset the conversation history.  Type `quit` or `exit` to leave.

## Odin's Explicit Allocator Model

Odin does not have a garbage collector.  Memory is managed through **allocators** passed via the implicit `context` struct.

### The three allocators you will encounter

| Allocator | Lifetime | Use case |
|-----------|---------|---------|
| `context.allocator` | Until you free it | Long-lived data (returned from procs, stored in structs) |
| `context.temp_allocator` | End of current scope / frame | Scratch strings, intermediate results |
| Custom arena | You control it | High-performance bulk allocation with a single free |

### How this code uses them

Every proc that allocates accepts an optional `allocator` parameter:

```odin
// Short-lived: use temp_allocator so it's freed automatically
escaped := _escape_json_string(text, context.temp_allocator)

// Long-lived: use default allocator (context.allocator)
result := make([]f64, len(parts), allocator)
```

The `make` and `new` builtins always take the current `context.allocator` unless you specify otherwise.  You can swap the allocator for an entire call subtree by assigning to `context.allocator`:

```odin
arena: virtual.Arena
virtual.arena_init(&arena)
context.allocator = virtual.arena_allocator(&arena)
// Everything allocated here uses the arena
defer virtual.arena_destroy(&arena)  // frees everything at once
```

This pattern — which Odin makes explicit — is what garbage-collected languages do implicitly for every short-lived allocation.  Making it visible means you can choose the right strategy per call-site and eliminate GC pauses entirely.

## Configuration

All settings are in `config.odin`.  Edit `default_config()` to change:

- `turso_url` / `turso_token` — your Turso database credentials
- `ollama_url` — where Ollama listens (default: `http://127.0.0.1:11434`)
- `chat_model` — LLM for answer generation (default: `gemma3:1b`)
- `embedding_model` — embedding model (default: `nomic-embed-text`)
- `embedding_dims` — must match the model (768 for nomic-embed-text)
- `docs_dir` — folder to scan during ingest
- `chunk_size` — max characters per chunk (default: 1500)
- `top_k` — chunks retrieved per query (default: 5)

## Notes on HTTP

Odin's standard library does not yet ship a stable `net/http` package on all platforms.  All HTTP calls in this implementation delegate to `curl` via `os.system()`.  This is an explicit trade-off: it adds a runtime dependency on curl (present on virtually every developer machine) and eliminates the need for C-binding boilerplate.  When `core:net` or a community HTTP package matures, swapping the transport layer is a surgical change confined to `turso.odin` and `ollama.odin`.
