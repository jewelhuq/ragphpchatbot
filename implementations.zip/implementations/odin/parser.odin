package parser

// parser.odin
// Reads a file from disk and returns its text content as a string.
//
// For plain text and Markdown files this is a direct read.  PDF and DOCX
// support is stubbed out with clear error messages; adding real parsers
// later only requires filling in those two branches without touching any
// other part of the codebase.
//
// Odin's os.read_entire_file_or_err returns the raw bytes; we transmute them
// to a string.  The caller owns the returned string's backing memory and is
// responsible for freeing it (or using context.temp_allocator if the string
// only needs to survive the current scope).

import "core:fmt"
import "core:os"
import "core:path/filepath"
import "core:strings"

// parse reads the file at file_path and returns its text content.
// Supported extensions: .txt, .md (direct read).
// Stubs: .pdf, .docx (returns an explanatory message instead of content).
// Unknown extensions are treated as plain text.
//
// On any I/O error the proc prints a diagnostic and returns an empty string
// so the ingest pipeline can skip the file gracefully.
parse :: proc(file_path: string, allocator := context.allocator) -> string {
    ext := strings.to_lower(filepath.ext(file_path), context.temp_allocator)

    switch ext {
    case ".pdf":
        // PDF parsing requires an external library (e.g. pdfium) or a tool
        // like `pdftotext`.  Stub: try pdftotext via shell; fall back to empty.
        return _try_pdftotext(file_path, allocator)

    case ".docx":
        // DOCX is a ZIP archive containing XML.  Full support would require a
        // ZIP reader and XML parser.  Stub: return a placeholder so the ingest
        // pipeline can skip this file without crashing.
        fmt.eprintfln("[parser] .docx not yet supported: %s", file_path)
        return ""

    case:
        // Plain text, Markdown, and anything else we read verbatim.
        return _read_text_file(file_path, allocator)
    }
}

// _read_text_file slurps the entire file into a string using Odin's standard
// os.read_entire_file.  The returned bytes are transmuted to a string in-place;
// no extra copy is made.
_read_text_file :: proc(file_path: string, allocator := context.allocator) -> string {
    data, ok := os.read_entire_file(file_path, allocator)
    if !ok {
        fmt.eprintfln("[parser] could not read file: %s", file_path)
        return ""
    }
    return string(data)
}

// _try_pdftotext shells out to the `pdftotext` command-line tool (part of
// poppler-utils) to extract plain text from a PDF.  If the tool is not
// installed or the extraction fails, an empty string is returned and a
// diagnostic is printed.
_try_pdftotext :: proc(file_path: string, allocator := context.allocator) -> string {
    out_path := "parser_pdf_tmp.txt"
    defer os.remove(out_path)

    cmd: string
    when ODIN_OS == .Windows {
        cmd = fmt.tprintf(`cmd /c pdftotext "%s" %s 2>nul`, file_path, out_path)
    } else {
        cmd = fmt.tprintf(`pdftotext "%s" %s 2>/dev/null`, file_path, out_path)
    }

    exit_code := os.system(cmd)
    if exit_code != 0 {
        fmt.eprintfln("[parser] pdftotext failed for: %s (is poppler-utils installed?)", file_path)
        return ""
    }

    data, ok := os.read_entire_file(out_path, allocator)
    if !ok do return ""

    return string(data)
}
