package main

// rag/main.odin
// The RAG answer binary: retrieve relevant chunks then generate a grounded
// answer with Ollama.
//
// Usage:
//   ./rag "what does the documentation say about authentication?"
//
// Pipeline:
//   1. Embed the question.
//   2. Retrieve top-k similar chunks from Turso.
//   3. Assemble a system prompt that contains the chunks as "context".
//   4. Ask Ollama to answer the question using only that context.
//   5. Stream the answer token-by-token to stdout.
//
// The answer is grounded — the LLM is instructed to answer only from the
// provided context and to say "I don't know" when the context is insufficient,
// which dramatically reduces hallucination.

import "core:fmt"
import "core:os"
import "core:strings"

import cfg "../config"
import trs "../turso"
import oll "../ollama"

// _build_context_block joins the retrieved chunks into a numbered context
// block that can be embedded verbatim into the system prompt.
_build_context_block :: proc(
    rows: []map[string]string,
    allocator := context.allocator,
) -> string {
    if len(rows) == 0 do return "(no context retrieved)"

    b := strings.builder_make(allocator)
    for row, i in rows {
        source := row["source"] or_else "unknown"
        chunk  := row["chunk"]  or_else ""
        fmt.sbprintf(&b, "[%d] (source: %s)\n%s\n\n", i+1, source, chunk)
    }
    return strings.to_string(b)
}

// _build_system_prompt constructs the RAG system message.
// The prompt instructs the LLM to treat the context as its sole source of
// truth and to admit ignorance rather than speculate.
_build_system_prompt :: proc(context_block: string, allocator := context.allocator) -> string {
    return fmt.tprintf(
        `You are a helpful assistant.  Answer the user's question using ONLY the context below.
If the answer is not in the context, say "I don't know based on the provided documents."
Do not speculate or add information from outside the context.

CONTEXT:
%s`,
        context_block,
    )
}

// _retrieve_chunks embeds the question and returns the top-k similar chunks
// from Turso.  Exits the process if embedding fails so the caller never has
// to handle a nil vector.
_retrieve_chunks :: proc(
    ollama: oll.Ollama_Client,
    turso: trs.Turso_Client,
    question: string,
    top_k: int,
    allocator := context.allocator,
) -> []map[string]string {
    fmt.println("[rag] embedding question ...")
    vec := oll.embed(ollama, question)
    if vec == nil || len(vec) == 0 {
        fmt.eprintln("[rag] embedding failed — is Ollama running?")
        os.exit(1)
    }

    // Build vector literal for Turso
    vb := strings.builder_make(context.temp_allocator)
    strings.write_byte(&vb, '[')
    for val, i in vec {
        if i > 0 do strings.write_byte(&vb, ',')
        fmt.sbprintf(&vb, "%.8f", val)
    }
    strings.write_byte(&vb, ']')
    vec_lit := strings.to_string(vb)

    sql := fmt.tprintf(
        `SELECT source, chunk, vector_distance_cos(embedding, vector('%s')) AS score
         FROM documents
         ORDER BY score ASC
         LIMIT %d`,
        vec_lit,
        top_k,
    )

    fmt.println("[rag] retrieving context chunks ...")
    rows := trs.fetch_all(turso, sql, nil, allocator)
    fmt.printfln("[rag] retrieved %d chunk(s)", len(rows))
    return rows
}

// main orchestrates the full RAG answer pipeline.
main :: proc() {
    if len(os.args) < 2 {
        fmt.eprintln("Usage: rag <question>")
        fmt.eprintln("Example: rag \"how does authentication work?\"")
        os.exit(1)
    }

    question := strings.join(os.args[1:], " ", context.temp_allocator)
    fmt.printfln("[rag] question: %s\n", question)

    config := cfg.default_config()
    turso  := trs.make_client(config.turso_url, config.turso_token)
    ollama := oll.make_client(
        config.ollama_url,
        config.chat_model,
        config.embedding_model,
    )

    // Step 1 & 2: retrieve grounding context.
    rows := _retrieve_chunks(ollama, turso, question, config.top_k)

    if len(rows) == 0 {
        fmt.println("[rag] no relevant documents found. Try ingesting some documents first.")
        return
    }

    // Step 3: assemble the prompt.
    context_block := _build_context_block(rows)
    system_prompt := _build_system_prompt(context_block)

    messages := []oll.Message{
        {role = "system", content = system_prompt},
        {role = "user",   content = question},
    }

    // Step 4 & 5: generate and stream the answer.
    fmt.println("\n" + strings.repeat("=", 60, context.temp_allocator))
    fmt.println("ANSWER")
    fmt.println(strings.repeat("=", 60, context.temp_allocator))

    ok := oll.chat_stream(ollama, messages, proc(token: string) {
        fmt.print(token)
    })

    fmt.println()
    fmt.println(strings.repeat("=", 60, context.temp_allocator))

    if !ok {
        fmt.eprintln("[rag] generation failed")
        os.exit(1)
    }
}
