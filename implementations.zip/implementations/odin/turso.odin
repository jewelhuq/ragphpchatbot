package turso

// turso.odin
// Everything the RAG system needs to talk to Turso (cloud libSQL).
//
// Turso exposes a simple HTTP POST endpoint:
//   POST /v2/pipeline
//   Authorization: Bearer <token>
//   Content-Type: application/json
//
// The body is a pipeline of SQL statements.  Each statement can have
// positional parameters represented as JSON arrays.  Turso returns
// result rows as arrays of column-value pairs.
//
// Because Odin's standard library does not yet ship a stable net/http
// package on all platforms, every HTTP call is made by shelling out to
// curl.  This is an explicit trade-off: it adds a runtime dependency but
// keeps the code free of C-binding boilerplate and works everywhere curl
// is available (Linux, macOS, Windows with Git-Bash / WSL).

import "core:fmt"
import "core:os"
import "core:strings"

// Turso_Client carries the credentials needed to reach one Turso database.
// Create one with make_client and pass it to every operation.
Turso_Client :: struct {
    base_url: string,
    token:    string,
}

// make_client constructs a Turso_Client from explicit credentials.
// No heap allocation beyond the struct itself; strings are borrowed from
// the caller so their lifetime must exceed the client's.
make_client :: proc(url, token: string) -> Turso_Client {
    return Turso_Client{base_url = url, token = token}
}

// --- internal helpers -------------------------------------------------------

// _escape_json_string wraps s in double quotes and escapes characters that
// would break JSON string syntax.  Odin's standard library does not expose a
// one-liner for this, so we roll our own using strings.Builder.
_escape_json_string :: proc(s: string, allocator := context.allocator) -> string {
    b := strings.builder_make(allocator)
    strings.write_byte(&b, '"')
    for ch in s {
        switch ch {
        case '"':  strings.write_string(&b, "\\\"")
        case '\\': strings.write_string(&b, "\\\\")
        case '\n': strings.write_string(&b, "\\n")
        case '\r': strings.write_string(&b, "\\r")
        case '\t': strings.write_string(&b, "\\t")
        case:      strings.write_rune(&b, ch)
        }
    }
    strings.write_byte(&b, '"')
    return strings.to_string(b)
}

// _build_pipeline_body crafts the JSON body that Turso's /v2/pipeline
// endpoint expects.  params is a slice of string values; each becomes a
// positional argument in the SQL statement.
//
// Example output for sql="INSERT INTO t(a) VALUES(?)" params=["hello"]:
//   {"requests":[{"type":"execute","stmt":{"sql":"INSERT INTO t(a) VALUES(?)","args":[{"type":"text","value":"hello"}]}}]}
_build_pipeline_body :: proc(
    sql: string,
    params: []string,
    allocator := context.allocator,
) -> string {
    b := strings.builder_make(allocator)

    strings.write_string(&b, `{"requests":[{"type":"execute","stmt":{"sql":`)
    escaped_sql := _escape_json_string(sql, allocator)
    strings.write_string(&b, escaped_sql)

    if len(params) > 0 {
        strings.write_string(&b, `,"args":[`)
        for param, i in params {
            if i > 0 {
                strings.write_byte(&b, ',')
            }
            strings.write_string(&b, `{"type":"text","value":`)
            escaped_param := _escape_json_string(param, allocator)
            strings.write_string(&b, escaped_param)
            strings.write_byte(&b, '}')
        }
        strings.write_byte(&b, ']')
    }

    strings.write_string(&b, `}}]}`)
    return strings.to_string(b)
}

// _run_curl fires an HTTP POST to url with the given bearer token and body,
// then returns the raw response text.  It writes the body to a temp file so
// curl can read it with @filename, avoiding shell-escaping nightmares with
// complex JSON.
_run_curl :: proc(
    url, token, body: string,
    allocator := context.allocator,
) -> (response: string, ok: bool) {
    // Write the JSON body to a temporary file so we can pass it to curl
    // with @path rather than embedding it in the command line.
    tmp_path := "turso_req_tmp.json"
    write_err := os.write_entire_file(tmp_path, transmute([]byte)body)
    if !write_err {
        fmt.eprintln("[turso] failed to write temp request file")
        return "", false
    }
    defer os.remove(tmp_path)

    auth_header := fmt.tprintf("Authorization: Bearer %s", token)
    cmd := fmt.tprintf(
        `curl -s -X POST "%s/v2/pipeline" -H "Content-Type: application/json" -H "%s" --data-binary @%s`,
        url, auth_header, tmp_path,
    )

    // os.system captures nothing; we need the output.  Shell out via the
    // platform's command interpreter and redirect stdout to a temp file.
    out_path := "turso_resp_tmp.json"
    defer os.remove(out_path)

    full_cmd: string
    when ODIN_OS == .Windows {
        full_cmd = fmt.tprintf(`cmd /c %s > %s 2>nul`, cmd, out_path)
    } else {
        full_cmd = fmt.tprintf(`%s > %s 2>/dev/null`, cmd, out_path)
    }

    exit_code := os.system(full_cmd)
    if exit_code != 0 {
        fmt.eprintfln("[turso] curl exited with code %d", exit_code)
        return "", false
    }

    data, read_ok := os.read_entire_file(out_path, allocator)
    if !read_ok {
        fmt.eprintln("[turso] failed to read curl response")
        return "", false
    }

    return string(data), true
}

// --- JSON parsing helpers ----------------------------------------------------
// These are hand-rolled because importing encoding/json would pull in
// reflection and add compile-time overhead.  For the small, predictable
// shapes that Turso returns this is both faster and simpler.

// _find_key locates the string value associated with key inside a flat JSON
// object fragment.  It does not handle nested objects — it is intentionally
// shallow and used only for the simple {"value":"..."} sub-objects Turso
// returns for each cell.
_find_key :: proc(src, key: string) -> (value: string, found: bool) {
    needle := fmt.tprintf(`"%s":"`, key)
    idx := strings.index(src, needle)
    if idx < 0 do return "", false

    start := idx + len(needle)
    rest  := src[start:]
    end   := 0
    for i := 0; i < len(rest); i += 1 {
        if rest[i] == '"' && (i == 0 || rest[i-1] != '\\') {
            end = i
            break
        }
    }
    return rest[:end], true
}

// _parse_rows extracts every row from a Turso pipeline response and returns
// them as a slice of string-map records keyed by column name.
// It walks the JSON text manually, finding the "cols" array for column names
// and then each "row" array for values.
_parse_rows :: proc(
    json_text: string,
    allocator := context.allocator,
) -> []map[string]string {
    rows := make([dynamic]map[string]string, allocator)

    // Locate the columns array: "cols":[{"name":"col1"},...]
    cols_marker := `"cols":[`
    cols_start  := strings.index(json_text, cols_marker)
    if cols_start < 0 do return rows[:]

    // Collect column names
    col_names := make([dynamic]string, allocator)
    cursor    := cols_start + len(cols_marker)
    for cursor < len(json_text) {
        // Find "name":"<value>" within this object
        obj_end := strings.index(json_text[cursor:], "]")
        if obj_end < 0 do break

        segment := json_text[cursor : cursor + obj_end]
        name_marker := `"name":"`
        ni := strings.index(segment, name_marker)
        if ni < 0 do break

        name_start := ni + len(name_marker)
        name_rest  := segment[name_start:]
        name_end   := strings.index(name_rest, `"`)
        if name_end < 0 do break

        append(&col_names, name_rest[:name_end])

        // Advance past this column object
        next_obj := strings.index(json_text[cursor:], `{"name":`)
        if next_obj < 0 do break
        next_obj2 := strings.index(json_text[cursor+next_obj+1:], `{"name":`)
        if next_obj2 < 0 do break
        cursor = cursor + next_obj + 1 + next_obj2
    }

    // Locate the rows array: "rows":[[...],[...],...]
    rows_marker := `"rows":[[`
    rows_start  := strings.index(json_text, rows_marker)
    if rows_start < 0 do return rows[:]

    rows_cursor := rows_start + len(rows_marker) - 1 // point at first '['
    for rows_cursor < len(json_text) {
        // Each row is a JSON array of cell objects
        row_open := strings.index(json_text[rows_cursor:], "[")
        if row_open < 0 do break

        row_start_abs := rows_cursor + row_open
        // Find matching close bracket
        depth     := 0
        row_end   := row_start_abs
        for row_end < len(json_text) {
            ch := json_text[row_end]
            if ch == '[' do depth += 1
            else if ch == ']' {
                depth -= 1
                if depth == 0 do break
            }
            row_end += 1
        }
        if row_end >= len(json_text) do break

        row_segment := json_text[row_start_abs : row_end + 1]

        // Extract cell values from this row segment
        row_map := make(map[string]string, allocator)
        col_idx := 0
        cell_cursor := 0
        for col_idx < len(col_names) {
            val_marker := `"value":"`
            vi := strings.index(row_segment[cell_cursor:], val_marker)
            if vi < 0 do break

            val_start := cell_cursor + vi + len(val_marker)
            val_rest  := row_segment[val_start:]
            val_end   := 0
            for i := 0; i < len(val_rest); i += 1 {
                if val_rest[i] == '"' && (i == 0 || val_rest[i-1] != '\\') {
                    val_end = i
                    break
                }
            }
            row_map[col_names[col_idx]] = val_rest[:val_end]
            cell_cursor = val_start + val_end + 1
            col_idx += 1
        }

        append(&rows, row_map)

        // Advance past this row
        next_row := strings.index(json_text[row_end+1:], ",[")
        if next_row < 0 do break
        rows_cursor = row_end + 1 + next_row + 1
    }

    return rows[:]
}

// --- Public API -------------------------------------------------------------

// execute runs a single DDL or DML statement (CREATE TABLE, INSERT, UPDATE,
// DELETE) and returns true when Turso confirms success.  Use it whenever you
// do not need result rows back.
execute :: proc(
    client: Turso_Client,
    sql: string,
    params: []string = nil,
    allocator := context.allocator,
) -> bool {
    body := _build_pipeline_body(sql, params, allocator)
    response, ok := _run_curl(client.base_url, client.token, body, allocator)
    if !ok do return false

    // A successful Turso response contains "type":"ok" somewhere in the body.
    return strings.contains(response, `"type":"ok"`)
}

// fetch_all runs a SELECT statement and returns all result rows as a slice of
// maps.  Each map key is a column name; each value is the cell content as a
// string.  NULL cells are represented as an empty string.
// The caller owns the returned slice and its maps; pass context.temp_allocator
// if the results only need to survive the current scope.
fetch_all :: proc(
    client: Turso_Client,
    sql: string,
    params: []string = nil,
    allocator := context.allocator,
) -> []map[string]string {
    body := _build_pipeline_body(sql, params, allocator)
    response, ok := _run_curl(client.base_url, client.token, body, allocator)
    if !ok do return nil

    return _parse_rows(response, allocator)
}
