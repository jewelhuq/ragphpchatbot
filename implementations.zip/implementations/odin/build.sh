#!/usr/bin/env bash
# build.sh — build all four RAG binaries with a single command.
#
# Usage:
#   chmod +x build.sh
#   ./build.sh          # build everything
#   ./build.sh ingest   # build only the ingest binary
#
# Odin package model:
#   Each subdirectory (ingest/, query/, rag/, chatbot/) is an independent
#   `package main`.  The shared packages (config, turso, ollama, chunker,
#   parser) live as single .odin files in the root directory and are imported
#   by relative path from within each main package.
#
#   odin build <dir>/ compiles everything in that directory as one package.
#   The -out flag controls the output binary name.
#   -o:speed enables optimisations (remove for faster debug builds).
#
# Odin's explicit allocator model:
#   Unlike Go or Rust, Odin does not insert hidden allocations.  Every proc
#   that allocates memory accepts an explicit `allocator` parameter defaulting
#   to `context.allocator`.  Callers can swap in `context.temp_allocator` for
#   short-lived data that is freed in bulk at the end of a scope, or pass a
#   custom arena allocator for maximum control.  This means you can profile
#   exactly where allocations happen and choose the right allocator per call-site.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Detect OS for binary extension
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" || "$OSTYPE" == "cygwin" ]]; then
    EXT=".exe"
else
    EXT=""
fi

BUILD_FLAGS="-o:speed"

build_binary() {
    local name="$1"
    local pkg_dir="$2"
    local out="$3"
    echo "==> Building $name ..."
    odin build "$pkg_dir" $BUILD_FLAGS -out:"${out}${EXT}"
    echo "    OK: ${out}${EXT}"
}

TARGET="${1:-all}"

case "$TARGET" in
    ingest)
        build_binary "ingest"  "ingest/"  "ingest"
        ;;
    query)
        build_binary "query"   "query/"   "query"
        ;;
    rag)
        build_binary "rag"     "rag/"     "rag"
        ;;
    chatbot)
        build_binary "chatbot" "chatbot/" "chatbot"
        ;;
    all|*)
        build_binary "ingest"  "ingest/"  "ingest"
        build_binary "query"   "query/"   "query"
        build_binary "rag"     "rag/"     "rag"
        build_binary "chatbot" "chatbot/" "chatbot"
        echo ""
        echo "All binaries built successfully."
        echo "  ./ingest${EXT}   — scan docs/ and populate the database"
        echo "  ./query${EXT}    — vector search without LLM generation"
        echo "  ./rag${EXT}      — one-shot RAG answer"
        echo "  ./chatbot${EXT}  — interactive multi-turn chat"
        ;;
esac
