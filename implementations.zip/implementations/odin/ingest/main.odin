package main

// ingest/main.odin
// The ingest binary: scans a docs/ folder, splits every document into chunks,
// embeds each chunk with Ollama, and stores the result in Turso.
//
// Pipeline overview:
//   1. Read config.
//   2. Connect to Turso and ensure the `documents` table exists.
//   3. Walk the docs directory.
//   4. For each file: compute a content hash, skip if already ingested.
//   5. Parse the file to plain text.
//   6. Split the text into overlapping chunks.
//   7. Embed each chunk with Ollama nomic-embed-text.
//   8. INSERT the chunk + embedding into Turso.
//
// Running it a second time is safe: the hash check in step 4 acts as an
// idempotency guard so documents are never double-ingested.

import "core:fmt"
import "core:os"
import "core:path/filepath"
import "core:strings"

// We import our sibling packages by relative path.
// Odin resolves these at build time when you pass the package directory.
import cfg "../config"      // config.odin  → package config
import trs "../turso"       // turso.odin   → package turso
import oll "../ollama"      // ollama.odin  → package ollama
import chk "../chunker"     // chunker.odin → package chunker
import prs "../parser"      // parser.odin  → package parser

// SUPPORTED_EXTS lists the file extensions the ingest pipeline will process.
// Files with other extensions are silently skipped.
SUPPORTED_EXTS :: []string{".txt", ".md", ".pdf"}

// _is_supported returns true when the file extension is in SUPPORTED_EXTS.
_is_supported :: proc(path: string) -> bool {
    ext := strings.to_lower(filepath.ext(path), context.temp_allocator)
    for supported in SUPPORTED_EXTS {
        if ext == supported do return true
    }
    return false
}

// _content_hash computes a simple but collision-resistant FNV-1a 64-bit hash
// of data and returns it formatted as a 16-character hex string.
// We use FNV-1a rather than SHA-256 to avoid uncertainty around the Odin
// crypto package API (which has changed across nightly builds).  For the
// deduplication use-case — detecting whether a chunk has changed — FNV-1a
// is fast, deterministic, and has excellent avalanche behaviour.
_content_hash :: proc(data: []byte, allocator := context.allocator) -> string {
    FNV_OFFSET_BASIS :: u64(14695981039346656037)
    FNV_PRIME        :: u64(1099511628211)

    h := FNV_OFFSET_BASIS
    for b in data {
        h ~= u64(b)
        h *= FNV_PRIME
    }

    // Format as 16 hex digits
    HEX_CHARS :: "0123456789abcdef"
    buf: [16]byte
    for i := 15; i >= 0; i -= 1 {
        buf[i] = HEX_CHARS[h & 0xf]
        h >>= 4
    }
    return strings.clone(string(buf[:]), allocator)
}

// _ensure_table creates the `documents` table if it does not already exist.
// Turso / libSQL supports vector columns via the F32_BLOB type.
// We store the embedding as a BLOB and cosine similarity is computed with
// Turso's vector_distance_cos() function at query time.
_ensure_table :: proc(client: trs.Turso_Client) -> bool {
    ddl := `CREATE TABLE IF NOT EXISTS documents (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        source    TEXT    NOT NULL,
        chunk     TEXT    NOT NULL,
        hash      TEXT    NOT NULL,
        embedding F32_BLOB(768)
    )`
    ok := trs.execute(client, ddl)
    if !ok {
        fmt.eprintln("[ingest] failed to create documents table")
    }
    return ok
}

// _hash_exists checks whether a chunk with the given content hash already
// lives in the database so we can skip re-embedding identical content.
_hash_exists :: proc(client: trs.Turso_Client, hash: string) -> bool {
    rows := trs.fetch_all(
        client,
        "SELECT id FROM documents WHERE hash = ? LIMIT 1",
        []string{hash},
        context.temp_allocator,
    )
    return len(rows) > 0
}

// _vector_to_blob serialises a []f64 embedding into the text literal that
// Turso / libSQL accepts for F32_BLOB columns: vector('[0.1,0.2,...]').
_vector_to_blob_literal :: proc(vec: []f64, allocator := context.allocator) -> string {
    b := strings.builder_make(allocator)
    strings.write_string(&b, "vector('[")
    for val, i in vec {
        if i > 0 do strings.write_byte(&b, ',')
        fmt.sbprintf(&b, "%.8f", val)
    }
    strings.write_string(&b, "]')")
    return strings.to_string(b)
}

// _insert_chunk persists one chunk together with its embedding to Turso.
// Because F32_BLOB values must be passed as a SQL expression (vector('...')),
// we construct the INSERT with the vector literal inlined rather than as a
// bind parameter.
_insert_chunk :: proc(
    client: trs.Turso_Client,
    source, chunk_text, hash: string,
    embedding: []f64,
) -> bool {
    vec_literal := _vector_to_blob_literal(embedding, context.temp_allocator)
    sql := fmt.tprintf(
        `INSERT INTO documents (source, chunk, hash, embedding) VALUES (?, ?, ?, %s)`,
        vec_literal,
    )
    return trs.execute(client, sql, []string{source, chunk_text, hash})
}

// _ingest_file is the per-file portion of the pipeline: parse → chunk →
// embed → insert.  It returns the number of chunks successfully stored.
_ingest_file :: proc(
    file_path: string,
    turso: trs.Turso_Client,
    ollama: oll.Ollama_Client,
    chunk_size: int,
) -> int {
    fmt.printfln("[ingest] processing: %s", file_path)

    // Step 1: parse to plain text.
    text := prs.parse(file_path)
    if len(text) == 0 {
        fmt.eprintfln("[ingest] empty or unreadable: %s", file_path)
        return 0
    }

    source := filepath.base(file_path)

    // Step 2: split into chunks.
    chunks := chk.chunk(text, source, chunk_size)
    if len(chunks) == 0 {
        fmt.eprintfln("[ingest] no chunks produced for: %s", file_path)
        return 0
    }

    stored := 0
    for chunk_text, i in chunks {
        // Step 3: compute content hash.
        hash := _content_hash(transmute([]byte)chunk_text, context.temp_allocator)

        if _hash_exists(turso, hash) {
            fmt.printfln("  chunk %d/%d already ingested, skipping", i+1, len(chunks))
            continue
        }

        // Step 4: embed.
        fmt.printf("  embedding chunk %d/%d ... ", i+1, len(chunks))
        embedding := oll.embed(ollama, chunk_text)
        if embedding == nil || len(embedding) == 0 {
            fmt.eprintln("FAILED (embed returned nil)")
            continue
        }
        fmt.printfln("done (%d dims)", len(embedding))

        // Step 5: insert.
        if _insert_chunk(turso, source, chunk_text, hash, embedding) {
            stored += 1
        } else {
            fmt.eprintfln("  failed to insert chunk %d", i+1)
        }
    }

    fmt.printfln("[ingest] stored %d/%d chunks from %s", stored, len(chunks), file_path)
    return stored
}

// _scan_dir_recursive walks dir recursively and calls ingest_file on every
// supported file it finds.  It uses os.read_dir which is stable across Odin
// versions and avoids the walk proc signature churn that filepath.walk has
// experienced across Odin nightly builds.
_scan_dir_recursive :: proc(
    dir: string,
    turso: trs.Turso_Client,
    ollama: oll.Ollama_Client,
    chunk_size: int,
    total: ^int,
) {
    fis, read_err := os.read_dir(dir, -1, context.temp_allocator)
    if read_err != 0 {
        fmt.eprintfln("[ingest] cannot read directory: %s", dir)
        return
    }

    for fi in fis {
        full_path := filepath.join([]string{dir, fi.name}, context.temp_allocator)

        if fi.is_dir {
            // Recurse into sub-directories
            _scan_dir_recursive(full_path, turso, ollama, chunk_size, total)
            continue
        }

        if !_is_supported(full_path) {
            fmt.printfln("[ingest] skipping (unsupported type): %s", full_path)
            continue
        }

        stored := _ingest_file(full_path, turso, ollama, chunk_size)
        total^ += stored
    }
}

// main is the entry point.  It loads config, sets up clients, ensures the
// schema exists, then walks the docs directory and ingests every supported file.
main :: proc() {
    config := cfg.default_config()

    turso := trs.make_client(config.turso_url, config.turso_token)
    ollama := oll.make_client(
        config.ollama_url,
        config.chat_model,
        config.embedding_model,
    )

    fmt.println("[ingest] ensuring database schema ...")
    if !_ensure_table(turso) {
        fmt.eprintln("[ingest] aborting: cannot create table")
        os.exit(1)
    }

    fmt.printfln("[ingest] scanning docs directory: %s", config.docs_dir)

    total_stored := 0
    _scan_dir_recursive(config.docs_dir, turso, ollama, config.chunk_size, &total_stored)

    fmt.printfln("[ingest] complete. Total chunks stored: %d", total_stored)
}
