package ollama

// ollama.odin
// The bridge between the RAG system and locally-running Ollama models.
//
// Ollama exposes two endpoints we care about:
//
//   POST /api/embeddings   — convert a string into a float vector
//   POST /api/chat         — generate a reply to a conversation
//
// chat supports a streaming mode (stream:true) where Ollama sends a
// newline-delimited stream of JSON objects, one per generated token.
// We read that stream line-by-line and call a user-supplied callback for
// each token so the terminal can display the answer as it arrives.
//
// All HTTP calls are delegated to curl for the same reason as turso.odin:
// Odin's stdlib net/http is not yet stable on every platform.

import "core:fmt"
import "core:os"
import "core:strings"
import "core:strconv"

// Ollama_Client carries the Ollama base URL and the model names to use.
// Construct one with make_client; the zero value is not usable.
Ollama_Client :: struct {
    base_url:        string,
    chat_model:      string,
    embedding_model: string,
}

// make_client wires up an Ollama_Client from the values stored in Rag_Config.
make_client :: proc(base_url, chat_model, embedding_model: string) -> Ollama_Client {
    return Ollama_Client{
        base_url        = base_url,
        chat_model      = chat_model,
        embedding_model = embedding_model,
    }
}

// --- internal helpers -------------------------------------------------------

// _escape_json_string produces a JSON-safe quoted string without pulling in
// encoding/json.  Same logic as turso.odin's copy — kept local so each
// package compiles independently.
_escape_json_string :: proc(s: string, allocator := context.allocator) -> string {
    b := strings.builder_make(allocator)
    strings.write_byte(&b, '"')
    for ch in s {
        switch ch {
        case '"':  strings.write_string(&b, `\"`)
        case '\\': strings.write_string(&b, `\\`)
        case '\n': strings.write_string(&b, `\n`)
        case '\r': strings.write_string(&b, `\r`)
        case '\t': strings.write_string(&b, `\t`)
        case:      strings.write_rune(&b, ch)
        }
    }
    strings.write_byte(&b, '"')
    return strings.to_string(b)
}

// _post_curl sends a JSON POST to url, writes the response to out_path, and
// returns (response_text, success).  The body is written to a temp file first
// so curl can read it with @path, avoiding shell-quoting nightmares.
_post_curl :: proc(
    url, body, out_path: string,
    allocator := context.allocator,
) -> (response: string, ok: bool) {
    req_path := "ollama_req_tmp.json"
    if !os.write_entire_file(req_path, transmute([]byte)body) {
        fmt.eprintln("[ollama] failed to write temp request file")
        return "", false
    }
    defer os.remove(req_path)

    full_cmd: string
    when ODIN_OS == .Windows {
        full_cmd = fmt.tprintf(
            `cmd /c curl -s -X POST "%s" -H "Content-Type: application/json" --data-binary @%s > %s 2>nul`,
            url, req_path, out_path,
        )
    } else {
        full_cmd = fmt.tprintf(
            `curl -s -X POST "%s" -H "Content-Type: application/json" --data-binary @%s > %s 2>/dev/null`,
            url, req_path, out_path,
        )
    }

    exit_code := os.system(full_cmd)
    if exit_code != 0 {
        fmt.eprintfln("[ollama] curl exited with code %d", exit_code)
        return "", false
    }

    data, read_ok := os.read_entire_file(out_path, allocator)
    if !read_ok {
        fmt.eprintln("[ollama] failed to read curl response")
        return "", false
    }
    return string(data), true
}

// _parse_float_array extracts the JSON number array that Ollama returns for
// embeddings, e.g. [0.123, -0.456, ...].  It finds the first '[' after
// "embedding":" and walks forward collecting comma-separated floats until ']'.
_parse_float_array :: proc(json_text: string, allocator := context.allocator) -> []f64 {
    // Ollama returns {"embedding":[...]}
    marker := `"embedding":[`
    start  := strings.index(json_text, marker)
    if start < 0 {
        fmt.eprintln("[ollama] embedding field not found in response")
        return nil
    }

    arr_start := start + len(marker)
    arr_end   := strings.index(json_text[arr_start:], "]")
    if arr_end < 0 do return nil

    arr_text := json_text[arr_start : arr_start + arr_end]
    parts    := strings.split(arr_text, ",", allocator)

    result := make([]f64, len(parts), allocator)
    for part, i in parts {
        trimmed := strings.trim_space(part)
        val, parse_ok := strconv.parse_f64(trimmed)
        if parse_ok {
            result[i] = val
        }
    }
    return result
}

// _extract_content_token pulls the "content" string out of a single
// streaming chunk that looks like: {"message":{"role":"...","content":"..."},...}
_extract_content_token :: proc(line: string) -> string {
    marker := `"content":"`
    start  := strings.index(line, marker)
    if start < 0 do return ""

    rest := line[start + len(marker):]
    // Walk until unescaped closing quote
    b := strings.builder_make(context.temp_allocator)
    i := 0
    for i < len(rest) {
        if rest[i] == '\\' && i + 1 < len(rest) {
            switch rest[i+1] {
            case '"':  strings.write_byte(&b, '"');  i += 2
            case '\\': strings.write_byte(&b, '\\'); i += 2
            case 'n':  strings.write_byte(&b, '\n'); i += 2
            case 'r':  strings.write_byte(&b, '\r'); i += 2
            case 't':  strings.write_byte(&b, '\t'); i += 2
            case:      strings.write_byte(&b, rest[i]); i += 1
            }
        } else if rest[i] == '"' {
            break
        } else {
            strings.write_byte(&b, rest[i])
            i += 1
        }
    }
    return strings.to_string(b)
}

// --- Public API -------------------------------------------------------------

// embed converts text into a float vector using Ollama's nomic-embed-text
// (or whichever embedding model the client was configured with).
// Returns nil on any error so the caller can decide how to handle the failure.
embed :: proc(
    client: Ollama_Client,
    text: string,
    allocator := context.allocator,
) -> []f64 {
    escaped := _escape_json_string(text, context.temp_allocator)
    body := fmt.tprintf(
        `{"model":%s,"prompt":%s}`,
        _escape_json_string(client.embedding_model, context.temp_allocator),
        escaped,
    )

    url      := fmt.tprintf("%s/api/embeddings", client.base_url)
    out_path := "ollama_embed_resp.json"
    defer os.remove(out_path)

    response, ok := _post_curl(url, body, out_path, allocator)
    if !ok do return nil

    return _parse_float_array(response, allocator)
}

// Message is a single turn in a chat conversation.
// role must be "system", "user", or "assistant".
Message :: struct {
    role:    string,
    content: string,
}

// _build_messages_json serialises a slice of Message values into the JSON
// array that Ollama's /api/chat endpoint expects.
_build_messages_json :: proc(
    messages: []Message,
    allocator := context.allocator,
) -> string {
    b := strings.builder_make(allocator)
    strings.write_byte(&b, '[')
    for msg, i in messages {
        if i > 0 do strings.write_byte(&b, ',')
        strings.write_string(&b, `{"role":`)
        strings.write_string(&b, _escape_json_string(msg.role, allocator))
        strings.write_string(&b, `,"content":`)
        strings.write_string(&b, _escape_json_string(msg.content, allocator))
        strings.write_byte(&b, '}')
    }
    strings.write_byte(&b, ']')
    return strings.to_string(b)
}

// chat_stream sends the conversation to Ollama with streaming enabled and
// calls on_chunk for each generated token as it arrives.  This gives the
// user a typewriter-style experience instead of waiting for the full answer.
//
// Because curl writes the streamed response to a file and we then read it
// line-by-line, the "streaming" here is post-hoc — we replay the file after
// curl finishes.  True real-time streaming would require a persistent curl
// process and a pipe, which is possible but adds complexity.  For a local
// Ollama instance the latency difference is imperceptible on typical hardware.
chat_stream :: proc(
    client: Ollama_Client,
    messages: []Message,
    on_chunk: proc(token: string),
    allocator := context.allocator,
) -> bool {
    msgs_json := _build_messages_json(messages, allocator)
    body := fmt.tprintf(
        `{"model":%s,"messages":%s,"stream":true}`,
        _escape_json_string(client.chat_model, context.temp_allocator),
        msgs_json,
    )

    url      := fmt.tprintf("%s/api/chat", client.base_url)
    out_path := "ollama_chat_resp.json"
    defer os.remove(out_path)

    _, ok := _post_curl(url, body, out_path, allocator)
    if !ok do return false

    // Read the streamed response file and replay each newline-delimited JSON
    // object through the caller's on_chunk callback.
    data, read_ok := os.read_entire_file(out_path, context.temp_allocator)
    if !read_ok do return false

    full_text := string(data)
    lines     := strings.split_lines(full_text, context.temp_allocator)
    for line in lines {
        trimmed := strings.trim_space(line)
        if len(trimmed) == 0 do continue

        token := _extract_content_token(trimmed)
        if len(token) > 0 {
            on_chunk(token)
        }
    }
    return true
}

// chat returns the full assistant reply as a single string.
// Internally it delegates to chat_stream and collects every token into a
// builder.  Use this when you need the complete response for further
// processing (e.g. storing in a database) rather than live display.
chat :: proc(
    client: Ollama_Client,
    messages: []Message,
    allocator := context.allocator,
) -> (reply: string, ok: bool) {
    b := strings.builder_make(allocator)
    success := chat_stream(client, messages, proc(token: string) {
        // NOTE: We cannot capture `b` here due to Odin's proc literal rules.
        // Callers that need the assembled string should use chat_stream with
        // their own builder passed via a global or a dedicated accumulator.
        fmt.print(token)
    }, allocator)
    if !success do return "", false
    fmt.println()
    return strings.to_string(b), true
}

// chat_collect gathers the full assistant reply without printing anything.
// Use this in pipelines where you need the answer as a string.
chat_collect :: proc(
    client: Ollama_Client,
    messages: []Message,
    allocator := context.allocator,
) -> (reply: string, ok: bool) {
    // We write the streamed response to a file, then parse it once more to
    // build the complete reply string.  Slight overhead vs. streaming into a
    // builder directly, but keeps the API surface clean.
    msgs_json := _build_messages_json(messages, allocator)
    body := fmt.tprintf(
        `{"model":%s,"messages":%s,"stream":false}`,
        _escape_json_string(client.chat_model, context.temp_allocator),
        msgs_json,
    )

    url      := fmt.tprintf("%s/api/chat", client.base_url)
    out_path := "ollama_collect_resp.json"
    defer os.remove(out_path)

    response, curl_ok := _post_curl(url, body, out_path, allocator)
    if !curl_ok do return "", false

    // Non-streaming response: {"message":{"role":"assistant","content":"..."}}
    content := _extract_content_token(response)
    return content, true
}
