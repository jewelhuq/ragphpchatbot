﻿package config

// config.odin
// The single source of truth for every knob in the RAG system.
// Change a value here and every binary that imports this package
// picks it up automatically — no hunting through multiple files.

// Rag_Config holds every tuneable parameter the system needs.
// All HTTP addresses, model names, database credentials, and
// chunking knobs live here so operators can read the whole
// configuration story in one place.
Rag_Config :: struct {
    // --- Turso (cloud libSQL / vector store) ---
    // turso_url is the HTTPS base address of your Turso database.
    turso_url:   string,
    // turso_token is the Bearer JWT that Turso issued for this database.
    turso_token: string,

    // --- Ollama (local AI inference) ---
    // ollama_url is the base address where Ollama listens.
    ollama_url:      string,
    // chat_model is the model name used for answer generation.
    chat_model:      string,
    // embedding_model is the model name used to embed text into vectors.
    embedding_model: string,
    // embedding_dims must match the dimensionality the embedding model produces.
    // nomic-embed-text → 768, mxbai-embed-large → 1024.
    embedding_dims:  int,

    // --- Document ingestion ---
    // docs_dir is the folder that ingest scans for source documents.
    docs_dir:      string,
    // chunk_size is the maximum character length of a single chunk (~250 words).
    chunk_size:    int,
    // chunk_overlap is how many trailing characters carry over into the next
    // chunk so sentences that straddle a boundary keep their meaning.
    chunk_overlap: int,

    // --- Retrieval ---
    // top_k controls how many nearest-neighbour chunks are fetched per query.
    // Higher values give the LLM more context at the cost of latency and tokens.
    top_k: int,
}

// default_config returns a fully populated Rag_Config wired to the project's
// real Turso database and local Ollama instance.  All binaries call this
// at startup so there is exactly one place to update credentials.
default_config :: proc() -> Rag_Config {
    return Rag_Config{
        turso_url   = "https://your-db-name.turso.io",
        turso_token = "your-turso-token-here",

        ollama_url      = "http://127.0.0.1:11434",
        chat_model      = "gemma3:1b",
        embedding_model = "nomic-embed-text",
        embedding_dims  = 768,

        docs_dir      = "docs",
        chunk_size    = 1500,
        chunk_overlap = 150,

        top_k = 5,
    }
}
