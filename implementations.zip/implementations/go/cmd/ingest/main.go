package main

// cmd/ingest/main.go — The document ingestion pipeline.
//
// This program scans a directory of documents, breaks them into chunks,
// embeds each chunk with Ollama, and stores the results in Turso so the
// query and RAG commands can retrieve them later.
//
// The key design decision here is idempotency: running ingest twice on the
// same documents should be a no-op, not a duplication. We achieve this by
// storing an MD5 hash of each file and only re-processing files whose hash
// has changed since last ingest. This matters in practice because embedding
// 1000 chunks takes minutes; re-embedding unchanged files wastes time and
// Ollama compute.
//
// Usage:
//   go run ./cmd/ingest [config.json]

import (
	"crypto/md5"
	"fmt"
	"io"
	"os"
	"path/filepath"

	rag "rag"
)

func main() {
	// ── 1. Configuration ──────────────────────────────────────────────────
	// Load config from the optional first argument, falling back to defaults
	// and then environment variable overrides.
	cfgPath := "config.json"
	if len(os.Args) > 1 {
		cfgPath = os.Args[1]
	}

	cfg, err := rag.LoadConfig(cfgPath)
	if err != nil {
		fatalf("loading config: %v", err)
	}
	cfg.LoadConfigFromEnv() // overlay TURSO_TOKEN etc. from environment

	if err := cfg.Validate(); err != nil {
		fatalf("invalid config: %v", err)
	}

	fmt.Printf("[ingest] Using docs_dir=%q chunk_size=%d top_k=%d\n",
		cfg.DocsDir, cfg.ChunkSize, cfg.TopK)

	// ── 2. Clients ────────────────────────────────────────────────────────
	turso := rag.NewTursoClient(cfg)
	ollama := rag.NewOllamaClient(cfg)

	// ── 3. Schema bootstrap ───────────────────────────────────────────────
	// We create the tables and index on every run because CREATE TABLE IF NOT
	// EXISTS and CREATE INDEX IF NOT EXISTS are both idempotent. This means
	// the ingestor is also the schema migration tool — no separate migration
	// step required for a first-time setup.
	fmt.Println("[ingest] Ensuring database schema exists…")

	// The chunks table stores:
	//   id         — auto-incrementing primary key for JOIN targets
	//   source     — filename (e.g. "manual.txt") for citation
	//   file_hash  — MD5 of the file at ingest time, used for change detection
	//   chunk_idx  — position within the file, for debugging ordering issues
	//   content    — the raw text of the chunk (shown to the LLM)
	//   embedding  — F32_BLOB(768) storing the nomic-embed-text vector
	createChunksSQL := fmt.Sprintf(`
		CREATE TABLE IF NOT EXISTS chunks (
			id        INTEGER PRIMARY KEY AUTOINCREMENT,
			source    TEXT NOT NULL,
			file_hash TEXT NOT NULL,
			chunk_idx INTEGER NOT NULL,
			content   TEXT NOT NULL,
			embedding F32_BLOB(%d)
		)`, cfg.EmbeddingDims)

	if err := turso.Execute(createChunksSQL); err != nil {
		fatalf("creating chunks table: %v", err)
	}

	// The DiskANN vector index enables approximate nearest-neighbour search
	// over the embedding column. Without it, vector_top_k() would fall back
	// to a full table scan — fine for a few hundred chunks, fatal at scale.
	createIndexSQL := `
		CREATE INDEX IF NOT EXISTS chunks_vector_idx
		ON chunks(libsql_vector_idx(embedding, 'metric=cosine', 'compress_neighbors=float8', 'max_neighbors=20'))`

	if err := turso.Execute(createIndexSQL); err != nil {
		// The index creation might fail if the extension isn't loaded.
		// We warn rather than fatal so the ingestor still works for testing
		// without the vector extension.
		fmt.Printf("[ingest] WARNING: could not create vector index: %v\n", err)
		fmt.Println("[ingest]          Queries will still work but will do full-table-scan ANN.")
	}

	// ── 4. Document scan ──────────────────────────────────────────────────
	fmt.Printf("[ingest] Scanning %q for documents…\n", cfg.DocsDir)

	var filePaths []string
	err = filepath.Walk(cfg.DocsDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			fmt.Printf("[ingest] WARNING: skipping %q: %v\n", path, err)
			return nil // don't abort the walk for a single bad path
		}
		if info.IsDir() {
			return nil
		}
		if rag.IsSupportedExtension(filepath.Ext(path)) {
			filePaths = append(filePaths, path)
		}
		return nil
	})
	if err != nil {
		fatalf("walking docs_dir %q: %v", cfg.DocsDir, err)
	}

	if len(filePaths) == 0 {
		fmt.Printf("[ingest] No supported documents found in %q. Nothing to do.\n", cfg.DocsDir)
		fmt.Println("[ingest] Supported extensions: .txt, .pdf, .docx")
		return
	}

	fmt.Printf("[ingest] Found %d document(s). Beginning ingest…\n", len(filePaths))

	// ── 5. Per-file processing ────────────────────────────────────────────
	for _, filePath := range filePaths {
		if err := ingestFile(cfg, turso, ollama, filePath); err != nil {
			// Log failures per-file but continue with the rest. A single
			// corrupted document shouldn't abort the entire batch.
			fmt.Printf("[ingest] ERROR processing %q: %v\n", filePath, err)
		}
	}

	fmt.Println("[ingest] Done.")
}

// ingestFile handles the full lifecycle for a single document:
// hash check → parse → chunk → embed → store.
func ingestFile(cfg *rag.Config, turso *rag.TursoClient, ollama *rag.OllamaClient, filePath string) error {
	// Use just the filename as the "source" label so chunks display nicely
	// in the RAG output regardless of the absolute path on disk.
	source := filepath.Base(filePath)

	// ── Hash check ────────────────────────────────────────────────────────
	// Compute MD5 of the file content. MD5 is not cryptographically secure,
	// but for change detection it's fast and collision-resistant enough.
	hash, err := md5File(filePath)
	if err != nil {
		return fmt.Errorf("hashing %q: %w", filePath, err)
	}

	// Ask Turso if we've already seen this source with this exact hash.
	existing, err := turso.FetchAll(
		"SELECT file_hash FROM chunks WHERE source = ? LIMIT 1",
		rag.TextArg(source),
	)
	if err != nil {
		return fmt.Errorf("checking existing chunks for %q: %w", source, err)
	}

	if len(existing) > 0 {
		if existing[0]["file_hash"] == hash {
			fmt.Printf("[ingest] %q is unchanged (hash=%s), skipping.\n", source, hash[:8])
			return nil // nothing to do
		}

		// The file has changed — delete the old chunks before inserting new ones.
		// Leaving stale chunks in the index would cause the vector search to return
		// outdated information even after the document has been updated.
		fmt.Printf("[ingest] %q has changed (hash=%s). Removing old chunks…\n", source, hash[:8])
		if err := turso.Execute("DELETE FROM chunks WHERE source = ?", rag.TextArg(source)); err != nil {
			return fmt.Errorf("deleting old chunks for %q: %w", source, err)
		}
	}

	// ── Parse ─────────────────────────────────────────────────────────────
	fmt.Printf("[ingest] Parsing %q…\n", source)
	text, err := rag.Parse(filePath)
	if err != nil {
		return fmt.Errorf("parsing %q: %w", filePath, err)
	}
	if len(text) == 0 {
		fmt.Printf("[ingest] %q produced no text — skipping.\n", source)
		return nil
	}

	// ── Chunk ─────────────────────────────────────────────────────────────
	chunks := rag.ChunkWithSize(text, source, cfg.ChunkSize)
	if len(chunks) == 0 {
		fmt.Printf("[ingest] %q produced no chunks after splitting — skipping.\n", source)
		return nil
	}
	fmt.Printf("[ingest] %q → %d chunk(s). Embedding…\n", source, len(chunks))

	// ── Embed + store ─────────────────────────────────────────────────────
	for i, chunk := range chunks {
		vec, err := ollama.Embed(chunk)
		if err != nil {
			return fmt.Errorf("embedding chunk %d of %q: %w", i, source, err)
		}

		// vector32(?) wraps the text representation of the float array into
		// Turso's native F32_BLOB type. The ? placeholder receives the
		// bracket-enclosed comma-separated float string produced by EncodeVector.
		sql := `INSERT INTO chunks (source, file_hash, chunk_idx, content, embedding)
		        VALUES (?, ?, ?, ?, vector32(?))`

		if err := turso.Execute(sql,
			rag.TextArg(source),
			rag.TextArg(hash),
			rag.IntArg(i),
			rag.TextArg(chunk),
			rag.TextArg(rag.EncodeVector(vec)),
		); err != nil {
			return fmt.Errorf("inserting chunk %d of %q: %w", i, source, err)
		}

		// Print progress every 10 chunks so the user knows it's working.
		if (i+1)%10 == 0 || i == len(chunks)-1 {
			fmt.Printf("[ingest]   %d/%d chunks stored\n", i+1, len(chunks))
		}
	}

	return nil
}

// md5File returns the hex-encoded MD5 hash of the file at path.
// We stream the file through the hash rather than loading it all into memory
// because documents can be large (multi-hundred-MB PDFs) and we don't want
// the ingestor to OOM just to compute a fingerprint.
func md5File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	h := md5.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", h.Sum(nil)), nil
}

// fatalf prints a formatted error to stderr and exits with code 1.
// It's the idiomatic Go equivalent of log.Fatalf but without importing "log".
func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "[ingest] FATAL: "+format+"\n", args...)
	os.Exit(1)
}
