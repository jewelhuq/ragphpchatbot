package main

// cmd/query/main.go — Low-level similarity search: embed a query and show the
// nearest chunks from Turso with their similarity scores.
//
// This command is intentionally simple — no LLM, no chat, just raw retrieval.
// It's useful for:
//   - Verifying the ingestor worked ("does the DB contain what I expect?")
//   - Tuning top_k: see how many relevant chunks exist for a given question
//   - Debugging retrieval quality before blaming the LLM for bad answers
//   - Understanding which documents are being matched for a given question
//
// Usage:
//   go run ./cmd/query [config.json] "your question here"
//   go run ./cmd/query "your question here"   # uses config.json from cwd

import (
	"fmt"
	"os"
	"strconv"

	rag "rag"
)

func main() {
	// ── Argument parsing ──────────────────────────────────────────────────
	// We support two calling conventions:
	//   query "question"              → uses config.json
	//   query config.json "question"  → uses the provided config file
	var cfgPath, query string

	switch len(os.Args) {
	case 2:
		cfgPath = "config.json"
		query = os.Args[1]
	case 3:
		cfgPath = os.Args[1]
		query = os.Args[2]
	default:
		fmt.Fprintln(os.Stderr, "Usage: query [config.json] \"your question\"")
		os.Exit(1)
	}

	// ── Configuration ─────────────────────────────────────────────────────
	cfg, err := rag.LoadConfig(cfgPath)
	if err != nil {
		fatalf("loading config: %v", err)
	}
	cfg.LoadConfigFromEnv()
	if err := cfg.Validate(); err != nil {
		fatalf("invalid config: %v", err)
	}

	// ── Clients ───────────────────────────────────────────────────────────
	turso := rag.NewTursoClient(cfg)
	ollama := rag.NewOllamaClient(cfg)

	// ── Embed + Search ────────────────────────────────────────────────────
	// RetrieveChunks handles both the embedding call and the vector search,
	// using the same code path as cmd/rag and cmd/chatbot. Consistent retrieval
	// logic means query results accurately predict what the RAG command will use.
	fmt.Printf("[query] Searching for top-%d results for: %q\n\n", cfg.TopK, query)

	chunks, err := rag.RetrieveChunks(turso, ollama, cfg, query)
	if err != nil {
		fatalf("retrieval failed: %v", err)
	}

	// ── Results display ───────────────────────────────────────────────────
	if len(chunks) == 0 {
		fmt.Println("No results found. Have you run the ingestor yet?")
		fmt.Println("  go run ./cmd/ingest")
		return
	}

	fmt.Printf("Top %d results for: %q\n", len(chunks), query)
	fmt.Println("─────────────────────────────────────────────────────────")

	for i, chunk := range chunks {
		// Parse the score back to float for formatted display.
		// The Score field is a string because FetchAll returns map[string]string;
		// formatting it to 4 decimal places is cleaner than showing "0.123456789".
		score, _ := strconv.ParseFloat(chunk.Score, 64)

		fmt.Printf("\n[%d] Source: %-20s  Chunk: %-4s  Distance: %.4f\n",
			i+1, chunk.Source, chunk.ChunkIdx, score)
		fmt.Println("─────────────────────────────────────────────────────────")

		// Truncate long chunks for display — the full content lives in the DB.
		// 500 characters is enough to judge relevance without flooding the terminal.
		content := chunk.Content
		if len(content) > 500 {
			content = content[:500] + "\n… (truncated, full content in DB)"
		}
		fmt.Println(content)
	}

	fmt.Println()
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "[query] FATAL: "+format+"\n", args...)
	os.Exit(1)
}
