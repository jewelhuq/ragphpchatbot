package main

// cmd/rag/main.go — The full Retrieval-Augmented Generation pipeline.
//
// This command answers a single question end-to-end:
//  1. Embed the question with Ollama.
//  2. Retrieve the top-k relevant chunks from Turso via DiskANN vector search.
//  3. Build a system prompt that includes those chunks and anti-hallucination
//     rules instructing the model to stay grounded in the provided context.
//  4. Stream the model's answer token-by-token to stdout.
//
// Why anti-hallucination rules?
// Small models like gemma3:1b are prone to "hallucination" — generating
// plausible-sounding but factually incorrect statements. The system prompt
// (built in retrieval.go:BuildSystemPrompt) explicitly tells the model to
// base its answer only on the provided context and to say "I don't know" when
// the context doesn't cover the question. These rules don't eliminate
// hallucinations, but they significantly reduce them when the context is relevant.
//
// Usage:
//   go run ./cmd/rag [config.json] "your question here"

import (
	"fmt"
	"os"

	rag "rag"
)

func main() {
	// ── Argument parsing ──────────────────────────────────────────────────
	// We support two calling conventions:
	//   rag "question"              → uses config.json from cwd
	//   rag config.json "question"  → uses the provided config file
	var cfgPath, query string

	switch len(os.Args) {
	case 2:
		cfgPath = "config.json"
		query = os.Args[1]
	case 3:
		cfgPath = os.Args[1]
		query = os.Args[2]
	default:
		fmt.Fprintln(os.Stderr, "Usage: rag [config.json] \"your question\"")
		os.Exit(1)
	}

	// ── Configuration ─────────────────────────────────────────────────────
	cfg, err := rag.LoadConfig(cfgPath)
	if err != nil {
		fatalf("loading config: %v", err)
	}
	cfg.LoadConfigFromEnv()
	if err := cfg.Validate(); err != nil {
		fatalf("invalid config: %v", err)
	}

	// ── Clients ───────────────────────────────────────────────────────────
	turso := rag.NewTursoClient(cfg)
	ollama := rag.NewOllamaClient(cfg)

	// ── Step 1: Retrieve relevant chunks ──────────────────────────────────
	// Print to stderr so stdout stays clean (only the model's answer goes to stdout).
	// This matters when piping: `go run ./cmd/rag "question" | pbcopy` should
	// copy just the answer, not the status messages.
	fmt.Fprintf(os.Stderr, "[rag] Searching for relevant context…\n")

	chunks, err := rag.RetrieveChunks(turso, ollama, cfg, query)
	if err != nil {
		fatalf("retrieving chunks: %v", err)
	}

	if len(chunks) == 0 {
		fmt.Fprintln(os.Stderr, "[rag] No relevant context found.")
		fmt.Fprintln(os.Stderr, "[rag] Have you ingested documents yet?  go run ./cmd/ingest")
		os.Exit(1)
	}

	fmt.Fprintf(os.Stderr, "[rag] Found %d context chunk(s). Generating answer…\n\n", len(chunks))

	// ── Step 2: Build messages ────────────────────────────────────────────
	// BuildRAGMessages packages the retrieved context and the user's question
	// into the [system, user] message format Ollama expects.
	messages := rag.BuildRAGMessages(chunks, query)

	// ── Step 3: Stream the answer ─────────────────────────────────────────
	// We print directly to stdout in the callback — no buffering — so the
	// user sees words appear as they're generated rather than waiting for
	// the full response.
	err = ollama.ChatStream(messages, func(token string) {
		fmt.Print(token)
	})
	if err != nil {
		fatalf("streaming response: %v", err)
	}

	// Ensure the terminal prompt appears on its own line after the response.
	fmt.Println()
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "[rag] FATAL: "+format+"\n", args...)
	os.Exit(1)
}
