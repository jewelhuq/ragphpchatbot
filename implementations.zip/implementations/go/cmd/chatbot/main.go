package main

// cmd/chatbot/main.go — An interactive multi-turn RAG chatbot.
//
// Unlike cmd/rag, which answers a single question and exits, the chatbot keeps
// a conversation history and maintains context across turns. This matters
// because follow-up questions ("what about the second option?", "can you
// elaborate?") are only sensible when the model can see what was said before.
//
// Design decisions:
//
// History window (last 10 turns):
//   We cap the history at 10 turns (5 user + 5 assistant messages) to prevent
//   the prompt from growing unboundedly. Small models have limited context
//   windows (~2048–8192 tokens) and slow down dramatically as the prompt grows.
//   Keeping only the most recent history is a pragmatic trade-off between
//   coherence and performance.
//
// Per-turn retrieval:
//   We re-run the vector search on every user message rather than searching
//   once at the start. This is correct because the user might pivot topics
//   mid-conversation — chunks relevant to "explain the warranty" differ from
//   those relevant to "now tell me about the return policy".
//
// Streaming output:
//   Token-by-token printing via fmt.Print (no newline) creates a natural
//   typewriter effect without any buffering or delay logic. The full response
//   is also collected in a strings.Builder so it can be appended to history
//   after the stream completes.
//
// Usage:
//   go run ./cmd/chatbot [config.json]
//   Then type questions interactively. Ctrl+D or type "quit" to exit.

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	rag "rag"
)

// maxHistoryTurns is the number of (user, assistant) pairs to retain in
// the sliding context window. Each pair is two Message entries, so the
// actual history slice grows to at most maxHistoryTurns*2 entries.
const maxHistoryTurns = 10

func main() {
	// ── Configuration ─────────────────────────────────────────────────────
	cfgPath := "config.json"
	if len(os.Args) > 1 {
		cfgPath = os.Args[1]
	}

	cfg, err := rag.LoadConfig(cfgPath)
	if err != nil {
		fatalf("loading config: %v", err)
	}
	cfg.LoadConfigFromEnv()
	if err := cfg.Validate(); err != nil {
		fatalf("invalid config: %v", err)
	}

	// ── Clients ───────────────────────────────────────────────────────────
	turso := rag.NewTursoClient(cfg)
	ollama := rag.NewOllamaClient(cfg)

	// ── Conversation history ──────────────────────────────────────────────
	// history stores the raw (user, assistant) messages from past turns.
	// We keep it separate from the system prompt because the system prompt
	// is rebuilt from fresh retrieval results on every turn.
	history := make([]rag.Message, 0, maxHistoryTurns*2)

	// ── Welcome banner ────────────────────────────────────────────────────
	fmt.Println("╔══════════════════════════════════════════════════════╗")
	fmt.Println("║             Go RAG Chatbot (Ollama + Turso)          ║")
	fmt.Println("╠══════════════════════════════════════════════════════╣")
	fmt.Printf("║  Model: %-44s║\n", cfg.ChatModel)
	fmt.Printf("║  Docs:  %-44s║\n", cfg.DocsDir)
	fmt.Println("╠══════════════════════════════════════════════════════╣")
	fmt.Println("║  Type your question. 'quit' or Ctrl+D to exit.      ║")
	fmt.Println("╚══════════════════════════════════════════════════════╝")
	fmt.Println()

	// ── Input loop ────────────────────────────────────────────────────────
	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Print("You: ")

		// scanner.Scan() returns false on EOF (Ctrl+D on Unix, Ctrl+Z on Windows)
		// or when the scanner encounters a read error. Either way we exit cleanly.
		if !scanner.Scan() {
			fmt.Println("\n[chatbot] Goodbye!")
			break
		}

		userInput := strings.TrimSpace(scanner.Text())
		if userInput == "" {
			continue
		}
		if strings.EqualFold(userInput, "quit") || strings.EqualFold(userInput, "exit") {
			fmt.Println("[chatbot] Goodbye!")
			break
		}

		// ── Retrieve context for this turn ─────────────────────────────
		// A fresh retrieval on every message means the context stays
		// relevant even when the user changes topics mid-conversation.
		chunks, err := rag.RetrieveChunks(turso, ollama, cfg, userInput)
		if err != nil {
			// Non-fatal: warn and continue without context rather than crashing
			// mid-conversation. The model will still answer from its priors.
			fmt.Printf("[chatbot] WARNING: retrieval failed: %v\n", err)
			fmt.Println("[chatbot] Continuing without context — answers may be less accurate.")
			chunks = nil
		}

		// ── Build the message list for this turn ───────────────────────
		// Message structure sent to Ollama:
		//   [system prompt with fresh context]
		//   [history: user1, assistant1, user2, assistant2, …]
		//   [current user message]
		//
		// The system prompt is rebuilt each turn so the retrieved context
		// is always fresh and relevant to the current question.
		systemMsg := rag.BuildChatbotSystemMessage(chunks)

		messages := make([]rag.Message, 0, 1+len(history)+1)
		messages = append(messages, systemMsg)
		messages = append(messages, history...)
		messages = append(messages, rag.Message{Role: "user", Content: userInput})

		// ── Stream the response ────────────────────────────────────────
		fmt.Print("\nAssistant: ")

		// Collect the full response so we can append it to history.
		// We can't append mid-stream because the response isn't complete yet.
		var responseBuf strings.Builder

		err = ollama.ChatStream(messages, func(token string) {
			fmt.Print(token)              // stream to terminal in real time
			responseBuf.WriteString(token) // collect for history
		})

		fmt.Println() // newline after the streamed response
		fmt.Println() // blank line before next prompt for readability

		if err != nil {
			fmt.Printf("[chatbot] WARNING: streaming failed: %v\n\n", err)
			// Don't add a failed/incomplete response to history — it would
			// corrupt the conversational context for subsequent turns.
			continue
		}

		// ── Update history ─────────────────────────────────────────────
		// Append the completed (user, assistant) pair to the sliding window.
		history = append(history,
			rag.Message{Role: "user", Content: userInput},
			rag.Message{Role: "assistant", Content: responseBuf.String()},
		)

		// Trim to the sliding window: drop the oldest (user, assistant) pair
		// (two entries) whenever we exceed the cap. This is a simple FIFO
		// eviction strategy. A more sophisticated approach would summarise
		// old turns into a compressed context message, but that adds
		// significant complexity for a small model deployment.
		if len(history) > maxHistoryTurns*2 {
			history = history[2:]
		}
	}

	if err := scanner.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "[chatbot] input error: %v\n", err)
		os.Exit(1)
	}
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "[chatbot] FATAL: "+format+"\n", args...)
	os.Exit(1)
}
