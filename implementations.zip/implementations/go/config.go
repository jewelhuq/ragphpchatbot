﻿package rag

// config.go — The single source of truth for every knob in the system.
//
// Why a Config struct instead of global variables?
// Because globals make testing a nightmare and dependency injection makes
// it trivial to swap out a real Turso endpoint for a mock in tests.
// Every client in this codebase receives a *Config, so changing one field
// changes behavior everywhere — no hunting through five files.

import (
	"encoding/json"
	"fmt"
	"os"
)

// Config holds every tunable parameter the RAG system needs.
// Fields are grouped by concern: storage, inference, retrieval, ingestion.
type Config struct {
	// TursoURL is the full base URL of the Turso database HTTP API,
	// e.g. "https://my-db-myorg.aws-us-east-1.turso.io".
	TursoURL string `json:"turso_url"`

	// TursoToken is the Bearer token used to authenticate with Turso.
	// Never log this value.
	TursoToken string `json:"turso_token"`

	// OllamaURL is the base URL of the local Ollama server,
	// typically "http://127.0.0.1:11434".
	OllamaURL string `json:"ollama_url"`

	// ChatModel is the Ollama model name used for answer generation,
	// e.g. "gemma3:1b". Kept small so it runs on modest hardware.
	ChatModel string `json:"chat_model"`

	// EmbeddingModel is the Ollama model name used to produce vector
	// embeddings, e.g. "nomic-embed-text". Must produce EmbeddingDims
	// dimensions — mismatches will silently corrupt similarity scores.
	EmbeddingModel string `json:"embedding_model"`

	// EmbeddingDims is the number of dimensions the embedding model outputs.
	// For nomic-embed-text this is 768. The Turso column type F32_BLOB(768)
	// must match this value exactly.
	EmbeddingDims int `json:"embedding_dims"`

	// TopK controls how many nearest-neighbour chunks are retrieved per query.
	// Higher values give the LLM more context but inflate the prompt size.
	TopK int `json:"top_k"`

	// DocsDir is the directory the ingestor scans for documents.
	// Subdirectories are walked recursively.
	DocsDir string `json:"docs_dir"`

	// ChunkSize is the target character count for each text chunk.
	// Chunks may be slightly larger when a paragraph boundary falls just
	// beyond the limit; they will never be smaller than 100 characters
	// (the minimum enforced by the chunker to avoid noise embeddings).
	ChunkSize int `json:"chunk_size"`
}

// DefaultConfig returns a Config pre-filled with sensible defaults.
// Callers should override individual fields or load from a JSON file
// via LoadConfig before creating any clients.
func DefaultConfig() *Config {
	return &Config{
		TursoURL:       "https://your-db-name.turso.io",
		TursoToken:     "",
		OllamaURL:      "http://127.0.0.1:11434",
		ChatModel:      "gemma3:1b",
		EmbeddingModel: "nomic-embed-text",
		EmbeddingDims:  768,
		TopK:           5,
		DocsDir:        "./docs",
		ChunkSize:      1000,
	}
}

// LoadConfig reads a JSON file at path and overlays its values on top of
// DefaultConfig. This means any field omitted from the file keeps its default,
// so users only need to specify what they want to change.
func LoadConfig(path string) (*Config, error) {
	cfg := DefaultConfig()

	data, err := os.ReadFile(path)
	if err != nil {
		// If the config file simply doesn't exist, proceed with defaults.
		// This lets the binaries run without any config file at all during
		// quick experiments.
		if os.IsNotExist(err) {
			return cfg, nil
		}
		return nil, fmt.Errorf("reading config file %q: %w", path, err)
	}

	// json.Unmarshal into a pre-populated struct performs a merge:
	// present JSON keys overwrite fields, absent keys are left at their
	// default values. Perfect for a "delta config" workflow.
	if err := json.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("parsing config file %q: %w", path, err)
	}

	return cfg, nil
}

// Validate checks that the Config is internally consistent enough to use.
// It does not make network calls — it only inspects values already present.
func (c *Config) Validate() error {
	if c.TursoURL == "" {
		return fmt.Errorf("turso_url must not be empty")
	}
	if c.TursoToken == "" {
		return fmt.Errorf("turso_token must not be empty — set it in config.json or the TURSO_TOKEN env var")
	}
	if c.OllamaURL == "" {
		return fmt.Errorf("ollama_url must not be empty")
	}
	if c.EmbeddingDims <= 0 {
		return fmt.Errorf("embedding_dims must be positive, got %d", c.EmbeddingDims)
	}
	if c.TopK <= 0 {
		return fmt.Errorf("top_k must be positive, got %d", c.TopK)
	}
	if c.ChunkSize < 100 {
		return fmt.Errorf("chunk_size should be at least 100 chars, got %d", c.ChunkSize)
	}
	return nil
}

// LoadConfigFromEnv reads the TURSO_TOKEN environment variable and, if set,
// writes it into c.TursoToken. This lets operators inject secrets via the
// environment without storing them in config.json.
func (c *Config) LoadConfigFromEnv() {
	if tok := os.Getenv("TURSO_TOKEN"); tok != "" {
		c.TursoToken = tok
	}
	if url := os.Getenv("TURSO_URL"); url != "" {
		c.TursoURL = url
	}
	if url := os.Getenv("OLLAMA_URL"); url != "" {
		c.OllamaURL = url
	}
}
