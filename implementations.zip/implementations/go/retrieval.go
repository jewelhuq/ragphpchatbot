package rag

// retrieval.go — Shared retrieval logic used by both rag and chatbot commands.
//
// Why extract this into the library package instead of keeping it in cmd/rag?
// Go's cmd/* packages use `package main`, which cannot be imported by other
// packages. Both cmd/rag and cmd/chatbot need the same "embed → vector_top_k →
// JOIN chunks" pipeline, so we extract it here to avoid duplication.
// The single-responsibility principle in action: this package owns the retrieval
// logic; the cmd packages own the presentation logic.

import (
	"fmt"
	"strings"
)

// ChunkResult holds a retrieved chunk together with its similarity score.
// The Score is the cosine distance from the DiskANN index: lower means more similar.
type ChunkResult struct {
	Source   string
	ChunkIdx string
	Content  string
	Score    string
}

// RetrieveChunks embeds query with Ollama and fetches the top-k most similar
// chunks from Turso using the DiskANN vector index.
//
// It is the hot path for every user-facing command: query, rag, and chatbot
// all call this function on every user input. Its latency is dominated by the
// Ollama embedding call (typically 50–200ms on CPU) plus the Turso HTTP round-
// trip (typically 50–150ms for a warm ANN index).
func RetrieveChunks(turso *TursoClient, ollama *OllamaClient, cfg *Config, query string) ([]ChunkResult, error) {
	// Step 1: embed the user's question.
	// The embedding model maps the question into the same vector space as the
	// stored document chunks. Cosine similarity then finds the chunks whose
	// meaning is closest to the question's meaning.
	vec, err := ollama.Embed(query)
	if err != nil {
		return nil, fmt.Errorf("embedding query: %w", err)
	}

	// Step 2: run the ANN search.
	// vector_top_k returns (id, distance) pairs sorted by ascending distance.
	// We JOIN back to chunks to get the content and metadata columns.
	searchSQL := `
		SELECT c.source, c.chunk_idx, c.content, v.distance AS score
		FROM vector_top_k('chunks_vector_idx', vector32(?), ?) v
		JOIN chunks c ON c.id = v.id
		ORDER BY v.distance ASC`

	rows, err := turso.FetchAll(searchSQL,
		TextArg(EncodeVector(vec)),
		IntArg(cfg.TopK),
	)
	if err != nil {
		return nil, fmt.Errorf("vector search: %w", err)
	}

	// Step 3: convert raw map rows into typed structs.
	// Typed structs are easier to work with in the presentation layer than
	// map[string]string, and the compiler will catch field-name typos.
	results := make([]ChunkResult, 0, len(rows))
	for _, row := range rows {
		results = append(results, ChunkResult{
			Source:   row["source"],
			ChunkIdx: row["chunk_idx"],
			Content:  row["content"],
			Score:    row["score"],
		})
	}
	return results, nil
}

// BuildRAGMessages constructs the Ollama message slice for a single-turn
// RAG query: a system prompt containing the retrieved context and anti-
// hallucination rules, followed by the user's question.
//
// This function is also called by the chatbot on each turn, with additional
// history messages inserted between the system message and the current user
// message by the chatbot itself.
func BuildRAGMessages(chunks []ChunkResult, query string) []Message {
	systemContent := BuildSystemPrompt(chunks)

	return []Message{
		{Role: "system", Content: systemContent},
		{Role: "user", Content: query},
	}
}

// BuildSystemPrompt constructs the system prompt text from retrieved chunks.
// Exported so cmd/chatbot can call it directly when it needs to splice the
// prompt into a longer message list that includes conversation history.
func BuildSystemPrompt(chunks []ChunkResult) string {
	var sb strings.Builder

	sb.WriteString("You are a helpful assistant. Answer the user's question using ONLY the information in the context passages below.\n\n")
	sb.WriteString("RULES:\n")
	sb.WriteString("1. Base your answer exclusively on the provided context. Do not use outside knowledge.\n")
	sb.WriteString("2. If the context does not contain enough information to answer the question, say:\n")
	sb.WriteString("   \"I don't have enough information in the provided documents to answer that.\"\n")
	sb.WriteString("3. Do not invent facts, dates, names, or figures not explicitly stated in the context.\n")
	sb.WriteString("4. When quoting or paraphrasing, mention the source document so the user can verify.\n")
	sb.WriteString("5. Be concise. Prefer short, direct answers over long preamble.\n\n")
	sb.WriteString("CONTEXT:\n")
	sb.WriteString("─────────────────────────────────────────────────────────\n")

	for i, chunk := range chunks {
		fmt.Fprintf(&sb, "[%d] %s\n%s\n", i+1, chunk.Source, chunk.Content)
		sb.WriteString("─────────────────────────────────────────────────────────\n")
	}

	return sb.String()
}

// BuildChatbotSystemMessage constructs a system Message for a chatbot turn.
// If no chunks were retrieved it falls back to a graceful "no context" prompt
// so the conversation can continue rather than hard-failing.
func BuildChatbotSystemMessage(chunks []ChunkResult) Message {
	if len(chunks) == 0 {
		return Message{
			Role: "system",
			Content: "You are a helpful assistant in an ongoing conversation.\n" +
				"No specific context was found in the document store for this question.\n" +
				"Answer based on your general knowledge, but be clear when you are uncertain.\n",
		}
	}

	var sb strings.Builder
	sb.WriteString("You are a helpful assistant in an ongoing conversation.\n")
	sb.WriteString("Answer the user's question using the context passages below.\n\n")
	sb.WriteString("RULES:\n")
	sb.WriteString("1. Base your answer on the provided context. Do not invent facts.\n")
	sb.WriteString("2. If the context does not answer the question, say so honestly.\n")
	sb.WriteString("3. Maintain conversational continuity — refer to earlier turns when relevant.\n")
	sb.WriteString("4. Be concise and direct.\n\n")
	sb.WriteString("CONTEXT:\n")
	sb.WriteString("─────────────────────────────────────────────────────────\n")

	for i, chunk := range chunks {
		fmt.Fprintf(&sb, "[%d] %s\n%s\n", i+1, chunk.Source, chunk.Content)
		sb.WriteString("─────────────────────────────────────────────────────────\n")
	}

	return Message{Role: "system", Content: sb.String()}
}
