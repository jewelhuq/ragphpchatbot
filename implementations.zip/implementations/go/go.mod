module rag

go 1.21
