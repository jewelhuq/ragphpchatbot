package rag

// ollama.go — Everything we need from Ollama: embeddings and streaming chat.
//
// Ollama exposes two endpoints we care about:
//   POST /api/embeddings — returns a single float vector for a text input
//   POST /api/chat       — streams an answer token-by-token as NDJSON
//
// Why streaming?
// A 1B-parameter model can take 10–30 seconds to generate a full answer.
// Streaming lets us print each token as it arrives, giving the user immediate
// feedback instead of a blank terminal for half a minute. The onChunk callback
// pattern keeps the transport layer decoupled from the presentation layer —
// the chatbot prints to stdout, but a future HTTP handler could flush SSE events
// with the exact same ChatStream call.

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
)

// OllamaClient wraps the HTTP calls to a local Ollama server.
// It holds the base URL and the model names so callers don't have to
// repeat them on every invocation.
type OllamaClient struct {
	baseURL        string
	chatModel      string
	embeddingModel string
	httpClient     *http.Client
}

// NewOllamaClient constructs an OllamaClient from Config.
// Using a dedicated http.Client (instead of http.DefaultClient) means we could
// add a custom timeout or transport in one place without touching anything else.
func NewOllamaClient(cfg *Config) *OllamaClient {
	return &OllamaClient{
		baseURL:        cfg.OllamaURL,
		chatModel:      cfg.ChatModel,
		embeddingModel: cfg.EmbeddingModel,
		httpClient:     &http.Client{},
	}
}

// ── Wire types ────────────────────────────────────────────────────────────────

// embeddingRequest is the JSON body for POST /api/embeddings.
type embeddingRequest struct {
	Model  string `json:"model"`
	Prompt string `json:"prompt"`
}

// embeddingResponse is the JSON response from POST /api/embeddings.
type embeddingResponse struct {
	Embedding []float64 `json:"embedding"`
}

// Message is a single turn in a conversation.
// The Role field must be "system", "user", or "assistant" — Ollama follows
// the OpenAI convention for role names.
type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

// chatRequest is the JSON body for POST /api/chat.
// Setting Stream to true tells Ollama to emit one JSON object per token
// instead of waiting for the whole response before replying.
type chatRequest struct {
	Model    string    `json:"model"`
	Messages []Message `json:"messages"`
	Stream   bool      `json:"stream"`
}

// chatChunk is one line from the NDJSON stream Ollama emits during generation.
// When Done is true, generation is complete and Message.Content will be empty.
type chatChunk struct {
	Model   string  `json:"model"`
	Message Message `json:"message"`
	Done    bool    `json:"done"`
}

// ── Embedding ─────────────────────────────────────────────────────────────────

// Embed converts text into a float64 slice suitable for vector similarity search.
//
// Under the hood, nomic-embed-text maps the semantic meaning of the text into a
// 768-dimensional space where similar passages land near each other. The ingestor
// stores these vectors in Turso; the query pipeline embeds the user's question
// and finds the nearest stored vectors to retrieve relevant context.
func (o *OllamaClient) Embed(text string) ([]float64, error) {
	reqBody := embeddingRequest{
		Model:  o.embeddingModel,
		Prompt: text,
	}

	raw, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("marshalling embedding request: %w", err)
	}

	url := strings.TrimRight(o.baseURL, "/") + "/api/embeddings"
	resp, err := o.httpClient.Post(url, "application/json", bytes.NewReader(raw))
	if err != nil {
		return nil, fmt.Errorf("calling ollama /api/embeddings: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("ollama embeddings returned HTTP %d: %s", resp.StatusCode, string(body))
	}

	var er embeddingResponse
	if err := json.NewDecoder(resp.Body).Decode(&er); err != nil {
		return nil, fmt.Errorf("decoding embedding response: %w", err)
	}

	if len(er.Embedding) == 0 {
		return nil, fmt.Errorf("ollama returned an empty embedding for model %q — is it loaded?", o.embeddingModel)
	}

	return er.Embedding, nil
}

// ── Chat streaming ────────────────────────────────────────────────────────────

// ChatStream sends a multi-turn conversation to Ollama and calls onChunk for
// every token the model generates. It blocks until the model signals Done=true
// or an error occurs.
//
// The onChunk callback receives raw token strings — often a single word or
// sub-word. Callers are responsible for deciding how to present them:
// the CLI chatbot prints them immediately with fmt.Print (no newline) to
// simulate a typewriter effect, while a future web handler might buffer them
// into SSE frames.
func (o *OllamaClient) ChatStream(messages []Message, onChunk func(string)) error {
	reqBody := chatRequest{
		Model:    o.chatModel,
		Messages: messages,
		Stream:   true,
	}

	raw, err := json.Marshal(reqBody)
	if err != nil {
		return fmt.Errorf("marshalling chat request: %w", err)
	}

	url := strings.TrimRight(o.baseURL, "/") + "/api/chat"
	resp, err := o.httpClient.Post(url, "application/json", bytes.NewReader(raw))
	if err != nil {
		return fmt.Errorf("calling ollama /api/chat: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("ollama chat returned HTTP %d: %s", resp.StatusCode, string(body))
	}

	// Ollama streams one JSON object per line (NDJSON).
	// bufio.Scanner reads line by line without loading the whole body into
	// memory, which matters for long answers that could be many kilobytes.
	scanner := bufio.NewScanner(resp.Body)

	// Increase the scanner buffer to handle potentially long lines from Ollama.
	// The default 64KB is usually fine, but a pathological model output could
	// produce a line that exceeds it and silently truncate the response.
	const maxTokenSize = 1024 * 1024 // 1 MB ought to be enough for any token
	buf := make([]byte, maxTokenSize)
	scanner.Buffer(buf, maxTokenSize)

	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue // Ollama sometimes emits blank lines as keep-alive pings
		}

		var chunk chatChunk
		if err := json.Unmarshal([]byte(line), &chunk); err != nil {
			// Non-fatal: log and continue. A malformed line mid-stream shouldn't
			// abort the entire conversation — we can still show the tokens we got.
			fmt.Fprintf(os.Stderr, "[ollama] warning: skipping malformed NDJSON line: %s\n", line)
			continue
		}

		if chunk.Done {
			// The model has finished generating. We return here rather than
			// breaking to ensure the scanner doesn't leave the body half-read,
			// which could cause the HTTP connection to be abandoned instead of
			// properly reused by the http.Client connection pool.
			return nil
		}

		if chunk.Message.Content != "" {
			onChunk(chunk.Message.Content)
		}
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("reading ollama chat stream: %w", err)
	}

	return nil
}

// ── Vector encoding ───────────────────────────────────────────────────────────

// EncodeVector converts a []float64 into the text representation that Turso's
// vector32() SQL function expects: a comma-separated list of floats wrapped in
// square brackets, e.g. "[0.123,0.456,-0.789]".
//
// Why not use a binary format?
// Turso's vector32() function is designed to accept this exact text syntax via
// a SQL bind parameter. Binary encoding would require base64 and a custom
// deserialization step on the database side — unnecessary complexity when the
// text form works perfectly and is human-readable during debugging.
func EncodeVector(vec []float64) string {
	var sb strings.Builder
	sb.WriteByte('[')
	for i, v := range vec {
		if i > 0 {
			sb.WriteByte(',')
		}
		fmt.Fprintf(&sb, "%g", v)
	}
	sb.WriteByte(']')
	return sb.String()
}
