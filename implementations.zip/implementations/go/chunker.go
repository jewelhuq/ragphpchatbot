package rag

// chunker.go — Turns raw document text into retrieval-ready chunks.
//
// Why chunking?
// An embedding model maps an entire text to a single point in vector space.
// If that text is 50 pages long, the point averages across thousands of topics
// and becomes meaningless for retrieval — every query lands "near" it because
// it contains something about everything. Short, topically coherent chunks
// produce embeddings that genuinely represent their content.
//
// Strategy:
//  1. Split on blank lines (paragraph boundaries in plain text).
//  2. Accumulate paragraphs until we'd exceed chunkSize characters.
//  3. When a paragraph looks like a section heading (ALL CAPS, < 120 chars),
//     remember it and prefix subsequent chunks with "Section: {heading}".
//  4. Prefix every chunk with "Source: {filename}" so the retriever can show
//     the user where the information came from.
//  5. Discard chunks shorter than 100 characters — they're almost always
//     stray page numbers, whitespace artefacts, or single-word headers that
//     would pollute the vector index without adding retrieval value.

import (
	"strings"
	"unicode"
)

const minChunkLen = 100 // characters — shorter chunks are noise

// Chunk splits text into overlapping, semantically coherent segments.
// source is typically the filename (e.g. "manual.txt") and is prepended to
// each chunk so the LLM can cite where each piece of knowledge came from.
func Chunk(text, source string) []string {
	// Normalise line endings — Windows files use \r\n, Unix files use \n.
	// We treat \r\n as \n so paragraph splitting works on both.
	text = strings.ReplaceAll(text, "\r\n", "\n")

	// Split into paragraphs on double newlines. A double newline is the
	// universal "new thought" separator in plain text documents.
	paragraphs := strings.Split(text, "\n\n")

	var chunks []string
	var buf strings.Builder    // accumulates paragraphs for the current chunk
	currentHeading := ""       // tracks the most recent section heading seen

	// flushChunk finalises the current buffer into a chunk, prepends the
	// metadata header, and appends it to chunks — if it's long enough.
	flushChunk := func() {
		raw := strings.TrimSpace(buf.String())
		if len(raw) < minChunkLen {
			buf.Reset()
			return
		}

		// Build the metadata prefix. Every chunk starts with the source so
		// retrieval results always include provenance. If we're inside a
		// named section, that goes on the second line.
		var header strings.Builder
		header.WriteString("Source: ")
		header.WriteString(source)
		header.WriteByte('\n')
		if currentHeading != "" {
			header.WriteString("Section: ")
			header.WriteString(currentHeading)
			header.WriteByte('\n')
		}
		header.WriteByte('\n')

		chunks = append(chunks, header.String()+raw)
		buf.Reset()
	}

	for _, para := range paragraphs {
		para = strings.TrimSpace(para)
		if para == "" {
			continue
		}

		// Detect section headings: a short ALL CAPS line signals a new topic.
		// We use a heuristic rather than document-format-specific logic so
		// the chunker works on arbitrary plain text exports.
		if isHeading(para) {
			// A new heading means we've moved to a new topic — flush whatever
			// accumulated so far before starting the new section.
			flushChunk()
			currentHeading = para
			// Don't include the bare heading as a standalone chunk; it will
			// appear in the prefix of the next content chunk instead.
			continue
		}

		// If adding this paragraph would push the buffer over chunkSize,
		// flush first. This creates a natural boundary between chunks while
		// keeping each one under the size limit.
		if buf.Len() > 0 && buf.Len()+len(para)+2 > chunkSizeFromContext() {
			flushChunk()
		}

		if buf.Len() > 0 {
			buf.WriteString("\n\n") // preserve paragraph separation within the chunk
		}
		buf.WriteString(para)
	}

	// Don't forget the last chunk — there's no trailing double-newline to
	// trigger a flush, so we do it explicitly after the loop.
	flushChunk()

	return chunks
}

// ChunkWithSize is the same as Chunk but accepts an explicit chunkSize,
// making it testable without a global Config and usable from the ingestor
// where the config value is known.
func ChunkWithSize(text, source string, chunkSize int) []string {
	text = strings.ReplaceAll(text, "\r\n", "\n")
	paragraphs := strings.Split(text, "\n\n")

	var chunks []string
	var buf strings.Builder
	currentHeading := ""

	flushChunk := func() {
		raw := strings.TrimSpace(buf.String())
		if len(raw) < minChunkLen {
			buf.Reset()
			return
		}

		var header strings.Builder
		header.WriteString("Source: ")
		header.WriteString(source)
		header.WriteByte('\n')
		if currentHeading != "" {
			header.WriteString("Section: ")
			header.WriteString(currentHeading)
			header.WriteByte('\n')
		}
		header.WriteByte('\n')

		chunks = append(chunks, header.String()+raw)
		buf.Reset()
	}

	for _, para := range paragraphs {
		para = strings.TrimSpace(para)
		if para == "" {
			continue
		}

		if isHeading(para) {
			flushChunk()
			currentHeading = para
			continue
		}

		if buf.Len() > 0 && buf.Len()+len(para)+2 > chunkSize {
			flushChunk()
		}

		if buf.Len() > 0 {
			buf.WriteString("\n\n")
		}
		buf.WriteString(para)
	}

	flushChunk()
	return chunks
}

// isHeading returns true if a paragraph looks like a section heading.
// The heuristic: the text is short (under 120 chars), contains no terminal
// punctuation, and consists mostly of uppercase letters.
//
// This intentionally avoids regex to keep the dependency list at zero.
// The tradeoff is that occasional ALL-CAPS acronym sentences get mis-classified
// as headings — acceptable for a plain-text RAG system.
func isHeading(s string) bool {
	// Must be a single line (no embedded newlines within the paragraph).
	if strings.Contains(s, "\n") {
		return false
	}

	// Short enough to be a heading.
	if len(s) >= 120 {
		return false
	}

	// Section headings don't end with sentence-closing punctuation.
	trimmed := strings.TrimRight(s, " \t")
	if len(trimmed) == 0 {
		return false
	}
	last := rune(trimmed[len(trimmed)-1])
	if last == '.' || last == '?' || last == '!' || last == ':' {
		return false
	}

	// Count uppercase vs lowercase letters.
	var upper, lower int
	for _, r := range s {
		if unicode.IsUpper(r) {
			upper++
		} else if unicode.IsLower(r) {
			lower++
		}
	}

	// Need at least a few alphabetic characters to decide.
	total := upper + lower
	if total < 3 {
		return false
	}

	// If 80% or more of the letters are uppercase, call it a heading.
	return float64(upper)/float64(total) >= 0.80
}

// chunkSizeFromContext returns the default chunk size used when Chunk() is
// called without an explicit size parameter. In production, callers should
// use ChunkWithSize() and pass cfg.ChunkSize. This fallback prevents a nil-
// dereference if someone calls Chunk() in a quick script.
func chunkSizeFromContext() int {
	return 1000
}
