package rag

// parser.go — Turns files on disk into raw strings the chunker can consume.
//
// Why a dedicated parser layer?
// Because the chunker shouldn't care whether its input came from a .txt file,
// a PDF, a Word doc, or a database row. Separating concerns here means we can
// swap in a real PDF library later without touching chunker.go at all.
//
// Current state of the art in this file:
//   .txt  — full support via os.ReadFile, handles UTF-8 cleanly
//   .pdf  — raw bytes only; real text extraction needs a C library binding
//   .docx — raw bytes only; real extraction needs an XML parser for Open XML
//
// For production use, replace the PDF and DOCX branches with calls to:
//   github.com/ledongthuc/pdf       (pure Go PDF text extractor)
//   github.com/nguyenthenguyen/docx (pure Go DOCX reader)
// Both are pure Go, so they'd keep the "no CGo" constraint.

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Parse reads the file at filePath and returns its text content as a string.
// The strategy differs by extension:
//   - .txt  → decoded as UTF-8 text (the common case)
//   - .pdf  → raw bytes cast to string; readable for debugging but not for production
//   - .docx → raw bytes; Open XML is ZIP+XML but we don't unzip it here
//   - other → returns an error so the ingestor can skip the file gracefully
func Parse(filePath string) (string, error) {
	ext := strings.ToLower(filepath.Ext(filePath))

	switch ext {
	case ".txt":
		return parseTxt(filePath)
	case ".pdf":
		return parsePDFRaw(filePath)
	case ".docx":
		return parseDOCXRaw(filePath)
	default:
		return "", fmt.Errorf("unsupported file type %q — only .txt, .pdf, .docx are handled", ext)
	}
}

// parseTxt reads a plain text file and returns its contents verbatim.
// os.ReadFile returns a []byte which we convert to string directly;
// Go strings are byte sequences, so this is zero-copy on most runtimes.
func parseTxt(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("reading text file %q: %w", path, err)
	}
	return string(data), nil
}

// parsePDFRaw reads the raw bytes of a PDF file and returns them as a string.
//
// NOTE: This does NOT extract readable text. PDF is a complex binary format;
// the text is embedded in content streams that require a proper parser to decode.
// What you'll get here is the raw binary including fonts, images, and metadata —
// useful for verifying that a file is a PDF and getting its size, but not for
// semantic chunking.
//
// To get real text from a PDF, replace this function body with:
//
//   import "github.com/ledongthuc/pdf"
//   f, r, _ := pdf.Open(path)
//   defer f.Close()
//   var buf bytes.Buffer
//   b, _ := r.GetPlainText()
//   buf.ReadFrom(b)
//   return buf.String(), nil
func parsePDFRaw(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("reading PDF file %q: %w", path, err)
	}

	// Emit a warning so operators know they're getting raw bytes.
	// In a production system this would go to a structured logger.
	fmt.Printf("[parser] WARNING: %q is a PDF — returning raw bytes, not extracted text.\n"+
		"         For real text extraction, integrate github.com/ledongthuc/pdf\n", path)

	return string(data), nil
}

// parseDOCXRaw reads the raw bytes of a .docx file and returns them as a string.
//
// NOTE: .docx files are ZIP archives containing XML files. The readable text
// lives inside word/document.xml, compressed inside the ZIP. Returning raw bytes
// gives you the ZIP binary — useful for existence checks but not for RAG.
//
// To get real text from a DOCX, replace this function body with something like:
//
//   import (
//       "archive/zip"
//       "encoding/xml"
//   )
//   r, _ := zip.OpenReader(path)
//   defer r.Close()
//   for _, f := range r.File {
//       if f.Name == "word/document.xml" {
//           rc, _ := f.Open()
//           // strip XML tags to get plain text
//           ...
//       }
//   }
//
// Or use github.com/nguyenthenguyen/docx for a higher-level API.
func parseDOCXRaw(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("reading DOCX file %q: %w", path, err)
	}

	fmt.Printf("[parser] WARNING: %q is a DOCX — returning raw ZIP bytes, not extracted text.\n"+
		"         For real text extraction, unzip and parse word/document.xml\n", path)

	return string(data), nil
}

// IsSupportedExtension reports whether the given file extension is one the
// parser can attempt to handle. The ingestor uses this to skip README.md,
// .DS_Store, and other files before even opening them.
func IsSupportedExtension(ext string) bool {
	switch strings.ToLower(ext) {
	case ".txt", ".pdf", ".docx":
		return true
	default:
		return false
	}
}
