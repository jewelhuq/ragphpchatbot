package rag

// turso.go — The bridge between our Go code and Turso's HTTP API.
//
// Turso exposes a /v2/pipeline endpoint that accepts a batch of SQL statements
// and executes them in a single round-trip. We wrap this in two methods:
//   - Execute: fire-and-forget (INSERT, CREATE TABLE, DELETE, …)
//   - FetchAll: runs a SELECT and returns rows as []map[string]string
//
// Why not use a SQLite driver directly?
// Turso's remote databases are accessible only via HTTP, not a file path.
// The pipeline API is simpler than maintaining a WebSocket connection and
// handles auth with a plain Bearer token, which fits stdlib perfectly.

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
)

// TursoClient holds the HTTP client and credentials needed to talk to Turso.
// It is safe to share across goroutines — http.Client is concurrency-safe and
// the fields are read-only after construction.
type TursoClient struct {
	baseURL    string
	token      string
	httpClient *http.Client
}

// NewTursoClient builds a TursoClient from the provided Config.
// We construct a dedicated http.Client so future callers can tune timeouts
// independently of any global default.
func NewTursoClient(cfg *Config) *TursoClient {
	return &TursoClient{
		baseURL:    cfg.TursoURL,
		token:      cfg.TursoToken,
		httpClient: &http.Client{},
	}
}

// ── Wire types ────────────────────────────────────────────────────────────────

// tursoArg represents a single bound parameter in a SQL statement.
// Turso requires explicit type tagging because JSON numbers are ambiguous:
// "42" is a valid integer, float, or text depending on the column.
type tursoArg struct {
	Type  string `json:"type"`
	Value any    `json:"value"`
}

// tursoStmt is a single SQL statement with its positional arguments.
type tursoStmt struct {
	SQL  string     `json:"sql"`
	Args []tursoArg `json:"args,omitempty"`
}

// tursoRequest is the outer request body sent to /v2/pipeline.
// Turso processes the requests array as a transaction in order.
type tursoRequest struct {
	Requests []tursoRequestItem `json:"requests"`
}

// tursoRequestItem wraps a statement with the request type.
// "execute" is the only type we use; Turso also supports "close" to end
// a pipeline session, but our stateless HTTP usage doesn't need it.
type tursoRequestItem struct {
	Type string    `json:"type"`
	Stmt tursoStmt `json:"stmt"`
}

// tursoResponse is the top-level shape of Turso's JSON reply.
type tursoResponse struct {
	Results []tursoResult `json:"results"`
}

// tursoResult is one result entry per request item.
type tursoResult struct {
	Type     string       `json:"type"`
	Response tursoPayload `json:"response"`
	Error    *tursoError  `json:"error,omitempty"`
}

type tursoPayload struct {
	Type   string     `json:"type"`
	Result tursoTable `json:"result"`
}

type tursoTable struct {
	Cols []tursoCol `json:"cols"`
	Rows [][]tursoCell `json:"rows"`
}

type tursoCol struct {
	Name string `json:"name"`
}

type tursoCell struct {
	Type  string `json:"type"`
	Value any    `json:"value"`
}

type tursoError struct {
	Message string `json:"message"`
	Code    string `json:"code"`
}

// ── Arg helpers ───────────────────────────────────────────────────────────────

// TextArg creates a text-typed argument. Use for strings and anything
// that isn't a number, including the encoded blob produced by vector32().
func TextArg(v string) tursoArg { return tursoArg{Type: "text", Value: v} }

// IntArg creates an integer-typed argument. Turso is strict: passing an
// integer value as type "text" will cause a type-mismatch in indexed columns.
func IntArg(v int) tursoArg { return tursoArg{Type: "integer", Value: v} }

// FloatArg creates a float-typed argument.
func FloatArg(v float64) tursoArg { return tursoArg{Type: "float", Value: v} }

// NullArg represents a SQL NULL value.
func NullArg() tursoArg { return tursoArg{Type: "null", Value: nil} }

// ── Core transport ────────────────────────────────────────────────────────────

// post sends a single pipeline request and returns the parsed response body.
// All public methods funnel through here so error handling and auth live in
// exactly one place — the "don't repeat yourself" principle applied to HTTP.
func (c *TursoClient) post(items []tursoRequestItem) (*tursoResponse, error) {
	body := tursoRequest{Requests: items}

	raw, err := json.Marshal(body)
	if err != nil {
		return nil, fmt.Errorf("marshalling turso request: %w", err)
	}

	url := strings.TrimRight(c.baseURL, "/") + "/v2/pipeline"
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(raw))
	if err != nil {
		return nil, fmt.Errorf("building turso HTTP request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+c.token)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("sending request to turso: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("reading turso response body: %w", err)
	}

	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("turso returned HTTP %d: %s", resp.StatusCode, string(respBody))
	}

	var tr tursoResponse
	if err := json.Unmarshal(respBody, &tr); err != nil {
		return nil, fmt.Errorf("parsing turso response JSON: %w\nbody: %s", err, string(respBody))
	}

	// Surface any per-statement errors from Turso's result array.
	// A query can return HTTP 200 but still contain statement-level errors
	// (constraint violations, bad SQL, etc.) — we check for them here so
	// callers don't have to.
	for i, r := range tr.Results {
		if r.Error != nil {
			return nil, fmt.Errorf("turso error in result[%d]: %s (code: %s)", i, r.Error.Message, r.Error.Code)
		}
	}

	return &tr, nil
}

// ── Public API ────────────────────────────────────────────────────────────────

// Execute runs a single SQL statement that does not need to return rows —
// CREATE TABLE, INSERT, DELETE, UPDATE, and so on.
// It returns an error if the statement itself fails; row counts are not surfaced
// because Turso's pipeline API doesn't expose last_insert_rowid in a convenient way.
func (c *TursoClient) Execute(sql string, args ...tursoArg) error {
	item := tursoRequestItem{
		Type: "execute",
		Stmt: tursoStmt{SQL: sql, Args: args},
	}
	_, err := c.post([]tursoRequestItem{item})
	return err
}

// ExecuteBatch runs multiple SQL statements in a single pipeline round-trip.
// This is critical for ingest performance: batching 50 INSERTs into one HTTP
// request is dramatically faster than 50 sequential requests.
func (c *TursoClient) ExecuteBatch(stmts []tursoStmt) error {
	items := make([]tursoRequestItem, len(stmts))
	for i, s := range stmts {
		items[i] = tursoRequestItem{Type: "execute", Stmt: s}
	}
	_, err := c.post(items)
	return err
}

// FetchAll runs a SELECT statement and returns the result rows as a slice of
// string maps. All cell values are coerced to strings for simplicity —
// the RAG system only reads text, IDs, and similarity scores, so precision
// loss is not a concern here.
//
// Why []map[string]string instead of typed structs?
// The queries in this system are ad-hoc and the column sets vary. A generic
// map lets every call site work without defining a bespoke result type,
// keeping the codebase lean.
func (c *TursoClient) FetchAll(sql string, args ...tursoArg) ([]map[string]string, error) {
	item := tursoRequestItem{
		Type: "execute",
		Stmt: tursoStmt{SQL: sql, Args: args},
	}

	tr, err := c.post([]tursoRequestItem{item})
	if err != nil {
		return nil, err
	}

	if len(tr.Results) == 0 {
		return nil, nil
	}

	table := tr.Results[0].Response.Result

	// Build a column-name index so we can populate maps by name, not by
	// positional integer. Positional access would be brittle if someone
	// ever reorders SELECT columns.
	colNames := make([]string, len(table.Cols))
	for i, col := range table.Cols {
		colNames[i] = col.Name
	}

	rows := make([]map[string]string, 0, len(table.Rows))
	for _, row := range table.Rows {
		m := make(map[string]string, len(colNames))
		for j, cell := range row {
			if j < len(colNames) {
				// cell.Value is an any coming out of JSON unmarshalling.
				// fmt.Sprintf handles nil (NULL), float64 (numbers), and
				// string transparently — good enough for our purposes.
				m[colNames[j]] = fmt.Sprintf("%v", cell.Value)
			}
		}
		rows = append(rows, m)
	}

	return rows, nil
}
