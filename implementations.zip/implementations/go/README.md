﻿# Go RAG Implementation

A complete Retrieval-Augmented Generation (RAG) system written in pure Go (stdlib only). Connects to Turso DB for vector storage and Ollama for local LLM inference.

## Architecture

```
docs/          ← your .txt / .pdf / .docx files
   |
   v
[ingest]  →  parse → chunk → embed (Ollama) → store (Turso)
                                                    |
[query]   →  embed (Ollama) → vector_top_k ────────┘
                                    |
[rag]     →  embed → retrieve → build prompt → ChatStream (Ollama) → stdout
                                    |
[chatbot] →  same as rag, but loops with history (last 10 turns)
```

## Prerequisites

1. **Go 1.21+** — `go version`
2. **Ollama** running locally — `ollama serve`
3. **Models pulled in Ollama**:
   ```
   ollama pull nomic-embed-text
   ollama pull gemma3:1b
   ```
4. **Turso account** with a database created at `https://your-db-name.turso.io`

## Configuration

Create `config.json` in the project root (or anywhere you run the commands from):

```json
{
  "turso_url":        "https://your-db-name.turso.io",
  "turso_token":      "YOUR_TURSO_BEARER_TOKEN",
  "ollama_url":       "http://127.0.0.1:11434",
  "chat_model":       "gemma3:1b",
  "embedding_model":  "nomic-embed-text",
  "embedding_dims":   768,
  "top_k":            5,
  "docs_dir":         "./docs",
  "chunk_size":       1000
}
```

| Field             | Description                                                        | Default                                               |
|-------------------|--------------------------------------------------------------------|-------------------------------------------------------|
| `turso_url`       | Full base URL of your Turso database                               | `https://your-db-name.turso.io`  |
| `turso_token`     | Bearer token from `turso db tokens create <db-name>`              | *(required)*                                          |
| `ollama_url`      | Base URL of the local Ollama server                                | `http://127.0.0.1:11434`                              |
| `chat_model`      | Ollama model for answer generation                                 | `gemma3:1b`                                           |
| `embedding_model` | Ollama model for embeddings — must produce `embedding_dims` dims  | `nomic-embed-text`                                    |
| `embedding_dims`  | Dimensions of the embedding model output                           | `768`                                                 |
| `top_k`           | Number of nearest chunks to retrieve per query                     | `5`                                                   |
| `docs_dir`        | Directory to scan for documents (recursive)                        | `./docs`                                              |
| `chunk_size`      | Target character count per chunk (minimum 100)                     | `1000`                                                |

You can also set secrets via environment variables (these override config.json values):

```bash
export TURSO_TOKEN="your-token-here"
export TURSO_URL="https://..."      # optional
export OLLAMA_URL="http://..."      # optional
```

## Running the Commands

All commands are run with `go run` from the project root (`implementations/go/`).

### 1. Ingest Documents

Place your `.txt`, `.pdf`, or `.docx` files in the `docs/` directory (or whatever `docs_dir` points to), then run:

```bash
go run ./cmd/ingest
# or with an explicit config file:
go run ./cmd/ingest /path/to/config.json
```

What it does:
- Creates the `chunks` table and `chunks_vector_idx` DiskANN index in Turso if they don't exist.
- Walks `docs_dir` recursively for `.txt`, `.pdf`, `.docx` files.
- For each file, computes an MD5 hash. If the file is unchanged since last ingest, it is skipped.
- If the file has changed, old chunks are deleted before re-ingesting.
- Each file is parsed, split into chunks, embedded with Ollama, and stored in Turso.

Re-running ingest is safe and idempotent — unchanged files are skipped.

### 2. Query (Raw Retrieval)

Test what chunks are retrieved for a question, without involving the LLM:

```bash
go run ./cmd/query "What is the return policy?"
# or with explicit config:
go run ./cmd/query config.json "What is the return policy?"
```

Output shows the top-k chunks ranked by cosine distance (lower = more similar), with source filename, chunk index, and a content preview.

Use this to:
- Verify ingest worked correctly
- Tune `top_k` — see how many good results exist
- Debug why the RAG answer seems wrong (is retrieval the problem, or is it the LLM?)

### 3. RAG (Single-Turn Question Answering)

Embed, retrieve, build prompt, and stream an LLM answer:

```bash
go run ./cmd/rag "What is the return policy?"
# or with explicit config:
go run ./cmd/rag config.json "What is the return policy?"
```

Status messages go to stderr; only the model's answer goes to stdout. This means you can pipe the answer:

```bash
go run ./cmd/rag "summarise the warranty terms" > answer.txt
```

The system prompt instructs the model to:
1. Base its answer exclusively on the retrieved context.
2. Say "I don't know" if the context is insufficient.
3. Not invent facts not present in the documents.
4. Cite source documents when quoting.

### 4. Chatbot (Multi-Turn Interactive)

An interactive loop with conversation history (last 10 turns):

```bash
go run ./cmd/chatbot
# or with explicit config:
go run ./cmd/chatbot config.json
```

Type questions at the `You:` prompt. The chatbot:
- Performs fresh vector retrieval on every question (so topic changes work correctly).
- Maintains the last 10 turns of history so follow-up questions have context.
- Streams token-by-token output for immediate feedback.
- Type `quit` or `exit`, or press Ctrl+D (Unix) / Ctrl+Z then Enter (Windows) to exit.

## File Structure

```
implementations/go/
├── go.mod                  module "rag", Go 1.21, no external deps
├── config.go               Config struct, LoadConfig, DefaultConfig, Validate
├── turso.go                TursoClient, Execute, FetchAll, arg helpers
├── ollama.go               OllamaClient, Embed, ChatStream, EncodeVector
├── chunker.go              Chunk, ChunkWithSize, isHeading
├── parser.go               Parse, IsSupportedExtension
├── retrieval.go            RetrieveChunks, BuildRAGMessages, BuildSystemPrompt
├── cmd/
│   ├── ingest/main.go      Document ingestion pipeline
│   ├── query/main.go       Raw vector similarity search
│   ├── rag/main.go         Single-turn RAG question answering
│   └── chatbot/main.go     Multi-turn interactive chatbot
└── docs/                   Put your documents here (create this directory)
```

## Database Schema

The ingestor creates this schema in Turso automatically:

```sql
CREATE TABLE IF NOT EXISTS chunks (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    source    TEXT NOT NULL,       -- filename, e.g. "manual.txt"
    file_hash TEXT NOT NULL,       -- MD5 of file at ingest time
    chunk_idx INTEGER NOT NULL,    -- position within file (0-based)
    content   TEXT NOT NULL,       -- raw chunk text shown to the LLM
    embedding F32_BLOB(768)        -- nomic-embed-text vector
);

CREATE INDEX IF NOT EXISTS chunks_vector_idx
ON chunks(libsql_vector_idx(embedding, 'metric=cosine', ...));
```

## Extending the System

**Add a real PDF parser**: Replace `parsePDFRaw` in `parser.go` with a call to `github.com/ledongthuc/pdf`. Add it to `go.mod` and update the import — no other files need to change.

**Add a real DOCX parser**: Replace `parseDOCXRaw` in `parser.go` with an `archive/zip` reader that extracts `word/document.xml` and strips the XML tags.

**Change the chat model**: Update `chat_model` in `config.json` to any model you have pulled in Ollama (`ollama list` to see available models).

**Increase retrieval quality**: Increase `top_k` in `config.json` to give the LLM more context. Decrease `chunk_size` to make chunks more specific (more chunks, each covering a narrower topic).

## Turso Setup

```bash
# Install the Turso CLI
curl -sSfL https://get.tur.so/install.sh | bash

# Create a database
turso db create engi-rag-test

# Get the URL
turso db show engi-rag-test --url

# Create a token
turso db tokens create engi-rag-test
```

Copy the URL and token into `config.json` or set them as environment variables.
