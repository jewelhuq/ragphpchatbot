﻿# RAG System — PHP Implementation

This is the original, reference implementation of the RAG pipeline in PHP.
All other language implementations are ports of this codebase.

## Why PHP

- Zero-setup HTTP via `curl` (built-in)
- `ZipArchive` for DOCX/PDF extraction
- Composer for dependency management
- Runs on any shared hosting or local PHP server
- Synchronous by default — simple to read and debug

## Architecture

```
┌─────────────────────────────────────────┐
│              docs/ folder               │
│   Drop .txt / .pdf / .docx files here   │
└──────────────────┬──────────────────────┘
                   │
           ┌───────▼────────┐
           │  DocumentParser │  Extracts plain text
           └───────┬────────┘
                   │
           ┌───────▼────────┐
           │    Chunker      │  Splits into ~1500-char chunks
           │                 │  with section context prefix
           └───────┬────────┘
                   │
           ┌───────▼────────┐
           │  Ollama.embed() │  nomic-embed-text → 768-dim vector
           └───────┬────────┘
                   │
           ┌───────▼────────┐
           │  Turso DB       │  F32_BLOB + DiskANN vector index
           │  vector32()     │  Native ANN search via vector_top_k()
           └───────┬────────┘
                   │
           ┌───────▼────────┐
           │  VectorSearch   │  Query expansion + top-k retrieval
           └───────┬────────┘
                   │
           ┌───────▼────────┐
           │  Prompt.build() │  Numbered context + anti-hallucination
           └───────┬────────┘
                   │
           ┌───────▼────────┐
           │  Ollama.chat()  │  gemma3:1b streaming response
           └────────────────┘
```

## Prerequisites

- PHP 8.1+
- Composer
- Ollama running locally (`ollama serve`)
- Turso cloud account (or local sqld)

## Setup

```bash
# 1. Install dependencies
composer install

# 2. Pull AI models
ollama pull gemma3:1b
ollama pull nomic-embed-text

# 3. Edit config.php — set your Turso URL and token
```

## Configuration

Edit `config.php`:

| Key | Default | Description |
|---|---|---|
| `turso_url` | — | Your Turso database URL |
| `turso_token` | — | Your Turso auth token |
| `ollama_url` | `http://127.0.0.1:11434` | Ollama API endpoint |
| `chat_model` | `gemma3:1b` | LLM for answer generation |
| `embedding_model` | `nomic-embed-text` | Embedding model |
| `embedding_dims` | `768` | Must match the embedding model |
| `chunk_size` | `1500` | Characters per chunk |
| `chunk_overlap` | `150` | Overlap between chunks |
| `top_k` | `5` | Chunks retrieved per query |
| `docs_dir` | `./docs` | Folder to scan for documents |

## Usage

```bash
# Ingest documents from docs/
php ingest.php

# Debug: see what chunks are retrieved for a query
php query.php "What is Positive Pay?"

# One-shot RAG answer
php rag.php "What does Your Knowledge Base do?"

# Interactive chatbot
php chatbot.php
```

## Source Files

| File | Purpose |
|---|---|
| `config.php` | All configuration settings |
| `ingest.php` | Scan docs/, chunk, embed, store in Turso |
| `query.php` | Debug retrieval — shows top-k chunks |
| `rag.php` | One-shot RAG question + streaming answer |
| `chatbot.php` | Interactive CLI chatbot with history |
| `src/Turso.php` | Turso HTTP API client |
| `src/Ollama.php` | Ollama embed + chatStream |
| `src/DocumentParser.php` | txt/pdf/docx text extraction |
| `src/Chunker.php` | Paragraph-aware chunker with context prefix |
| `src/VectorSearch.php` | Query expansion + Turso native vector search |
| `src/Prompt.php` | RAG system prompt builder |

## Key Design Decisions

**Native Turso vector search** — embeddings stored as `F32_BLOB(768)` with a DiskANN index. Search uses `vector_top_k()` inside Turso — no PHP math, no full table scan.

**Query expansion** — each query is searched twice: once with the original phrasing and once with stop words stripped. Results are merged and deduplicated by chunk ID, keeping the best score.

**Context prefix** — every chunk is prefixed with `Source: {file}\nSection: {heading}` before embedding, so the vector captures WHERE the text came from, not just what it says.

**Streaming** — `Ollama::chatStream()` uses curl's `CURLOPT_WRITEFUNCTION` to process tokens as they arrive, enabling typewriter-style output.
