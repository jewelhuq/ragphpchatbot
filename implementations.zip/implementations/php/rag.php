﻿<?php

// ============================================================
// rag.php — One-Shot RAG Query (CLI)
// ============================================================
// Ask a single question and get an answer from the knowledge base.
// Good for testing retrieval and answer quality quickly.
//
// Unlike chatbot.php, this has no conversation history —
// each run is a fresh, standalone question.
//
// Usage:
//   php rag.php "What does Your Knowledge Base do?"
// ============================================================

require __DIR__ . '/vendor/autoload.php';

use RAG\Turso;
use RAG\Ollama;
use RAG\VectorSearch;
use RAG\Prompt;

$config = require __DIR__ . '/config.php';

$question = $argv[1] ?? null;
if (!$question) {
    echo "Usage: php rag.php \"your question here\"\n";
    exit(1);
}

$turso  = new Turso($config);
$ollama = new Ollama($config);
$search = new VectorSearch($turso, $ollama, $config['top_k']);

// ----------------------------------------------------------------
// Step 1: Search the knowledge base for relevant chunks.
// ----------------------------------------------------------------
echo "Searching knowledge base...\n";
$relevantChunks = $search->search($question);

if (empty($relevantChunks)) {
    echo "No relevant chunks found for this question.\n";
    exit(1);
}

// Show which chunks were retrieved (helpful for debugging)
echo "Retrieved " . count($relevantChunks) . " chunks:\n";
foreach ($relevantChunks as $i => $chunk) {
    echo "  [" . ($i + 1) . "] {$chunk['source']} (score: {$chunk['score']})\n";
}
echo "\n";

// ----------------------------------------------------------------
// Step 2: Build the prompt with retrieved context injected.
// ----------------------------------------------------------------
$messages = [
    ['role' => 'system', 'content' => Prompt::build($relevantChunks)],
    ['role' => 'user',   'content' => $question],
];

// ----------------------------------------------------------------
// Step 3: Stream the answer token by token.
// ----------------------------------------------------------------
echo "Generating answer...\n\n";
echo str_repeat('=', 60) . "\n";

$ollama->chatStream($messages, function (string $token) {
    echo $token;
    flush();
});

echo "\n" . str_repeat('=', 60) . "\n";
