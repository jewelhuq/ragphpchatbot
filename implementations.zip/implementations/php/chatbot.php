<?php

// ============================================================
// chatbot.php — Interactive CLI Chatbot
// ============================================================
// This is the terminal interface for the RAG system.
// It keeps a conversation history so the AI remembers what
// was said earlier in the same session.
//
// Each turn works like this:
//   1. Read the user's message from the terminal
//   2. Search Turso for the most relevant document chunks
//   3. Build a system prompt from those chunks
//   4. Send the full conversation (history + new message) to the LLM
//   5. Stream the response back token by token
//   6. Save both sides of the exchange to history
//
// Usage:
//   php chatbot.php
// ============================================================

require __DIR__ . '/vendor/autoload.php';

use RAG\Turso;
use RAG\Ollama;
use RAG\VectorSearch;
use RAG\Prompt;

$config = require __DIR__ . '/config.php';

$turso   = new Turso($config);
$ollama  = new Ollama($config);
$search  = new VectorSearch($turso, $ollama, $config['top_k']);

// Conversation history — grows as the chat continues.
// We trim it to the last 20 messages to avoid token bloat.
$history = [];

echo str_repeat('=', 60) . "\n";
echo "  RAG Chatbot — powered by {$config['chat_model']}\n";
echo "  Commands: 'clear' to reset history | 'exit' to quit\n";
echo str_repeat('=', 60) . "\n\n";

// ----------------------------------------------------------------
// Main chat loop — runs until the user types 'exit' or 'quit'
// ----------------------------------------------------------------
while (true) {

    echo "\033[36mYou:\033[0m ";
    $userMessage = trim(fgets(STDIN));

    if ($userMessage === '') continue;

    // Handle special commands
    if (in_array(strtolower($userMessage), ['exit', 'quit'])) {
        echo "Goodbye!\n";
        break;
    }

    if (strtolower($userMessage) === 'clear') {
        $history = [];
        echo "\033[33mConversation history cleared.\033[0m\n\n";
        continue;
    }

    // ----------------------------------------------------------------
    // Step 1: Find relevant chunks from the knowledge base.
    //
    // We search every turn so the retrieved context always reflects
    // the current question, not previous turns.
    // ----------------------------------------------------------------
    echo "\033[90mSearching knowledge base...\033[0m\n";
    $relevantChunks = $search->search($userMessage);

    // ----------------------------------------------------------------
    // Step 2: Build the system prompt with retrieved context injected.
    //
    // The Prompt class formats the chunks into numbered, labelled
    // blocks with clear rules about how the AI must use them.
    // ----------------------------------------------------------------
    $systemPrompt = Prompt::build($relevantChunks);

    // ----------------------------------------------------------------
    // Step 3: Assemble the full message list for the LLM.
    //
    // Format: [system] + [past conversation] + [new user message]
    //
    // The system prompt goes first and sets the rules.
    // Then we replay the conversation history so the AI has context.
    // Then the new question goes last.
    // ----------------------------------------------------------------
    $messages = [['role' => 'system', 'content' => $systemPrompt]];

    foreach ($history as $pastTurn) {
        $messages[] = $pastTurn;
    }

    $messages[] = ['role' => 'user', 'content' => $userMessage];

    // Save the user message to history before generating the response
    $history[] = ['role' => 'user', 'content' => $userMessage];

    // ----------------------------------------------------------------
    // Step 4: Stream the AI response token by token.
    //
    // Each token arrives immediately as the model generates it.
    // We print it right away so the user sees output instantly
    // rather than waiting for the full answer.
    // ----------------------------------------------------------------
    echo "\033[32mAssistant:\033[0m ";

    $fullResponse = '';
    $ollama->chatStream($messages, function (string $token) use (&$fullResponse) {
        echo $token;
        flush();
        $fullResponse .= $token;
    });

    echo "\n\n";

    // Save the assistant's full response to history
    $history[] = ['role' => 'assistant', 'content' => $fullResponse];

    // Keep only the last 20 messages (10 turns) to prevent token bloat
    if (count($history) > 20) {
        $history = array_slice($history, -20);
    }
}
