<?php

// ============================================================
// query.php — Debug: See What Chunks Get Retrieved
// ============================================================
// This script shows exactly what the vector search returns
// for a given query — without calling the LLM.
//
// Use this to debug retrieval quality:
//   - Are the right chunks being found?
//   - Are scores high enough?
//   - Is the chunk content meaningful?
//
// Usage:
//   php query.php "your question here"
// ============================================================

require __DIR__ . '/vendor/autoload.php';

use RAG\Turso;
use RAG\Ollama;
use RAG\VectorSearch;

$config = require __DIR__ . '/config.php';

$question = $argv[1] ?? null;
if (!$question) {
    echo "Usage: php query.php \"your question here\"\n";
    exit(1);
}

$turso  = new Turso($config);
$ollama = new Ollama($config);
$search = new VectorSearch($turso, $ollama, $config['top_k']);

echo "Query: $question\n";
echo str_repeat('-', 60) . "\n\n";

$chunks = $search->search($question);

if (empty($chunks)) {
    echo "No chunks found.\n";
    exit;
}

foreach ($chunks as $rank => $chunk) {
    $number = $rank + 1;
    echo "RESULT $number\n";
    echo "  Source:    {$chunk['source']} (chunk #{$chunk['chunk_idx']})\n";
    echo "  Relevance: {$chunk['score']}\n";
    echo "  Content:\n";
    // Indent each line of content for readability
    echo "    " . implode("\n    ", explode("\n", $chunk['content'])) . "\n";
    echo str_repeat('-', 60) . "\n\n";
}
