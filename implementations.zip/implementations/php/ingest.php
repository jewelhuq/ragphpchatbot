<?php

// ============================================================
// ingest.php — Feed Documents Into the RAG System
// ============================================================
// This script is the starting point of the RAG pipeline.
// Run it whenever you add or update documents in the docs/ folder.
//
// What happens step by step:
//   1. Scan the docs/ folder for txt, pdf, and docx files
//   2. Skip files that haven't changed since last ingest (via MD5 hash)
//   3. Read each file and convert it to plain text
//   4. Split the text into overlapping chunks
//   5. Convert each chunk into a vector using the embedding model
//   6. Store the chunk + vector in Turso under a native F32_BLOB column
//
// Usage:
//   php ingest.php
// ============================================================

require __DIR__ . '/vendor/autoload.php';

use RAG\Turso;
use RAG\Ollama;
use RAG\DocumentParser;
use RAG\Chunker;

$config  = require __DIR__ . '/config.php';
$turso   = new Turso($config);
$ollama  = new Ollama($config);
$parser  = new DocumentParser();
$chunker = new Chunker($config['chunk_size'], $config['chunk_overlap']);

// ----------------------------------------------------------------
// Step 1: Make sure the database table exists.
//
// We store embeddings as F32_BLOB — a native Turso vector type.
// The dimension (768 for nomic-embed-text) must match the model.
//
// file_hash lets us detect unchanged files and skip re-ingesting them.
// ----------------------------------------------------------------
$dims = $config['embedding_dims'];

$turso->execute("
    CREATE TABLE IF NOT EXISTS chunks (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        source    TEXT    NOT NULL,
        chunk_idx INTEGER NOT NULL,
        content   TEXT    NOT NULL,
        embedding F32_BLOB($dims) NOT NULL,
        file_hash TEXT    NOT NULL DEFAULT ''
    )
");

// DiskANN vector index — this is what makes vector_top_k() fast.
// Without this index, every query would scan the entire table.
$turso->execute("
    CREATE INDEX IF NOT EXISTS chunks_vector_idx
    ON chunks(libsql_vector_idx(embedding))
");

// Regular B-tree index for source lookups (skip check, delete old chunks)
$turso->execute("
    CREATE INDEX IF NOT EXISTS idx_chunks_source ON chunks(source)
");

// ----------------------------------------------------------------
// Step 2: Orphan cleanup — delete chunks for files no longer on disk.
//
// If someone deletes a file from docs/, its chunks would normally
// stay in Turso forever (orphaned). We fix this by comparing every
// distinct source name in the DB against what's actually on disk.
// Any source with no matching file gets its chunks deleted.
// ----------------------------------------------------------------
$supportedTypes  = ['txt', 'pdf', 'docx'];
$docsDir         = $config['docs_dir'];
$ingestedSources = $turso->fetchAll("SELECT DISTINCT source FROM chunks");

foreach ($ingestedSources as $row) {
    $source   = $row['source'];
    $fullPath = $docsDir . DIRECTORY_SEPARATOR . $source;

    if (!file_exists($fullPath)) {
        $turso->execute("DELETE FROM chunks WHERE source = ?", [$source]);
        echo "Removed orphaned chunks for deleted file: $source\n";
        $stats['removed'] = ($stats['removed'] ?? 0) + 1;
    }
}

// ----------------------------------------------------------------
// Step 3: Walk through the docs/ folder and process each file.
// ----------------------------------------------------------------
$allFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($docsDir));

$stats = array_merge($stats ?? [], ['new' => 0, 'updated' => 0, 'skipped' => 0]);

foreach ($allFiles as $file) {
    if (!$file->isFile()) continue;

    $extension = strtolower($file->getExtension());
    if (!in_array($extension, $supportedTypes)) continue;

    $filePath = $file->getPathname();
    $filename = $file->getFilename();
    $fileHash = md5_file($filePath);

    // ----------------------------------------------------------------
    // Step 4: Skip unchanged files using MD5 hash comparison.
    //
    // If the file hasn't changed since last ingest, its hash will
    // match what's stored in the database — no need to re-embed.
    // ----------------------------------------------------------------
    $existing = $turso->fetchAll(
        "SELECT COUNT(*) as count, MAX(file_hash) as hash FROM chunks WHERE source = ?",
        [$filename]
    );

    $alreadyIngested = (int) ($existing[0]['count'] ?? 0) > 0;
    $hashMatches     = ($existing[0]['hash'] ?? '') === $fileHash;

    if ($alreadyIngested && $hashMatches) {
        echo "Skipping (unchanged): $filename\n";
        $stats['skipped']++;
        continue;
    }

    // File is new or has changed — delete old chunks before re-ingesting
    if ($alreadyIngested) {
        $turso->execute("DELETE FROM chunks WHERE source = ?", [$filename]);
        echo "Re-ingesting (file changed): $filename\n";
        $stats['updated']++;
    } else {
        echo "Ingesting (new file): $filename\n";
        $stats['new']++;
    }

    // ----------------------------------------------------------------
    // Step 5: Parse → chunk → embed → store.
    // ----------------------------------------------------------------
    try {
        $rawText = $parser->parse($filePath);

        // Pass the filename as source so each chunk gets prefixed with
        // "Source: filename" — this improves embedding quality
        $documentName = pathinfo($filename, PATHINFO_FILENAME);
        $chunks       = $chunker->chunk($rawText, $documentName);

        echo "  -> " . count($chunks) . " chunks\n";

        foreach ($chunks as $index => $chunkText) {
            echo "  Embedding chunk " . ($index + 1) . "/" . count($chunks) . "...\r";

            // Turn text into a vector of floats
            $embedding = $ollama->embed($chunkText);

            // Turso's vector32() function converts our float array string
            // into a native F32_BLOB that the vector index can work with
            $vectorString = '[' . implode(',', $embedding) . ']';

            $turso->execute(
                "INSERT INTO chunks (source, chunk_idx, content, embedding, file_hash)
                 VALUES (?, ?, ?, vector32(?), ?)",
                [$filename, $index, $chunkText, $vectorString, $fileHash]
            );
        }

        echo "\n  Done: $filename\n";

    } catch (\Exception $error) {
        echo "\n  ERROR processing $filename: " . $error->getMessage() . "\n";
    }
}

// ----------------------------------------------------------------
// Step 6: Print a summary of what was done.
// ----------------------------------------------------------------
echo "\n";
if (!empty($stats['removed'])) echo "Removed: {$stats['removed']} orphaned document(s) (file deleted from disk)\n";
if ($stats['new'])              echo "New:     {$stats['new']} document(s)\n";
if ($stats['updated'])          echo "Updated: {$stats['updated']} document(s)\n";
if ($stats['skipped'])          echo "Skipped: {$stats['skipped']} document(s) (unchanged)\n";

if (!$stats['new'] && !$stats['updated'] && empty($stats['removed'])) {
    echo "Nothing to ingest — all documents are up to date.\n";
}
