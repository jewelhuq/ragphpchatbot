﻿# Haskell RAG Implementation

A Retrieval-Augmented Generation system written in Haskell. Connects to
**Turso** (vector database over HTTP) and **Ollama** (local LLM server) to
answer questions grounded in your document corpus.

---

## Haskell's Safety Model

Haskell is a **purely functional** language where the type system enforces
safety guarantees that other languages rely on discipline to achieve.

### IO is explicit and traceable

Every function that communicates with the outside world — reading a file,
making an HTTP request, printing to the terminal — must declare this in its
return type with `IO`:

```haskell
embed       :: OllamaClient -> Text -> IO [Double]  -- network call
parseDocument :: FilePath -> IO Text                 -- file read
buildPrompt :: [ChunkResult] -> Text                 -- pure, no IO
chunk       :: Text -> Text -> Int -> [Text]         -- pure, no IO
```

The compiler **rejects** any attempt to call an `IO` function from a pure
context. Hidden network calls inside a "pure helper" are a compile-time error,
not a runtime surprise.

### Immutability by default

All values in Haskell are immutable. To model changing state (like conversation
history), you use `IORef` — a mutable reference that can only be read and
written inside `IO`. This makes every mutation **visible** at the declaration
site:

```haskell
historyRef <- newIORef ([] :: [Message])    -- declares mutable state
modifyIORef' historyRef (trimHistory . (++ [msg]))  -- explicit mutation
```

Compare this to Python, where any function can mutate a list with no
declaration of intent.

### Pattern matching exhaustiveness

When you pattern-match in Haskell, the compiler checks that you handle every
possible case. If you add a new constructor to a type and forget to update a
pattern match, the build **fails** — not at runtime, at compile time:

```haskell
cellValueToString :: Value -> String
cellValueToString (String t)   = T.unpack t
cellValueToString (Number n)   = show n
cellValueToString (Bool b)     = show b
cellValueToString Null         = ""
cellValueToString (Array arr)  = show arr
cellValueToString (Object obj) = show obj
-- Compiler verifies: all six Value constructors are handled. ✓
```

### Pure functions prevent entire bug classes

Functions like `chunk`, `buildPrompt`, and `isHeading` have no IO in their
types. This means:

- **No race conditions** — pure functions can run concurrently without locks.
- **Trivially testable** — call the function, check the output, no mocks needed.
- **Referential transparency** — same input always produces same output;
  you can substitute a function call with its result and the program doesn't
  change.
- **Easier reasoning** — when debugging, you can rule out an entire module
  if it's free of IO.

---

## Prerequisites

| Tool | Install |
|------|---------|
| Stack | `curl -sSL https://get.haskellstack.org/ \| sh` |
| Ollama | [ollama.ai](https://ollama.ai) |
| nomic-embed-text | `ollama pull nomic-embed-text` |
| gemma3:1b | `ollama pull gemma3:1b` |

---

## Quick Start

### 1. Set your Turso token

```bash
export TURSO_TOKEN=your_turso_bearer_token_here
```

Or add it to a shell profile so you don't have to set it every session.

### 2. Build the project

```bash
cd implementations/haskell
stack build
```

Stack downloads GHC and all dependencies automatically on the first run.
Subsequent builds are incremental and fast.

### 3. Add documents

```bash
mkdir -p docs
cp /path/to/your/documents/*.txt docs/
```

### 4. Ingest documents

```bash
stack exec ingest
```

This creates the database schema, chunks your documents, embeds each chunk
with `nomic-embed-text`, and stores the vectors in Turso. Unchanged files
are skipped on re-runs (idempotent by MD5 hash).

### 5. Search (retrieval only, no LLM)

```bash
stack exec query -- "What is the return policy?"
```

Shows the raw retrieved chunks so you can verify retrieval quality before
involving the LLM.

### 6. Single-turn RAG

```bash
stack exec rag -- "What is the warranty period for the product?"
```

Retrieves context and streams the LLM's answer token by token.

### 7. Interactive chatbot

```bash
stack exec chatbot
```

Opens an interactive loop. Each turn re-retrieves relevant context and
maintains a sliding window of the last 10 conversation turns. Type `quit`
or press Ctrl+D to exit.

---

## Project Structure

```
haskell/
├── src/
│   ├── Config.hs       -- Pure config record, no IO
│   ├── Turso.hs        -- HTTP client for Turso /v2/pipeline API
│   ├── Ollama.hs       -- HTTP client for Ollama embeddings and chat
│   ├── Chunker.hs      -- Pure text chunking (no IO whatsoever)
│   ├── Parser.hs       -- Document text extraction (IO for file reads)
│   ├── VectorSearch.hs -- Embed query + ANN search → [ChunkResult]
│   └── Prompt.hs       -- Pure prompt construction (no IO)
├── app/
│   ├── Ingest.hs       -- main: document ingestion pipeline
│   ├── Query.hs        -- main: retrieval-only search
│   ├── Rag.hs          -- main: single-turn RAG
│   └── Chatbot.hs      -- main: interactive multi-turn chatbot
├── package.yaml        -- Hpack build specification
├── stack.yaml          -- Stack resolver and extra deps
└── README.md
```

---

## Configuration

Edit `src/Config.hs` to change defaults:

| Field | Default | Description |
|-------|---------|-------------|
| `tursoUrl` | `https://your-db-name.turso.io` | Turso DB URL |
| `tursoToken` | `""` | Set via `TURSO_TOKEN` env var |
| `ollamaUrl` | `http://127.0.0.1:11434` | Local Ollama server |
| `chatModel` | `gemma3:1b` | LLM for answer generation |
| `embeddingModel` | `nomic-embed-text` | Embedding model (768 dims) |
| `topK` | `5` | Chunks retrieved per query |
| `chunkSize` | `1000` | Target characters per chunk |
| `docsDir` | `./docs` | Directory to ingest |

---

## Key Dependencies

| Package | Purpose |
|---------|---------|
| `aeson` | JSON encoding/decoding (ToJSON/FromJSON typeclasses) |
| `http-client` | HTTP connection pooling and requests |
| `http-client-tls` | TLS support for HTTPS (Turso) |
| `text` | Efficient packed Unicode strings |
| `bytestring` | Efficient byte arrays for HTTP bodies |
| `containers` | `Map`, `Set`, and other data structures |
| `conduit` | Streaming data processing |
| `directory` | File system operations |
| `cryptohash-md5` | MD5 hashing for change detection |

---

## Haskell Concepts in This Codebase

### do-notation

`do` blocks sequence IO actions. Each `<-` "extracts" a value from IO:

```haskell
result <- search turso ollama question (topK cfg)
-- `result` is now [ChunkResult], extracted from IO [ChunkResult]
```

### Higher-order functions

Functions that accept functions as arguments are idiomatic Haskell:

```haskell
chatStream ollama messages TIO.putStr
--                          ^^^^^^^^^^
--                          Text -> IO () callback, passed as a value
```

### Record syntax

Haskell records are immutable by default. "Updating" a record creates a new one:

```haskell
let cfg' = defaultConfig { tursoToken = tok }
-- defaultConfig is unchanged; cfg' is a new Config with one field different
```

### Maybe for safe absence

`Map.lookup` returns `Maybe String` — the compiler forces you to handle both
the "found" and "not found" cases:

```haskell
fromMaybe "" (Map.lookup "content" row)
-- If "content" key is absent, use "" — no KeyError possible at runtime
```
