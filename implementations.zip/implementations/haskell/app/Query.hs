module Main where

{- app/Query.hs — Search the vector index and print retrieved chunks.

   This program takes a query from the command line, embeds it, searches
   the Turso vector index, and prints the top-k most relevant chunks.
   It does NOT call the LLM — it shows the raw retrieval results so you can
   diagnose what context the RAG system would provide to the model.

   Why a separate `query` binary?
   Observability. When the chatbot gives a wrong answer, you need to know
   whether the problem is in retrieval (wrong chunks) or generation (LLM
   misused good chunks). `stack exec query -- "your question"` lets you
   inspect retrieval in isolation.

   Usage:
     TURSO_TOKEN=<token> stack exec query -- "What is the warranty period?"
-}

import Config (Config(..), defaultConfig)
import Turso (newTursoClient)
import Ollama (newOllamaClient)
import VectorSearch (ChunkResult(..), search)

import Data.Maybe (fromMaybe)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import System.Environment (getArgs, lookupEnv)
import System.IO (hPutStrLn, stderr)

main :: IO ()
main = do
  args <- getArgs
  tok  <- lookupEnv "TURSO_TOKEN"

  let cfg = defaultConfig
        { tursoToken = fromMaybe (tursoToken defaultConfig) tok }

  case args of
    []    -> hPutStrLn stderr "Usage: query <question>" >> fail "No query provided"
    (q:_) -> runQuery cfg (T.pack q)

runQuery :: Config -> Text -> IO ()
runQuery cfg queryText = do
  putStrLn $ "[query] Searching for: " ++ T.unpack queryText
  putStrLn $ "[query] top_k = " ++ show (topK cfg)

  turso  <- newTursoClient cfg
  ollama <- newOllamaClient cfg

  -- `search` is in IO because it makes HTTP calls to Ollama and Turso.
  -- The `<-` sequences these IO actions: search must complete before we
  -- can use the results.
  results <- search turso ollama queryText (topK cfg)

  putStrLn $ "\n[query] Found " ++ show (length results) ++ " result(s)\n"

  -- Pattern match over the results list.
  -- `[]` and `_` are exhaustive — the compiler verifies both cases are handled.
  case results of
    [] -> putStrLn "No results found. Have you run `stack exec ingest` first?"
    _  -> mapM_ printResult (zip [1..] results)

-- | Print one retrieved chunk with its metadata.
--   This is an IO action (it prints to stdout), made explicit by its type.
printResult :: (Int, ChunkResult) -> IO ()
printResult (i, cr) = do
  let bar = replicate 60 '-'
  putStrLn bar
  putStrLn $ "[" ++ show i ++ "] Source: " ++ T.unpack (source cr)
  putStrLn $ "    Score:  " ++ show (score cr)
  putStrLn ""
  TIO.putStrLn (content cr)
  putStrLn ""
