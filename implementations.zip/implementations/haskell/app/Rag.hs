module Main where

{- app/Rag.hs — Single-turn retrieval-augmented generation.

   This program takes a question from the command line, retrieves the most
   relevant chunks from Turso, builds a system prompt, and streams the LLM's
   answer to stdout token by token.

   "Single-turn" means no conversation history: each invocation is stateless.
   For a stateful multi-turn experience, use `stack exec chatbot`.

   The streaming output (token by token via `chatStream`) demonstrates one of
   Haskell's elegance points: the callback `TIO.putStr` is a value of type
   `Text -> IO ()`, passed as a first-class argument. Functions that accept
   functions are "higher-order functions" — idiomatic Haskell, zero ceremony.

   Usage:
     TURSO_TOKEN=<token> stack exec rag -- "What is the return policy?"
-}

import Config (Config(..), defaultConfig)
import Turso (newTursoClient)
import Ollama (OllamaClient, Message(..), newOllamaClient, chatStream)
import VectorSearch (ChunkResult(..), search)
import Prompt (buildPrompt)

import Data.Maybe (fromMaybe)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import System.Environment (getArgs, lookupEnv)
import System.IO (hPutStrLn, stderr, hFlush, stdout)

main :: IO ()
main = do
  args <- getArgs
  tok  <- lookupEnv "TURSO_TOKEN"

  let cfg = defaultConfig
        { tursoToken = fromMaybe (tursoToken defaultConfig) tok }

  case args of
    []    -> hPutStrLn stderr "Usage: rag <question>" >> fail "No question provided"
    (q:_) -> runRag cfg (T.pack q)

runRag :: Config -> Text -> IO ()
runRag cfg question = do
  putStrLn $ "[rag] Question: " ++ T.unpack question
  putStrLn "[rag] Retrieving context …"

  turso  <- newTursoClient cfg
  ollama <- newOllamaClient cfg

  -- Retrieve the top-k most relevant chunks.
  chunks <- search turso ollama question (topK cfg)

  putStrLn $ "[rag] Retrieved " ++ show (length chunks) ++ " chunk(s)"
  putStrLn "[rag] Generating answer …\n"
  putStrLn $ replicate 60 '='

  -- Build the system prompt from retrieved chunks.
  -- `buildPrompt` is a PURE function — [ChunkResult] -> Text — with no IO.
  -- Its purity is guaranteed by its type: no IO in the return type.
  let systemPrompt = buildPrompt chunks

  -- Construct the message list for Ollama.
  -- `Message` is a plain Haskell record — just data, no behaviour.
  let messages =
        [ Message { msgRole = "system", msgContent = systemPrompt }
        , Message { msgRole = "user",   msgContent = question      }
        ]

  -- Stream the answer token by token.
  -- `TIO.putStr` is the callback: it prints each token as it arrives.
  -- Higher-order functions (functions that take functions) are idiomatic
  -- Haskell — here `chatStream` takes `(Text -> IO ())` as its third argument.
  chatStream ollama messages TIO.putStr

  -- Ensure the final newline appears after the streamed output.
  putStrLn ""
  putStrLn $ replicate 60 '='
  putStrLn "[rag] Done."
  hFlush stdout
