module Main where

{- app/Ingest.hs — The document ingestion pipeline.

   This program scans a directory of documents, breaks them into chunks,
   embeds each chunk with Ollama, and stores the results in Turso so that
   the query, rag, and chatbot commands can retrieve them later.

   Key design: idempotency.
   Running ingest twice on the same documents should be a no-op, not a
   duplication. We achieve this by storing an MD5 hash of each file and only
   re-processing files whose hash has changed since last ingest. This matters
   in practice because embedding 1000 chunks takes minutes; re-embedding
   unchanged files wastes time and compute.

   The `main :: IO ()` type signature is Haskell's declaration that this
   function is the entry point and performs IO. Everything called from `main`
   that also performs IO must be in the IO monad — the compiler traces the
   dependency chain automatically. Pure helper functions (chunking, hashing
   preparation) are visibly separate by their non-IO types.

   Usage:
     stack exec ingest
     TURSO_TOKEN=<token> stack exec ingest
-}

import Config (Config(..), defaultConfig)
import Turso
  ( TursoClient, TursoArg(..), newTursoClient, execute, fetchAll, encodeVector )
import Ollama (OllamaClient, newOllamaClient, embed)
import Chunker (chunk)
import Parser (parseDocument)

import Crypto.Hash.MD5 (hash)
import Data.ByteString (ByteString)
import qualified Data.ByteString as BS
import Data.List (sort)
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe (fromMaybe)
import Data.Text (Text)
import qualified Data.Text as T
import Numeric (showHex)
import System.Directory (listDirectory, doesFileExist, doesDirectoryExist)
import System.Environment (lookupEnv)
import System.FilePath ((</>), takeExtension)
import System.IO (hPutStrLn, stderr, hFlush, stdout)

-- ── Entry point ───────────────────────────────────────────────────────────────

main :: IO ()
main = do
  -- Overlay the Turso token from the environment if present.
  -- We never store secrets in source code — only defaults with an empty token.
  tok <- lookupEnv "TURSO_TOKEN"
  let cfg = defaultConfig
        { tursoToken = fromMaybe (tursoToken defaultConfig) tok }

  if null (tursoToken cfg)
    then do
      hPutStrLn stderr "[ingest] ERROR: TURSO_TOKEN is not set."
      hPutStrLn stderr "[ingest] Set it with: export TURSO_TOKEN=your_token"
      fail "Missing TURSO_TOKEN"
    else runIngest cfg

runIngest :: Config -> IO ()
runIngest cfg = do
  putStrLn "[ingest] Starting RAG ingest pipeline"
  putStrLn $ "[ingest] docs_dir  = " ++ docsDir cfg
  putStrLn $ "[ingest] chunk_size = " ++ show (chunkSize cfg)
  putStrLn $ "[ingest] embedding  = " ++ embeddingModel cfg
  hFlush stdout

  -- ── 1. Clients ────────────────────────────────────────────────────────
  -- newTursoClient and newOllamaClient are in IO because they allocate
  -- HTTP connection pools. The `<-` syntax sequences these IO actions.
  turso  <- newTursoClient cfg
  ollama <- newOllamaClient cfg

  -- ── 2. Schema bootstrap ───────────────────────────────────────────────
  -- CREATE TABLE IF NOT EXISTS and CREATE INDEX IF NOT EXISTS are idempotent.
  -- Running them on every ingest means the ingestor is also the schema
  -- migration tool — no separate migration step for a first-time setup.
  putStrLn "[ingest] Ensuring database schema …"
  let dimStr = show (embeddingDims cfg)

  execute turso
    (T.pack $ unlines
      [ "CREATE TABLE IF NOT EXISTS chunks ("
      , "  id        INTEGER PRIMARY KEY AUTOINCREMENT,"
      , "  source    TEXT NOT NULL,"
      , "  file_hash TEXT NOT NULL,"
      , "  chunk_idx INTEGER NOT NULL,"
      , "  content   TEXT NOT NULL,"
      , "  embedding F32_BLOB(" ++ dimStr ++ ")"
      , ")"
      ])
    []

  execute turso
    (T.pack $
      "CREATE TABLE IF NOT EXISTS file_hashes (" ++
      "  source TEXT PRIMARY KEY," ++
      "  hash   TEXT NOT NULL" ++
      ")")
    []

  execute turso
    (T.pack $
      "CREATE INDEX IF NOT EXISTS chunks_vector_idx " ++
      "ON chunks(libsql_vector_idx(embedding))")
    []

  -- ── 3. Discover documents ─────────────────────────────────────────────
  putStrLn "[ingest] Scanning document directory …"
  files <- walkDirectory (docsDir cfg)
  putStrLn $ "[ingest] Found " ++ show (length files) ++ " document(s)"

  -- ── 4. Process each file ──────────────────────────────────────────────
  -- `mapM_` applies an IO action to each element of a list sequentially.
  -- It's the monadic equivalent of `for` in an imperative language.
  mapM_ (processFile cfg turso ollama) files

  putStrLn "[ingest] Done."

-- ── File processing ───────────────────────────────────────────────────────────

-- | Process a single file: hash it, check for changes, chunk, embed, store.
processFile :: Config -> TursoClient -> OllamaClient -> FilePath -> IO ()
processFile cfg turso ollama filePath = do
  let sourceName = T.pack filePath

  -- Read the raw file bytes for hashing.
  rawBytes <- BS.readFile filePath
  let fileHash = md5Hex rawBytes

  -- Check if this file has been ingested before with the same hash.
  existing <- fetchAll turso
    "SELECT hash FROM file_hashes WHERE source = ?"
    [TextArg sourceName]

  let storedHash = case existing of
        (row : _) -> fromMaybe "" (Map.lookup "hash" row)
        []        -> ""

  if storedHash == fileHash
    then putStrLn $ "[ingest] Skipping (unchanged): " ++ filePath
    else do
      putStrLn $ "[ingest] Processing: " ++ filePath
      ingestFile cfg turso ollama filePath sourceName fileHash

-- | Actually ingest a file: delete old chunks, re-chunk, embed, insert.
ingestFile :: Config -> TursoClient -> OllamaClient -> FilePath -> Text -> String -> IO ()
ingestFile cfg turso ollama filePath sourceName fileHash = do

  -- Delete old chunks for this source so re-ingest is clean.
  execute turso "DELETE FROM chunks WHERE source = ?" [TextArg sourceName]
  execute turso "DELETE FROM file_hashes WHERE source = ?" [TextArg sourceName]

  -- Parse the document text.
  docText <- parseDocument filePath

  -- Chunk the document. `chunk` is a PURE function — it takes Text and
  -- returns [Text] with zero IO. The compiler proves it cannot have side effects.
  let chunks = chunk sourceName docText (chunkSize cfg)

  putStrLn $ "  " ++ show (length chunks) ++ " chunks"

  -- Embed and insert each chunk.
  -- `zip [0..]` pairs each chunk with its index — no mutable counter needed.
  mapM_ (embedAndInsert turso ollama sourceName fileHash) (zip [0..] chunks)

  -- Record the file hash so subsequent runs can skip this file.
  execute turso
    "INSERT OR REPLACE INTO file_hashes (source, hash) VALUES (?, ?)"
    [TextArg sourceName, TextArg (T.pack fileHash)]

  putStrLn $ "  Inserted successfully."

-- | Embed one chunk and insert it into the database.
embedAndInsert :: TursoClient -> OllamaClient -> Text -> String -> (Int, Text) -> IO ()
embedAndInsert turso ollama sourceName fileHash (idx, chunkText) = do
  -- `embed` returns IO [Double] — an IO action that calls Ollama.
  vec <- embed ollama chunkText

  let vecEncoded = encodeVector vec

  execute turso
    (T.pack $ unlines
      [ "INSERT INTO chunks (source, file_hash, chunk_idx, content, embedding)"
      , "VALUES (?, ?, ?, ?, vector32(?))"
      ])
    [ TextArg sourceName
    , TextArg (T.pack fileHash)
    , IntArg idx
    , TextArg chunkText
    , TextArg vecEncoded
    ]

-- ── Directory walking ─────────────────────────────────────────────────────────

-- | Recursively collect all supported document files under a directory.
--   Returns a sorted list of file paths for deterministic ordering.
walkDirectory :: FilePath -> IO [FilePath]
walkDirectory dir = do
  exists <- doesDirectoryExist dir
  if not exists
    then do
      hPutStrLn stderr $ "[ingest] WARNING: docs_dir not found: " ++ dir
      return []
    else do
      entries <- listDirectory dir
      fmap (sort . concat) $ mapM (classifyEntry dir) entries

classifyEntry :: FilePath -> FilePath -> IO [FilePath]
classifyEntry base name = do
  let full = base </> name
  isDir  <- doesDirectoryExist full
  isFile <- doesFileExist full
  if isDir
    then walkDirectory full
    else if isFile && isSupportedExt (takeExtension name)
      then return [full]
      else return []

isSupportedExt :: String -> Bool
isSupportedExt ext = ext `elem` [".txt", ".md", ".pdf", ".docx"]

-- ── MD5 hashing ───────────────────────────────────────────────────────────────

-- | Compute the MD5 hash of a ByteString and return it as a hex string.
--   Pure function: ByteString -> String. No IO.
md5Hex :: ByteString -> String
md5Hex bs =
  concatMap byteToHex $ BS.unpack $ hash bs
  where
    byteToHex b =
      let h = showHex b ""
      in  if length h == 1 then '0' : h else h
