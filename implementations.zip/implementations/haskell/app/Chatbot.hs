module Main where

{- app/Chatbot.hs — Interactive multi-turn RAG chatbot.

   Unlike the single-turn `rag` binary, the chatbot maintains a conversation
   history across turns. Follow-up questions like "what about the second
   option?" and "can you elaborate?" only make sense when the model can see
   what was said before.

   Architecture decisions:

   History window (last 10 turns):
   We cap the history at 10 (user, assistant) pairs to prevent the prompt from
   growing unboundedly. Small models have limited context windows (~2048–8192
   tokens) and slow down as the prompt grows. Keeping only the most recent
   history is a pragmatic trade-off between coherence and performance.

   Per-turn retrieval:
   We re-run the vector search on every user message rather than searching once
   at the start. This is correct because the user might pivot topics mid-
   conversation — chunks relevant to "explain the warranty" differ from those
   relevant to "tell me about the return policy".

   Streaming output:
   Token-by-token printing via the `TIO.putStr` callback creates a typewriter
   effect. The full response is collected in an IORef so it can be appended to
   history after the stream completes.

   Purity vs IO in this file:
   The main loop is in IO (getLine, printing, HTTP calls). But `buildChatPrompt`
   and the message-assembly logic are pure functions called from the IO loop.
   The separation is explicit in the types — you can see at a glance which parts
   have side effects and which don't.

   Usage:
     TURSO_TOKEN=<token> stack exec chatbot
     Then type questions. Type "quit" or "exit" to leave. Ctrl+D also works.
-}

import Config (Config(..), defaultConfig)
import Turso (TursoClient, newTursoClient)
import Ollama (OllamaClient, Message(..), newOllamaClient, chatStream)
import VectorSearch (ChunkResult(..), search)
import Prompt (buildChatPrompt)

import Data.IORef
import Data.Maybe (fromMaybe)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import System.Environment (lookupEnv)
import System.IO
  ( hPutStrLn, stderr, hFlush, stdout, hSetBuffering, BufferMode(..) )
import Control.Exception (catch, IOException)

-- | Maximum number of (user, assistant) pairs to retain in history.
--   Each pair is two Message values, so the history list grows to at most
--   maxHistoryTurns * 2 entries.
maxHistoryTurns :: Int
maxHistoryTurns = 10

main :: IO ()
main = do
  -- Disable output buffering so streaming tokens appear immediately.
  -- With line buffering (the default), the output would only flush on '\n',
  -- making the typewriter effect invisible.
  hSetBuffering stdout NoBuffering

  tok <- lookupEnv "TURSO_TOKEN"
  let cfg = defaultConfig
        { tursoToken = fromMaybe (tursoToken defaultConfig) tok }

  if null (tursoToken cfg)
    then do
      hPutStrLn stderr "[chatbot] ERROR: TURSO_TOKEN is not set."
      fail "Missing TURSO_TOKEN"
    else runChatbot cfg

runChatbot :: Config -> IO ()
runChatbot cfg = do
  turso  <- newTursoClient cfg
  ollama <- newOllamaClient cfg

  -- Print welcome banner.
  putStrLn $ replicate 58 '='
  putStrLn "  Haskell RAG Chatbot (Ollama + Turso)"
  putStrLn $ replicate 58 '='
  putStrLn $ "  Model: " ++ chatModel cfg
  putStrLn $ "  Docs:  " ++ docsDir cfg
  putStrLn $ replicate 58 '='
  putStrLn "  Type a question and press Enter."
  putStrLn "  Type 'quit' or 'exit' to stop. Ctrl+D also exits."
  putStrLn $ replicate 58 '='
  putStrLn ""

  -- Use an IORef to hold the mutable conversation history.
  --
  -- In Haskell, immutability is the default. To model "state that changes
  -- over time" we use an IORef — a mutable reference that can only be read
  -- and written inside IO. This makes the mutation explicit and auditable:
  -- you can search for `modifyIORef` to find every place the history changes.
  --
  -- Contrast with Python where a list can be mutated anywhere with no
  -- declaration of intent. In Haskell, the type `IORef [Message]` announces
  -- "this is mutable state" at the declaration site.
  historyRef <- newIORef ([] :: [Message])

  -- Run the interactive loop.
  loop cfg turso ollama historyRef

-- | The main conversation loop.
--   Reads a line, processes it, updates history, and recurses.
--
--   Recursion replaces `while True:` loops in Haskell. Each recursive call
--   passes the updated state as arguments rather than mutating a shared variable.
--   Here we use an IORef for history because the loop needs to accumulate state
--   across many iterations — passing it as a parameter would also work but
--   IORef is idiomatic for "I/O loop state".
loop :: Config -> TursoClient -> OllamaClient -> IORef [Message] -> IO ()
loop cfg turso ollama historyRef = do
  putStr "\nYou: "
  hFlush stdout

  -- `catch` handles IOException (e.g. EOF on Ctrl+D) gracefully.
  -- Without it, Ctrl+D would print an ugly exception trace.
  lineResult <- catch (fmap Just TIO.getLine) eofHandler

  case lineResult of
    Nothing   -> putStrLn "\n[chatbot] Goodbye!" >> return ()
    Just line -> do
      let trimmed = T.strip line
      if T.null trimmed || trimmed `elem` ["quit", "exit", "q"]
        then putStrLn "[chatbot] Goodbye!" >> return ()
        else do
          processTurn cfg turso ollama historyRef trimmed
          loop cfg turso ollama historyRef  -- tail-recursive: no stack growth

  where
    eofHandler :: IOException -> IO (Maybe Text)
    eofHandler _ = return Nothing

-- | Process one conversation turn: retrieve, prompt, stream, record history.
processTurn
  :: Config
  -> TursoClient
  -> OllamaClient
  -> IORef [Message]
  -> Text
  -> IO ()
processTurn cfg turso ollama historyRef userText = do

  -- ── 1. Retrieve relevant chunks ───────────────────────────────────────
  -- We re-retrieve on every turn because the topic may have shifted.
  chunks <- search turso ollama userText (topK cfg)

  -- ── 2. Build the system prompt ────────────────────────────────────────
  -- `buildChatPrompt` is a PURE function — [ChunkResult] -> Text.
  -- No IO, no side effects. We call it with `let` not `<-`.
  let systemPrompt = buildChatPrompt chunks

  -- ── 3. Assemble the message list ──────────────────────────────────────
  -- Read the current history from the IORef.
  history <- readIORef historyRef

  -- The message list Ollama receives:
  --   system prompt (fresh retrieval context)
  --   past (user, assistant) pairs — bounded by maxHistoryTurns
  --   current user message
  let systemMsg = Message { msgRole = "system", msgContent = systemPrompt }
      userMsg   = Message { msgRole = "user",   msgContent = userText     }
      messages  = systemMsg : history ++ [userMsg]

  -- ── 4. Stream the response ────────────────────────────────────────────
  putStr "\nAssistant: "
  hFlush stdout

  -- Collect the full response while streaming it.
  -- IORef accumulates tokens as they arrive; after the stream completes
  -- we read the full text to store in history.
  responseRef <- newIORef T.empty

  -- The callback appends each token to the IORef AND prints it.
  -- This demonstrates composing IO actions: we do two things per token
  -- by sequencing them with `>>` (then, discarding the left result).
  chatStream ollama messages $ \tok -> do
    modifyIORef' responseRef (<> tok)
    TIO.putStr tok
    hFlush stdout

  putStrLn ""  -- newline after streamed response

  -- ── 5. Update conversation history ───────────────────────────────────
  fullResponse <- readIORef responseRef
  let assistantMsg = Message { msgRole = "assistant", msgContent = fullResponse }

  -- Append user and assistant messages, then trim to the sliding window.
  -- `modifyIORef'` is the strict (non-lazy) variant — it evaluates the new
  -- value immediately, preventing memory leaks from accumulated thunks.
  modifyIORef' historyRef $ \hist ->
    trimHistory (hist ++ [userMsg, assistantMsg])

-- | Keep at most `maxHistoryTurns * 2` messages (user + assistant pairs).
--   Drop from the front (oldest messages) when the limit is exceeded.
--
--   Pure function: [Message] -> [Message]. No IO.
trimHistory :: [Message] -> [Message]
trimHistory msgs =
  let maxMsgs = maxHistoryTurns * 2
  in  if length msgs > maxMsgs
        then drop (length msgs - maxMsgs) msgs
        else msgs
