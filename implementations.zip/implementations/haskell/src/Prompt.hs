module Prompt
  ( buildPrompt
  , buildChatPrompt
  ) where

{- Prompt.hs — Pure prompt construction. No IO, no side effects.

   The entire module is free of IO. Every function here has a type like:

       buildPrompt :: [ChunkResult] -> Text

   This guarantees: given retrieved chunks, produce a system prompt string.
   Same input, same output, every time. No network calls, no file reads,
   no mutable state — the compiler enforces this by rejecting any IO action
   in a non-IO function.

   Why does purity matter for prompts specifically?
   Prompts are the most important input to the LLM. If prompt construction had
   hidden side effects — reading a config file mid-build, logging to a database,
   checking a flag — those effects would be invisible at the call site and hard
   to debug. Pure functions are self-documenting: the type signature tells you
   exactly what goes in and what comes out.

   Anti-hallucination rules:
   The system prompt explicitly constrains the model to the provided context.
   Without these rules, small models tend to "fill in" gaps with plausible-
   sounding but invented facts. The numbered rules make the constraints explicit
   and easy to audit.
-}

import VectorSearch (ChunkResult(..))
import Data.List (intercalate)
import Data.Text (Text)
import qualified Data.Text as T

-- | Build a system prompt for a single-turn RAG query.
--
--   The prompt contains:
--   1. A role statement ("You are a helpful assistant…")
--   2. Numbered anti-hallucination rules
--   3. Numbered context blocks, one per retrieved chunk
--
--   Why numbered blocks?
--   Numbered citations let the LLM reference specific sources ("According to
--   context [2]…") and let the user verify the answer against the original.
--   This is especially important for factual queries where accuracy matters.
buildPrompt :: [ChunkResult] -> Text
buildPrompt chunks =
  T.unlines $
    [ "You are a helpful assistant. Answer the user's question using ONLY"
    , "the information in the context passages below."
    , ""
    , "RULES:"
    , "1. Base your answer exclusively on the provided context."
    , "   Do not use outside knowledge."
    , "2. If the context does not contain enough information to answer,"
    , "   say: \"I don't have enough information in the provided documents"
    , "   to answer that.\""
    , "3. Do not invent facts, dates, names, or figures not in the context."
    , "4. When quoting or paraphrasing, mention the source document so the"
    , "   user can verify."
    , "5. Be concise. Prefer short, direct answers over long preamble."
    , ""
    , "CONTEXT:"
    , separator
    ] ++
    concatMap formatChunk (zip [1..] chunks) ++
    [ separator ]

  where
    separator :: Text
    separator = T.replicate 57 "-"

    -- | Format one chunk as a numbered context block.
    --   Pure pattern matching: the fields `source` and `content` are accessed
    --   by name from the ChunkResult record. The compiler verifies these field
    --   names exist at compile time — no runtime KeyError.
    formatChunk :: (Int, ChunkResult) -> [Text]
    formatChunk (i, cr) =
      [ "[" <> T.pack (show i) <> "] Source: " <> source cr
      , content cr
      , separator
      ]

-- | Build a system prompt for a chatbot turn with conversation context.
--
--   This variant adds a note about maintaining conversational continuity,
--   which is important when the user asks follow-up questions that refer
--   to earlier turns ("what about the second option?" etc.).
--
--   If no chunks were retrieved, we return a graceful fallback prompt rather
--   than crashing. This is the Haskell idiom for "total functions": handle
--   ALL possible inputs, not just the happy path. The `[]` pattern here is
--   checked exhaustively by the compiler.
buildChatPrompt :: [ChunkResult] -> Text
buildChatPrompt [] =
  T.unlines
    [ "You are a helpful assistant in an ongoing conversation."
    , "No specific context was found in the document store for this question."
    , "Answer based on your general knowledge, but be clear when you are uncertain."
    ]

buildChatPrompt chunks =
  T.unlines $
    [ "You are a helpful assistant in an ongoing conversation."
    , "Answer the user's question using the context passages below."
    , ""
    , "RULES:"
    , "1. Base your answer on the provided context. Do not invent facts."
    , "2. If the context does not answer the question, say so honestly."
    , "3. Maintain conversational continuity — refer to earlier turns when relevant."
    , "4. Be concise and direct."
    , ""
    , "CONTEXT:"
    , separator
    ] ++
    concatMap formatChunk (zip [1..] chunks) ++
    [ separator ]

  where
    separator :: Text
    separator = T.replicate 57 "-"

    formatChunk :: (Int, ChunkResult) -> [Text]
    formatChunk (i, cr) =
      [ "[" <> T.pack (show i) <> "] Source: " <> source cr
      , content cr
      , separator
      ]
