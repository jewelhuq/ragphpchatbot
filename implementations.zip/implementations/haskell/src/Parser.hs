module Parser
  ( parseDocument
  ) where

{- Parser.hs — Extract text from document files.

   The type signature tells the whole story:

       parseDocument :: FilePath -> IO Text

   `FilePath` is just a type alias for `String` in Haskell, representing a
   file system path. The `IO Text` return means: this function reads from the
   file system (a side effect) and produces Text.

   Because it returns `IO Text` rather than `Text`, the Haskell compiler
   guarantees you cannot call `parseDocument` from pure code and quietly ignore
   the IO dependency. This is enforced at compile time — no runtime surprise
   where "pure" code secretly reads files.

   Current implementations:
   - .txt  — full implementation via readFile
   - .pdf  — stub (returns informative placeholder)
   - .docx — stub (returns informative placeholder)
   - other — stub with extension name

   Stubs return descriptive text rather than errors so the ingestor can still
   process mixed document directories without crashing on unsupported formats.
   When you add a real PDF library (e.g. pdf-toolbox or hpdf), you replace the
   stub body — the type signature and call site stay the same.
-}

import Data.Char (toLower)
import Data.List (isSuffixOf)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import System.FilePath (takeExtension)

-- | Extract text content from a file at the given path.
--
--   Dispatches on file extension (case-insensitive) to the appropriate parser.
--   Unsupported formats return a stub string rather than throwing an exception,
--   so a directory walk over mixed content doesn't abort mid-ingest.
parseDocument :: FilePath -> IO Text
parseDocument path =
  case map toLower (takeExtension path) of
    ".txt"  -> parseTxt path
    ".md"   -> parseTxt path    -- Markdown is valid UTF-8 text too
    ".pdf"  -> parsePdf path
    ".docx" -> parseDocx path
    ext     -> parseUnknown path ext

-- ── .txt / .md ────────────────────────────────────────────────────────────────

{- parseTxt is the only fully-implemented parser.

   `TIO.readFile` reads the file as UTF-8 Text (Data.Text.IO).
   Using Text rather than String matters for performance:
   - String is a linked list of Char (pointer-per-character, cache-hostile).
   - Text is a packed UTF-16 array (compact, cache-friendly for NLP workloads).

   The `IO Text` return type means this function is in the IO monad.
   Any function that calls parseTxt must also be in IO — the effect propagates
   upward through the call stack, making the dependency visible everywhere.
-}
parseTxt :: FilePath -> IO Text
parseTxt path = TIO.readFile path

-- ── PDF stub ──────────────────────────────────────────────────────────────────

{- parsePdf is a stub.

   To implement this properly, add one of:
     - pdf-toolbox (hackage.haskell.org/package/pdf-toolbox)
     - pypdftotext via System.Process (call the pdftotext CLI)

   The stub returns a descriptive placeholder so ingestion can continue.
   Pattern matching on the return value in the ingestor would let you log
   that a file was skipped rather than silently producing empty chunks.
-}
parsePdf :: FilePath -> IO Text
parsePdf path = do
  return $ T.pack $
    "[PDF parser not yet implemented]\n" ++
    "File: " ++ path ++ "\n\n" ++
    "To add PDF support, install the pdf-toolbox Haskell package " ++
    "or shell out to pdftotext via System.Process.\n" ++
    "The type signature `parseDocument :: FilePath -> IO Text` stays the same; " ++
    "only this function body changes."

-- ── DOCX stub ────────────────────────────────────────────────────────────────

{- parseDocx is a stub.

   DOCX files are ZIP archives containing XML. A full implementation would use:
     - zip (hackage.haskell.org/package/zip) to extract word/document.xml
     - xml-conduit or hxt to parse the XML and extract text runs

   Until then, the stub returns a placeholder that the chunker will produce
   a single short chunk for — which will be filtered out as below-minimum-length.
-}
parseDocx :: FilePath -> IO Text
parseDocx path = do
  return $ T.pack $
    "[DOCX parser not yet implemented]\n" ++
    "File: " ++ path ++ "\n\n" ++
    "To add DOCX support, use the `zip` package to read word/document.xml " ++
    "and xml-conduit to extract text nodes.\n" ++
    "The call site in Ingest.hs needs no changes — only this stub body."

-- ── Unknown extension ─────────────────────────────────────────────────────────

parseUnknown :: FilePath -> String -> IO Text
parseUnknown path ext = do
  return $ T.pack $
    "[Unsupported file format: " ++ ext ++ "]\n" ++
    "File: " ++ path ++ "\n\n" ++
    "Add a new pattern match in Parser.hs to handle '" ++ ext ++ "' files."
