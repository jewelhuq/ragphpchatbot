module Chunker
  ( chunk
  ) where

{- Chunker.hs — Pure text chunking. No IO, no side effects, no surprises.

   This module is the clearest demonstration of Haskell's purity guarantee:
   the entire module is free of IO. The type of `chunk` is:

       chunk :: Text -> Text -> Int -> [Text]

   This signature says: given a source name, document text, and chunk size,
   produce a list of text chunks. The compiler guarantees there are no hidden
   file reads, no network calls, no database writes, nothing — just a function
   from inputs to outputs.

   Why chunking?
   An embedding model maps an entire text to a single point in vector space.
   If that text is 50 pages long, the point averages across thousands of topics
   and becomes meaningless for retrieval — every query lands "near" it because
   it contains something about everything. Short, topically coherent chunks
   produce embeddings that genuinely represent their content.

   Chunking strategy:
   1. Split on double newlines (paragraph boundaries in plain text).
   2. Accumulate paragraphs until we'd exceed chunkSize characters.
   3. When a paragraph looks like a section heading (ALL CAPS, < 120 chars),
      remember it and prefix subsequent chunks with "Section: {heading}".
   4. Prefix every chunk with "Source: {filename}" for citation provenance.
   5. Discard chunks shorter than 100 characters — they're almost always
      stray page numbers, whitespace artefacts, or single-word headers that
      would pollute the vector index.

   Pure functions are safer because:
   - Same input always gives same output (referential transparency).
   - No race conditions — pure functions can run concurrently trivially.
   - Trivially testable: no mocks, no setup, just call the function.
   - The compiler checks exhaustiveness of pattern matches at compile time.
-}

import Data.Char (isUpper, isLower, isAlpha)
import Data.List (intercalate)
import Data.Text (Text)
import qualified Data.Text as T

-- | Minimum chunk length in characters.
--   Shorter chunks are noise: page numbers, bare headers, stray whitespace.
minChunkLen :: Int
minChunkLen = 100

-- | Split a document into retrieval-ready chunks.
--
--   Parameters:
--     source    — typically the filename, e.g. "manual.txt"
--     docText   — the full document text
--     size      — target character count per chunk
--
--   Returns a list of chunks, each prefixed with source/section metadata
--   so the LLM can always cite where each piece of knowledge came from.
--
--   This function is PURE — the `Text -> Text -> Int -> [Text]` type guarantees
--   it has no side effects whatsoever. Contrast with functions that return
--   `IO [Text]`, which must perform some external action.
chunk :: Text -> Text -> Int -> [Text]
chunk source docText size =
  -- Normalise line endings: Windows uses \r\n, Unix uses \n.
  -- We treat both as \n so paragraph splitting works everywhere.
  let normalised = T.replace "\r\n" "\n" docText
      paragraphs = T.splitOn "\n\n" normalised
  in  go paragraphs [] "" size

  where
    {- `go` is a tail-recursive accumulator loop.

       Haskell does not have mutable variables, so we pass state as function
       arguments. The accumulator pattern replaces what would be a `for` loop
       with mutation in an imperative language.

       Parameters:
         paras          — remaining paragraphs to process
         acc            — completed chunks so far
         (buf, heading) — current working buffer and active section heading
         sz             — the chunk size limit
    -}
    go :: [Text] -> [Text] -> Text -> Int -> [Text]
    go [] acc buf  -- no more paragraphs: flush the last buffer
      | T.length (T.strip buf) < minChunkLen = acc
      | otherwise = acc ++ [buildChunk buf]

    -- Pattern matching: Haskell checks ALL patterns at compile time.
    -- If you add a new case and forget to handle it, the compiler warns you.
    go (para : rest) acc buf sz =
      let p = T.strip para
      in if T.null p
           then go rest acc buf sz            -- skip empty paragraphs
           else if isHeading p
             then
               -- A new heading means a new topic. Flush the current buffer
               -- and start fresh under the new heading.
               let flushed = maybeFlush buf acc
               in  goWithHeading rest flushed T.empty p sz
             else
               -- Would adding this paragraph overflow the buffer?
               if not (T.null buf) && T.length buf + T.length p + 2 > sz
                 then
                   -- Flush, then start a new buffer with this paragraph.
                   let flushed = maybeFlush buf acc
                   in  go rest flushed p sz
                 else
                   -- Append to the current buffer.
                   let newBuf = if T.null buf then p
                                else buf <> "\n\n" <> p
                   in  go rest acc newBuf sz

    -- | Variant of `go` that carries an active section heading.
    --   When a new heading appears, this restarts with the new heading.
    goWithHeading :: [Text] -> [Text] -> Text -> Text -> Int -> [Text]
    goWithHeading [] acc buf heading
      | T.length (T.strip buf) < minChunkLen = acc
      | otherwise = acc ++ [buildChunkWithHeading buf heading]

    goWithHeading (para : rest) acc buf heading sz =
      let p = T.strip para
      in if T.null p
           then goWithHeading rest acc buf heading sz
           else if isHeading p
             then
               let flushed = maybeFlushH buf acc heading
               in  goWithHeading rest flushed T.empty p sz
             else
               if not (T.null buf) && T.length buf + T.length p + 2 > sz
                 then
                   let flushed = maybeFlushH buf acc heading
                   in  goWithHeading rest flushed p heading sz
                 else
                   let newBuf = if T.null buf then p
                                else buf <> "\n\n" <> p
                   in  goWithHeading rest acc newBuf heading sz

    -- | Flush `buf` into `acc` if it is long enough; otherwise discard it.
    maybeFlush :: Text -> [Text] -> [Text]
    maybeFlush buf acc
      | T.length (T.strip buf) < minChunkLen = acc
      | otherwise = acc ++ [buildChunk buf]

    maybeFlushH :: Text -> [Text] -> Text -> [Text]
    maybeFlushH buf acc heading
      | T.length (T.strip buf) < minChunkLen = acc
      | otherwise = acc ++ [buildChunkWithHeading buf heading]

    -- | Build a chunk with just the source prefix.
    buildChunk :: Text -> Text
    buildChunk buf =
      "Source: " <> source <> "\n\n" <> T.strip buf

    -- | Build a chunk with source and section heading prefix.
    buildChunkWithHeading :: Text -> Text -> Text
    buildChunkWithHeading buf heading =
      "Source: "  <> source  <> "\n" <>
      "Section: " <> heading <> "\n\n" <>
      T.strip buf

-- | Detect section headings using a heuristic:
--   a short (< 120 chars) single-line string with 80%+ uppercase letters
--   and no terminal sentence punctuation.
--
--   This is a pure function — no IO — so it's easy to unit-test in isolation.
--   In GHCi you can just run `isHeading "INTRODUCTION"` and see `True`.
isHeading :: Text -> Bool
isHeading t =
  let s = T.unpack t
  in  and
        [ not (T.isInfixOf "\n" t)          -- must be a single line
        , T.length t < 120                  -- headings are short
        , noPunctEnd s                      -- no terminal sentence punctuation
        , highUppercaseRatio s              -- mostly uppercase letters
        ]

  where
    noPunctEnd :: String -> Bool
    noPunctEnd [] = True
    noPunctEnd s  =
      let last' = last (dropWhile (== ' ') (reverse s))
      in  last' `notElem` ['.', '?', '!', ':']

    highUppercaseRatio :: String -> Bool
    highUppercaseRatio s =
      let letters = filter isAlpha s
          uppers  = length (filter isUpper letters)
          total   = length letters
      in  total >= 3 && fromIntegral uppers / fromIntegral total >= (0.80 :: Double)
