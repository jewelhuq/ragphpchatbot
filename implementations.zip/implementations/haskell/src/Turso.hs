module Turso
  ( TursoClient(..)
  , TursoArg(..)
  , newTursoClient
  , execute
  , fetchAll
  , encodeVector
  ) where

{- Turso.hs — The bridge between Haskell and Turso's HTTP API.

   Turso exposes a /v2/pipeline endpoint that accepts a batch of SQL statements
   and executes them in a single round-trip. We wrap this in two functions:
     - execute  : fire-and-forget (INSERT, CREATE TABLE, DELETE, …)
     - fetchAll : runs a SELECT and returns rows as [Map String String]

   Why the IO monad?
   HTTP requests are side effects — they communicate with the outside world.
   Haskell's type system enforces that any function performing IO must declare
   it in its return type via `IO a`. You cannot accidentally call an HTTP
   function from pure code; the compiler will reject it. This makes the
   boundary between pure logic and impure effects explicit and auditable.

   Compare Python, where `requests.get(...)` can be called from anywhere,
   including inside a "pure" helper that you thought was just computing a value.
   In Haskell, if you see `-> IO ()` you know side effects happen; if you see
   `-> Text` you know it's pure.
-}

import Config (Config(..))
import Control.Exception (throwIO, Exception)
import Data.Aeson
  ( Value(..), encode, decode, object, (.=), (.:), (.:?)
  , FromJSON(..), ToJSON(..), withObject
  )
import qualified Data.ByteString.Lazy as BL
import qualified Data.ByteString.Lazy.Char8 as BLC
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import Network.HTTP.Client
  ( Manager, newManager, defaultManagerSettings
  , httpLbs, parseRequest, requestBody, requestHeaders
  , method, responseBody, responseStatus, RequestBody(..)
  )
import Network.HTTP.Client.TLS (tlsManagerSettings)
import Network.HTTP.Types.Status (statusCode)

-- ── Exceptions ────────────────────────────────────────────────────────────────

{- TursoError is a typed exception.

   Haskell's exception system (via Control.Exception) is similar to other
   languages, but exceptions are values with types. The `Exception` typeclass
   allows any type to be thrown and caught. We use a newtype wrapper so that
   callers can pattern-match on TursoError specifically rather than catching
   all SomeException.

   Why not return Either String a instead?
   Both approaches are idiomatic. We use IO + exceptions here because the
   calling code (main executables) would need to handle errors at the top level
   anyway, and exception propagation keeps the happy-path code clean.
-}
newtype TursoError = TursoError String deriving (Show)
instance Exception TursoError

-- ── Client ────────────────────────────────────────────────────────────────────

-- | TursoClient holds the HTTP manager and credentials needed to talk to Turso.
--   The Manager is thread-safe and reuses connections via a connection pool —
--   constructing it once and sharing it is more efficient than creating a new
--   one per request.
data TursoClient = TursoClient
  { tcBaseUrl :: String
  , tcToken   :: String
  , tcManager :: Manager
  }

-- | Construct a TursoClient from a Config value.
--   Uses TLS because Turso's endpoint is HTTPS.
--   This lives in IO because creating a Manager allocates system resources
--   (sockets, thread pools) — a genuine side effect.
newTursoClient :: Config -> IO TursoClient
newTursoClient cfg = do
  mgr <- newManager tlsManagerSettings
  return TursoClient
    { tcBaseUrl = tursoUrl cfg
    , tcToken   = tursoToken cfg
    , tcManager = mgr
    }

-- ── Wire types (JSON serialisation) ──────────────────────────────────────────

{- Haskell's aeson library uses two typeclasses for JSON:
     ToJSON   — Haskell value → JSON (serialisation)
     FromJSON — JSON → Haskell value (deserialisation)

   We implement ToJSON manually using the `object` helper and the `.=` operator,
   which produces key-value pairs. The compiler checks that every field we
   mention in `toJSON` actually exists — no typos at runtime.
-}

-- | A single bound parameter in a SQL statement.
--   Turso requires explicit type tagging because JSON numbers are ambiguous.
data TursoArg
  = TextArg Text
  | IntArg  Int
  | FloatArg Double
  | NullArg
  deriving (Show)

instance ToJSON TursoArg where
  toJSON (TextArg  v) = object ["type" .= ("text"    :: Text), "value" .= v]
  toJSON (IntArg   v) = object ["type" .= ("integer" :: Text), "value" .= v]
  toJSON (FloatArg v) = object ["type" .= ("float"   :: Text), "value" .= v]
  toJSON NullArg      = object ["type" .= ("null"    :: Text), "value" .= Null]

-- | A single SQL statement with its positional arguments.
data TursoStmt = TursoStmt
  { stmtSql  :: Text
  , stmtArgs :: [TursoArg]
  } deriving (Show)

instance ToJSON TursoStmt where
  toJSON s = object
    [ "sql"  .= stmtSql s
    , "args" .= stmtArgs s
    ]

-- | One item in the pipeline request array.
data PipelineItem = PipelineItem
  { itemType :: Text    -- always "execute"
  , itemStmt :: TursoStmt
  } deriving (Show)

instance ToJSON PipelineItem where
  toJSON i = object
    [ "type" .= itemType i
    , "stmt" .= itemStmt i
    ]

-- | The outer request body sent to /v2/pipeline.
newtype PipelineRequest = PipelineRequest { prRequests :: [PipelineItem] }

instance ToJSON PipelineRequest where
  toJSON r = object ["requests" .= prRequests r]

-- | Shape of Turso's JSON reply — we only parse what we need.
data TursoResponse = TursoResponse
  { trResults :: [TursoResult]
  } deriving (Show)

data TursoResult = TursoResult
  { rrType     :: Text
  , rrResponse :: Maybe TursoPayload
  , rrError    :: Maybe TursoResultError
  } deriving (Show)

data TursoPayload = TursoPayload
  { rpResult :: TursoTable
  } deriving (Show)

data TursoTable = TursoTable
  { ttCols :: [TursoCol]
  , ttRows :: [[TursoCell]]
  } deriving (Show)

data TursoCol = TursoCol { colName :: Text } deriving (Show)

data TursoCell = TursoCell
  { cellType  :: Text
  , cellValue :: Value   -- keep as raw Value; we coerce to Text later
  } deriving (Show)

data TursoResultError = TursoResultError
  { errMessage :: Text
  , errCode    :: Text
  } deriving (Show)

-- FromJSON instances — pattern-matched by the compiler for exhaustiveness

instance FromJSON TursoResponse where
  parseJSON = withObject "TursoResponse" $ \o ->
    TursoResponse <$> o .: "results"

instance FromJSON TursoResult where
  parseJSON = withObject "TursoResult" $ \o ->
    TursoResult
      <$> o .:  "type"
      <*> o .:? "response"
      <*> o .:? "error"

instance FromJSON TursoPayload where
  parseJSON = withObject "TursoPayload" $ \o ->
    TursoPayload <$> o .: "result"

instance FromJSON TursoTable where
  parseJSON = withObject "TursoTable" $ \o ->
    TursoTable
      <$> o .: "cols"
      <*> o .: "rows"

instance FromJSON TursoCol where
  parseJSON = withObject "TursoCol" $ \o ->
    TursoCol <$> o .: "name"

instance FromJSON TursoCell where
  parseJSON = withObject "TursoCell" $ \o ->
    TursoCell
      <$> o .: "type"
      <*> o .: "value"

instance FromJSON TursoResultError where
  parseJSON = withObject "TursoResultError" $ \o ->
    TursoResultError
      <$> o .: "message"
      <*> o .: "code"

-- ── Core transport ────────────────────────────────────────────────────────────

{- postPipeline is the single function that all public API calls funnel through.

   This is the "don't repeat yourself" principle: auth headers, URL construction,
   error checking, and JSON decoding live in exactly one place. If Turso changes
   their API, we update one function — not five call sites.

   The `do` block is Haskell's sequencing syntax for IO actions. Each line
   produces a value that the next line can use. The `<-` operator "extracts"
   the result from IO, like `await` in async/await or `>>=` in monadic style.
-}
postPipeline :: TursoClient -> [PipelineItem] -> IO TursoResponse
postPipeline client items = do
  let url      = stripSlash (tcBaseUrl client) ++ "/v2/pipeline"
      bodyJson = encode (PipelineRequest items)

  -- parseRequest builds an HTTP request value — pure, no network call yet.
  initReq <- parseRequest url

  let req = initReq
        { method         = "POST"
        , requestBody    = RequestBodyLBS bodyJson
        , requestHeaders =
            [ ("Content-Type",  "application/json")
            , ("Authorization", "Bearer " <> TE.encodeUtf8 (T.pack (tcToken client)))
            ]
        }

  -- httpLbs is where the actual network IO happens.
  -- The Manager handles connection pooling and TLS handshakes transparently.
  resp <- httpLbs req (tcManager client)

  let status = statusCode (responseStatus resp)
      body   = responseBody resp

  if status >= 400
    then throwIO $ TursoError $
           "Turso returned HTTP " ++ show status ++ ": " ++ BLC.unpack body
    else case decode body of
      Nothing  -> throwIO $ TursoError $
                    "Failed to parse Turso response JSON: " ++ BLC.unpack body
      Just tr  -> do
        -- Surface per-statement errors. A query can return HTTP 200 but still
        -- contain statement-level errors (constraint violations, bad SQL, …).
        mapM_ checkResult (zip [0..] (trResults tr))
        return tr

  where
    checkResult (i, r) = case rrError r of
      Nothing  -> return ()
      Just err -> throwIO $ TursoError $
        "Turso error in result[" ++ show i ++ "]: " ++
        T.unpack (errMessage err) ++ " (code: " ++ T.unpack (errCode err) ++ ")"

-- ── Public API ────────────────────────────────────────────────────────────────

-- | Run a single SQL statement that does not need to return rows —
--   CREATE TABLE, INSERT, DELETE, UPDATE, and so on.
--
--   The return type `IO ()` (pronounced "IO unit") is Haskell's equivalent of
--   `void` in C-family languages: we perform side effects and return nothing
--   meaningful. The IO wrapper is mandatory — you cannot call this from pure code.
execute :: TursoClient -> Text -> [TursoArg] -> IO ()
execute client sql args = do
  let item = PipelineItem
        { itemType = "execute"
        , itemStmt = TursoStmt { stmtSql = sql, stmtArgs = args }
        }
  _ <- postPipeline client [item]
  return ()

-- | Run a SELECT statement and return the result rows as a list of
--   String maps. All cell values are coerced to Strings for simplicity.
--
--   Why [Map String String] instead of typed structs?
--   The queries in this system are ad-hoc and the column sets vary. A generic
--   map lets every call site work without defining a bespoke result type,
--   keeping the codebase lean. If you wanted type-safety here, you'd use
--   aeson's generic deriving to parse rows directly into Haskell records.
fetchAll :: TursoClient -> Text -> [TursoArg] -> IO [Map String String]
fetchAll client sql args = do
  let item = PipelineItem
        { itemType = "execute"
        , itemStmt = TursoStmt { stmtSql = sql, stmtArgs = args }
        }
  tr <- postPipeline client [item]
  case trResults tr of
    []    -> return []
    (r:_) -> case rrResponse r of
      Nothing      -> return []
      Just payload -> do
        let table    = rpResult payload
            colNames = map (T.unpack . colName) (ttCols table)
        return $ map (rowToMap colNames) (ttRows table)

  where
    -- Convert a row of TursoCell values into a Map keyed by column name.
    -- cellValueToString handles all JSON value types we'd realistically see.
    rowToMap :: [String] -> [TursoCell] -> Map String String
    rowToMap cols cells =
      Map.fromList
        [ (col, cellValueToString (cellValue cell))
        | (col, cell) <- zip cols cells
        ]

    cellValueToString :: Value -> String
    cellValueToString (String t)   = T.unpack t
    cellValueToString (Number n)   = show n
    cellValueToString (Bool b)     = show b
    cellValueToString Null         = ""
    cellValueToString (Array arr)  = show arr
    cellValueToString (Object obj) = show obj

-- ── Vector encoding ───────────────────────────────────────────────────────────

-- | Convert a list of Doubles into the text representation that Turso's
--   vector32() SQL function expects: "[0.123,0.456,-0.789]"
--
--   This is a pure function — no IO, no side effects. The type `[Double] -> Text`
--   tells you everything: it maps a list of doubles to text, deterministically,
--   with no observable interaction with the outside world.
--   Pure functions are easier to test (just call them), easier to reason about
--   (same input always gives same output), and can be safely shared across threads.
encodeVector :: [Double] -> Text
encodeVector dims =
  T.pack $ "[" ++ intercalateWith "," (map showDouble dims) ++ "]"
  where
    showDouble d = show d
    intercalateWith _   []     = ""
    intercalateWith _   [x]    = x
    intercalateWith sep (x:xs) = x ++ sep ++ intercalateWith sep xs

-- ── Utilities ─────────────────────────────────────────────────────────────────

stripSlash :: String -> String
stripSlash s = reverse $ dropWhile (== '/') (reverse s)
