module Ollama
  ( OllamaClient(..)
  , Message(..)
  , newOllamaClient
  , embed
  , chatStream
  ) where

{- Ollama.hs — Embeddings and streaming chat via the Ollama HTTP API.

   Ollama exposes two endpoints we care about:
     POST /api/embeddings — returns a single float vector for a text input
     POST /api/chat       — streams an answer token-by-token as NDJSON

   Why streaming matters:
   A 1B-parameter model can take 10–30 seconds to generate a full answer.
   Streaming lets us print each token as it arrives, giving the user immediate
   feedback instead of a blank terminal for half a minute.

   The `chatStream` function accepts a callback `(Text -> IO ())` rather than
   returning all tokens at once. This "callback" pattern keeps the transport
   layer decoupled from the presentation layer — the chatbot prints to stdout,
   but a future HTTP handler could flush SSE events with the exact same call.

   Haskell's type system enforces this cleanly: the callback's type `Text -> IO ()`
   tells you it receives text and performs IO (printing, writing to a channel, etc.)
   but returns nothing. You can't accidentally pass a pure function where an IO
   callback is expected.

   Streaming implementation:
   We use http-conduit with conduit for streaming. The response body is consumed
   line by line without buffering the entire response in memory. This is important
   for long answers that could be many kilobytes of NDJSON.
-}

import Config (Config(..))
import Control.Exception (throwIO, Exception)
import Data.Aeson
  ( Value(..), encode, decode, object, (.=), (.:)
  , FromJSON(..), ToJSON(..), withObject
  )
import Data.ByteString (ByteString)
import qualified Data.ByteString as BS
import qualified Data.ByteString.Lazy as BL
import qualified Data.ByteString.Lazy.Char8 as BLC
import qualified Data.ByteString.Char8 as BSC
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import Network.HTTP.Client
  ( Manager, newManager, defaultManagerSettings
  , httpLbs, parseRequest, requestBody, requestHeaders
  , method, responseBody, responseStatus, RequestBody(..)
  , brRead, withResponse
  )
import Network.HTTP.Client.TLS (tlsManagerSettings)
import Network.HTTP.Types.Status (statusCode)
import System.IO (hPutStrLn, stderr)

-- ── Exceptions ────────────────────────────────────────────────────────────────

newtype OllamaError = OllamaError String deriving (Show)
instance Exception OllamaError

-- ── Client ────────────────────────────────────────────────────────────────────

-- | OllamaClient wraps an HTTP manager and the model names so callers don't
--   have to repeat them on every invocation.
data OllamaClient = OllamaClient
  { ocBaseUrl        :: String
  , ocChatModel      :: String
  , ocEmbeddingModel :: String
  , ocManager        :: Manager
  }

-- | Construct an OllamaClient from a Config.
--   This is in IO because creating an HTTP Manager allocates OS resources.
newOllamaClient :: Config -> IO OllamaClient
newOllamaClient cfg = do
  -- Use the plain manager for HTTP (Ollama runs locally, no TLS needed).
  mgr <- newManager defaultManagerSettings
  return OllamaClient
    { ocBaseUrl        = ollamaUrl cfg
    , ocChatModel      = chatModel cfg
    , ocEmbeddingModel = embeddingModel cfg
    , ocManager        = mgr
    }

-- ── Wire types ────────────────────────────────────────────────────────────────

{- Haskell records with derived JSON instances.

   `deriving (Show)` gives us a free Show instance for debugging.
   The ToJSON / FromJSON instances below are written manually so we control
   the exact JSON field names (matching Ollama's API contract).

   An alternative is `deriving (Generic)` + `genericToJSON defaultOptions`,
   but explicit instances are clearer when the field names differ between
   Haskell convention (camelCase) and the wire format (snake_case or other).
-}

-- | A single turn in a conversation.
--   The role must be "system", "user", or "assistant".
data Message = Message
  { msgRole    :: Text
  , msgContent :: Text
  } deriving (Show, Eq)

instance ToJSON Message where
  toJSON m = object
    [ "role"    .= msgRole m
    , "content" .= msgContent m
    ]

instance FromJSON Message where
  parseJSON = withObject "Message" $ \o ->
    Message <$> o .: "role" <*> o .: "content"

-- Internal types for serialising requests and parsing responses.

data EmbeddingRequest = EmbeddingRequest
  { erModel  :: Text
  , erPrompt :: Text
  }

instance ToJSON EmbeddingRequest where
  toJSON r = object
    [ "model"  .= erModel r
    , "prompt" .= erPrompt r
    ]

data EmbeddingResponse = EmbeddingResponse
  { erEmbedding :: [Double]
  } deriving (Show)

instance FromJSON EmbeddingResponse where
  parseJSON = withObject "EmbeddingResponse" $ \o ->
    EmbeddingResponse <$> o .: "embedding"

data ChatRequest = ChatRequest
  { crModel    :: Text
  , crMessages :: [Message]
  , crStream   :: Bool
  }

instance ToJSON ChatRequest where
  toJSON r = object
    [ "model"    .= crModel r
    , "messages" .= crMessages r
    , "stream"   .= crStream r
    ]

-- | One line from the NDJSON stream Ollama emits during generation.
--   When crDone is True, generation is complete.
data ChatChunk = ChatChunk
  { ccMessage :: Message
  , ccDone    :: Bool
  } deriving (Show)

instance FromJSON ChatChunk where
  parseJSON = withObject "ChatChunk" $ \o ->
    ChatChunk
      <$> o .: "message"
      <*> o .: "done"

-- ── Embedding ─────────────────────────────────────────────────────────────────

-- | Convert text into a vector suitable for similarity search.
--
--   Under the hood, nomic-embed-text maps the semantic meaning of the text into
--   a 768-dimensional space where similar passages land near each other.
--
--   Return type: `IO [Double]`
--   The IO wrapper is mandatory — network calls are side effects. You cannot
--   call `embed` from pure code; the compiler will reject it. This is Haskell's
--   safety guarantee: the type signature is an honest contract.
embed :: OllamaClient -> Text -> IO [Double]
embed client txt = do
  let reqBody = EmbeddingRequest
        { erModel  = T.pack (ocEmbeddingModel client)
        , erPrompt = txt
        }
      url = stripSlash (ocBaseUrl client) ++ "/api/embeddings"

  initReq <- parseRequest url
  let req = initReq
        { method         = "POST"
        , requestBody    = RequestBodyLBS (encode reqBody)
        , requestHeaders = [("Content-Type", "application/json")]
        }

  resp <- httpLbs req (ocManager client)
  let status = statusCode (responseStatus resp)
      body   = responseBody resp

  if status >= 400
    then throwIO $ OllamaError $
           "Ollama /api/embeddings returned HTTP " ++ show status ++
           ": " ++ BLC.unpack body
    else case decode body of
      Nothing -> throwIO $ OllamaError $
                   "Failed to parse Ollama embedding response: " ++ BLC.unpack body
      Just er ->
        if null (erEmbedding er)
          then throwIO $ OllamaError $
                 "Ollama returned an empty embedding — is the model loaded?"
          else return (erEmbedding er)

-- ── Chat streaming ────────────────────────────────────────────────────────────

-- | Send a multi-turn conversation to Ollama and call `onToken` for every
--   token the model generates. Blocks until the model signals Done=True.
--
--   The callback type `(Text -> IO ())` is the key design decision:
--   - It's generic: the caller decides what to do with each token.
--   - It's honest: the IO in the callback type tells you that printing,
--     writing to a buffer, etc. will happen.
--   - It composes: you can wrap the callback to add logging, filtering, etc.
--
--   We stream by reading the response body in chunks, splitting on newlines,
--   and parsing each line as a JSON ChatChunk. This avoids loading the entire
--   response into memory.
chatStream :: OllamaClient -> [Message] -> (Text -> IO ()) -> IO ()
chatStream client messages onToken = do
  let reqBody = ChatRequest
        { crModel    = T.pack (ocChatModel client)
        , crMessages = messages
        , crStream   = True
        }
      url = stripSlash (ocBaseUrl client) ++ "/api/chat"

  initReq <- parseRequest url
  let req = initReq
        { method         = "POST"
        , requestBody    = RequestBodyLBS (encode reqBody)
        , requestHeaders = [("Content-Type", "application/json")]
        }

  -- Open the response without consuming the body yet.
  -- withResponse ensures the connection is closed even if an exception is thrown.
  withResponse req (ocManager client) $ \resp -> do
    let status = statusCode (responseStatus resp)
    if status >= 400
      then do
        -- Read error body for a useful message.
        errBody <- brRead (responseBody resp)
        throwIO $ OllamaError $
          "Ollama /api/chat returned HTTP " ++ show status ++
          ": " ++ BSC.unpack errBody
      else
        -- Stream the response body line by line.
        -- `go` is a local recursive loop — no mutation, no mutable state.
        -- `buf` accumulates bytes until we see a newline.
        go (responseBody resp) BS.empty

  where
    -- | Recursive streaming loop.
    --   `brRead` reads the next available chunk from the HTTP response body.
    --   When it returns an empty ByteString, the response is complete.
    go bodyReader buf = do
      chunk <- brRead bodyReader
      if BS.null chunk
        then processLines buf  -- flush any remaining data
        else do
          let combined = buf <> chunk
              -- Split on newlines to get complete NDJSON lines.
              (completeLines, remainder) = splitLines combined
          mapM_ parseLine completeLines
          go bodyReader remainder

    -- | Split a ByteString into complete lines and a (possibly incomplete) tail.
    splitLines bs =
      let allLines = BSC.split '\n' bs
      in  (init allLines, last allLines)

    -- | Process any leftover bytes after the stream ends.
    processLines bs
      | BS.null bs = return ()
      | otherwise  = parseLine bs

    -- | Parse one NDJSON line and call onToken if it contains a content token.
    parseLine lineBytes
      | BS.null (BSC.dropWhile (== ' ') lineBytes) = return ()
      | otherwise =
          case decode (BL.fromStrict lineBytes) of
            Nothing    ->
              -- Non-fatal: log and continue. A malformed line shouldn't abort
              -- the entire conversation.
              hPutStrLn stderr $
                "[ollama] warning: skipping malformed NDJSON line: " ++
                BSC.unpack lineBytes
            Just chunk ->
              if ccDone chunk
                then return ()  -- generation complete
                else do
                  let tok = msgContent (ccMessage chunk)
                  if T.null tok
                    then return ()
                    else onToken tok

-- ── Utilities ─────────────────────────────────────────────────────────────────

stripSlash :: String -> String
stripSlash = reverse . dropWhile (== '/') . reverse
