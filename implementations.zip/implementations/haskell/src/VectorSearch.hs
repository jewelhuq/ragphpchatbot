module VectorSearch
  ( ChunkResult(..)
  , search
  ) where

{- VectorSearch.hs — Embed a query and retrieve the most relevant chunks.

   This module is the "hot path" of the RAG system: every user question passes
   through here before the LLM sees it.

   Pipeline:
   1. Embed the query text with Ollama → a 768-dimensional float vector.
   2. Send that vector to Turso's `vector_top_k` function → nearest-neighbour IDs.
   3. JOIN the IDs back to the `chunks` table → content + metadata.
   4. Return typed ChunkResult values.

   Why typed results?
   `fetchAll` returns `[Map String String]`, which is generic but stringly typed.
   By converting to `ChunkResult` here, we give the rest of the system a clear
   contract: a chunk has a source (Text), content (Text), and similarity score
   (Double). The compiler will catch field-name typos and type mismatches that
   would be silent bugs in a dynamically typed language.

   The latency of `search` is dominated by:
   - Ollama embed call:  ~50–200ms on CPU
   - Turso HTTP call:    ~50–150ms for a warm ANN index
   Total: typically 100–350ms per query.
-}

import Config (Config(..))
import Ollama (OllamaClient, embed)
import Turso (TursoClient, fetchAll, encodeVector, TursoArg(..))

import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe (fromMaybe)
import Data.Text (Text)
import qualified Data.Text as T

-- | A retrieved chunk together with its similarity score.
--
--   This is a pure data type — no IO, no behaviour, just structure.
--   In Haskell, data types and functions that operate on them are kept
--   separate (unlike OOP where they'd be bundled in a class). This makes
--   `ChunkResult` easy to use anywhere: pass it to a prompt builder,
--   serialize it to JSON, print it — all without any coupling to the
--   retrieval logic that produced it.
data ChunkResult = ChunkResult
  { source   :: Text    -- ^ Filename the chunk came from (e.g. "manual.txt")
  , content  :: Text    -- ^ The raw text shown to the LLM
  , score    :: Double  -- ^ Cosine distance — lower means more similar
  } deriving (Show, Eq)

-- | Embed `queryText` with Ollama and return the top-k most similar chunks
--   from the Turso vector index.
--
--   Return type: `IO [ChunkResult]`
--   The IO is necessary because this function makes two HTTP calls (Ollama
--   and Turso). The type signature advertises this honestly — no hidden
--   network calls in a "pure" function.
search :: TursoClient -> OllamaClient -> Text -> Int -> IO [ChunkResult]
search turso ollama queryText k = do

  -- Step 1: embed the query.
  -- `embed` returns IO [Double]. The `<-` operator "extracts" the [Double]
  -- from IO, binding it to `vec`. This is monadic sequencing: embed must
  -- complete before we can use the vector.
  vec <- embed ollama queryText

  -- Step 2: encode the vector as Turso's text format "[f1,f2,…,fn]".
  -- `encodeVector` is a pure function — no IO — so we use `let` not `<-`.
  let vecText = encodeVector vec

  -- Step 3: run the ANN search.
  -- vector_top_k returns (id, distance) pairs sorted by ascending distance.
  -- We JOIN back to chunks to get content and metadata in one round-trip.
  let searchSQL = T.unlines
        [ "SELECT c.source, c.content, v.distance AS score"
        , "FROM vector_top_k('chunks_vector_idx', vector32(?), ?) v"
        , "JOIN chunks c ON c.id = v.id"
        , "ORDER BY v.distance ASC"
        ]

  rows <- fetchAll turso searchSQL [TextArg vecText, IntArg k]

  -- Step 4: convert raw map rows into typed ChunkResult values.
  -- `mapM` is the monadic equivalent of `map` — it applies a function
  -- that returns IO to each element and sequences the IO actions.
  -- Here, `rowToResult` is pure so we use the simpler `map`.
  return $ map rowToResult rows

-- | Convert a `Map String String` row into a `ChunkResult`.
--
--   This is a pure function — it takes data and returns data, with no
--   interaction with the outside world. We use `fromMaybe` to provide
--   safe defaults rather than crashing on missing keys. The alternative
--   `Map.lookup` returns `Maybe String`, which forces us to handle the
--   absent-key case explicitly — the compiler won't let us ignore it.
rowToResult :: Map String String -> ChunkResult
rowToResult row = ChunkResult
  { source  = T.pack $ fromMaybe "" (Map.lookup "source"  row)
  , content = T.pack $ fromMaybe "" (Map.lookup "content" row)
  , score   = maybe 1.0 parseDouble (Map.lookup "score" row)
  }
  where
    -- `reads` returns a list of (parsed, remainder) pairs.
    -- Pattern matching on the list is Haskell's idiomatic safe parse:
    -- [(v, _)] succeeds with value v; anything else falls through to the default.
    parseDouble s = case reads s of
      [(v, _)] -> v
      _        -> 1.0
