﻿module Config
  ( Config(..)
  , defaultConfig
  ) where

{- Config.hs — The single source of truth for every knob in the RAG system.

   In Haskell, configuration is a pure value — a record with no hidden state,
   no mutable globals, and no implicit environment. When a function needs the
   configuration it receives it as an explicit argument. This makes the
   dependency crystal-clear in every type signature and makes testing trivial:
   swap one field, pass the modified Config, done.

   Compare this to Python's os.environ lookups scattered across modules, or
   Go's package-level vars. Here the compiler tracks every Config use. If you
   remove a field, every function that reads it fails to compile — no silent
   runtime surprises.

   The `deriving (Show, Eq)` at the bottom is Haskell's zero-boilerplate
   serialisation: the compiler generates a Show instance (human-readable
   printing) and Eq instance (equality comparison) automatically from the
   field types. In a language without deriving, you'd write this by hand.
-}

-- | Config holds every tunable parameter the RAG system needs.
--   Fields are grouped by concern: storage, inference, retrieval, ingestion.
--
--   All fields are strict (the bang patterns would normally be written here,
--   but for a configuration record read once at startup, laziness is fine and
--   the code stays readable).
data Config = Config
  { -- | Full base URL of the Turso database HTTP API.
    --   e.g. "https://my-db-myorg.aws-us-east-1.turso.io"
    tursoUrl        :: String

    -- | Bearer token used to authenticate with Turso. Never log this value.
  , tursoToken      :: String

    -- | Base URL of the local Ollama server.
    --   Typically "http://127.0.0.1:11434".
  , ollamaUrl       :: String

    -- | Ollama model name used for answer generation, e.g. "gemma3:1b".
    --   Kept small so it runs on modest hardware without a GPU.
  , chatModel       :: String

    -- | Ollama model name used to produce vector embeddings.
    --   Must produce embeddingDims dimensions — mismatches silently corrupt
    --   similarity scores, so the two values must always agree.
  , embeddingModel  :: String

    -- | Number of dimensions the embedding model outputs.
    --   For nomic-embed-text this is 768. The Turso column type F32_BLOB(768)
    --   must match this value exactly.
  , embeddingDims   :: Int

    -- | How many nearest-neighbour chunks to retrieve per query.
    --   Higher values give the LLM more context but inflate the prompt size.
  , topK            :: Int

    -- | Directory the ingestor scans for documents.
    --   Subdirectories are walked recursively.
  , docsDir         :: String

    -- | Target character count for each text chunk.
    --   Chunks shorter than 100 characters are discarded as noise.
  , chunkSize       :: Int
  } deriving (Show, Eq)

{- defaultConfig — Pre-filled sensible defaults.

   Why a function rather than a top-level value?
   In Haskell, top-level values are computed once and shared (they're
   Haskell's equivalent of constants). A function `defaultConfig :: Config`
   (with no arguments) is semantically identical here, but the function form
   makes it obvious to readers that this is a "factory" you can call.

   Note that tursoToken is left empty intentionally. Tokens are secrets;
   hardcoding them — even in a "defaults" file — is a security smell. The
   real token should come from an environment variable or a config file that
   lives outside version control. The empty string will cause a helpful error
   at runtime rather than silently using a wrong token.
-}
defaultConfig :: Config
defaultConfig = Config
  { tursoUrl       = "https://your-db-name.turso.io"
  , tursoToken     = ""                   -- must be set via env or config file
  , ollamaUrl      = "http://127.0.0.1:11434"
  , chatModel      = "gemma3:1b"
  , embeddingModel = "nomic-embed-text"
  , embeddingDims  = 768
  , topK           = 5
  , docsDir        = "./docs"
  , chunkSize      = 1000
  }
