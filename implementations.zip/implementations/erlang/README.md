﻿# RAG -- Retrieval-Augmented Generation in Erlang

A complete RAG system that connects a Turso vector database to a locally-running
Ollama instance.  Documents are chunked, embedded, and stored; at query time the
most relevant chunks are retrieved and fed to an LLM whose answer streams live to
your terminal.

What makes this implementation interesting is not the RAG logic (which is identical
to the Python and Rust versions) -- it is **how Erlang approaches failure**.

---

## The "Let It Crash" Philosophy

Every other implementation in this repository uses defensive programming:

- **Python**: `try/except` everywhere
- **Rust**: `Result<T, E>` propagated explicitly with `?`
- **Java**: checked exceptions
- **C/C++**: error codes and NULL checks

Erlang does something radically different.  It does not try to prevent crashes.
**It embraces them.**

### Process Isolation

In Erlang, every concurrent task runs in its own **process** -- a tiny, isolated
unit of execution with its own heap, its own mailbox, and its own call stack.
Erlang processes are not OS threads.  They are scheduled by the BEAM virtual machine,
take about 300 bytes of memory to create, and can be spawned in nanoseconds.

```erlang
%% Spawn a process for each file -- if one crashes, the others continue.
{Pid, Ref} = spawn_monitor(fun() ->
    ingest_file_process(FilePath, Config)
end).
```

If `ingest_file_process` crashes -- corrupt file, network error, OOM, anything --
**only that process dies**.  The process that spawned it receives a `'DOWN'` message
and decides what to do:

```erlang
receive
    {'DOWN', Ref, process, _, normal}  -> ok;           % success
    {'DOWN', Ref, process, _, skipped} -> skip;         % intentional early exit
    {'DOWN', Ref, process, _, Reason}  ->               % crash
        io:format("File crashed: ~p~n", [Reason])
        %% move on to the next file
end
```

No try/catch.  No defensive code inside `ingest_file_process`.  The isolation is
the safety mechanism.

### No Shared Memory = No Data Races. Ever.

Erlang processes do not share memory.  When one process sends a message to another,
the data is **copied**.  This is not a performance compromise -- it is the design.

- No mutexes.  No deadlocks.  No race conditions.
- No `synchronized` blocks, no `Arc<Mutex<T>>`, no GIL.
- The compiler enforces this at the language level: there is no syntax for
  sharing a pointer between processes.

### Supervisors

OTP (Open Telecom Platform) extends "let it crash" into a structured pattern:
**supervisor trees**.

```
rag_supervisor (one_for_one)
     |
     +-- chatbot_worker (transient -- restart only on crash)
```

A `supervisor` behaviour monitors its children.  If a child crashes, the supervisor
restarts it automatically according to its strategy:

- `one_for_one` -- restart only the crashed child
- `one_for_all` -- restart all children when one crashes (for interdependent processes)
- `rest_for_one` -- restart the crashed child and all children started after it

The chatbot uses this to provide resilient conversation turns:

```erlang
%% Each conversation turn runs in a monitored worker process.
{_WorkerPid, MonRef} = spawn_monitor(fun() ->
    rag_worker_body(Question, History, Self, Config)
end),

receive
    {rag_done, _Pid, Response} ->
        demonitor(MonRef, [flush]),
        {ok, Response};

    {'DOWN', MonRef, process, _, Reason} ->
        io:format("Turn crashed: ~p~nRetrying...~n", [Reason]),
        handle_rag_turn(Question, History, Config, Chunks, RetriesLeft - 1)
end
```

If the RAG pipeline crashes mid-turn -- Ollama times out, a JSON parse fails,
the network drops -- the user sees "Retrying..." and the turn is attempted again
from scratch.  The conversation history (stored in the UI loop process, not the
worker) is preserved.

---

## How This Differs from Rust and Ada Safety

| Language | Safety Mechanism | Failure Mode |
|----------|-----------------|--------------|
| **Rust** | Ownership + borrow checker | Compiler refuses unsafe code; no runtime crashes for memory bugs |
| **Ada** | Design-by-contract, strong typing | Runtime `Constraint_Error`; contracts proven at compile time |
| **Erlang** | Process isolation + supervisors | Processes crash freely; supervisors restart them |

Rust and Ada prevent failures by making them impossible at compile time.
Erlang permits failures and makes them **recoverable** at runtime.

Neither approach is strictly better.  Rust is ideal for systems where a single
crash is unacceptable (embedded firmware, OS kernels, cryptographic code).
Erlang is ideal for systems that must remain available in the face of unpredictable
failures at scale (messaging infrastructure, phone switches, web services).

The WhatsApp case study:
- 2 billion users, 9 engineers, 99.9% uptime.
- Each user session is an Erlang process (or a cluster of them).
- Supervisor trees restart failed sessions automatically.
- The system degrades gracefully: one user's bug does not affect others.

---

## Supervisor Tree (Visual)

```
application: rag
     |
     +-- rag_supervisor  (supervisor, one_for_one)
              |
              +-- chatbot_worker  (worker, transient)
                       |
                       +-- [spawns per-turn RAG processes]
                                |
                                +-- ollama_client (HTTP streaming)
                                +-- turso_client  (HTTP pipeline)
```

During ingestion, a flat pool of worker processes handles files:

```
ingest:main/1  (main escript process)
     |
     +-- spawn_monitor -> ingest_file_process (file_1.txt)
     +-- spawn_monitor -> ingest_file_process (file_2.txt)
     +-- spawn_monitor -> ingest_file_process (file_3.txt)
     |       ...
     +-- collect_results (waits for 'DOWN' messages from all workers)
```

---

## Architecture

```
docs/          -->  rag_ingest  -->  Turso (chunks + embeddings)
                                         |
user question  -->  rag_query   -->  vector_top_k  -->  ranked chunks
                                         |
               -->  rag_rag     -->  prompt builder  -->  Ollama (streaming)
                                         |
               -->  rag_chatbot -->  supervised loop with history
```

---

## Prerequisites

- **Erlang/OTP 25+** -- `erl -version` to check.
  Install via [erlang.org](https://erlang.org/downloads) or `brew install erlang`.
- **rebar3** -- `rebar3 --version` to check.
  Install from [rebar3.org](https://rebar3.org).
- **Ollama** running locally on `http://127.0.0.1:11434`

```bash
ollama serve
ollama pull nomic-embed-text
ollama pull gemma3:1b
```

- A **Turso** database URL and Bearer token.

---

## Configuration

All settings live in `src/rag_config.erl`'s `default_config/0` function.
The most important ones:

| Key | Default | Description |
|-----|---------|-------------|
| `turso_url` | `https://your-db-name.turso.io` | Turso HTTP endpoint |
| `turso_token` | `YOUR_TURSO_TOKEN_HERE` | Bearer token -- **change this** |
| `ollama_url` | `http://127.0.0.1:11434` | Ollama base URL |
| `chat_model` | `gemma3:1b` | Model for answer generation |
| `embedding_model` | `nomic-embed-text` | Model for embeddings |
| `embedding_dims` | `768` | Must match the embedding model |
| `top_k` | `5` | Chunks to retrieve per query |
| `docs_dir` | `docs` | Directory scanned by ingest |
| `chunk_size` | `512` | Max characters per chunk |

Edit `src/rag_config.erl` before building.

---

## Build

```bash
# Compile and build all four escripts
make build

# Or use rebar3 directly for a specific escript:
rebar3 as ingest     escriptize   # builds rag_ingest
rebar3 as query_tool escriptize   # builds rag_query
rebar3 as rag_tool   escriptize   # builds rag_rag
rebar3 as chatbot    escriptize   # builds rag_chatbot
```

The escripts are placed in `_build/<profile>/bin/` and copied to the current
directory by `make build`.

---

## Usage

### 1. Ingest documents

Place `.txt` or `.md` files in the `docs/` directory, then run:

```bash
./rag_ingest
# or: make ingest
```

The ingest binary:
- Creates the `rag_files`, `rag_chunks` tables and vector index if they do not exist.
- Skips files whose MD5 hash has not changed since the last run.
- Processes each file in its own isolated Erlang process -- if one file fails,
  the others continue unaffected.

```
============================================================
RAG Ingestion Pipeline (Erlang)
============================================================
Docs directory : docs
Turso URL      : https://your-db-name.turso.io
Embed model    : nomic-embed-text
Chunk size     : 512 chars

Ensuring database schema ...
Schema ready.
Found 3 document(s) to process

  [new] introduction.txt -- ingesting for the first time ...
  Parsed 8432 characters
  Split into 17 chunks
  Embedded 10/17 chunks ...
  Embedded 17/17 chunks ...
  Done: inserted 17 chunks for introduction.txt

  [skip] policies.txt -- unchanged (MD5 matches)

============================================================
Ingestion complete in 23.4s
  Succeeded: 2   Failed: 0
============================================================
```

### 2. Query the knowledge base (debugging)

```bash
./rag_query "What is the refund policy?"
# or: make query
```

Prints the top-K most relevant chunks with similarity scores, so you can verify
retrieval quality before blaming the LLM.

### 3. Ask a single question

```bash
./rag_rag "Summarise the safety guidelines"
# or: make rag
```

Retrieves context, builds a prompt, and streams the model's answer to stdout.

### 4. Start the interactive chatbot

```bash
./rag_chatbot
# or: make chatbot
```

Opens a conversational loop.  The last 10 turns of history are retained.
Each turn runs in a supervised worker process -- if the RAG pipeline crashes,
the supervisor retries the turn automatically (up to 3 times per question).

---

## File Layout

```
src/
  rag_config.erl      -- Configuration map (all tunable parameters)
  turso_client.erl    -- HTTP client for the Turso /v2/pipeline API
  ollama_client.erl   -- Embedding and streaming-chat client for Ollama
  chunker.erl         -- Pure paragraph-based text splitter with heading detection
  parser.erl          -- File reader (.txt/.md supported)
  ingest.erl          -- Scans docs/, spawns per-file processes, embeds, stores
  query.erl           -- Embeds a query and prints the top-K results
  rag.erl             -- Full RAG pipeline: retrieve + prompt + stream
  rag_supervisor.erl  -- OTP supervisor behaviour (one_for_one, chatbot worker)
  chatbot.erl         -- Interactive loop with supervised per-turn RAG processes

rebar.config          -- Build configuration, escript profiles
Makefile              -- Convenience targets
README.md             -- This file
```

---

## Erlang Concepts Demonstrated

### Pattern matching in function heads

```erlang
handle_response({ok, Body})    -> process(Body);
handle_response({error, Reason}) -> log(Reason).
```

Every function clause handles exactly one shape of input.  No `if` chains.
The runtime tries clauses top-to-bottom and selects the first that matches.
A `function_clause` exception is thrown if no clause matches -- which is a
crash, which is caught by the supervisor.

### Binary pattern matching

```erlang
escape_json(<<$", Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, $\\, $">>);
escape_json(<<Byte, Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, Byte>>).
```

Erlang's binary syntax is extraordinarily powerful.  Parsing JSON, HTTP headers,
or binary network protocols with pattern matching is both faster and clearer than
byte-array manipulation in most other languages.

### Sending messages between processes

```erlang
%% Send a message (the ! operator)
WorkerPid ! {question, "What is the policy?"},

%% Receive a message
receive
    {answer, Text} -> io:put_chars(Text);
    {error, Reason} -> io:format("Error: ~p~n", [Reason])
after 30000 ->
    timeout
end.
```

There are no shared variables between processes.  All coordination is via
message passing.  Messages are copied on send, so no aliasing is possible.

### List comprehensions

```erlang
%% Encode all parameters in parallel (syntactically, not concurrently)
EncodedParams = [encode_param(P) || P <- Params],

%% Filter and transform in one expression
ValidChunks = [Chunk || Chunk <- Chunks, byte_size(Chunk) > 100],
```

### Tail recursion for loops

```erlang
%% Erlang has no while/for loops. Recursion IS the loop.
%% Tail calls are optimised to jumps -- no stack growth.
chatbot_loop(History, LastChunks, Config) ->
    Line = io:get_line("> "),
    NewHistory = handle_turn(Line, History, Config),
    chatbot_loop(NewHistory, LastChunks, Config).  % tail call
```

---

## Troubleshooting

| Symptom | Likely cause |
|---------|--------------|
| `Turso HTTP 401` | `turso_token` in `rag_config.erl` is wrong or missing |
| `Cannot connect to Ollama` | Run `ollama serve` first |
| `No results found` | Run `./rag_ingest` first |
| `vector_top_k` SQL error | Vector index not created; re-run ingest |
| Chunks too long/short | Adjust `chunk_size` in `rag_config.erl` |
| Compile error `warnings_as_errors` | Fix the warning; or temporarily remove from `rebar.config` |
| `enoent` on file read | Check that `docs_dir` exists and contains `.txt` files |

---

## Adding PDF Support

See `src/parser.erl`.  Add a new `parse_by_extension` clause:

```erlang
parse_by_extension(<<".pdf">>, Path) ->
    %% Use the 'pdfminer' or 'erlware_commons' library,
    %% or shell out to pdftotext:
    Cmd = io_lib:format("pdftotext ~s -", [Path]),
    Text = os:cmd(Cmd),
    {ok, list_to_binary(Text)};
```

No changes needed in any other module -- the interface `{ok, Binary}` is
the same regardless of the file format.
