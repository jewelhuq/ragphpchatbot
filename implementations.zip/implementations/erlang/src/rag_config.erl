﻿%% rag_config.erl — The single source of truth for the entire RAG system.
%%
%% In Erlang, configuration is just data.  A plain map is a perfectly good
%% configuration store: it is immutable, pattern-matchable, and trivially
%% passed into every function that needs it.  No global state, no singletons,
%% no configuration servers — just a map that gets created once and threaded
%% through the call graph.
%%
%% Why a map and not a record?  Records require a compile-time definition and
%% are awkward to extend at runtime.  Maps are open, readable in the shell,
%% and work beautifully with pattern matching in function heads:
%%
%%     handle(#{turso_url := Url} = Cfg) -> ...
%%
%% Every knob lives here.  Changing the Turso endpoint, the chunk size, or
%% the embedding model is a one-line edit in default_config/0, not an
%% archaeological dig through ten source files.

-module(rag_config).
-export([default_config/0, get/2]).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% default_config/0 — Build the canonical configuration map.
%%
%% Returns a map() containing every parameter the pipeline needs.
%% Keys are atoms; values are binaries, integers, or atoms depending on type.
%%
%% The empty turso_token is intentional: you must supply a real token before
%% running the ingest or query binaries.  Keeping it empty here rather than
%% including a fake token prevents accidental commits of credentials.
-spec default_config() -> map().
default_config() ->
    #{
        %% --- Turso (libSQL over HTTP) ---
        %% The HTTPS base URL of your Turso database instance.
        turso_url   => <<"https://your-db-name.turso.io">>,

        %% Bearer token for Turso authentication. Set this before running.
        %% Never commit a real token — pass it via environment variable:
        %%   export TURSO_TOKEN="eyJ..."
        turso_token => <<"YOUR_TURSO_TOKEN_HERE">>,

        %% --- Ollama (local LLM server) ---
        %% Where the Ollama daemon listens. Default is localhost port 11434.
        ollama_url       => <<"http://127.0.0.1:11434">>,

        %% The model used for /api/chat (answer generation).
        %% gemma3:1b is intentionally small so it runs on CPU in seconds.
        chat_model       => <<"gemma3:1b">>,

        %% The model used for /api/embeddings.
        %% nomic-embed-text produces 768-dimensional unit-normalised vectors.
        embedding_model  => <<"nomic-embed-text">>,

        %% Must match what the embedding model actually produces.
        %% The Turso vector index is created with this dimensionality, so
        %% changing it later requires dropping and recreating the table.
        embedding_dims   => 768,

        %% --- Retrieval ---
        %% How many chunks to return from the vector search.
        %% Higher values give the LLM more context but inflate the prompt.
        top_k => 5,

        %% --- Filesystem ---
        %% Directory that ingest.erl scans for source documents.
        %% Relative to the directory from which the escript is invoked.
        docs_dir => <<"docs">>,

        %% --- Text processing ---
        %% Soft upper-bound in characters for each text chunk.
        %% 512 chars is a practical sweet-spot for short-context local models:
        %% precise enough to carry a single idea, large enough for context.
        chunk_size  => 512,

        %% Paragraphs shorter than this many characters are treated as
        %% noise (footers, headers, stray labels) and discarded.
        min_chunk_len => 100
    }.

%% get/2 — A safe accessor that reads a key from any config map.
%%
%% This is intentionally a thin wrapper around maps:get/2 so that callers
%% never have to worry about crash messages for missing keys — any module
%% that calls get/2 with a key that is not in the map gets a clear runtime
%% crash pointing here, rather than a cryptic key_not_found deep inside
%% business logic.
%%
%% Usage:
%%   Url = rag_config:get(turso_url, Cfg),
%%   K   = rag_config:get(top_k, Cfg).
-spec get(atom(), map()) -> term().
get(Key, Config) ->
    maps:get(Key, Config).
