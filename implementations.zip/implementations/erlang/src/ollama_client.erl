%% ollama_client.erl — The voice and mind of the RAG system.
%%
%% Ollama is a local inference server that runs open-weight models on your
%% own hardware.  It exposes a clean HTTP API that needs no SDK — raw httpc
%% calls are fine and keep our dependency count at zero.
%%
%% Two capabilities live here:
%%
%%   embed/2         — Turn a chunk of text into a 768-dimensional float vector
%%                     so that "meaning" becomes a point in geometric space.
%%
%%   chat_stream/3   — Ask the model a question and deliver each token to a
%%                     caller-supplied fun/1 as it arrives, rather than waiting
%%                     for the full response.
%%
%% The streaming path is the UX secret ingredient: users start reading the
%% answer before the model finishes generating it, which makes a local
%% 1-billion-parameter model feel far more responsive than it really is.
%%
%% Erlang process model note:
%%   Both embed/2 and chat_stream/3 are synchronous from the perspective of
%%   the calling process.  They block that one process until the response
%%   arrives.  Because Erlang processes are cheap (a few hundred bytes each),
%%   the idiomatic approach is to spawn a fresh process for each concurrent
%%   operation rather than reaching for threads or async machinery.
%%   ingest.erl demonstrates this: each file gets its own process.

-module(ollama_client).
-export([embed/2, chat_stream/3]).

%% ---------------------------------------------------------------------------
%% Internal helpers
%% ---------------------------------------------------------------------------

%% ollama_url/2 — Build a full Ollama endpoint URL.
-spec ollama_url(binary(), map()) -> string().
ollama_url(Path, Config) ->
    Base = rag_config:get(ollama_url, Config),
    binary_to_list(<<Base/binary, Path/binary>>).

%% build_embed_body/2 — Build the JSON body for /api/embeddings.
%%
%% Ollama's embedding endpoint is simple:
%%   POST /api/embeddings
%%   {"model": "nomic-embed-text", "prompt": "the text to embed"}
-spec build_embed_body(binary(), map()) -> iolist().
build_embed_body(Text, Config) ->
    Model   = rag_config:get(embedding_model, Config),
    TextEsc = escape_json(Text),
    ModelEsc = escape_json(Model),
    io_lib:format(
        "{\"model\":\"~s\",\"prompt\":\"~s\"}",
        [ModelEsc, TextEsc]
    ).

%% build_chat_body/2 — Build the JSON body for /api/chat with streaming=true.
%%
%% Ollama's chat endpoint accepts an OpenAI-compatible messages array:
%%   {"model": "gemma3:1b", "messages": [...], "stream": true}
%%
%% Messages is a list of #{<<"role">> => Role, <<"content">> => Content} maps.
-spec build_chat_body([map()], map()) -> iolist().
build_chat_body(Messages, Config) ->
    Model    = rag_config:get(chat_model, Config),
    ModelEsc = escape_json(Model),
    MsgJson  = encode_messages(Messages),
    io_lib:format(
        "{\"model\":\"~s\",\"messages\":~s,\"stream\":true}",
        [ModelEsc, MsgJson]
    ).

%% encode_messages/1 — Serialize the messages list to a JSON array string.
-spec encode_messages([map()]) -> iolist().
encode_messages(Messages) ->
    Encoded = [encode_message(M) || M <- Messages],
    [<<"[">>, lists:join(<<",">>, Encoded), <<"]">>].

encode_message(#{role := Role, content := Content}) ->
    RoleEsc    = escape_json(to_binary(Role)),
    ContentEsc = escape_json(to_binary(Content)),
    io_lib:format(
        "{\"role\":\"~s\",\"content\":\"~s\"}",
        [RoleEsc, ContentEsc]
    );
encode_message(M) when is_map(M) ->
    %% Handle maps keyed by binary strings (common from fetch_all results).
    Role    = maps:get(<<"role">>, M, <<"user">>),
    Content = maps:get(<<"content">>, M, <<>>),
    encode_message(#{role => Role, content => Content}).

%% to_binary/1 — Coerce atoms or lists to binary.
to_binary(B) when is_binary(B) -> B;
to_binary(A) when is_atom(A)   -> atom_to_binary(A, utf8);
to_binary(L) when is_list(L)   -> list_to_binary(L).

%% escape_json/1 — Escape a binary for safe embedding inside a JSON string.
%%
%% We only handle the characters JSON mandates be escaped.  Ollama communicates
%% over UTF-8, so multi-byte characters pass through unmodified.
-spec escape_json(binary()) -> binary().
escape_json(Bin) ->
    escape_json(Bin, <<>>).

escape_json(<<>>, Acc) -> Acc;
escape_json(<<$", Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, $\\, $">>);
escape_json(<<$\\, Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, $\\, $\\>>);
escape_json(<<$\n, Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, $\\, $n>>);
escape_json(<<$\r, Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, $\\, $r>>);
escape_json(<<$\t, Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, $\\, $t>>);
escape_json(<<Byte, Rest/binary>>, Acc) ->
    escape_json(Rest, <<Acc/binary, Byte>>).

%% ---------------------------------------------------------------------------
%% Embedding parser
%% ---------------------------------------------------------------------------

%% parse_embedding/1 — Extract the float list from Ollama's embedding JSON response.
%%
%% The response shape is:
%%   {"model":"nomic-embed-text","embedding":[0.123, -0.456, ...]}
%%
%% We find the "embedding":[ marker and then parse the comma-separated floats
%% that follow.  No full JSON parser needed — binary pattern matching handles
%% this in a tight loop.
-spec parse_embedding(binary()) -> {ok, [float()]} | {error, binary()}.
parse_embedding(Body) ->
    Key = <<"\"embedding\":[">>,
    case binary:match(Body, Key) of
        nomatch ->
            {error, <<"Ollama embedding response missing 'embedding' field">>};
        {Start, Len} ->
            After  = binary:part(Body, Start + Len, byte_size(Body) - Start - Len),
            Floats = parse_float_array(After, []),
            {ok, Floats}
    end.

%% parse_float_array/2 — Parse a JSON float array like [0.1,-0.2,0.3] into [float()].
parse_float_array(<<$], _Rest/binary>>, Acc) ->
    lists:reverse(Acc);
parse_float_array(<<>>, Acc) ->
    lists:reverse(Acc);
parse_float_array(Bin, Acc) ->
    case binary:match(Bin, [<<",">>, <<"]">>]) of
        nomatch ->
            {NumBin, _} = split_on(Bin, <<$]>>),
            lists:reverse([parse_float_val(NumBin) | Acc]);
        {Start, _} ->
            NumBin = binary:part(Bin, 0, Start),
            RestBin = binary:part(Bin, Start + 1, byte_size(Bin) - Start - 1),
            Sep = binary:part(Bin, Start, 1),
            case Sep of
                <<$]>> ->
                    F = parse_float_val(NumBin),
                    lists:reverse([F | Acc]);
                _ ->
                    F = parse_float_val(NumBin),
                    parse_float_array(RestBin, [F | Acc])
            end
    end.

split_on(Bin, Sep) ->
    case binary:match(Bin, Sep) of
        nomatch -> {Bin, <<>>};
        {Start, Len} ->
            { binary:part(Bin, 0, Start)
            , binary:part(Bin, Start + Len, byte_size(Bin) - Start - Len) }
    end.

parse_float_val(Bin) ->
    Trimmed = binary:replace(Bin, <<" ">>, <<>>, [global]),
    case Trimmed of
        <<>> -> 0.0;
        _ ->
            S = binary_to_list(Trimmed),
            case catch list_to_float(S) of
                {'EXIT', _} ->
                    case catch list_to_integer(S) of
                        {'EXIT', _} -> 0.0;
                        I -> float(I)
                    end;
                F -> F
            end
    end.

%% ---------------------------------------------------------------------------
%% Streaming chat — NDJSON line-by-line delivery
%% ---------------------------------------------------------------------------
%%
%% Ollama's streaming chat endpoint returns Newline-Delimited JSON (NDJSON).
%% Each line is a JSON object describing one token:
%%   {"model":"gemma3:1b","message":{"role":"assistant","content":"word"},"done":false}
%%
%% The final line has "done":true and contains timing statistics.
%%
%% httpc's async mode sends a stream_start message, followed by one http_chunk
%% message per network chunk, followed by a stream_end message.  We receive
%% all three in our process mailbox using the receive ... end construct.
%%
%% This is Erlang's message-passing model in action: no callbacks, no async/await,
%% no event loop — just a process that sends messages to another process.

%% stream_chat/4 — Internal: post to /api/chat and deliver tokens via httpc streaming.
-spec stream_chat(iolist(), fun((binary()) -> ok), map()) -> ok | {error, term()}.
stream_chat(Body, OnChunk, Config) ->
    Url     = ollama_url(<<"/api/chat">>, Config),
    Headers = [],
    BodyBin = iolist_to_binary(Body),
    Self    = self(),
    %% httpc async streaming: responses arrive as messages in our mailbox.
    case httpc:request(post,
                       {Url, Headers, "application/json", BodyBin},
                       [{timeout, 120000}],
                       [{sync, false}, {stream, {self, Self}}, {body_format, binary}]) of
        {ok, RequestId} ->
            receive_stream(RequestId, OnChunk, <<>>);
        {error, Reason} ->
            {error, Reason}
    end.

%% receive_stream/3 — Process the streaming HTTP response message by message.
%%
%% httpc sends three kinds of messages:
%%   {http, {RequestId, stream_start, Headers}}
%%   {http, {RequestId, stream, Chunk}}
%%   {http, {RequestId, stream_end, Headers}}
%%
%% We accumulate partial lines in a buffer (because a network chunk may split
%% a JSON object across two messages) and call OnChunk whenever we assemble
%% a complete NDJSON line containing a token.
-spec receive_stream(term(), fun((binary()) -> ok), binary()) -> ok | {error, term()}.
receive_stream(RequestId, OnChunk, Buffer) ->
    receive
        {http, {RequestId, stream_start, _Headers}} ->
            receive_stream(RequestId, OnChunk, Buffer);

        {http, {RequestId, stream, Chunk}} ->
            %% Append chunk to our line buffer and flush complete lines.
            NewBuffer = <<Buffer/binary, Chunk/binary>>,
            Remaining = process_ndjson_lines(NewBuffer, OnChunk),
            receive_stream(RequestId, OnChunk, Remaining);

        {http, {RequestId, stream_end, _Headers}} ->
            %% Flush any final incomplete line in the buffer.
            _ = process_ndjson_lines(Buffer, OnChunk),
            ok;

        {http, {RequestId, {error, Reason}}} ->
            {error, Reason}

    after 120000 ->
        {error, <<"Ollama chat stream timed out">>}
    end.

%% process_ndjson_lines/2 — Split on newlines, call OnChunk per complete line.
%%
%% Returns any trailing bytes that do not yet end with \n (a partial line).
-spec process_ndjson_lines(binary(), fun((binary()) -> ok)) -> binary().
process_ndjson_lines(Buffer, OnChunk) ->
    Lines = binary:split(Buffer, <<"\n">>, [global]),
    process_lines(Lines, OnChunk).

process_lines([], _OnChunk) ->
    <<>>;
process_lines([Last], _OnChunk) ->
    %% No trailing newline — this is an incomplete line, keep it in buffer.
    Last;
process_lines([Line | Rest], OnChunk) ->
    %% This line ended with \n so it is complete.
    case Line of
        <<>> ->
            %% Blank line — NDJSON separator, ignore.
            process_lines(Rest, OnChunk);
        _ ->
            maybe_deliver_token(Line, OnChunk),
            process_lines(Rest, OnChunk)
    end.

%% maybe_deliver_token/2 — Parse one NDJSON line and call OnChunk if it has a token.
-spec maybe_deliver_token(binary(), fun((binary()) -> ok)) -> ok.
maybe_deliver_token(Line, OnChunk) ->
    %% We look for "content":"<token>" in the JSON object.
    %% The streaming format is:
    %%   {"message":{"role":"assistant","content":"word"},"done":false}
    ContentKey = <<"\"content\":\"">>,
    case binary:match(Line, ContentKey) of
        nomatch ->
            ok;
        {Start, Len} ->
            After  = binary:part(Line, Start + Len, byte_size(Line) - Start - Len),
            Token  = extract_until_unescaped_quote(After, <<>>),
            if byte_size(Token) > 0 ->
                OnChunk(Token);
            true ->
                ok
            end
    end.

%% extract_until_unescaped_quote/2 — Read a JSON string value respecting escapes.
extract_until_unescaped_quote(<<>>, Acc) ->
    Acc;
extract_until_unescaped_quote(<<$", _Rest/binary>>, Acc) ->
    Acc;
extract_until_unescaped_quote(<<$\\, $", Rest/binary>>, Acc) ->
    extract_until_unescaped_quote(Rest, <<Acc/binary, $">>);
extract_until_unescaped_quote(<<$\\, $n, Rest/binary>>, Acc) ->
    extract_until_unescaped_quote(Rest, <<Acc/binary, $\n>>);
extract_until_unescaped_quote(<<$\\, $t, Rest/binary>>, Acc) ->
    extract_until_unescaped_quote(Rest, <<Acc/binary, $\t>>);
extract_until_unescaped_quote(<<$\\, $\\, Rest/binary>>, Acc) ->
    extract_until_unescaped_quote(Rest, <<Acc/binary, $\\>>);
extract_until_unescaped_quote(<<Byte, Rest/binary>>, Acc) ->
    extract_until_unescaped_quote(Rest, <<Acc/binary, Byte>>).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% embed/2 — Convert a text string into a 768-dimensional float vector.
%%
%% This is the mathematical heart of the retrieval step.  Two pieces of text
%% with similar meaning end up geometrically close in the 768-dimensional space
%% produced by nomic-embed-text, which is what makes "find the most relevant
%% chunks" work at all.
%%
%% Returns {ok, [float()]} on success or {error, Reason} on any failure.
%% The caller can pattern-match on this:
%%
%%   case ollama_client:embed(Text, Config) of
%%       {ok, Vec}       -> store_in_db(Vec);
%%       {error, Reason} -> log_error(Reason)   %% let it crash, or handle gracefully
%%   end.
-spec embed(binary(), map()) -> {ok, [float()]} | {error, term()}.
embed(Text, Config) ->
    Url     = ollama_url(<<"/api/embeddings">>, Config),
    Body    = build_embed_body(Text, Config),
    BodyBin = iolist_to_binary(Body),
    case httpc:request(post,
                       {Url, [], "application/json", BodyBin},
                       [{timeout, 60000}],
                       [{body_format, binary}]) of
        {ok, {{_, 200, _}, _Headers, RespBody}} ->
            parse_embedding(RespBody);
        {ok, {{_, Status, _}, _Headers, RespBody}} ->
            Msg = io_lib:format("Ollama embed HTTP ~p: ~s", [Status, RespBody]),
            {error, iolist_to_binary(Msg)};
        {error, Reason} ->
            {error, Reason}
    end.

%% chat_stream/3 — Send messages and deliver tokens one-by-one via OnChunk.
%%
%% OnChunk is a fun/1 that receives each generated token as a binary.
%% It is called in the same process as the caller — no spawning happens here.
%% The typical usage pattern:
%%
%%   ollama_client:chat_stream(
%%       Messages,
%%       fun(Token) -> io:put_chars(Token), ok end,
%%       Config
%%   ).
%%
%% Returns ok when the stream is finished, or {error, Reason} on failure.
-spec chat_stream([map()], fun((binary()) -> ok), map()) -> ok | {error, term()}.
chat_stream(Messages, OnChunk, Config) ->
    Body = build_chat_body(Messages, Config),
    stream_chat(Body, OnChunk, Config).
