%% parser.erl — The gatekeeper that reads documents off disk.
%%
%% Every document format is a different lock; this module holds the keys.
%% Right now we support .txt files via file:read_file/1, which is the most
%% reliable format: no dependencies, no binary format quirks, no encoding
%% guesswork beyond UTF-8.
%%
%% Why file:read_file/1 instead of something fancier?
%% Erlang's file module ships in the standard library and handles the
%% OS-level read in a single call, returning a binary.  No buffering,
%% no streaming, no teardown — just {ok, Binary} or {error, Reason}.
%% Pattern matching on that return value is idiomatic and self-documenting:
%%
%%   case parser:parse(Path) of
%%       {ok, Text}      -> process(Text);
%%       {error, Reason} -> log_and_skip(Reason)
%%   end.
%%
%% Adding PDF or DOCX support later is a matter of adding new clauses to
%% parse/1 that pattern-match on the file extension.  The interface stays
%% the same; the implementation changes in one place.

-module(parser).
-export([parse/1]).

%% ---------------------------------------------------------------------------
%% Extension helpers
%% ---------------------------------------------------------------------------

%% file_extension/1 — Extract the lowercase file extension from a path binary.
%%
%% Examples:
%%   file_extension(<<"docs/readme.txt">>)  => <<".txt">>
%%   file_extension(<<"report.PDF">>)       => <<".pdf">>
%%   file_extension(<<"no_extension">>)     => <<"">>
-spec file_extension(binary()) -> binary().
file_extension(Path) ->
    Str = binary_to_list(Path),
    Ext = filename:extension(Str),
    list_to_binary(string:lowercase(Ext)).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% parse/1 — Read a file and return its text content as a binary.
%%
%% The path can be a binary or a list (Erlang string).  We normalise to a
%% list because most file system functions in stdlib prefer lists.
%%
%% Return values:
%%   {ok, Content :: binary()}  — file was read and decoded successfully
%%   {error, Reason}            — file could not be read, or format unsupported
%%
%% The "let it crash" principle applies here: parse/1 does NOT swallow errors.
%% It returns them as tagged tuples so callers can decide what to do.
%% ingest.erl, for example, logs the error and moves on to the next file —
%% one bad document does not halt the entire ingestion pipeline.
-spec parse(binary() | string()) -> {ok, binary()} | {error, term()}.
parse(FilePath) when is_binary(FilePath) ->
    parse(binary_to_list(FilePath));
parse(FilePath) when is_list(FilePath) ->
    Ext = file_extension(list_to_binary(FilePath)),
    parse_by_extension(Ext, FilePath).

%% parse_by_extension/2 — Dispatch to the correct reader based on file extension.
%%
%% Pattern matching in function heads is Erlang at its most expressive.
%% Each supported format is one clause; unsupported formats fall through to
%% the catch-all at the bottom.  Adding PDF support means adding one clause —
%% no if/else chains, no switch statements, no map lookups.
-spec parse_by_extension(binary(), string()) -> {ok, binary()} | {error, term()}.
parse_by_extension(<<".txt">>, Path) ->
    read_text_file(Path);
parse_by_extension(<<".md">>, Path) ->
    %% Markdown is plain text — read it as-is.
    %% A richer implementation might strip Markdown syntax, but for embedding
    %% purposes the headings and paragraphs are already meaningful structure.
    read_text_file(Path);
parse_by_extension(<<".rst">>, Path) ->
    %% reStructuredText is also plain text at the byte level.
    read_text_file(Path);
parse_by_extension(Ext, _Path) ->
    %% Return a descriptive error rather than crashing.  The caller decides
    %% whether to skip this file or propagate the error upstream.
    {error, {unsupported_format, Ext}}.

%% ---------------------------------------------------------------------------
%% Readers
%% ---------------------------------------------------------------------------

%% read_text_file/1 — Read a UTF-8 text file and return its content as a binary.
%%
%% file:read_file/1 is the simplest possible implementation: one syscall,
%% no buffering, no encoding conversion.  It returns the raw bytes of the
%% file as an Erlang binary.  For UTF-8 encoded files this is exactly what
%% we want — the binary IS the UTF-8 text.
%%
%% If the file does not exist or cannot be opened, file:read_file/1 returns
%% {error, Reason} where Reason is a POSIX error atom like enoent or eacces.
%% We propagate that tuple directly so callers can pattern-match on it.
-spec read_text_file(string()) -> {ok, binary()} | {error, term()}.
read_text_file(Path) ->
    case file:read_file(Path) of
        {ok, Bytes} ->
            %% Normalise Windows line endings to Unix style for the chunker.
            Normalised = binary:replace(Bytes, <<"\r\n">>, <<"\n">>, [global]),
            {ok, Normalised};
        {error, Reason} ->
            {error, {read_failed, Reason, Path}}
    end.
