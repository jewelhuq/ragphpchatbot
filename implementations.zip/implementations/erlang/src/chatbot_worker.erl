%% chatbot_worker.erl — The supervised worker process for individual RAG turns.
%%
%% This module is the child process that rag_supervisor.erl manages.
%%
%% In a full OTP application this would be a gen_server with a rich protocol.
%% In our escript demo it is a simple process that:
%%   1. Receives a {rag_turn, Question, History, ReplyTo} message.
%%   2. Calls rag:answer/4 with a streaming callback that prints to stdout.
%%   3. Sends {rag_done, Response} back to the caller.
%%   4. Loops to handle the next question.
%%
%% If step 2 crashes (Ollama down, network error, unexpected response),
%% the process exits abnormally.  rag_supervisor detects this via monitor
%% and restarts the worker.  The chatbot UI loop then retries the question.
%%
%% This is the OTP supervisor pattern in miniature:
%%
%%   +-------------+       spawn_monitor        +----------------+
%%   |  UI loop    |  ========================> |  rag_worker    |
%%   | (chatbot.erl)|                           | (this module)  |
%%   |             |  <-- {rag_done, Response}  |                |
%%   |             |  <-- {'DOWN', _, crash}    |                |
%%   +-------------+                            +----------------+
%%              ^                                      |
%%              |         restart                      | crash
%%              +---------- rag_supervisor  <----------+

-module(chatbot_worker).
-export([start_link/0, handle_question/3]).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% start_link/0 — Start the worker process and link it to the caller.
%%
%% Called by rag_supervisor when the supervisor starts or restarts this child.
%% Returns {ok, Pid} on success.
%%
%% The worker enters a receive loop waiting for {rag_turn, ...} messages.
%% It remains alive between turns, which avoids the overhead of spawning a
%% new process per question.  (In the chatbot.erl implementation we spawn
%% per-turn for stronger isolation — both approaches are valid trade-offs.)
-spec start_link() -> {ok, pid()}.
start_link() ->
    Pid = spawn_link(fun() -> worker_loop() end),
    {ok, Pid}.

%% handle_question/3 — Send a question to the worker and wait for the reply.
%%
%% This is a synchronous call from the UI loop's perspective: we send a message
%% to the worker process and then block in receive until we get a reply.
%%
%% Timeout: 3 minutes.  If the worker does not reply in time, we return
%% {error, timeout} and the UI loop can retry.
-spec handle_question(pid(), binary(), [map()]) ->
    {ok, binary()} | {error, term()}.
handle_question(WorkerPid, Question, History) ->
    WorkerPid ! {rag_turn, Question, History, self()},
    receive
        {rag_done, Response} ->
            {ok, Response};
        {rag_error, Reason} ->
            {error, Reason}
    after 180000 ->
        {error, timeout}
    end.

%% ---------------------------------------------------------------------------
%% Worker loop
%% ---------------------------------------------------------------------------

%% worker_loop/0 — The receive loop that handles one RAG turn per message.
%%
%% This is a tail-recursive loop (like chatbot_loop in chatbot.erl).
%% Each iteration receives one {rag_turn, ...} message, processes it,
%% replies to the caller, and loops to wait for the next message.
%%
%% If rag:answer/4 crashes, the exception propagates out of worker_loop,
%% the process exits with the crash reason, and the supervisor restarts it.
%% The restart is transparent to the UI loop, which retried on {error, _}.
-spec worker_loop() -> no_return().
worker_loop() ->
    receive
        {rag_turn, Question, History, ReplyTo} ->
            %% Load config fresh on each turn so changes to rag_config.erl
            %% take effect without restarting (useful in development).
            Config = rag_config:default_config(),

            %% Accumulate streamed tokens so we can send the full response back.
            Acc = erlang:make_ref(),   % used as a unique token for the ETS trick
            _ = Acc,                   % suppress unused warning
            FullTokens = [],

            %% We capture tokens in a closure shared with the callback.
            %% Because Erlang data is immutable, we cannot mutate FullTokens from
            %% inside the callback.  Instead we use process dictionary (get/put)
            %% as a lightweight accumulator scoped to this process.
            put(response_acc, []),

            OnChunk = fun(Token) ->
                io:put_chars(Token),
                put(response_acc, [Token | get(response_acc)]),
                ok
            end,

            case rag:answer(Question, History, OnChunk, Config) of
                ok ->
                    Parts    = lists:reverse(get(response_acc)),
                    Response = iolist_to_binary(Parts),
                    ReplyTo ! {rag_done, Response};
                {error, Reason} ->
                    ReplyTo ! {rag_error, Reason}
            end,

            _ = FullTokens,  % suppress unused warning
            worker_loop();

        stop ->
            ok
    end.
