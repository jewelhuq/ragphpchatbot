%% query.erl — A command-line tool for inspecting what the retrieval step sees.
%%
%% Before trusting the chatbot's answers, it is enormously valuable to look at
%% the raw chunks that the vector search returns.  If the retrieved chunks are
%% irrelevant or duplicated, the problem is in the chunking or embedding stage —
%% not in the LLM's reasoning.
%%
%% This module takes a single query string, embeds it, runs the vector search,
%% and prints the ranked results with their cosine similarity scores.  It is
%% intentionally a developer/debugging tool rather than a user-facing interface.
%%
%% Usage (after rebar3 escriptize):
%%   ./rag_query "What is the refund policy?"
%%   ./rag_query "how does authentication work"
%%
%% This module also exports vector_search/3 so that rag.erl and chatbot.erl
%% can reuse the retrieval logic without duplicating the SQL.

-module(query).
-export([main/1, vector_search/3]).

%% ---------------------------------------------------------------------------
%% Vector search
%% ---------------------------------------------------------------------------

%% vector_search/3 — Embed the query and find the most similar chunks in Turso.
%%
%% The search uses Turso's vector_top_k() table-valued function, which performs
%% an approximate nearest-neighbour (ANN) search over the HNSW index we created
%% during ingestion.  Results are ordered by distance (ascending): smaller
%% distance = higher similarity.
%%
%% We JOIN back to rag_chunks to recover the chunk text and to rag_files to
%% recover the source filename — both are needed for display and for building
%% the LLM prompt.
%%
%% Return value: a list of maps, one per result, with keys:
%%   <<"chunk_id">>  — the integer row id (as binary string)
%%   <<"content">>   — the chunk text
%%   <<"source">>    — the source file path
%%   <<"chunk_idx">> — the index of this chunk within its file
%%   <<"distance">>  — similarity distance (lower = better, as binary string)
%%
%% We add a "score" field (1 - distance) as a float for human-friendly display.
-spec vector_search(binary(), map(), map()) -> {ok, [map()]} | {error, term()}.
vector_search(QueryText, OllamaConfig, TursoConfig) ->
    io:format("Embedding query: '~s' ...~n", [QueryText]),
    case ollama_client:embed(QueryText, OllamaConfig) of
        {error, Reason} ->
            {error, Reason};
        {ok, Vec} ->
            VecLit = vec_to_literal(Vec),
            TopK   = rag_config:get(top_k, TursoConfig),

            Sql = <<"SELECT "
                    "  c.id        AS chunk_id, "
                    "  c.content   AS content, "
                    "  f.path      AS source, "
                    "  c.chunk_idx AS chunk_idx, "
                    "  vt.distance AS distance "
                    "FROM vector_top_k('rag_chunks_vec', vector32(?), ?) AS vt "
                    "JOIN rag_chunks c ON c.id = vt.id "
                    "JOIN rag_files  f ON f.id = c.file_id "
                    "ORDER BY vt.distance ASC">>,

            case turso_client:fetch_all(Sql, [VecLit, TopK], TursoConfig) of
                {ok, Rows} ->
                    Results = [ annotate_score(R) || R <- Rows ],
                    {ok, Results};
                {error, Reason} ->
                    {error, Reason}
            end
    end.

%% vec_to_literal/1 — Format a float list as the string Turso's vector32() expects.
-spec vec_to_literal([float()]) -> binary().
vec_to_literal(Vec) ->
    Parts = [io_lib:format("~f", [F]) || F <- Vec],
    iolist_to_binary([<<"[">>, lists:join(<<",">>, Parts), <<"]">>]).

%% annotate_score/1 — Add a human-friendly "score" field to a result row.
%%
%% score = 1 - distance gives a value in [0, 1] for unit-normalised vectors.
%% nomic-embed-text L2-normalises its output, so this approximation holds well.
-spec annotate_score(map()) -> map().
annotate_score(Row) ->
    DistBin  = maps:get(<<"distance">>, Row, <<"1.0">>),
    Distance = parse_float(DistBin),
    Score    = max(0.0, 1.0 - Distance),
    Row#{<<"distance_float">> => Distance, <<"score">> => Score}.

%% parse_float/1 — Safely convert a binary to a float (default 1.0 on failure).
-spec parse_float(binary() | null) -> float().
parse_float(null) -> 1.0;
parse_float(Bin) when is_binary(Bin) ->
    S = binary_to_list(Bin),
    case catch list_to_float(S) of
        {'EXIT', _} ->
            case catch list_to_integer(S) of
                {'EXIT', _} -> 1.0;
                I            -> float(I)
            end;
        F -> F
    end.

%% ---------------------------------------------------------------------------
%% Result display
%% ---------------------------------------------------------------------------

%% print_results/1 — Print ranked retrieval results for developer inspection.
%%
%% Each result shows its rank, similarity score, source file, and a truncated
%% preview of the chunk content.  This is the information you need to evaluate
%% whether retrieval quality is good enough before blaming the LLM.
-spec print_results([map()]) -> ok.
print_results([]) ->
    io:format("~nNo results found.  Have you run rag_ingest?~n"),
    ok;
print_results(Results) ->
    io:format("~nTop ~p result(s):~n~n", [length(Results)]),
    io:format("======================================================================~n"),
    lists:foreach(
        fun({Rank, Row}) ->
            Source   = maps:get(<<"source">>,    Row, <<"unknown">>),
            ChunkIdx = maps:get(<<"chunk_idx">>, Row, <<"0">>),
            Content  = maps:get(<<"content">>,   Row, <<>>),
            Score    = maps:get(<<"score">>,     Row, 0.0),
            Distance = maps:get(<<"distance_float">>, Row, 1.0),

            SourceDisplay = filename:basename(binary_to_list(to_binary(Source))),

            %% Score bar using ASCII block characters
            BarFilled = round(Score * 20),
            BarEmpty  = 20 - BarFilled,
            Bar = lists:flatten([
                lists:duplicate(BarFilled, $#),
                lists:duplicate(BarEmpty,  $-)
            ]),

            io:format("  Rank ~2w  |  Score: ~.4f  [~s]~n",
                      [Rank, Score, Bar]),
            io:format("  Source: ~s  (chunk #~s)~n",
                      [SourceDisplay, to_binary(ChunkIdx)]),
            io:format("  Distance: ~.6f~n~n", [Distance]),

            %% Truncate long chunks for readability
            ContentBin = to_binary(Content),
            Preview    = if byte_size(ContentBin) > 400 ->
                                <<(binary:part(ContentBin, 0, 400))/binary,
                                  " ... [truncated]">>;
                           true ->
                                ContentBin
                        end,

            %% Print each line of the preview indented
            Lines = binary:split(Preview, <<"\n">>, [global]),
            lists:foreach(
                fun(L) -> io:format("  ~s~n", [L]) end,
                Lines
            ),
            io:format("~n"),
            io:format("----------------------------------------------------------------------~n")
        end,
        lists:zip(lists:seq(1, length(Results)), Results)
    ),
    io:format("~n").

%% to_binary/1 — Coerce various types to binary for uniform display.
to_binary(B) when is_binary(B) -> B;
to_binary(null)                 -> <<"null">>;
to_binary(A) when is_atom(A)   -> atom_to_binary(A, utf8);
to_binary(L) when is_list(L)   -> list_to_binary(L);
to_binary(I) when is_integer(I)-> integer_to_binary(I);
to_binary(F) when is_float(F)  -> iolist_to_binary(io_lib:format("~f", [F])).

%% ---------------------------------------------------------------------------
%% Main entry point
%% ---------------------------------------------------------------------------

%% main/1 — The escript entry point for the query debugging tool.
%%
%% Reads the query from the first command-line argument, runs the vector search,
%% and prints results.  Exits non-zero if required arguments are missing.
-spec main([string()]) -> ok.
main([]) ->
    io:format("Usage: rag_query <query> [top_k]~n"),
    io:format("Example: rag_query \"What is machine learning?\"~n"),
    halt(1);
main([QueryStr | Rest]) ->
    ok = application:start(crypto),
    ok = application:start(inets),
    ok = application:start(ssl),

    Config = rag_config:default_config(),

    %% Allow overriding top_k from the command line.
    Cfg = case Rest of
        [K | _] ->
            Config#{top_k => list_to_integer(K)};
        [] ->
            Config
    end,

    QueryBin = list_to_binary(QueryStr),

    io:format("~nQuery: ~s~n", [QueryBin]),
    io:format("-----------------------------------------------------------------~n"),

    case vector_search(QueryBin, Cfg, Cfg) of
        {ok, Results} ->
            print_results(Results);
        {error, Reason} ->
            io:format("[error] ~p~n", [Reason]),
            halt(1)
    end,
    halt(0).
