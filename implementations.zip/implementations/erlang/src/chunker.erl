%% chunker.erl — The art of slicing documents into bite-sized pieces.
%%
%% Retrieval-Augmented Generation lives or dies by the quality of its chunks.
%% A chunk that is too large dilutes the relevance signal — the embedding vector
%% averages over too many ideas, so semantically distant content blurs together.
%% A chunk that is too small loses the surrounding sentences that give individual
%% claims their meaning.
%%
%% This module's chunker follows a few simple editorial instincts:
%%
%%   1. Respect paragraph boundaries.  Authors already decided where ideas end;
%%      we should not split mid-thought just because we hit a character limit.
%%
%%   2. Detect headings.  A short, ALL-CAPS line is almost certainly a section
%%      title.  We remember it and prepend it to every chunk in that section,
%%      so a retrieved chunk carries the section heading even in isolation.
%%
%%   3. Keep source provenance.  Every chunk is prefixed with its filename so
%%      the LLM and the human reader always know where the text came from.
%%
%% This is a pure module — chunk/3 is a pure function with no side effects,
%% no message sends, no process communication.  It takes text in and returns
%% a list of binaries out.  Pure functions are the easiest to test, reason
%% about, and run concurrently with zero coordination overhead.

-module(chunker).
-export([chunk/3]).

%% ---------------------------------------------------------------------------
%% Heading detection
%% ---------------------------------------------------------------------------

%% is_heading/1 — Decide whether a paragraph looks like a section heading.
%%
%% Our heuristic: a heading is a single line that is entirely uppercase
%% (allowing punctuation and spaces), shorter than 120 characters, and
%% does not end with a period (headings are titles, not sentences).
%%
%% This catches common document headings like:
%%   "INTRODUCTION"
%%   "1. BACKGROUND AND MOTIVATION"
%%   "CHAPTER 3: RELATED WORK"
%%
%% Pattern matching in function heads is idiomatic Erlang.  Each clause
%% handles one case cleanly, and the VM tries them top-to-bottom.
-spec is_heading(binary()) -> boolean().
is_heading(Para) ->
    Stripped = string:trim(Para),
    Len = byte_size(Stripped),
    case Len of
        0   -> false;
        N when N > 120 -> false;
        _ ->
            %% Reject multi-line paragraphs — real headings are single lines.
            case binary:match(Stripped, <<"\n">>) of
                {_, _} -> false;
                nomatch ->
                    %% Reject paragraphs ending with a period.
                    LastByte = binary:last(Stripped),
                    case LastByte of
                        $. -> false;
                        _  ->
                            %% Accept if all letters are uppercase.
                            all_uppercase_letters(Stripped)
                    end
            end
    end.

%% all_uppercase_letters/1 — True if every letter byte in the binary is A-Z.
-spec all_uppercase_letters(binary()) -> boolean().
all_uppercase_letters(<<>>) ->
    %% No letters found at all — cannot be a heading.
    false;
all_uppercase_letters(Bin) ->
    all_uppercase_letters(Bin, false).  % second arg = found_a_letter

all_uppercase_letters(<<>>, FoundLetter) ->
    FoundLetter;  % True only if we saw at least one letter
all_uppercase_letters(<<Byte, Rest/binary>>, Found) ->
    if
        Byte >= $A, Byte =< $Z ->
            all_uppercase_letters(Rest, true);      % uppercase letter: ok
        Byte >= $a, Byte =< $z ->
            false;                                  % lowercase: not a heading
        true ->
            all_uppercase_letters(Rest, Found)      % punctuation/space: skip
    end.

%% ---------------------------------------------------------------------------
%% Paragraph splitting
%% ---------------------------------------------------------------------------

%% split_paragraphs/1 — Split a document into paragraphs on blank lines.
%%
%% We treat "\n\n" (two consecutive newlines) as the paragraph separator,
%% which matches the convention in most plain-text and Markdown documents.
%% Each paragraph is stripped of leading/trailing whitespace.
-spec split_paragraphs(binary()) -> [binary()].
split_paragraphs(Text) ->
    Raw = binary:split(Text, <<"\n\n">>, [global]),
    [ string:trim(P) || P <- Raw, byte_size(string:trim(P)) > 0 ].

%% ---------------------------------------------------------------------------
%% Chunk assembly
%% ---------------------------------------------------------------------------

%% build_chunk/3 — Assemble a finished chunk string with provenance prefix.
%%
%% Every chunk begins with "Source: <filename>\nSection: <heading>\n\n" so that
%% when this chunk is retrieved by the vector search and shown to the LLM, the
%% model always knows which document and section the text came from.
%%
%% The prefix is NOT counted toward ChunkSize — it is metadata overhead, not
%% document content.
-spec build_chunk([binary()], binary(), binary()) -> binary().
build_chunk(Parts, Source, Heading) ->
    Prefix = <<"Source: ", Source/binary, "\nSection: ", Heading/binary, "\n\n">>,
    Body   = iolist_to_binary(lists:join(<<"\n\n">>, Parts)),
    <<Prefix/binary, Body/binary>>.

%% extract_tail_sentence/1 — Pull the last sentence out of the last paragraph.
%%
%% We use this for sentence-level overlap: the final sentence of one chunk
%% becomes the first sentence of the next.  This prevents a relevant passage
%% from being missed just because the query term landed on a chunk boundary.
%%
%% The heuristic: split on ". " (period + space) and take the last element.
%% If the result is fewer than 40 characters it is probably a label, not a
%% real sentence — return empty binary in that case.
-spec extract_tail_sentence([binary()]) -> binary().
extract_tail_sentence([]) ->
    <<>>;
extract_tail_sentence(Parts) ->
    Last      = lists:last(Parts),
    Sentences = binary:split(Last, <<". ">>, [global]),
    Tail      = lists:last(Sentences),
    if byte_size(Tail) >= 40 -> Tail;
       true                  -> <<>>
    end.

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% chunk/3 — Split a document into overlapping, context-prefixed chunks.
%%
%% Algorithm:
%%   1. Split the full text on "\n\n" to get paragraphs.
%%   2. Walk the paragraphs, tracking the current section heading.
%%   3. Accumulate paragraphs into a buffer until it exceeds ChunkSize chars.
%%   4. When the buffer overflows, finalise a chunk (with source/heading prefix
%%      and an overlap tail from the previous chunk) and start a new buffer
%%      carrying the last sentence of the old buffer.
%%   5. Flush any remaining buffer as the final chunk.
%%
%% Parameters:
%%   Text      — the full document text as a binary.
%%   Source    — a human-readable label (usually the filename without extension).
%%   ChunkSize — soft upper bound in characters per chunk.
%%
%% Returns a list of binary chunks.  Each chunk is a self-contained piece of
%% text that can be embedded and stored independently.
%%
%% This function is completely pure: same inputs always produce the same output,
%% with no side effects, no process spawning, no I/O.  You can call it from
%% any number of concurrent processes without any coordination at all.
-spec chunk(binary(), binary(), non_neg_integer()) -> [binary()].
chunk(Text, Source, ChunkSize) ->
    Paras = split_paragraphs(Text),
    chunk_paragraphs(Paras, Source, ChunkSize, <<"General">>, [], 0, <<>>, []).

%% chunk_paragraphs/8 — The recursive workhorse of chunk/3.
%%
%% Arguments:
%%   Paras       — remaining paragraphs to process
%%   Source      — source label (unchanged throughout)
%%   ChunkSize   — size limit (unchanged throughout)
%%   Heading     — current section heading (updated when a heading is detected)
%%   Buffer      — paragraphs accumulated in the current chunk
%%   BufferChars — total character count of Buffer (avoid re-counting each time)
%%   OverlapTail — last sentence from the previous chunk (for overlap)
%%   Acc         — finished chunks collected so far (reversed list)
-spec chunk_paragraphs(
    [binary()], binary(), non_neg_integer(),
    binary(), [binary()], non_neg_integer(), binary(), [binary()]
) -> [binary()].

%% Base case: no more paragraphs.  Flush the buffer and return.
chunk_paragraphs([], Source, _ChunkSize, Heading, Buffer, _BufferChars, OverlapTail, Acc) ->
    case Buffer of
        [] ->
            lists:reverse(Acc);
        _ ->
            AllParts = case OverlapTail of
                           <<>> -> Buffer;
                           Tail -> [Tail | Buffer]
                       end,
            Chunk = build_chunk(AllParts, Source, Heading),
            lists:reverse([Chunk | Acc])
    end;

chunk_paragraphs([Para | Rest], Source, ChunkSize, Heading, Buffer, BufferChars, OverlapTail, Acc) ->
    case is_heading(Para) of
        true ->
            %% Heading detected: flush the current buffer (section boundary is
            %% a natural chunk break) and start a new section.
            NewAcc = flush_buffer(Buffer, Source, Heading, OverlapTail, Acc),
            NewTail = extract_tail_sentence(Buffer),
            chunk_paragraphs(Rest, Source, ChunkSize, Para, [], 0, NewTail, NewAcc);

        false ->
            ParaLen = byte_size(Para),
            MinLen  = 100,  % discard paragraphs shorter than this as noise
            if
                ParaLen < MinLen ->
                    %% Too short to carry meaning — skip silently.
                    chunk_paragraphs(Rest, Source, ChunkSize, Heading,
                                     Buffer, BufferChars, OverlapTail, Acc);

                BufferChars + ParaLen > ChunkSize, Buffer /= [] ->
                    %% Adding this paragraph would overflow the chunk size.
                    %% Finalise the current chunk and start a fresh one.
                    NewAcc  = flush_buffer(Buffer, Source, Heading, OverlapTail, Acc),
                    NewTail = extract_tail_sentence(Buffer),
                    chunk_paragraphs(Rest, Source, ChunkSize, Heading,
                                     [Para], ParaLen, NewTail, NewAcc);

                true ->
                    %% Accumulate the paragraph into the current buffer.
                    chunk_paragraphs(Rest, Source, ChunkSize, Heading,
                                     Buffer ++ [Para],
                                     BufferChars + ParaLen,
                                     OverlapTail, Acc)
            end
    end.

%% flush_buffer/5 — Finalise the current buffer as a chunk and append to Acc.
%%
%% If the buffer is empty there is nothing to flush — return Acc unchanged.
%% Otherwise, prepend the overlap tail (if non-empty), build the chunk, and
%% cons it onto Acc (we reverse Acc at the end in the base case above).
-spec flush_buffer([binary()], binary(), binary(), binary(), [binary()]) -> [binary()].
flush_buffer([], _Source, _Heading, _OverlapTail, Acc) ->
    Acc;
flush_buffer(Buffer, Source, Heading, OverlapTail, Acc) ->
    AllParts = case OverlapTail of
                   <<>> -> Buffer;
                   Tail -> [Tail | Buffer]
               end,
    Chunk = build_chunk(AllParts, Source, Heading),
    [Chunk | Acc].
