%% chatbot.erl — The conversational front-end of the RAG system.
%%
%% This is what users actually interact with.  It wraps the RAG pipeline in an
%% interactive read-eval-print loop that feels like chatting with a knowledgeable
%% colleague who has read all the documents in your docs/ folder.
%%
%% What makes this Erlang and not just a port of the Python chatbot?
%%
%%   1. Each conversation TURN is handled by a supervised worker process.
%%      If the RAG pipeline crashes mid-turn — Ollama times out, the network
%%      blips, a pattern-match fails somewhere — the supervisor restarts the
%%      worker and the user sees "Retrying your question..." instead of a crash.
%%      The conversation history is preserved by the supervisor loop; only the
%%      failed turn is lost.
%%
%%   2. The UI loop and the RAG computation are separate processes.
%%      The UI loop (running in the main process) can remain responsive while
%%      the RAG worker is generating an answer.  In a richer implementation,
%%      you could show a spinner, accept "cancel" commands, or handle multiple
%%      concurrent users — all without threads or locks.
%%
%%   3. Process monitoring with 'DOWN' messages.
%%      The UI loop monitors the RAG worker via spawn_monitor/1.  When the
%%      worker finishes (or crashes), a 'DOWN' message arrives in the UI loop's
%%      mailbox.  No callbacks, no futures, no promises — just a message.
%%
%% This architecture is a miniature version of Erlang/OTP's gen_server:
%%   Client (UI loop) sends a request message to a server (RAG worker).
%%   Server processes the request and sends a reply.
%%   If the server crashes, the client's monitor fires and it can retry.
%%
%% Usage (after rebar3 escriptize):
%%   ./rag_chatbot

-module(chatbot).
-export([main/1]).

%% ---------------------------------------------------------------------------
%% chatbot_worker — The supervised RAG worker process
%% ---------------------------------------------------------------------------
%%
%% This module is also referenced by rag_supervisor.erl.  We define the worker
%% logic here inline (as a local function spawned by the UI loop) rather than
%% in a separate file, because the chatbot is a standalone escript rather than
%% a full OTP application.  In a production system, chatbot_worker would be
%% its own gen_server module.

%% rag_worker_body/4 — The body function of the supervised RAG worker.
%%
%% This function runs in its own process (spawned by the UI loop).
%% It performs the full RAG pipeline for one question, streams tokens to
%% stdout, then sends {done, Response} to the UI loop.
%%
%% If ANYTHING in this function crashes (pattern-match failure, network error,
%% Ollama timeout, unexpected response format), the process exits with a reason.
%% The UI loop's monitor fires, and the UI loop can decide to retry.
%%
%% "Let it crash" means we do not defensive-code every possible failure inside
%% this function.  The isolation is the safety mechanism, not the try/catch.
-spec rag_worker_body(binary(), [map()], pid(), map()) -> ok.
rag_worker_body(Question, History, UILoop, Config) ->
    %% Accumulate streamed tokens in the process dictionary so the immutable
    %% closure captures the dictionary key rather than a mutable reference.
    put(chatbot_tokens, []),

    %% Collect tokens into a process-dictionary accumulator, and print them.
    OnChunk = fun(Token) ->
        io:put_chars(Token),
        put(chatbot_tokens, [Token | get(chatbot_tokens)]),
        ok
    end,

    case rag:answer(Question, History, OnChunk, Config) of
        ok ->
            %% Generation finished cleanly.  Reconstruct full response and notify UI.
            Parts    = lists:reverse(get(chatbot_tokens)),
            Response = iolist_to_binary(Parts),
            UILoop ! {rag_done, self(), Response};
        {error, Reason} ->
            %% Generation failed.  Exit with the reason so the monitor fires.
            exit({rag_error, Reason})
    end.

%% ---------------------------------------------------------------------------
%% UI loop — Interactive read-print loop with supervised RAG turns
%% ---------------------------------------------------------------------------

-define(MAX_HISTORY_TURNS, 10).

%% print_banner/0 — Greet the user and explain the available commands.
print_banner() ->
    io:format("~n"),
    io:format("+----------------------------------------------------------+~n"),
    io:format("|               Erlang RAG Chatbot                        |~n"),
    io:format("|  Powered by Turso (vector search) + Ollama (local LLM)  |~n"),
    io:format("+----------------------------------------------------------+~n"),
    io:format("|  Type your question and press Enter.                     |~n"),
    io:format("|  Commands: exit | quit | clear | sources | history       |~n"),
    io:format("|  Erlang's supervisors restart failed turns automatically.|~n"),
    io:format("+----------------------------------------------------------+~n"),
    io:format("~n").

%% trim_history/1 — Keep only the most recent MAX_HISTORY_TURNS conversation turns.
%%
%% Each "turn" is a user message + assistant response pair (2 messages).
%% We always discard from the oldest end to bound the prompt size.
-spec trim_history([map()]) -> [map()].
trim_history(History) ->
    MaxMessages = ?MAX_HISTORY_TURNS * 2,
    case length(History) > MaxMessages of
        true  -> lists:nthtail(length(History) - MaxMessages, History);
        false -> History
    end.

%% format_source_list/1 — Format retrieved chunk sources for display.
-spec format_source_list([map()]) -> iolist().
format_source_list([]) ->
    "  (no relevant context found)";
format_source_list(Chunks) ->
    lists:map(
        fun({N, C}) ->
            Src   = maps:get(<<"source">>, C, <<"unknown">>),
            Score = maps:get(<<"score">>,  C, 0.0),
            Display = filename:basename(binary_to_list(to_binary(Src))),
            io_lib:format("  [~p] ~s  (relevance: ~.1f%)~n",
                          [N, Display, Score * 100])
        end,
        lists:zip(lists:seq(1, length(Chunks)), Chunks)
    ).

%% to_binary/1 — Coerce various types to binary.
to_binary(B) when is_binary(B) -> B;
to_binary(null)                 -> <<>>;
to_binary(A) when is_atom(A)   -> atom_to_binary(A, utf8);
to_binary(L) when is_list(L)   -> list_to_binary(L).

%% handle_rag_turn/4 — Execute one RAG turn in a supervised worker process.
%%
%% This is the heart of the Erlang chatbot's fault-tolerance model.
%%
%% We use spawn_monitor/1 to create a new process for the RAG computation.
%% spawn_monitor/1 returns {Pid, MonitorRef}.  When the child process exits
%% (for any reason — normal, crash, timeout), we receive a DOWN message:
%%
%%   {'DOWN', MonitorRef, process, Pid, Reason}
%%
%% Reason is:
%%   normal            — computation completed successfully
%%   {rag_error, R}    — computation returned an error (captured by rag_worker_body)
%%   any other term    — unexpected crash
%%
%% In all non-normal cases we print "Retrying..." and spawn a fresh worker.
%% After MAX_RETRIES failures we give up and tell the user.
-spec handle_rag_turn(binary(), [map()], map(), [map()]) ->
    {ok, binary(), [map()]} | {error, term()}.
handle_rag_turn(Question, History, Config, LastChunks) ->
    handle_rag_turn(Question, History, Config, LastChunks, 3).

handle_rag_turn(_Question, _History, _Config, _LastChunks, 0) ->
    {error, <<"Too many failures — please check Ollama is running and retry.">>};
handle_rag_turn(Question, History, Config, PrevChunks, RetriesLeft) ->
    Self = self(),

    %% First, retrieve the context chunks (used for the "sources" command
    %% and to avoid re-embedding on retry).
    io:format("~n"),
    case query:vector_search(Question, Config, Config) of
        {error, SearchErr} ->
            {error, SearchErr};
        {ok, Chunks} ->
            %% Show sources before streaming the answer.
            io:format("Context sources:~n"),
            io:format("~s~n", [format_source_list(Chunks)]),
            io:format("Assistant: "),

            %% Spawn the RAG worker process.
            %%
            %% The key message: "!" is the send operator.  We send no message
            %% to the worker — instead we use monitor + DOWN message to know
            %% when the worker is done.  The worker sends {rag_done, ...} back
            %% to us, but since we monitor it, we can also detect crashes.
            %%
            %% This asymmetry is deliberate: the monitor fires even if the
            %% worker crashes before it can send {rag_done}.  A plain send/receive
            %% pattern would block forever if the worker crashed before replying.
            {_WorkerPid, MonRef} = spawn_monitor(fun() ->
                rag_worker_body(Question, History, Self, Config)
            end),

            %% Wait for the worker to finish or crash.
            receive
                %% Worker finished cleanly.  The DOWN message will also arrive
                %% (with reason 'normal') but we don't need to do anything with it.
                {rag_done, _Pid, FullResponse} ->
                    demonitor(MonRef, [flush]),
                    io:format("~n~n"),
                    {ok, FullResponse, Chunks};

                %% Worker crashed or exited abnormally.
                {'DOWN', MonRef, process, _Pid, Reason} ->
                    case Reason of
                        normal ->
                            %% The worker exited normally but sent no rag_done message.
                            %% This can happen if rag:answer returned ok but the message
                            %% was somehow lost. Very unlikely, but handle it gracefully.
                            io:format("~n~n"),
                            {ok, <<>>, Chunks};
                        _ ->
                            io:format("~n[turn crashed: ~p]~n", [Reason]),
                            io:format("Retrying your question...~n"),
                            handle_rag_turn(Question, History, Config, Chunks,
                                            RetriesLeft - 1)
                    end

            after 180000 ->
                %% 3-minute timeout per turn.  The worker may still be running;
                %% the demonitor cleans up the monitor reference.
                demonitor(MonRef, [flush]),
                io:format("~n[turn timed out]~n"),
                io:format("Retrying your question...~n"),
                handle_rag_turn(Question, History, Config, PrevChunks,
                                RetriesLeft - 1)
            end
    end.

%% chatbot_loop/3 — The main interactive loop.
%%
%% This is a tail-recursive function — each iteration calls itself at the end,
%% making the loop run indefinitely without consuming stack space.
%% Erlang optimises tail calls to jumps, so this loop can run for billions of
%% iterations without a stack overflow (unlike most recursive languages).
-spec chatbot_loop([map()], [map()], map()) -> ok.
chatbot_loop(History, LastChunks, Config) ->
    case io:get_line("> ") of
        eof ->
            io:format("~nGoodbye!~n");

        {error, _} ->
            io:format("~nGoodbye!~n");

        Line ->
            Input = string:trim(binary_to_list(list_to_binary(Line))),
            handle_input(Input, History, LastChunks, Config)
    end.

%% handle_input/4 — Dispatch on user input: commands or RAG question.
-spec handle_input(string(), [map()], [map()], map()) -> ok.
handle_input("", History, LastChunks, Config) ->
    chatbot_loop(History, LastChunks, Config);

handle_input(Cmd, _History, _LastChunks, _Config)
        when Cmd =:= "exit"; Cmd =:= "quit"; Cmd =:= "bye" ->
    io:format("~nGoodbye!~n");

handle_input("clear", _History, _LastChunks, Config) ->
    io:format("Conversation history cleared.~n~n"),
    chatbot_loop([], [], Config);

handle_input("sources", History, LastChunks, Config) ->
    case LastChunks of
        [] ->
            io:format("No sources retrieved yet.~n~n");
        _ ->
            io:format("~nLast retrieved sources:~n"),
            io:format("~s~n", [format_source_list(LastChunks)])
    end,
    chatbot_loop(History, LastChunks, Config);

handle_input("history", History, LastChunks, Config) ->
    case History of
        [] ->
            io:format("No conversation history yet.~n~n");
        _ ->
            io:format("~nConversation history (~p turn(s)):~n",
                      [length(History) div 2]),
            lists:foreach(
                fun(Msg) ->
                    Role    = maps:get(role,    Msg, <<"?">>),
                    Content = maps:get(content, Msg, <<>>),
                    Preview = binary:part(to_binary(Content), 0,
                                          min(120, byte_size(to_binary(Content)))),
                    io:format("  ~s: ~s~n", [Role, Preview])
                end,
                History
            ),
            io:format("~n")
    end,
    chatbot_loop(History, LastChunks, Config);

handle_input(Question, History, LastChunks, Config) ->
    QuestionBin = list_to_binary(Question),

    %% Handle this turn with a supervised worker process.
    %%
    %% If the worker crashes, handle_rag_turn retries up to 3 times.
    %% The conversation history is preserved here in the UI loop process
    %% and is never inside the worker — so a worker crash cannot corrupt
    %% or lose the conversation history.  This is the process isolation
    %% model paying dividends.
    case handle_rag_turn(QuestionBin, History, Config, []) of
        {ok, Response, NewChunks} ->
            NewHistory = trim_history(
                History ++
                [#{role => <<"user">>,      content => QuestionBin},
                 #{role => <<"assistant">>, content => Response}]
            ),
            chatbot_loop(NewHistory, NewChunks, Config);

        {error, Reason} ->
            io:format("[error] ~s~n~n", [Reason]),
            chatbot_loop(History, LastChunks, Config)
    end.

%% ---------------------------------------------------------------------------
%% Main entry point
%% ---------------------------------------------------------------------------

%% main/1 — The escript entry point for the interactive chatbot.
%%
%% Starts required OTP applications, verifies Ollama is reachable,
%% prints the banner, and enters the conversation loop.
-spec main([string()]) -> ok.
main(_Args) ->
    ok = application:start(crypto),
    ok = application:start(inets),
    ok = application:start(ssl),

    Config = rag_config:default_config(),

    %% Quick Ollama health check — fail fast with a friendly message
    %% rather than letting the first embed call fail with a confusing error.
    OllamaUrl = binary_to_list(rag_config:get(ollama_url, Config)),
    io:format("Checking Ollama availability at ~s ...~n", [OllamaUrl]),
    case httpc:request(get, {OllamaUrl ++ "/", []}, [{timeout, 5000}], []) of
        {ok, {{_, 200, _}, _, _}} ->
            io:format("Ollama ready.~n");
        _ ->
            io:format("[error] Ollama is not reachable at ~s~n", [OllamaUrl]),
            io:format("Please start it with:  ollama serve~n"),
            io:format("And ensure models are pulled:~n"),
            io:format("  ollama pull ~s~n",
                      [rag_config:get(embedding_model, Config)]),
            io:format("  ollama pull ~s~n",
                      [rag_config:get(chat_model, Config)]),
            halt(1)
    end,

    io:format("Database: ~s~n", [rag_config:get(turso_url, Config)]),
    print_banner(),

    chatbot_loop([], [], Config).

%% chatbot_worker is defined in its own file: src/chatbot_worker.erl
%% It provides start_link/0 for the rag_supervisor child specification.
