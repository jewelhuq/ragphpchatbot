%% turso_client.erl — The librarian who reads and writes to our vector database.
%%
%% Turso exposes a stateless HTTP API at /v2/pipeline.  Each request is a JSON
%% envelope containing one or more SQL statements; each statement carries typed
%% positional parameters.  The response mirrors that structure, with rows encoded
%% as arrays of {"type":"…","value":"…"} objects.
%%
%% We wrap all of that in two simple functions:
%%   execute/3   — fire-and-forget DDL / DML (CREATE TABLE, INSERT, DELETE, …)
%%   fetch_all/3 — SELECT queries that return rows as a list of maps
%%
%% JSON encoding is done entirely with io_lib:format/2 and manual string
%% building.  This keeps the dependency tree at zero — no jsone, no jiffy,
%% no jsx.  The trade-off is that the JSON builder only handles the subset
%% of JSON shapes that Turso's pipeline API actually needs, which is fine.
%%
%% HTTP is handled by httpc, which ships with Erlang/OTP in the inets
%% application.  We start inets once at the top of each escript's main/1.
%%
%% Erlang's concurrency model shines here: because every request is a
%% message-passing round-trip that blocks only the calling process, dozens
%% of parallel ingest workers can issue independent requests without any
%% shared locking or connection-pool management.  Each process owns its
%% request; no memory is shared.

-module(turso_client).
-export([execute/3, fetch_all/3]).

%% ---------------------------------------------------------------------------
%% Internal JSON helpers — manual builders for the Turso wire format
%% ---------------------------------------------------------------------------

%% encode_param/1 — Wrap a native Erlang value in a Turso typed-parameter object.
%%
%% Turso's pipeline API refuses raw JSON values as bind parameters.  Every
%% positional argument must be wrapped in an object like:
%%   {"type": "text",    "value": "hello"}
%%   {"type": "integer", "value": "42"}
%%   {"type": "float",   "value": 3.14}
%%   {"type": "null",    "value": null}
%%
%% We pattern-match on the Erlang type to select the right wrapper.
%% io_lib:format returns an iolist (a tree of strings), which httpc accepts
%% directly — no need to flatten to a binary before sending.
-spec encode_param(term()) -> iolist().
encode_param(null) ->
    <<"{"
      "\"type\":\"null\","
      "\"value\":null"
      "}">>;
encode_param(V) when is_integer(V) ->
    io_lib:format("{\"type\":\"integer\",\"value\":\"~b\"}", [V]);
encode_param(V) when is_float(V) ->
    io_lib:format("{\"type\":\"float\",\"value\":~f}", [V]);
encode_param(V) when is_binary(V) ->
    Escaped = escape_json_string(V),
    io_lib:format("{\"type\":\"text\",\"value\":\"~s\"}", [Escaped]);
encode_param(V) when is_list(V) ->
    %% Accept plain Erlang strings (lists of integers) as text parameters.
    encode_param(list_to_binary(V)).

%% escape_json_string/1 — Escape a binary so it is safe inside a JSON string.
%%
%% We only need to handle the characters that JSON absolutely requires
%% to be escaped: double quotes, backslashes, and control characters.
%% Everything else can pass through as-is because Turso's endpoint
%% communicates over UTF-8 HTTP and Erlang binaries are already bytes.
-spec escape_json_string(binary()) -> binary().
escape_json_string(Bin) ->
    escape_json_string(Bin, <<>>).

escape_json_string(<<>>, Acc) ->
    Acc;
escape_json_string(<<$", Rest/binary>>, Acc) ->
    escape_json_string(Rest, <<Acc/binary, $\\, $">>);
escape_json_string(<<$\\, Rest/binary>>, Acc) ->
    escape_json_string(Rest, <<Acc/binary, $\\, $\\>>);
escape_json_string(<<$\n, Rest/binary>>, Acc) ->
    escape_json_string(Rest, <<Acc/binary, $\\, $n>>);
escape_json_string(<<$\r, Rest/binary>>, Acc) ->
    escape_json_string(Rest, <<Acc/binary, $\\, $r>>);
escape_json_string(<<$\t, Rest/binary>>, Acc) ->
    escape_json_string(Rest, <<Acc/binary, $\\, $t>>);
escape_json_string(<<Byte, Rest/binary>>, Acc) ->
    escape_json_string(Rest, <<Acc/binary, Byte>>).

%% join_params/1 — Format a list of encoded parameters as a JSON array body.
-spec join_params([iolist()]) -> iolist().
join_params([]) ->
    <<"[]">>;
join_params(Encoded) ->
    [<<"[">>, lists:join(<<",">>, Encoded), <<"]">>].

%% build_pipeline_body/2 — Assemble the full /v2/pipeline request body.
%%
%% The Turso pipeline envelope wraps one or more SQL execute requests plus
%% a trailing "close" request that tells Turso to commit and release the
%% implicit transaction.  Using a single HTTP round-trip for this is both
%% faster and more correct than batching multiple requests.
-spec build_pipeline_body(binary(), [term()]) -> iolist().
build_pipeline_body(Sql, Params) ->
    EncodedParams = join_params([encode_param(P) || P <- Params]),
    EscapedSql    = escape_json_string(Sql),
    [
        <<"{\"requests\":["
          "{\"type\":\"execute\","
           "\"stmt\":{"
            "\"sql\":\"">>,
        EscapedSql,
        <<"\","
           "\"args\":">>,
        EncodedParams,
        <<"}},"
          "{\"type\":\"close\"}"
          "]}">>
    ].

%% ---------------------------------------------------------------------------
%% HTTP helpers
%% ---------------------------------------------------------------------------

%% pipeline_url/1 — Build the full /v2/pipeline endpoint URL.
-spec pipeline_url(map()) -> string().
pipeline_url(Config) ->
    Url = rag_config:get(turso_url, Config),
    binary_to_list(<<Url/binary, "/v2/pipeline">>).

%% auth_header/1 — Build the Authorization: Bearer … header tuple.
-spec auth_header(map()) -> {string(), string()}.
auth_header(Config) ->
    Token = rag_config:get(turso_token, Config),
    {"Authorization", binary_to_list(<<"Bearer ", Token/binary>>)}.

%% post_pipeline/2 — Fire one HTTP POST to /v2/pipeline and return the body.
%%
%% httpc is synchronous within the calling process: this function blocks until
%% the response arrives, then returns the body binary.  Other processes are
%% unaffected — they run concurrently without any shared lock or pool state.
-spec post_pipeline(iolist(), map()) -> {ok, binary()} | {error, term()}.
post_pipeline(Body, Config) ->
    Url     = pipeline_url(Config),
    Headers = [auth_header(Config)],
    BodyBin = iolist_to_binary(Body),
    case httpc:request(post,
                       {Url, Headers, "application/json", BodyBin},
                       [{timeout, 30000}],
                       [{body_format, binary}]) of
        {ok, {{_, 200, _}, _RespHeaders, RespBody}} ->
            {ok, RespBody};
        {ok, {{_, Status, _}, _RespHeaders, RespBody}} ->
            Msg = io_lib:format("Turso HTTP ~p: ~s", [Status, RespBody]),
            {error, iolist_to_binary(Msg)};
        {error, Reason} ->
            {error, Reason}
    end.

%% ---------------------------------------------------------------------------
%% Minimal JSON decoder — hand-rolled for the Turso response shape
%% ---------------------------------------------------------------------------
%%
%% We only ever decode Turso pipeline responses, which have a predictable
%% schema.  Rather than pulling in a full JSON library, we do targeted
%% extraction with binary pattern matching and a recursive descent parser
%% for the parts we need.
%%
%% This is idiomatic Erlang: binary pattern matching is extraordinarily fast,
%% and writing a small bespoke parser for a known schema is often cleaner than
%% fighting a general-purpose library's API.

%% check_for_errors/1 — Scan the JSON body for embedded Turso error objects.
%%
%% A successful Turso response looks like:
%%   {"results": [{"type": "ok", ...}, {"type": "ok", ...}]}
%% An error response looks like:
%%   {"results": [{"type": "error", "error": {"message": "..."}}]}
%%
%% We use a simple substring search rather than full JSON parsing because
%% we only care about the presence of "type\":\"error" and the message string.
-spec check_for_errors(binary()) -> ok | {error, binary()}.
check_for_errors(Body) ->
    case binary:match(Body, <<"\"type\":\"error\"">>) of
        nomatch ->
            ok;
        _ ->
            %% Extract the error message with a heuristic substring search.
            Msg = extract_error_message(Body),
            {error, Msg}
    end.

%% extract_error_message/1 — Pull the error message string out of the JSON body.
-spec extract_error_message(binary()) -> binary().
extract_error_message(Body) ->
    Key = <<"\"message\":\"">>,
    case binary:match(Body, Key) of
        nomatch ->
            <<"Turso returned an error (no message field)">>;
        {Start, Len} ->
            After = binary:part(Body, Start + Len, byte_size(Body) - Start - Len),
            extract_until_quote(After, <<>>)
    end.

extract_until_quote(<<>>, Acc) ->
    Acc;
extract_until_quote(<<$", _Rest/binary>>, Acc) ->
    Acc;
extract_until_quote(<<$\\, $", Rest/binary>>, Acc) ->
    extract_until_quote(Rest, <<Acc/binary, $">>);
extract_until_quote(<<Byte, Rest/binary>>, Acc) ->
    extract_until_quote(Rest, <<Acc/binary, Byte>>).

%% ---------------------------------------------------------------------------
%% Row parsing for fetch_all
%% ---------------------------------------------------------------------------
%%
%% Turso's fetch response has the shape (abbreviated):
%%   {
%%     "results": [{
%%       "type": "ok",
%%       "response": {
%%         "type": "execute",
%%         "result": {
%%           "cols": [{"name":"id","decltype":"INTEGER"}, ...],
%%           "rows": [[{"type":"text","value":"abc"}, ...], ...]
%%         }
%%       }
%%     }]
%%   }
%%
%% We extract the "cols" array (just the name strings) and the "rows" array
%% (list of lists of typed cells) and zip them together into a list of maps.

%% parse_response_rows/1 — Top-level decoder: body binary -> [{col, val}] maps.
-spec parse_response_rows(binary()) -> {ok, [map()]} | {error, binary()}.
parse_response_rows(Body) ->
    %% Locate the "cols" array and the "rows" array using substring anchors.
    case {find_cols(Body), find_rows_section(Body)} of
        {error, _} ->
            {ok, []};   % No cols means no result rows — treat as empty.
        {{ok, Cols}, {ok, RowsSection}} ->
            Rows = parse_rows(RowsSection, Cols),
            {ok, Rows};
        {{ok, _}, error} ->
            {ok, []}
    end.

%% find_cols/1 — Extract column names from the "cols" JSON array.
-spec find_cols(binary()) -> {ok, [binary()]} | error.
find_cols(Body) ->
    Key = <<"\"cols\":[">>,
    case binary:match(Body, Key) of
        nomatch ->
            error;
        {Start, Len} ->
            After = binary:part(Body, Start + Len, byte_size(Body) - Start - Len),
            Cols  = extract_col_names(After, []),
            {ok, Cols}
    end.

%% extract_col_names/2 — Walk the cols array and collect each "name" value.
extract_col_names(<<$], _Rest/binary>>, Acc) ->
    lists:reverse(Acc);
extract_col_names(<<>>, Acc) ->
    lists:reverse(Acc);
extract_col_names(Bin, Acc) ->
    Key = <<"\"name\":\"">>,
    case binary:match(Bin, Key) of
        nomatch ->
            lists:reverse(Acc);
        {Start, Len} ->
            After  = binary:part(Bin, Start + Len, byte_size(Bin) - Start - Len),
            Name   = extract_until_quote(After, <<>>),
            NameLen = byte_size(Name),
            %% Skip past this name and continue scanning for more.
            Skip   = Start + Len + NameLen + 1,
            if Skip < byte_size(Bin) ->
                Rest = binary:part(Bin, Skip, byte_size(Bin) - Skip),
                extract_col_names(Rest, [Name | Acc]);
            true ->
                lists:reverse([Name | Acc])
            end
    end.

%% find_rows_section/1 — Locate the start of the "rows":[ content.
-spec find_rows_section(binary()) -> {ok, binary()} | error.
find_rows_section(Body) ->
    Key = <<"\"rows\":[">>,
    case binary:match(Body, Key) of
        nomatch ->
            error;
        {Start, Len} ->
            After = binary:part(Body, Start + Len, byte_size(Body) - Start - Len),
            {ok, After}
    end.

%% parse_rows/2 — Convert the raw rows JSON section into a list of maps.
%%
%% Each row in Turso's response is a JSON array of typed cells:
%%   [{"type":"text","value":"hello"}, {"type":"integer","value":"42"}, ...]
%%
%% We scan for each "value" field and pair it with the corresponding column
%% name from Cols.  The result is a plain Erlang map:
%%   #{ <<"id">> => <<"42">>, <<"content">> => <<"hello">> }
-spec parse_rows(binary(), [binary()]) -> [map()].
parse_rows(Bin, Cols) ->
    parse_rows(Bin, Cols, []).

parse_rows(<<$], _Rest/binary>>, _Cols, Acc) ->
    lists:reverse(Acc);
parse_rows(<<>>, _Cols, Acc) ->
    lists:reverse(Acc);
parse_rows(Bin, Cols, Acc) ->
    %% Each row starts with "[[" (first row) or ",["
    case find_row_start(Bin) of
        {ok, RowBin, RestBin} ->
            Row = parse_single_row(RowBin, Cols),
            parse_rows(RestBin, Cols, [Row | Acc]);
        nomatch ->
            lists:reverse(Acc)
    end.

%% find_row_start/1 — Find the next "[" that opens a row's cell array.
find_row_start(Bin) ->
    case binary:match(Bin, <<"[">>) of
        nomatch ->
            nomatch;
        {Start, 1} ->
            After = binary:part(Bin, Start + 1, byte_size(Bin) - Start - 1),
            {End, _} = find_matching_bracket(After, 0),
            RowBin  = binary:part(After, 0, End),
            RestBin = binary:part(After, End + 1, byte_size(After) - End - 1),
            {ok, RowBin, RestBin}
    end.

%% find_matching_bracket/2 — Find the position of the closing "]" for a row.
find_matching_bracket(Bin, Depth) ->
    find_matching_bracket(Bin, Depth, 0).

find_matching_bracket(<<$[, Rest/binary>>, Depth, Pos) ->
    find_matching_bracket(Rest, Depth + 1, Pos + 1);
find_matching_bracket(<<$], _Rest/binary>>, 0, Pos) ->
    {Pos, 0};
find_matching_bracket(<<$], Rest/binary>>, Depth, Pos) when Depth > 0 ->
    find_matching_bracket(Rest, Depth - 1, Pos + 1);
find_matching_bracket(<<_, Rest/binary>>, Depth, Pos) ->
    find_matching_bracket(Rest, Depth, Pos + 1);
find_matching_bracket(<<>>, _Depth, Pos) ->
    {Pos, 0}.

%% parse_single_row/2 — Turn one row's JSON array into a map keyed by column name.
-spec parse_single_row(binary(), [binary()]) -> map().
parse_single_row(RowBin, Cols) ->
    Cells = extract_cell_values(RowBin, []),
    zip_cols_cells(Cols, Cells, #{}).

%% extract_cell_values/2 — Pull the "value" string from each cell object in a row.
extract_cell_values(<<>>, Acc) ->
    lists:reverse(Acc);
extract_cell_values(Bin, Acc) ->
    %% Cells that are null have "type":"null" and no "value" field — return null atom.
    NullKey = <<"\"type\":\"null\"">>,
    ValueKey = <<"\"value\":\"">>,
    ValueNumKey = <<"\"value\":">>,
    case binary:match(Bin, [NullKey, ValueKey]) of
        nomatch ->
            %% Try numeric value (integer or float — no quotes around value)
            case binary:match(Bin, ValueNumKey) of
                nomatch ->
                    lists:reverse(Acc);
                {Start, Len} ->
                    After = binary:part(Bin, Start + Len, byte_size(Bin) - Start - Len),
                    {Val, RestBin} = extract_numeric_value(After),
                    extract_cell_values(RestBin, [Val | Acc])
            end;
        {Start, _MatchLen} ->
            Slice = binary:part(Bin, Start, byte_size(Bin) - Start),
            case binary:match(Slice, NullKey) of
                {0, _} ->
                    %% This cell is null
                    Skip = byte_size(NullKey),
                    Rest = binary:part(Bin, Start + Skip, byte_size(Bin) - Start - Skip),
                    extract_cell_values(Rest, [null | Acc]);
                _ ->
                    %% This cell has a string value
                    case binary:match(Bin, ValueKey) of
                        nomatch ->
                            lists:reverse(Acc);
                        {VS, VL} ->
                            After  = binary:part(Bin, VS + VL, byte_size(Bin) - VS - VL),
                            Val    = extract_until_quote(After, <<>>),
                            ValLen = byte_size(Val),
                            Skip   = VS + VL + ValLen + 1,
                            Rest   = if Skip < byte_size(Bin) ->
                                            binary:part(Bin, Skip, byte_size(Bin) - Skip);
                                        true -> <<>>
                                     end,
                            extract_cell_values(Rest, [Val | Acc])
                    end
            end
    end.

%% extract_numeric_value/1 — Read a JSON number (no surrounding quotes).
extract_numeric_value(Bin) ->
    extract_numeric_value(Bin, <<>>).

extract_numeric_value(<<>>, Acc) ->
    {Acc, <<>>};
extract_numeric_value(<<$,, Rest/binary>>, Acc) ->
    {Acc, Rest};
extract_numeric_value(<<$}, Rest/binary>>, Acc) ->
    {Acc, <<$}, Rest/binary>>};
extract_numeric_value(<<$], Rest/binary>>, Acc) ->
    {Acc, <<$], Rest/binary>>};
extract_numeric_value(<<Byte, Rest/binary>>, Acc) ->
    extract_numeric_value(Rest, <<Acc/binary, Byte>>).

%% zip_cols_cells/3 — Pair column names with cell values into a map.
zip_cols_cells([], _Cells, Map) ->
    Map;
zip_cols_cells(_Cols, [], Map) ->
    Map;
zip_cols_cells([Col | RestCols], [Cell | RestCells], Map) ->
    zip_cols_cells(RestCols, RestCells, Map#{Col => Cell}).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% execute/3 — Run a SQL statement and ignore the result rows.
%%
%% Perfect for DDL (CREATE TABLE) or DML (INSERT, UPDATE, DELETE) where
%% we only care about success or failure.
%%
%% This function sends one HTTP request and blocks until the response arrives.
%% Other Erlang processes run concurrently — there is no thread or lock.
-spec execute(binary(), [term()], map()) -> ok | {error, term()}.
execute(Sql, Params, Config) ->
    Body = build_pipeline_body(Sql, Params),
    case post_pipeline(Body, Config) of
        {ok, RespBody} ->
            case check_for_errors(RespBody) of
                ok          -> ok;
                {error, Msg} -> {error, Msg}
            end;
        {error, Reason} ->
            {error, Reason}
    end.

%% fetch_all/3 — Run a SELECT and return all rows as a list of maps.
%%
%% Each map has binary column names as keys and binary (or null atom) values.
%% Example return:
%%   {ok, [#{<<"id">> => <<"1">>, <<"content">> => <<"hello world">>}]}
-spec fetch_all(binary(), [term()], map()) -> {ok, [map()]} | {error, term()}.
fetch_all(Sql, Params, Config) ->
    Body = build_pipeline_body(Sql, Params),
    case post_pipeline(Body, Config) of
        {ok, RespBody} ->
            case check_for_errors(RespBody) of
                {error, Msg} ->
                    {error, Msg};
                ok ->
                    parse_response_rows(RespBody)
            end;
        {error, Reason} ->
            {error, Reason}
    end.
