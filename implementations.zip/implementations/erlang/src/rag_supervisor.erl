%% rag_supervisor.erl — The guardian that makes the chatbot unkillable.
%%
%% This module demonstrates Erlang's OTP Supervisor behaviour, the mechanism
%% that makes Erlang systems self-healing.
%%
%% In most languages, if a critical function throws an exception, the program
%% either crashes or you wrap everything in try/catch and hope for the best.
%%
%% Erlang takes a different approach:
%%   1. Let the worker process crash cleanly.
%%   2. The supervisor detects the crash via process monitoring.
%%   3. The supervisor restarts a fresh worker automatically.
%%   4. The user sees "retrying..." instead of a stack trace.
%%
%% This is the "let it crash" philosophy with a safety net.
%%
%% The supervisor tree for our chatbot:
%%
%%   rag_supervisor (one_for_one)
%%        |
%%        +-- chatbot_worker (permanent, restart on any exit)
%%
%% one_for_one means: if the worker dies, restart only that worker.
%% Other strategies (one_for_all, rest_for_one) exist for interdependent
%% processes where one failure should cascade.
%%
%% Real-world example: WhatsApp's supervisor tree.
%% Each user's messaging session is a supervised worker.  Millions of them.
%% If your session process crashes (malformed message, memory spike, anything),
%% the supervisor restarts it.  You briefly disconnect and reconnect.  The
%% system does not go down.  This is how 9 engineers serve 2 billion users.

-module(rag_supervisor).
-behaviour(supervisor).

-export([start_link/0, init/1]).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% start_link/0 — Start the supervisor and link it to the calling process.
%%
%% Linking means: if the supervisor itself crashes (which should not happen
%% in normal operation), the linked process also dies.  This creates a
%% crash-propagation chain that eventually reaches the top-level process,
%% which can make the decision to halt or restart the whole application.
%%
%% In our chatbot, we call this from chatbot.erl's main/1.  If the supervisor
%% dies, the escript exits cleanly rather than hanging.
-spec start_link() -> {ok, pid()} | {error, term()}.
start_link() ->
    supervisor:start_link({local, ?MODULE}, ?MODULE, []).

%% init/1 — Called by the supervisor framework to get the child specification.
%%
%% The return value has two parts:
%%
%%   SupFlags: #{strategy, intensity, period}
%%     strategy  — one_for_one: restart only the crashed child.
%%     intensity — max restarts in the given period before giving up.
%%     period    — the window (in seconds) for counting restart intensity.
%%
%%   ChildSpecs: a list of child specifications.
%%     Each spec tells the supervisor how to start, identify, and restart a child.
%%
%% We use one child: the chatbot worker process.
%%
%% The worker is marked 'transient' here to illustrate the concept:
%% transient means restart only on abnormal exit (crash), not on normal exit
%% (when the user types "exit").  For a permanent process, use 'permanent'.
-spec init([]) -> {ok, {supervisor:sup_flags(), [supervisor:child_spec()]}}.
init([]) ->
    %% Supervisor flags:
    %%   strategy  = one_for_one (restart only the failing child)
    %%   intensity = 10 restarts
    %%   period    = 60 seconds
    %% If the worker crashes more than 10 times in 60 seconds, the supervisor
    %% itself gives up and exits — this prevents infinite restart loops when
    %% the problem is structural (e.g. wrong token, Ollama not running).
    SupFlags = #{
        strategy  => one_for_one,
        intensity => 10,
        period    => 60
    },

    %% Child specification for the chatbot worker.
    %%
    %% id:       the internal name the supervisor uses to identify this child.
    %% start:    {Module, Function, Args} — how to start the child.
    %% restart:  transient — only restart on crash, not on normal exit.
    %% shutdown: 5000ms — wait up to 5 seconds for clean shutdown.
    %% type:     worker — as opposed to supervisor (this is a leaf process).
    %% modules:  which modules the child uses (for hot-code upgrade support).
    ChatbotWorkerSpec = #{
        id       => chatbot_worker,
        start    => {chatbot_worker, start_link, []},
        restart  => transient,
        shutdown => 5000,
        type     => worker,
        modules  => [chatbot_worker]
    },

    {ok, {SupFlags, [ChatbotWorkerSpec]}}.

%% ---------------------------------------------------------------------------
%% Supervisor utilities
%% ---------------------------------------------------------------------------

%% restart_worker/0 — Manually trigger a worker restart (useful for testing).
%%
%% In normal operation the supervisor restarts automatically; this function
%% is here for demonstration and testing purposes.
-spec restart_worker() -> ok | {error, term()}.
restart_worker() ->
    case supervisor:terminate_child(?MODULE, chatbot_worker) of
        ok ->
            case supervisor:restart_child(?MODULE, chatbot_worker) of
                {ok, _Pid} -> ok;
                {error, Reason} -> {error, Reason}
            end;
        {error, Reason} ->
            {error, Reason}
    end.

%% child_pids/0 — Return the PIDs of all currently running children.
%%
%% Useful for introspection and debugging.  In the Erlang shell:
%%   rag_supervisor:child_pids().
-spec child_pids() -> [pid()].
child_pids() ->
    Children = supervisor:which_children(?MODULE),
    [ Pid || {_Id, Pid, _Type, _Modules} <- Children, is_pid(Pid) ].
