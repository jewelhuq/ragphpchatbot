%% rag.erl — Where retrieval meets generation.
%%
%% This module is the bridge between the vector database and the language model.
%% Its job is simple but critical: take a user's question, find the most relevant
%% chunks of source material, build a carefully structured prompt that tells the
%% model what it is allowed to say and what it must not invent, then stream the
%% answer back to the caller.
%%
%% The system prompt design follows a few deliberate anti-hallucination rules:
%%
%%   1. Explicit grounding.  The model is told it must only use the provided
%%      context and must never draw on its training knowledge for factual claims.
%%
%%   2. Numbered sources.  Each context chunk is presented as [1], [2], etc.
%%      The model is instructed to cite sources by number, which forces it to
%%      trace each claim back to a specific retrieved chunk.
%%
%%   3. Honest ignorance.  If the retrieved chunks do not contain enough
%%      information, the model is told to say so.  "I don't know based on the
%%      provided documents" is a correct answer; a confident hallucination is not.
%%
%%   4. Short, direct answers.  The model is nudged toward concise responses
%%      rather than padded prose, which suits the limited context window of
%%      small local models like gemma3:1b.
%%
%% This module also exports answer/4 so chatbot.erl can reuse the RAG pipeline
%% without duplicating the prompt-building and streaming logic.

-module(rag).
-export([main/1, answer/4]).

%% ---------------------------------------------------------------------------
%% Prompt construction
%% ---------------------------------------------------------------------------

-define(SYSTEM_PROMPT_TEMPLATE,
    "You are a helpful research assistant with access to a curated document collection.\n"
    "\n"
    "INSTRUCTIONS:\n"
    "1. Answer the user's question using ONLY the information in the numbered context chunks below.\n"
    "2. Do NOT use your training knowledge for any factual claims — only use what is in the context.\n"
    "3. Cite the source number(s) after each factual statement, e.g. \"The sky is blue [1].\"\n"
    "4. If the context does not contain enough information to answer the question, say:\n"
    "   \"I don't have enough information in the provided documents to answer that.\"\n"
    "5. Keep your answer concise and direct. Avoid padding or repetition.\n"
    "6. If multiple chunks support the same point, cite all relevant ones.\n"
    "\n"
    "CONTEXT:\n"
    "~s\n"
    "\n"
    "Remember: only use information from the context above. Do not invent facts."
).

%% build_context_block/1 — Format retrieved chunks into a numbered context block.
%%
%% Each chunk is preceded by its citation number [N] and source filename.
%% The content follows, separated by a horizontal rule.
%% This format helps the model clearly see where one source ends and another begins.
-spec build_context_block([map()]) -> binary().
build_context_block([]) ->
    <<"(no context retrieved)">>;
build_context_block(Chunks) ->
    Parts = lists:map(
        fun({N, Chunk}) ->
            Source  = maps:get(<<"source">>,  Chunk, <<"unknown">>),
            Content = maps:get(<<"content">>, Chunk, <<>>),
            Display = list_to_binary(filename:basename(binary_to_list(to_binary(Source)))),
            io_lib:format("[~p] Source: ~s~n~s", [N, Display, to_binary(Content)])
        end,
        lists:zip(lists:seq(1, length(Chunks)), Chunks)
    ),
    iolist_to_binary(lists:join("\n\n---\n\n", Parts)).

%% build_system_prompt/1 — Inject the context block into the system prompt template.
-spec build_system_prompt([map()]) -> binary().
build_system_prompt(Chunks) ->
    ContextBlock = build_context_block(Chunks),
    Formatted    = io_lib:format(?SYSTEM_PROMPT_TEMPLATE, [ContextBlock]),
    iolist_to_binary(Formatted).

%% to_binary/1 — Coerce various types to binary for uniform handling.
to_binary(B) when is_binary(B) -> B;
to_binary(null)                 -> <<>>;
to_binary(A) when is_atom(A)   -> atom_to_binary(A, utf8);
to_binary(L) when is_list(L)   -> list_to_binary(L).

%% ---------------------------------------------------------------------------
%% Public API
%% ---------------------------------------------------------------------------

%% answer/4 — The full RAG pipeline: retrieve, prompt, generate, stream.
%%
%% This function orchestrates the three-phase RAG cycle:
%%
%%   Phase 1 — Retrieve: embed the question, search the vector index, get the
%%             top_k most relevant chunks.
%%
%%   Phase 2 — Augment: build a system prompt that injects the retrieved chunks
%%             as numbered sources, with anti-hallucination instructions.
%%
%%   Phase 3 — Generate: send the augmented prompt + conversation history to
%%             the LLM and stream the response token-by-token via OnChunk.
%%
%% Parameters:
%%   Question — the user's question as a binary
%%   History  — prior conversation turns as a list of #{role, content} maps
%%   OnChunk  — a fun/1 called with each generated token binary
%%   Config   — the configuration map
%%
%% Returns ok on success, {error, Reason} on any failure.
-spec answer(binary(), [map()], fun((binary()) -> ok), map()) -> ok | {error, term()}.
answer(Question, History, OnChunk, Config) ->
    %% Phase 1: Retrieve
    case query:vector_search(Question, Config, Config) of
        {error, EmbedErr} ->
            {error, EmbedErr};

        {ok, []} ->
            %% No chunks found — tell the user honestly.
            Msg = <<"I don't have enough information in the provided documents to answer that. "
                    "Please run rag_ingest to populate the knowledge base.">>,
            OnChunk(Msg),
            ok;

        {ok, Chunks} ->
            %% Phase 2: Augment — build the system prompt
            SystemPrompt = build_system_prompt(Chunks),

            %% Build the messages list: system message + history + current question.
            SystemMsg = #{role => <<"system">>, content => SystemPrompt},
            UserMsg   = #{role => <<"user">>,   content => Question},
            Messages  = [SystemMsg] ++ History ++ [UserMsg],

            %% Phase 3: Generate — stream the response
            ollama_client:chat_stream(Messages, OnChunk, Config)
    end.

%% ---------------------------------------------------------------------------
%% Main entry point
%% ---------------------------------------------------------------------------

%% main/1 — The escript entry point for one-shot RAG queries.
%%
%% Usage:
%%   ./rag_rag "What does the document say about X?"
%%
%% Prints retrieved chunk sources first (for transparency), then streams the
%% generated answer to stdout.
-spec main([string()]) -> ok.
main([]) ->
    io:format("Usage: rag_rag <question>~n"),
    io:format("Example: rag_rag \"What is the refund policy?\"~n"),
    halt(1);
main(Args) ->
    ok = application:start(crypto),
    ok = application:start(inets),
    ok = application:start(ssl),

    Config   = rag_config:default_config(),
    Question = list_to_binary(string:join(Args, " ")),

    io:format("~nQuestion: ~s~n", [Question]),
    io:format("~n-----------------------------------------------------------------~n"),
    io:format("Retrieving relevant context ...~n"),

    %% Show the retrieved sources first so the user can judge retrieval quality.
    case query:vector_search(Question, Config, Config) of
        {error, Reason} ->
            io:format("[error] ~p~n", [Reason]),
            halt(1);
        {ok, Chunks} ->
            case Chunks of
                [] ->
                    io:format("No relevant context found. Have you run rag_ingest?~n");
                _ ->
                    io:format("Using ~p context chunk(s):~n", [length(Chunks)]),
                    lists:foreach(
                        fun({N, C}) ->
                            Src   = maps:get(<<"source">>, C, <<"unknown">>),
                            Score = maps:get(<<"score">>,  C, 0.0),
                            Display = filename:basename(binary_to_list(to_binary(Src))),
                            io:format("  [~p] ~s  (score: ~.3f)~n", [N, Display, Score])
                        end,
                        lists:zip(lists:seq(1, length(Chunks)), Chunks)
                    )
            end,

            io:format("~nAnswer:~n"),
            io:format("-----------------------------------------------------------------~n"),

            %% Stream the answer token by token.
            PrintChunk = fun(Token) ->
                io:put_chars(Token),
                ok
            end,

            case answer(Question, [], PrintChunk, Config) of
                ok ->
                    io:format("~n-----------------------------------------------------------------~n");
                {error, GenErr} ->
                    io:format("~n[generation error] ~p~n", [GenErr]),
                    halt(1)
            end
    end,
    halt(0).
