%% ingest.erl — The pipeline that turns raw documents into searchable knowledge.
%%
%% Running this escript is the first step before any queries can be answered.
%% It walks the docs/ directory, reads every supported .txt file, slices the
%% text into chunks, converts each chunk into a vector embedding, and writes
%% everything to Turso so the retrieval step can find it later.
%%
%% The Erlang philosophy shines brightest here.
%%
%% In Python or Java, you would wrap the per-file loop in try/except and hope
%% you caught everything.  In Erlang, each file is ingested in its OWN process.
%% If that process crashes — malformed file, network blip, embedding error,
%% anything — only that process dies.  The supervisor loop keeps running.
%% The next file gets its own fresh process.  No global state is corrupted.
%%
%%   "Let it crash" is not negligence.  It is a design decision: process
%%   isolation IS the error boundary.  You don't need try/catch everywhere
%%   because the crash cannot propagate beyond the process.
%%
%% This is how WhatsApp serves 2 billion users with 9 engineers: each
%% conversation is an isolated process.  Crashes are contained; supervisors
%% restart; the system self-heals.
%%
%% Process model used here:
%%   main/1
%%     -> spawn(ingest_file_process, [FilePath, Config]) per file
%%     -> wait for all processes to finish (collect_results)
%%
%% No shared memory, no locks, no mutexes.  Each process owns its own state.
%% Messages carry data between processes; the data is copied on send, so
%% the sender and receiver can never alias the same memory.

-module(ingest).
-export([main/1]).

%% ---------------------------------------------------------------------------
%% SQL schema constants
%% ---------------------------------------------------------------------------

-define(CREATE_FILES_TABLE,
    <<"CREATE TABLE IF NOT EXISTS rag_files ("
      "  id       INTEGER PRIMARY KEY AUTOINCREMENT,"
      "  path     TEXT    NOT NULL UNIQUE,"
      "  md5      TEXT    NOT NULL,"
      "  ingested INTEGER NOT NULL DEFAULT 0"
      ")">>).

-define(CREATE_CHUNKS_TABLE,
    <<"CREATE TABLE IF NOT EXISTS rag_chunks ("
      "  id        INTEGER PRIMARY KEY AUTOINCREMENT,"
      "  file_id   INTEGER NOT NULL REFERENCES rag_files(id),"
      "  chunk_idx INTEGER NOT NULL,"
      "  content   TEXT    NOT NULL,"
      "  embedding F32_BLOB(768)"
      ")">>).

-define(CREATE_VECTOR_INDEX,
    <<"CREATE INDEX IF NOT EXISTS rag_chunks_vec "
      "ON rag_chunks (libsql_vector_idx(embedding))">>).

%% ---------------------------------------------------------------------------
%% Schema management
%% ---------------------------------------------------------------------------

%% ensure_schema/1 — Create database tables and vector index if they do not exist.
%%
%% CREATE TABLE IF NOT EXISTS makes this safe to call on every run.
%% The vector index uses Turso's libsql_vector_idx() extension which builds
%% an HNSW (Hierarchical Navigable Small World) index for sub-linear ANN search.
-spec ensure_schema(map()) -> ok.
ensure_schema(Config) ->
    io:format("Ensuring database schema ...~n"),
    ok = turso_client:execute(?CREATE_FILES_TABLE, [], Config),
    ok = turso_client:execute(?CREATE_CHUNKS_TABLE, [], Config),
    case turso_client:execute(?CREATE_VECTOR_INDEX, [], Config) of
        ok ->
            ok;
        {error, Reason} ->
            %% The index may already exist — this is safe to ignore.
            io:format("  [warn] Vector index: ~p~n", [Reason])
    end,
    io:format("Schema ready.~n"),
    ok.

%% ---------------------------------------------------------------------------
%% File discovery
%% ---------------------------------------------------------------------------

%% discover_files/1 — Walk a directory tree and return all .txt file paths.
%%
%% filelib:wildcard/1 is the idiomatic Erlang way to enumerate files matching
%% a glob pattern.  It is eager (returns a list), fast, and handles nested
%% directories automatically when you use "**".
-spec discover_files(string()) -> [string()].
discover_files(DocsDir) ->
    Pattern = filename:join(DocsDir, "**/*.txt"),
    Txt     = filelib:wildcard(Pattern),
    MdPat   = filename:join(DocsDir, "**/*.md"),
    Md      = filelib:wildcard(MdPat),
    lists:sort(Txt ++ Md).

%% ---------------------------------------------------------------------------
%% MD5 hashing for change detection
%% ---------------------------------------------------------------------------

%% md5_file/1 — Compute the MD5 hex digest of a file's contents.
%%
%% MD5 is not cryptographically secure, but that is irrelevant here — we use
%% it purely as a fast change-detection fingerprint.  Two identical files
%% always produce the same digest; any byte-level change produces a different one.
-spec md5_file(string()) -> binary().
md5_file(Path) ->
    {ok, Bytes} = file:read_file(Path),
    Digest = crypto:hash(md5, Bytes),
    iolist_to_binary(
        [ io_lib:format("~2.16.0b", [B]) || <<B>> <= Digest ]
    ).

%% ---------------------------------------------------------------------------
%% Vector literal formatting
%% ---------------------------------------------------------------------------

%% vec_to_literal/1 — Format a float list as the string Turso's vector32() expects.
%%
%% Turso stores embeddings as binary blobs created by vector32('[1.0,2.0,...]').
%% The argument must be a JSON array of floats formatted as a string.
-spec vec_to_literal([float()]) -> binary().
vec_to_literal(Vec) ->
    Parts = [io_lib:format("~f", [F]) || F <- Vec],
    iolist_to_binary([<<"[">>, lists:join(<<",">>, Parts), <<"]">>]).

%% ---------------------------------------------------------------------------
%% Per-file ingestion — "let it crash" edition
%% ---------------------------------------------------------------------------

%% ingest_file_process/2 — Ingest one file, then send a result message to Parent.
%%
%% This function is the body of a spawned process.  Every file gets its own
%% isolated process.  If anything goes wrong — network error, parse failure,
%% embedding timeout — only THIS process crashes.  The parent process (which
%% is collecting results via receive) simply records it as a failure and
%% continues with the next file.
%%
%% This is the "let it crash" philosophy in action:
%%   - We do NOT wrap everything in try/catch.
%%   - We DO isolate the work so a crash has minimal blast radius.
%%   - We trust the process model to contain failures.
-spec ingest_file_process(string(), map()) -> ok.
ingest_file_process(FilePath, Config) ->
    FileName = filename:basename(FilePath),
    io:format("~n  Processing: ~s~n", [FileName]),

    %% Step 1: Hash the file for change detection
    CurrentMd5 = md5_file(FilePath),

    %% Step 2: Look up this file in the database
    {ok, Existing} = turso_client:fetch_all(
        <<"SELECT id, md5 FROM rag_files WHERE path = ?">>,
        [list_to_binary(FilePath)],
        Config
    ),

    FileId = case Existing of
        [Row | _] ->
            Id       = maps:get(<<"id">>, Row),
            StoredMd5 = maps:get(<<"md5">>, Row),
            if StoredMd5 =:= CurrentMd5 ->
                io:format("  [skip] ~s — unchanged (MD5 matches)~n", [FileName]),
                exit(skipped);
            true ->
                io:format("  [update] ~s — content changed, re-ingesting ...~n", [FileName]),
                ok = turso_client:execute(
                    <<"DELETE FROM rag_chunks WHERE file_id = ?">>,
                    [Id], Config
                ),
                ok = turso_client:execute(
                    <<"UPDATE rag_files SET md5 = ?, ingested = 0 WHERE id = ?">>,
                    [CurrentMd5, Id], Config
                ),
                Id
            end;
        [] ->
            %% Brand new file: create a record.
            ok = turso_client:execute(
                <<"INSERT INTO rag_files (path, md5, ingested) VALUES (?, ?, 0)">>,
                [list_to_binary(FilePath), CurrentMd5],
                Config
            ),
            {ok, [NewRow | _]} = turso_client:fetch_all(
                <<"SELECT id FROM rag_files WHERE path = ?">>,
                [list_to_binary(FilePath)],
                Config
            ),
            io:format("  [new] ~s — ingesting for the first time ...~n", [FileName]),
            maps:get(<<"id">>, NewRow)
    end,

    %% Step 3: Parse the document
    {ok, Text} = parser:parse(list_to_binary(FilePath)),

    if byte_size(Text) =:= 0 ->
        io:format("  [warn] ~s produced no text — skipping~n", [FileName]),
        exit(empty_file);
    true -> ok
    end,

    io:format("  Parsed ~p characters~n", [byte_size(Text)]),

    %% Step 4: Chunk the text
    Source    = list_to_binary(filename:rootname(FileName)),
    ChunkSize = rag_config:get(chunk_size, Config),
    Chunks    = chunker:chunk(Text, Source, ChunkSize),

    io:format("  Split into ~p chunks~n", [length(Chunks)]),

    if Chunks =:= [] ->
        io:format("  [warn] No chunks produced for ~s~n", [FileName]),
        exit(no_chunks);
    true -> ok
    end,

    %% Step 5: Embed each chunk and insert into Turso
    %%
    %% We embed sequentially within this file's process.  Files themselves
    %% run in parallel (each in its own spawned process), so multiple files
    %% are embedded concurrently.  Within a file, sequential embedding is
    %% simpler and avoids hammering Ollama with too many simultaneous requests.
    Inserted = lists:foldl(
        fun({Idx, ChunkText}, Count) ->
            case ollama_client:embed(ChunkText, Config) of
                {ok, Vec} ->
                    VecLit = vec_to_literal(Vec),
                    ok = turso_client:execute(
                        <<"INSERT INTO rag_chunks (file_id, chunk_idx, content, embedding) "
                          "VALUES (?, ?, ?, vector32(?))">>,
                        [FileId, Idx, ChunkText, VecLit],
                        Config
                    ),
                    if (Idx + 1) rem 10 =:= 0 ->
                        io:format("  Embedded ~p/~p chunks ...~n",
                                  [Idx + 1, length(Chunks)]);
                    true -> ok
                    end,
                    Count + 1;
                {error, Reason} ->
                    io:format("  [error] Embedding chunk ~p: ~p~n", [Idx, Reason]),
                    Count
            end
        end,
        0,
        lists:zip(lists:seq(0, length(Chunks) - 1), Chunks)
    ),

    %% Mark the file as fully ingested
    ok = turso_client:execute(
        <<"UPDATE rag_files SET ingested = 1 WHERE id = ?">>,
        [FileId],
        Config
    ),
    io:format("  Done: inserted ~p chunks for ~s~n", [Inserted, FileName]),
    ok.

%% ---------------------------------------------------------------------------
%% Parallel file ingestion with process-per-file isolation
%% ---------------------------------------------------------------------------

%% ingest_files_parallel/2 — Spawn one process per file, collect results.
%%
%% spawn/1 creates a brand new Erlang process.  The new process runs
%% ingest_file_process/2 completely independently — it has its own heap,
%% its own mailbox, its own call stack.  No memory is shared with the parent.
%%
%% The parent sends a message to itself (using !) and waits.  Actually, we
%% use process monitoring: spawn_monitor/1 returns a monitor reference.
%% When the child process exits (normally or with a crash), the parent receives
%% a {'DOWN', Ref, process, Pid, Reason} message.  We collect one DOWN message
%% per spawned file and then return.
%%
%% This is Erlang's message-passing and monitoring model in a nutshell.
-spec ingest_files_parallel([string()], map()) -> {ok, non_neg_integer(), non_neg_integer()}.
ingest_files_parallel(Files, Config) ->
    Self = self(),
    %% Spawn a monitoring process per file.
    Monitors = [ begin
                     {Pid, Ref} = spawn_monitor(fun() ->
                         ingest_file_process_wrapper(FilePath, Config, Self)
                     end),
                     {Pid, Ref, FilePath}
                 end
                 || FilePath <- Files ],

    %% Collect one DOWN message per file.
    collect_results(Monitors, 0, 0).

%% ingest_file_process_wrapper/3 — Wrapper that catches exits and reports back.
%%
%% spawn_monitor already delivers a DOWN message on any exit, so this wrapper
%% simply runs ingest_file_process and lets any exception propagate naturally.
%% The monitor catches it and sends the DOWN message.
%%
%% The key insight: exceptions in the child do NOT affect the parent.
%% The parent only receives a message.  Messages cannot crash the receiver.
ingest_file_process_wrapper(FilePath, Config, _Parent) ->
    ingest_file_process(FilePath, Config).

%% collect_results/3 — Wait for all spawned file processes to finish.
%%
%% The receive ... end block is Erlang's selective message receive.
%% It blocks the current process until a matching message arrives in the
%% mailbox.  Non-matching messages remain in the mailbox for later receives.
%%
%% This is fundamentally different from polling or callbacks:
%%   - No busy waiting.
%%   - No callback registration.
%%   - No thread pool.
%% Just: "I will block here until the message I care about arrives."
-spec collect_results([{pid(), reference(), string()}],
                      non_neg_integer(), non_neg_integer())
    -> {ok, non_neg_integer(), non_neg_integer()}.
collect_results([], Ok, Failed) ->
    {ok, Ok, Failed};
collect_results([{_Pid, Ref, FilePath} | Rest], Ok, Failed) ->
    receive
        {'DOWN', Ref, process, _, normal} ->
            collect_results(Rest, Ok + 1, Failed);
        {'DOWN', Ref, process, _, skipped} ->
            io:format("  Skipped: ~s~n", [FilePath]),
            collect_results(Rest, Ok, Failed);
        {'DOWN', Ref, process, _, Reason} ->
            io:format("  [crash] ~s crashed: ~p~n", [FilePath, Reason]),
            collect_results(Rest, Ok, Failed + 1)
    after 300000 ->  % 5-minute timeout per file
        io:format("  [timeout] ~s timed out~n", [FilePath]),
        collect_results(Rest, Ok, Failed + 1)
    end.

%% ---------------------------------------------------------------------------
%% Main entry point
%% ---------------------------------------------------------------------------

%% main/1 — The escript entry point for the ingestion pipeline.
%%
%% rebar3 escriptize builds this module into a self-contained Erlang escript.
%% The escript VM calls main/1 with a list of command-line argument strings.
%%
%% Steps:
%%   1. Start required OTP applications (inets for httpc, crypto for MD5).
%%   2. Load configuration.
%%   3. Ensure the database schema exists.
%%   4. Discover documents.
%%   5. Spawn one process per document and wait for all to finish.
%%   6. Print a summary.
-spec main([string()]) -> ok.
main(Args) ->
    %% Start applications that ship with Erlang/OTP.
    %% inets provides httpc; crypto provides hash functions.
    ok = application:start(crypto),
    ok = application:start(inets),
    ok = application:start(ssl),

    Config = rag_config:default_config(),

    %% Allow overriding the docs directory from the command line.
    DocsDir = case Args of
        [Dir | _] -> Dir;
        []        -> binary_to_list(rag_config:get(docs_dir, Config))
    end,

    io:format("~n"),
    io:format("============================================================~n"),
    io:format("RAG Ingestion Pipeline (Erlang)~n"),
    io:format("============================================================~n"),
    io:format("Docs directory : ~s~n", [DocsDir]),
    io:format("Turso URL      : ~s~n", [rag_config:get(turso_url, Config)]),
    io:format("Ollama URL     : ~s~n", [rag_config:get(ollama_url, Config)]),
    io:format("Embed model    : ~s~n", [rag_config:get(embedding_model, Config)]),
    io:format("Chunk size     : ~p chars~n", [rag_config:get(chunk_size, Config)]),
    io:format("~n"),

    %% Ensure the schema is in place.
    ensure_schema(Config),

    %% Discover files.
    Files = discover_files(DocsDir),
    case Files of
        [] ->
            io:format("~nNo supported documents found in ~s~n", [DocsDir]),
            io:format("Add some .txt or .md files and re-run rag_ingest~n"),
            halt(0);
        _ ->
            io:format("Found ~p document(s) to process~n", [length(Files)])
    end,

    %% Spawn one process per file — "let it crash" in action.
    %% Each file is isolated; a crash in one does not affect others.
    StartTime = erlang:monotonic_time(millisecond),
    {ok, Succeeded, Failed} = ingest_files_parallel(Files, Config),
    ElapsedMs = erlang:monotonic_time(millisecond) - StartTime,

    io:format("~n"),
    io:format("============================================================~n"),
    io:format("Ingestion complete in ~.1fs~n", [ElapsedMs / 1000]),
    io:format("  Succeeded: ~p   Failed: ~p~n", [Succeeded, Failed]),
    io:format("============================================================~n"),
    io:format("You can now run:  ./rag_chatbot~n"),
    halt(0).
