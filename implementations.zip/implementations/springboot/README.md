﻿# Spring Boot RAG System

A complete Retrieval-Augmented Generation system built with Spring Boot 3.2 and Java 21.
Connects to **Turso** (LibSQL vector database) and **Ollama** (local LLM inference) via raw HTTP APIs.
No Spring AI dependency — all API calls are made with WebClient directly.

---

## Architecture

```
HTTP Client
    │
    ▼
RagController  (Spring MVC REST)
    │
    ├─── IngestService  ─────────────► ChunkerService
    │         │                              │
    │         ▼                              ▼
    │     OllamaClient (/api/embed)    paragraph + heading split
    │         │
    │         ▼
    │     TursoClient (/v2/pipeline)   INSERT chunks + vector32()
    │
    ├─── VectorSearchService
    │         │
    │         ├── OllamaClient (/api/embed)   embed query
    │         └── TursoClient                vector_top_k()
    │
    └─── RagService
              │
              ├── VectorSearchService         retrieve context
              └── OllamaClient (/api/chat)    stream answer
```

---

## Prerequisites

| Tool   | Version  | Notes |
|--------|----------|-------|
| Java   | 21+      | Virtual threads required |
| Maven  | 3.9+     | Or use the bundled `mvnw` wrapper |
| Ollama | latest   | Running at `http://127.0.0.1:11434` |
| Turso  | any      | HTTP endpoint configured in `application.properties` |

Pull the required Ollama models before starting:

```bash
ollama pull nomic-embed-text
ollama pull gemma3:1b
```

---

## Configuration

Edit `src/main/resources/application.properties`:

```properties
# Required — get this from the Turso dashboard
rag.turso.token=YOUR_TURSO_BEARER_TOKEN

# Optional overrides (defaults shown)
rag.turso.url=https://your-db-name.turso.io
rag.ollama.url=http://127.0.0.1:11434
rag.chat-model=gemma3:1b
rag.embedding-model=nomic-embed-text
rag.embedding-dims=768
rag.top-k=5
rag.docs-dir=./docs
rag.chunk-size=500
```

You can also override any property with an environment variable:

```bash
export RAG_TURSO_TOKEN=eyJhbGc...
mvn spring-boot:run
```

---

## Running

```bash
# Development (live reload not configured, just a clean run)
mvn spring-boot:run

# Build and run the fat jar
mvn clean package -DskipTests
java -jar target/springboot-rag-1.0.0.jar

# Override the token without editing properties
java -Drag.turso.token=eyJhbGc... -jar target/springboot-rag-1.0.0.jar
```

The server starts on `http://localhost:8080`.

---

## API Endpoints

### POST /api/ingest — Upload a document

Uploads a file, splits it into chunks, embeds each chunk with `nomic-embed-text`,
and stores the vectors in Turso. The endpoint is **idempotent** — uploading the
same file twice returns `"skipped": true` on the second call.

```bash
curl -X POST http://localhost:8080/api/ingest \
  -F "file=@/path/to/your/document.txt"
```

**Response:**

```json
{
  "filename": "document.txt",
  "chunks": 12,
  "skipped": false,
  "message": "Ingest complete."
}
```

Supports any plain-text format: `.txt`, `.md`, `.py`, `.java`, `.json`, etc.
For PDFs, convert to text first with `pdftotext`.

---

### POST /api/query — Semantic search (no LLM)

Embeds the query and runs `vector_top_k()` against the Turso HNSW index.
Returns the top-k most relevant chunks with their cosine distances.
Useful for debugging retrieval quality without invoking the language model.

```bash
curl -X POST http://localhost:8080/api/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the system architecture?"}'
```

**Response:**

```json
{
  "query": "What is the system architecture?",
  "count": 5,
  "results": [
    {
      "id": "c3f2a1b0-...",
      "source": "design-doc.md",
      "content": "[Source: design-doc.md]\n## Architecture\nThe system is composed of...",
      "distance": 0.1823
    }
  ]
}
```

Lower `distance` = higher relevance (cosine distance, 0 = identical).

---

### POST /api/chat — Full RAG with SSE streaming

Runs the complete RAG pipeline: retrieves context, builds a grounded prompt,
and streams the LLM's answer token-by-token using **Server-Sent Events**.

```bash
# Stream with curl (--no-buffer prevents curl from buffering the SSE stream)
curl -X POST http://localhost:8080/api/chat \
  --no-buffer \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "query": "Explain the chunking strategy used in this system.",
    "history": []
  }'
```

**Streamed response (one line per SSE event):**

```
event: token
data: The

event: token
data:  chunking

event: token
data:  strategy

...

event: done
data: [DONE]
```

#### Multi-turn conversation

Pass previous turns in the `history` array:

```bash
curl -X POST http://localhost:8080/api/chat \
  --no-buffer \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "query": "Can you elaborate on the vector index?",
    "history": [
      {"role": "user",      "content": "Explain the chunking strategy."},
      {"role": "assistant", "content": "The chunking strategy splits text at paragraph boundaries..."}
    ]
  }'
```

#### JavaScript EventSource (browser)

```javascript
const response = await fetch('http://localhost:8080/api/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ query: 'What is RAG?', history: [] })
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;

  const text = decoder.decode(value);
  // Each SSE event arrives as:
  // "event: token\ndata: <fragment>\n\n"
  const lines = text.split('\n');
  for (const line of lines) {
    if (line.startsWith('data: ') && !line.includes('[DONE]')) {
      process.stdout.write(line.slice(6)); // strip "data: " prefix
    }
  }
}
```

---

### GET /api/documents — List ingested documents

```bash
curl http://localhost:8080/api/documents
```

**Response:**

```json
{
  "count": 3,
  "documents": [
    {
      "id": "a1b2c3d4-...",
      "filename": "architecture.md",
      "chunks": 24,
      "ingested_at": "2025-05-04 10:23:11"
    },
    {
      "id": "e5f6g7h8-...",
      "filename": "api-spec.txt",
      "chunks": 8,
      "ingested_at": "2025-05-04 09:45:02"
    }
  ]
}
```

---

## Database Schema

Turso tables created automatically on first startup:

```sql
-- One row per ingested file
CREATE TABLE IF NOT EXISTS documents (
    id          TEXT PRIMARY KEY,
    filename    TEXT NOT NULL,
    hash        TEXT NOT NULL UNIQUE,   -- SHA-256, used for idempotency
    chunks      INTEGER,
    ingested_at TEXT DEFAULT (datetime('now'))
);

-- One row per text chunk
CREATE TABLE IF NOT EXISTS chunks (
    id          TEXT PRIMARY KEY,
    doc_id      TEXT NOT NULL,          -- FK to documents.id
    source      TEXT NOT NULL,          -- denormalised filename
    content     TEXT NOT NULL,          -- the raw chunk text
    embedding   F32_BLOB(768),          -- 768-dim float32 vector
    chunk_index INTEGER                 -- position within parent document
);

-- HNSW vector index powering vector_top_k() queries
CREATE INDEX IF NOT EXISTS chunks_embedding_idx
ON chunks (libsql_vector_idx(embedding));
```

To reset the database (re-ingest everything):

```sql
-- Run in the Turso shell or dashboard
DROP TABLE IF EXISTS chunks;
DROP TABLE IF EXISTS documents;
```

Then restart the application — it will recreate the schema automatically.

---

## Project Structure

```
springboot/
├── pom.xml
├── README.md
└── src/
    └── main/
        ├── java/com/rag/
        │   ├── RagApplication.java          # @SpringBootApplication entry point
        │   ├── config/
        │   │   └── RagConfig.java           # @ConfigurationProperties record
        │   ├── client/
        │   │   ├── TursoClient.java         # Turso /v2/pipeline HTTP client
        │   │   └── OllamaClient.java        # Ollama embed + chat stream client
        │   ├── service/
        │   │   ├── ChunkerService.java      # Paragraph/heading-aware text splitting
        │   │   ├── IngestService.java       # Parse → chunk → embed → store pipeline
        │   │   ├── VectorSearchService.java # ANN search via vector_top_k()
        │   │   └── RagService.java          # Prompt builder + streaming orchestrator
        │   └── controller/
        │       └── RagController.java       # REST endpoints + SSE chat
        └── resources/
            └── application.properties
```

---

## Troubleshooting

**`Connection refused` to Ollama**
Make sure Ollama is running: `ollama serve` (or it may start automatically).

**`401 Unauthorized` from Turso**
Double-check `rag.turso.token` in `application.properties`.

**Empty results from `/api/query`**
The corpus may be empty. Run `GET /api/documents` to verify ingest succeeded.
Also check that `rag.top-k` is not set to 0.

**`DataBufferLimitException`**
The OllamaClient sets a 10 MB buffer. If you hit this with very large responses,
increase the value in `OllamaClient.client()`.

**Schema already exists error**
All DDL uses `IF NOT EXISTS` — this should not occur. If it does, check that
your Turso token has DDL permissions.

**Chat hangs and never completes**
Check that `gemma3:1b` is pulled (`ollama list`). The first run after a cold
start may take 30+ seconds as the model loads into memory.
