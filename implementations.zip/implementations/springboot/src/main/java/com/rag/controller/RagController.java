package com.rag.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.rag.client.OllamaClient.Message;
import com.rag.config.RagConfig;
import com.rag.service.IngestService;
import com.rag.service.IngestService.IngestResult;
import com.rag.service.RagService;
import com.rag.service.VectorSearchService;
import com.rag.service.VectorSearchService.ChunkResult;
import com.rag.client.TursoClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * RagController is the HTTP front door of the RAG system.
 *
 * <p>It exposes four endpoints that together cover the full lifecycle of a
 * document-question-answering system:
 * <ul>
 *   <li>{@code POST /api/ingest} — upload and vectorise a document.</li>
 *   <li>{@code POST /api/query} — semantic search without LLM generation.</li>
 *   <li>{@code POST /api/chat}  — full RAG: retrieve + generate, streamed via SSE.</li>
 *   <li>{@code GET  /api/documents} — list ingested documents.</li>
 * </ul>
 *
 * <p><b>Why SSE for chat?</b><br>
 * Server-Sent Events are the simplest way to push incremental data over HTTP.
 * Unlike WebSockets, SSE is unidirectional (server → client), which is exactly
 * what we need for token streaming.  SSE works through proxies and load
 * balancers that understand standard HTTP chunked transfer encoding, and it is
 * natively supported by every modern browser via {@code EventSource}.
 *
 * <p><b>Threading model for SSE</b><br>
 * Spring MVC's Tomcat thread pool should not be held for the duration of a
 * streaming response (which can last several seconds).  We use a virtual-thread
 * executor (available since Java 21) to run the blocking Ollama stream off the
 * Tomcat thread.  Virtual threads are extremely cheap — the JVM schedules them
 * on a small pool of OS threads — so we don't need to size a thread pool.
 *
 * <p><b>Timeout</b><br>
 * The {@link SseEmitter} is created with a 120-second timeout, matching the
 * {@code spring.mvc.async.request-timeout} in {@code application.properties}.
 * After that the connection is closed and the client must reconnect.  For
 * production use, a heartbeat keep-alive ping (not implemented here for clarity)
 * would prevent proxy timeouts.
 */
@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class RagController {

    private final RagConfig config;
    private final IngestService ingestService;
    private final VectorSearchService vectorSearch;
    private final RagService ragService;
    private final TursoClient turso;

    /**
     * A virtual-thread executor for running blocking SSE operations off the
     * Tomcat request thread.  Virtual threads are lightweight and created on
     * demand, so we don't need to configure a pool size.
     */
    private final ExecutorService virtualThreadExecutor =
            Executors.newVirtualThreadPerTaskExecutor();

    // =========================================================================
    //  POST /api/ingest — Upload a document for vectorisation
    // =========================================================================

    /**
     * Accept a multipart file upload, save it to the configured docs directory,
     * and run the full ingest pipeline (parse → chunk → embed → store).
     *
     * <p>The endpoint is idempotent: uploading the same file twice returns a
     * {@code 200 OK} with {@code "skipped": true} on the second call, without
     * reprocessing the file.  This makes it safe to use in retry loops.
     *
     * <p>Large files may take several seconds because each chunk requires a
     * round-trip to Ollama for embedding.  The endpoint is synchronous (the HTTP
     * response is sent after ingest completes) so the client gets an accurate
     * count of stored chunks.
     *
     * @param file the uploaded file (text, Markdown, code, etc.)
     * @return JSON with filename, chunks stored, and whether it was skipped
     */
    @PostMapping(value = "/ingest", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> ingest(
            @RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Uploaded file is empty"));
        }

        String filename = file.getOriginalFilename() != null
                ? file.getOriginalFilename() : "upload.txt";
        log.info("Ingest request: '{}' ({} bytes)", filename, file.getSize());

        try {
            // Save the upload to the docs directory so IngestService can read it.
            Path docsDir = Paths.get(config.docsDir());
            Files.createDirectories(docsDir);
            Path savedPath = docsDir.resolve(filename);
            file.transferTo(savedPath);

            IngestResult result = ingestService.ingest(savedPath);

            return ResponseEntity.ok(Map.of(
                    "filename",     result.filename(),
                    "chunks",       result.chunksStored(),
                    "skipped",      result.skipped(),
                    "message",      result.skipped()
                            ? "File already ingested; skipped."
                            : "Ingest complete."
            ));

        } catch (Exception e) {
            log.error("Ingest failed for '{}'", filename, e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // =========================================================================
    //  POST /api/query — Semantic search (no LLM)
    // =========================================================================

    /**
     * Run a vector search and return the top-k most relevant chunks without
     * invoking the language model.
     *
     * <p>This endpoint is useful for:
     * <ul>
     *   <li>Debugging retrieval quality — you can see exactly what the LLM
     *       would receive as context.</li>
     *   <li>Building custom UI that shows relevant excerpts alongside the
     *       generated answer.</li>
     *   <li>Batch evaluation of retrieval without the cost of generation.</li>
     * </ul>
     *
     * @param body JSON object with a {@code "query"} string field
     * @return JSON array of chunk results ordered by relevance
     */
    @PostMapping("/query")
    public ResponseEntity<Map<String, Object>> query(@RequestBody Map<String, String> body) {
        String query = body.get("query");
        if (query == null || query.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Missing 'query' field"));
        }

        log.info("Query request: '{}'", query);
        try {
            List<ChunkResult> results = vectorSearch.search(query);

            List<Map<String, Object>> items = results.stream()
                    .map(r -> Map.<String, Object>of(
                            "id",       r.id(),
                            "source",   r.source(),
                            "content",  r.content(),
                            "distance", r.distance()
                    ))
                    .toList();

            return ResponseEntity.ok(Map.of(
                    "query",   query,
                    "results", items,
                    "count",   items.size()
            ));

        } catch (Exception e) {
            log.error("Query failed", e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // =========================================================================
    //  POST /api/chat — Full RAG with SSE token streaming
    // =========================================================================

    /**
     * Run the full RAG pipeline and stream the language model's answer token-by
     * token using Server-Sent Events.
     *
     * <p>The request body accepts:
     * <pre>
     * {
     *   "query": "What is the capital of France?",
     *   "history": [
     *     { "role": "user",      "content": "Tell me about Europe." },
     *     { "role": "assistant", "content": "Europe is a continent..." }
     *   ]
     * }
     * </pre>
     * {@code history} is optional.  Each SSE event has the event type
     * {@code "token"} for content fragments and {@code "done"} for the
     * end-of-stream signal.  The client can distinguish them with
     * {@code EventSource.addEventListener("token", ...)}.
     *
     * <p><b>SSE implementation details</b><br>
     * We return a {@link SseEmitter} immediately (ending the Tomcat thread's
     * work), then hand off the actual streaming to a virtual thread.  The
     * virtual thread calls {@link RagService#askStreaming}, which blocks on
     * the Ollama stream, calling the consumer for each token.  The consumer
     * sends each token as an SSE event.  When the stream ends we send a
     * {@code "done"} event and complete the emitter.
     *
     * @param body JSON with {@code query} (required) and {@code history}
     *             (optional array of {@code {role, content}} objects)
     * @return an SSE emitter that will emit token events
     */
    @PostMapping(value = "/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter chat(@RequestBody Map<String, Object> body) {
        String query = (String) body.get("query");
        if (query == null || query.isBlank()) {
            SseEmitter errorEmitter = new SseEmitter();
            try {
                errorEmitter.send(SseEmitter.event()
                        .name("error")
                        .data("{\"error\":\"Missing 'query' field\"}"));
            } catch (IOException ignored) {}
            errorEmitter.complete();
            return errorEmitter;
        }

        // Parse optional conversation history.
        List<Message> history = parseHistory(body);

        log.info("Chat request: '{}' ({} history messages)", query, history.size());

        // Create the emitter with a generous timeout to accommodate slow models.
        SseEmitter emitter = new SseEmitter(120_000L);

        // Hand streaming work off to a virtual thread so the Tomcat thread
        // is immediately freed to handle other requests.
        virtualThreadExecutor.submit(() -> {
            try {
                ragService.askStreaming(query, history, token -> {
                    try {
                        // Each token is sent as a "token" named event so the
                        // client can filter with addEventListener("token", ...).
                        emitter.send(SseEmitter.event()
                                .name("token")
                                .data(token));
                    } catch (IOException e) {
                        // Client disconnected — stop generating.
                        log.debug("SSE client disconnected during streaming");
                        emitter.completeWithError(e);
                        throw new RuntimeException("Client disconnected", e);
                    }
                });

                // Signal end of stream so the client can close the EventSource.
                emitter.send(SseEmitter.event().name("done").data("[DONE]"));
                emitter.complete();

            } catch (Exception e) {
                log.error("SSE stream failed", e);
                emitter.completeWithError(e);
            }
        });

        return emitter;
    }

    // =========================================================================
    //  GET /api/documents — List all ingested documents
    // =========================================================================

    /**
     * Return a list of all documents that have been ingested into the vector
     * store, ordered by ingest time (newest first).
     *
     * <p>This endpoint does not load embeddings — it reads only the lightweight
     * {@code documents} table — so it is fast even with thousands of documents.
     *
     * @return JSON array of document metadata records
     */
    @GetMapping("/documents")
    public ResponseEntity<Map<String, Object>> documents() {
        log.info("Documents list request");
        try {
            List<JsonNode> rows = turso.fetchAll(
                    "SELECT id, filename, chunks, ingested_at FROM documents ORDER BY ingested_at DESC",
                    List.of()
            );

            List<Map<String, Object>> docs = rows.stream()
                    .map(row -> Map.<String, Object>of(
                            "id",          cellText(row, 0),
                            "filename",    cellText(row, 1),
                            "chunks",      cellInt(row, 2),
                            "ingested_at", cellText(row, 3)
                    ))
                    .toList();

            return ResponseEntity.ok(Map.of(
                    "documents", docs,
                    "count",     docs.size()
            ));

        } catch (Exception e) {
            log.error("Documents list failed", e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // =========================================================================
    //  Utility helpers
    // =========================================================================

    /**
     * Parse the optional {@code history} field from the chat request body into a
     * typed list of {@link Message} objects.
     *
     * <p>The field is expected to be a JSON array:
     * <pre>
     *   [{"role":"user","content":"..."}, {"role":"assistant","content":"..."}]
     * </pre>
     * Jackson deserialises it as {@code List<Map<String,String>>} because the
     * request body type is {@code Map<String,Object>}.  We convert explicitly
     * to avoid unchecked cast warnings.
     *
     * @param body the parsed request body
     * @return typed history list; empty list if the field is absent or malformed
     */
    @SuppressWarnings("unchecked")
    private List<Message> parseHistory(Map<String, Object> body) {
        List<Message> history = new ArrayList<>();
        Object rawHistory = body.get("history");
        if (rawHistory instanceof List<?> list) {
            for (Object item : list) {
                if (item instanceof Map<?,?> map) {
                    String role    = (String) map.get("role");
                    String content = (String) map.get("content");
                    if (role != null && content != null) {
                        history.add(new Message(role, content));
                    }
                }
            }
        }
        return history;
    }

    /**
     * Extract text from a Turso row cell (cell is a JSON object with a
     * {@code "value"} key).
     *
     * @param row   the row array node
     * @param index zero-based column index
     * @return text value or empty string
     */
    private String cellText(JsonNode row, int index) {
        if (row.isArray() && row.size() > index) {
            return row.get(index).path("value").asText("");
        }
        return "";
    }

    /**
     * Extract an integer from a Turso row cell.
     *
     * @param row   the row array node
     * @param index zero-based column index
     * @return integer value or 0
     */
    private int cellInt(JsonNode row, int index) {
        if (row.isArray() && row.size() > index) {
            return row.get(index).path("value").asInt(0);
        }
        return 0;
    }
}
