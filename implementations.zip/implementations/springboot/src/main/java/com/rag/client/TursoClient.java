package com.rag.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.rag.config.RagConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * TursoClient is the single gateway between this application and Turso's
 * LibSQL HTTP API.
 *
 * <p><b>Why the /v2/pipeline endpoint?</b><br>
 * Turso's HTTP API supports two modes: {@code /v1/execute} (one statement per
 * request) and {@code /v2/pipeline} (a batch of statements in one round-trip).
 * The pipeline endpoint lets us create the table <em>and</em> index in the
 * same network call during {@code IngestService.ensureSchema()}, halving
 * latency on cold starts.  We use the same endpoint for single-statement calls
 * simply by wrapping them in a one-element batch — no special-casing needed.
 *
 * <p><b>Why WebClient instead of RestTemplate?</b><br>
 * {@code RestTemplate} is synchronous and its future development is uncertain
 * in Spring 6+.  {@code WebClient} is non-blocking and works equally well for
 * request-response calls (we just call {@code .block()}) and streaming calls.
 * Using one HTTP client throughout the codebase keeps configuration (timeouts,
 * base URL, default headers) in a single place.
 *
 * <p><b>Parameter encoding</b><br>
 * Turso's protocol encodes each bind parameter as a JSON object:
 * <pre>
 *   { "type": "text", "value": "hello" }
 *   { "type": "integer", "value": "42" }
 *   { "type": "blob", "base64": "..." }
 * </pre>
 * We accept {@code List<Map<String,String>>} so callers can pass arbitrary
 * type/value pairs without depending on this client's internal representation.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TursoClient {

    private final RagConfig config;
    private final ObjectMapper objectMapper;

    /**
     * Lazily-created WebClient configured with Turso's base URL and the
     * Bearer token.  We build it on first use rather than in the constructor
     * so that the {@link RagConfig} record is fully populated before we read
     * its fields.
     */
    private volatile WebClient webClient;

    // -------------------------------------------------------------------------
    //  Public API
    // -------------------------------------------------------------------------

    /**
     * Execute a single SQL statement that does not return rows (DDL, INSERT,
     * UPDATE, DELETE).
     *
     * <p>Example:
     * <pre>
     *   tursoClient.execute(
     *       "INSERT INTO chunks (id, content) VALUES (?, ?)",
     *       List.of(
     *           Map.of("type", "text", "value", uuid),
     *           Map.of("type", "text", "value", content)
     *       )
     *   );
     * </pre>
     *
     * @param sql    parameterised SQL statement with {@code ?} placeholders
     * @param params ordered list of bind-parameter descriptors
     * @throws RuntimeException if Turso returns an error response
     */
    public void execute(String sql, List<Map<String, String>> params) {
        log.debug("Turso execute: {}", sql);
        String body = buildPipelineBody(sql, params);
        String response = client()
                .post()
                .uri("/v2/pipeline")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        checkForErrors(response, sql);
    }

    /**
     * Execute a SQL SELECT statement and return all result rows.
     *
     * <p>Each row is represented as a {@link JsonNode} (an array node whose
     * elements correspond to the selected columns in order).  Callers parse
     * the specific columns they need — this keeps the client generic and
     * reusable across all services.
     *
     * @param sql    parameterised SELECT statement
     * @param params ordered list of bind-parameter descriptors
     * @return list of row nodes; empty list if the query returns no rows
     */
    public List<JsonNode> fetchAll(String sql, List<Map<String, String>> params) {
        log.debug("Turso fetchAll: {}", sql);
        String body = buildPipelineBody(sql, params);
        String response = client()
                .post()
                .uri("/v2/pipeline")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        checkForErrors(response, sql);
        return parseRows(response);
    }

    // -------------------------------------------------------------------------
    //  Internal helpers
    // -------------------------------------------------------------------------

    /**
     * Build the JSON body for a /v2/pipeline request.
     *
     * <p>The pipeline envelope looks like:
     * <pre>
     * {
     *   "requests": [
     *     {
     *       "type": "execute",
     *       "stmt": {
     *         "sql": "SELECT ...",
     *         "args": [ {"type":"text","value":"foo"}, ... ]
     *       }
     *     },
     *     { "type": "close" }
     *   ]
     * }
     * </pre>
     * The trailing {@code close} request is required by the Turso protocol to
     * release the server-side logical connection associated with this pipeline.
     *
     * @param sql    SQL statement
     * @param params bind parameters
     * @return serialised JSON string
     */
    private String buildPipelineBody(String sql, List<Map<String, String>> params) {
        try {
            ObjectNode root = objectMapper.createObjectNode();
            ArrayNode requests = root.putArray("requests");

            // --- Execute request ---
            ObjectNode executeReq = requests.addObject();
            executeReq.put("type", "execute");
            ObjectNode stmt = executeReq.putObject("stmt");
            stmt.put("sql", sql);

            ArrayNode args = stmt.putArray("args");
            if (params != null) {
                for (Map<String, String> param : params) {
                    ObjectNode arg = args.addObject();
                    param.forEach(arg::put);
                }
            }

            // --- Close request (required by protocol) ---
            ObjectNode closeReq = requests.addObject();
            closeReq.put("type", "close");

            return objectMapper.writeValueAsString(root);
        } catch (Exception e) {
            throw new RuntimeException("Failed to build Turso pipeline body", e);
        }
    }

    /**
     * Parse the rows from a /v2/pipeline response.
     *
     * <p>The response structure is:
     * <pre>
     * {
     *   "results": [
     *     {
     *       "type": "ok",
     *       "response": {
     *         "type": "execute",
     *         "result": {
     *           "cols": [ {"name":"id",...}, ... ],
     *           "rows":  [ [ {"type":"text","value":"..."}, ... ], ... ]
     *         }
     *       }
     *     }
     *   ]
     * }
     * </pre>
     * Each row is an array of cell objects.  We return the rows as-is and let
     * callers extract values by index using {@code row.get(n).get("value").asText()}.
     *
     * @param responseBody raw JSON string from Turso
     * @return list of row arrays
     */
    private List<JsonNode> parseRows(String responseBody) {
        List<JsonNode> rows = new ArrayList<>();
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode results = root.path("results");
            if (results.isArray() && !results.isEmpty()) {
                JsonNode firstResult = results.get(0);
                JsonNode rowsNode = firstResult
                        .path("response")
                        .path("result")
                        .path("rows");
                if (rowsNode.isArray()) {
                    for (JsonNode row : rowsNode) {
                        rows.add(row);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Failed to parse Turso response", e);
        }
        return rows;
    }

    /**
     * Inspect the response for Turso error objects and throw a descriptive
     * exception so callers get a meaningful stack trace rather than a silent
     * null pointer later in the pipeline.
     *
     * @param responseBody raw JSON string from Turso
     * @param sql          the statement that was executed (for the error message)
     */
    private void checkForErrors(String responseBody, String sql) {
        if (responseBody == null) {
            throw new RuntimeException("Turso returned null response for: " + sql);
        }
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode results = root.path("results");
            if (results.isArray()) {
                for (JsonNode result : results) {
                    if ("error".equals(result.path("type").asText())) {
                        String message = result.path("error").path("message").asText("unknown error");
                        throw new RuntimeException("Turso error executing [" + sql + "]: " + message);
                    }
                }
            }
        } catch (RuntimeException re) {
            throw re;
        } catch (Exception e) {
            log.warn("Could not parse Turso error response: {}", e.getMessage());
        }
    }

    /**
     * Return (or lazily create) the {@link WebClient} configured for Turso.
     *
     * <p>We use double-checked locking with a {@code volatile} field.  In a
     * Spring application the bean is a singleton so this executes at most once,
     * but the pattern is safe even under concurrent startup scenarios.
     *
     * @return configured WebClient instance
     */
    private WebClient client() {
        if (webClient == null) {
            synchronized (this) {
                if (webClient == null) {
                    webClient = WebClient.builder()
                            .baseUrl(config.tursoUrl())
                            .defaultHeader("Authorization", "Bearer " + config.tursoToken())
                            .defaultHeader("Content-Type", "application/json")
                            .build();
                }
            }
        }
        return webClient;
    }
}
