package com.rag.service;

import com.rag.config.RagConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * ChunkerService is the librarian who decides how to split a long document into
 * meaningful, retrievable pieces.
 *
 * <p><b>Why not just split by character count?</b><br>
 * A naive fixed-size split risks cutting mid-sentence or mid-paragraph, which
 * produces incoherent chunks that confuse both the embedding model (the vector
 * won't represent a complete thought) and the language model (the context it
 * receives won't be grammatically intact).  Instead we use a hierarchy of
 * natural boundaries:
 * <ol>
 *   <li>Markdown headings ({@code ## Title}) — semantic section boundaries.</li>
 *   <li>Blank lines — paragraph boundaries, still meaningful.</li>
 *   <li>Hard size limit — prevents any single chunk from exceeding the embedding
 *       model's input length.</li>
 * </ol>
 *
 * <p><b>Context prefix</b><br>
 * Every chunk is prefixed with the document source name.  When Turso returns
 * the chunk text to the LLM we want the model to know <em>where</em> this
 * excerpt came from without having to query a separate metadata table:
 * <pre>
 *   [Source: design-doc.md]
 *   ## Architecture
 *   The system is composed of three layers...
 * </pre>
 * This is a lightweight version of the "contextual retrieval" technique
 * popularised by Anthropic.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ChunkerService {

    private final RagConfig config;

    /** Matches Markdown ATX headings (#, ##, ###, …). */
    private static final Pattern HEADING_PATTERN =
            Pattern.compile("^#{1,6}\\s+.+", Pattern.MULTILINE);

    /** Two or more consecutive newlines mark a paragraph boundary. */
    private static final Pattern PARAGRAPH_BOUNDARY =
            Pattern.compile("\\n{2,}");

    // -------------------------------------------------------------------------
    //  Public API
    // -------------------------------------------------------------------------

    /**
     * Split {@code text} into a list of overlapping, context-rich chunks ready
     * for embedding.
     *
     * <p>The algorithm:
     * <ol>
     *   <li>Split the text at paragraph boundaries (blank lines).</li>
     *   <li>Walk through the paragraph list, accumulating paragraphs into the
     *       current chunk buffer.</li>
     *   <li>When a paragraph starts with a Markdown heading <em>and</em> the
     *       buffer already contains content, flush the buffer as a new chunk
     *       and reset — the heading begins a new logical section.</li>
     *   <li>When adding a paragraph would push the buffer over
     *       {@link RagConfig#chunkSize()}, flush first then start a new buffer
     *       with that paragraph.</li>
     *   <li>Add a 1-paragraph look-back overlap so that consecutive chunks
     *       share their boundary paragraph — this prevents answers that straddle
     *       a chunk boundary from being missed by retrieval.</li>
     * </ol>
     *
     * @param text   the full document text
     * @param source a short human-readable label for the document (filename)
     * @return ordered list of chunk strings, each prefixed with the source label
     */
    public List<String> chunk(String text, String source) {
        if (text == null || text.isBlank()) {
            return List.of();
        }

        String[] paragraphs = PARAGRAPH_BOUNDARY.split(text.strip());
        List<String> chunks = new ArrayList<>();
        StringBuilder buffer = new StringBuilder();
        String lastParagraph = null;   // for overlap between chunks

        for (String paragraph : paragraphs) {
            String para = paragraph.strip();
            if (para.isBlank()) continue;

            boolean isHeading = HEADING_PATTERN.matcher(para).find();
            boolean bufferWouldOverflow =
                    buffer.length() + para.length() + 2 > config.chunkSize();

            // Flush on heading boundary (start of new section) or size overflow.
            if ((isHeading && !buffer.isEmpty()) || bufferWouldOverflow) {
                flushBuffer(buffer, source, chunks);

                // Overlap: re-add the last paragraph to the fresh buffer so that
                // a sentence split across chunks is retrievable from either side.
                if (lastParagraph != null && !isHeading) {
                    buffer.append(lastParagraph).append("\n\n");
                }
            }

            buffer.append(para).append("\n\n");
            lastParagraph = para;
        }

        // Flush any remaining content.
        flushBuffer(buffer, source, chunks);

        log.debug("Chunked '{}' into {} chunks (chunkSize={})",
                source, chunks.size(), config.chunkSize());
        return chunks;
    }

    // -------------------------------------------------------------------------
    //  Helpers
    // -------------------------------------------------------------------------

    /**
     * Write the current buffer as a new chunk, prepend the source label, and
     * reset the buffer.
     *
     * <p>The source prefix {@code [Source: filename.txt]} is intentionally
     * plain text rather than JSON metadata so that it is embedded as part of
     * the semantic content.  The embedding model will learn that chunks from the
     * same source are semantically related — useful when the corpus has
     * specialised vocabulary per document.
     *
     * @param buffer  the accumulator (will be cleared after flushing)
     * @param source  document label to prepend
     * @param chunks  the output list to append to
     */
    private void flushBuffer(StringBuilder buffer, String source, List<String> chunks) {
        String content = buffer.toString().strip();
        if (!content.isBlank()) {
            String chunk = "[Source: " + source + "]\n" + content;
            chunks.add(chunk);
        }
        buffer.setLength(0);
    }
}
