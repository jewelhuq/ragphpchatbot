package com.rag.service;

import com.rag.client.OllamaClient;
import com.rag.client.OllamaClient.Message;
import com.rag.service.VectorSearchService.ChunkResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * RagService is the conductor of the Retrieval-Augmented Generation pipeline.
 *
 * <p>It sits between the HTTP controller (which handles transport concerns) and
 * the lower-level clients/services (which handle individual AI calls).  Its
 * single responsibility is to answer a question by:
 * <ol>
 *   <li>Retrieving relevant context from the vector store.</li>
 *   <li>Assembling a prompt that instructs the LLM to answer using only that
 *       context.</li>
 *   <li>Calling Ollama (streaming or blocking) and forwarding the answer.</li>
 * </ol>
 *
 * <p><b>Why RAG instead of plain chat?</b><br>
 * Small local models like {@code gemma3:1b} have limited training data and a
 * small context window.  RAG lets us extend their knowledge cheaply by
 * injecting relevant excerpts at query time.  The model doesn't need to
 * "know" the answer — it just needs to be able to follow a well-structured
 * prompt.
 *
 * <p><b>Prompt design</b><br>
 * The system prompt follows a "grounded answering" pattern:
 * <ul>
 *   <li>Tell the model it is a helpful assistant with access to specific
 *       documents.</li>
 *   <li>Paste the retrieved chunks verbatim as a numbered list.</li>
 *   <li>Instruct the model to cite sources and to say "I don't know" if the
 *       chunks don't contain the answer — this reduces hallucination.</li>
 * </ul>
 *
 * <p><b>Multi-turn history</b><br>
 * The caller passes the conversation history as a list of {@link Message}
 * objects.  We prepend our system prompt and the retrieved context, then
 * append the history, so the model has both the grounding and the
 * conversational context.  This is sometimes called the "stuffing" pattern.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RagService {

    private final VectorSearchService vectorSearch;
    private final OllamaClient ollama;

    // -------------------------------------------------------------------------
    //  Public API
    // -------------------------------------------------------------------------

    /**
     * Answer a question using retrieved context, streaming each token via the
     * provided consumer.
     *
     * <p>This is the primary entry point for the SSE chat endpoint.  The
     * controller passes an {@link org.springframework.web.servlet.mvc.method.annotation.SseEmitter}
     * send callback as {@code onChunk}.
     *
     * @param query   the user's current question
     * @param history previous turns in the conversation (may be empty for the
     *                first message)
     * @param onChunk called once per generated token; must not throw exceptions
     */
    public void askStreaming(String query, List<Message> history, Consumer<String> onChunk) {
        log.info("RAG ask (streaming): {}", query);

        List<ChunkResult> chunks = vectorSearch.search(query);
        log.info("Retrieved {} context chunks", chunks.size());

        List<Message> messages = buildMessages(query, history, chunks);
        ollama.chatStream(messages, onChunk);
    }

    /**
     * Answer a question using retrieved context, returning the complete answer
     * as a string.
     *
     * <p>Use this for programmatic callers (e.g., test cases or batch jobs)
     * where streaming is not required.
     *
     * @param query   the user's question
     * @param history conversation history
     * @return the assistant's full response text
     */
    public String ask(String query, List<Message> history) {
        log.info("RAG ask (blocking): {}", query);

        List<ChunkResult> chunks = vectorSearch.search(query);
        log.info("Retrieved {} context chunks", chunks.size());

        List<Message> messages = buildMessages(query, history, chunks);
        return ollama.chat(messages);
    }

    // -------------------------------------------------------------------------
    //  Prompt construction
    // -------------------------------------------------------------------------

    /**
     * Assemble the full message list that will be sent to Ollama.
     *
     * <p>Structure (in order):
     * <ol>
     *   <li><b>System message</b> — grounding instructions and the retrieved
     *       context blocks.</li>
     *   <li><b>History messages</b> — prior user/assistant turns so the model
     *       can maintain conversational coherence.</li>
     *   <li><b>Current user message</b> — the question being asked right now.</li>
     * </ol>
     *
     * <p>We put the context in the system message (not the user message) so that
     * the model treats it as background knowledge rather than part of the
     * conversation, which reduces the risk of the model "discussing" the context
     * rather than using it to answer.
     *
     * @param query   the current user question
     * @param history previous conversation turns
     * @param chunks  retrieved context chunks from vector search
     * @return ordered list of messages ready for Ollama
     */
    private List<Message> buildMessages(String query, List<Message> history,
                                        List<ChunkResult> chunks) {
        List<Message> messages = new ArrayList<>();

        // --- System prompt with injected context ----------------------------
        String contextBlock = buildContextBlock(chunks);
        String systemPrompt = """
                You are a helpful assistant that answers questions based on the provided document context.

                INSTRUCTIONS:
                - Answer using only the information in the CONTEXT section below.
                - If the context does not contain enough information to answer, say "I don't have enough information in the provided documents to answer that."
                - When citing information, mention the source document name (shown in [Source: ...] headers).
                - Be concise and accurate.
                - Do not make up information not present in the context.

                CONTEXT:
                %s
                """.formatted(contextBlock);

        messages.add(new Message("system", systemPrompt));

        // --- Conversation history -------------------------------------------
        // Copy history as-is; the caller is responsible for trimming if the
        // context window is tight.
        messages.addAll(history);

        // --- Current question -----------------------------------------------
        messages.add(new Message("user", query));

        return messages;
    }

    /**
     * Format the retrieved chunks into a numbered list for the system prompt.
     *
     * <p>Each chunk gets a sequential number so the model can refer to
     * "Document 1" or "Document 2" in its answer.  If no chunks were found we
     * return a notice so the model knows not to invent context.
     *
     * @param chunks ANN search results
     * @return a formatted multi-line string ready to paste into the prompt
     */
    private String buildContextBlock(List<ChunkResult> chunks) {
        if (chunks.isEmpty()) {
            return "(No relevant documents found in the knowledge base.)";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < chunks.size(); i++) {
            ChunkResult c = chunks.get(i);
            sb.append("--- Document ").append(i + 1)
              .append(" (source: ").append(c.source())
              .append(", relevance distance: ").append(String.format("%.4f", c.distance()))
              .append(") ---\n")
              .append(c.content())
              .append("\n\n");
        }
        return sb.toString().strip();
    }
}
