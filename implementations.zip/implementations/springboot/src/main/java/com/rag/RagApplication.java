package com.rag;

import com.rag.config.RagConfig;
import com.rag.service.IngestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * RagApplication is the entry point of the Spring Boot RAG system.
 *
 * <p>{@link SpringBootApplication} is a convenience annotation that combines:
 * <ul>
 *   <li>{@code @Configuration} — this class may declare beans.</li>
 *   <li>{@code @EnableAutoConfiguration} — Spring Boot configures sensible
 *       defaults (embedded Tomcat, Jackson, WebClient, etc.) based on the
 *       dependencies present on the classpath.</li>
 *   <li>{@code @ComponentScan} — Spring discovers all {@code @Service},
 *       {@code @RestController}, and {@code @Repository} classes under the
 *       {@code com.rag} package automatically.</li>
 * </ul>
 *
 * <p>{@link EnableConfigurationProperties} tells Spring to bind the
 * {@code application.properties} {@code rag.*} keys to our {@link RagConfig}
 * record and register it as a managed bean.  Without this annotation,
 * {@code @ConfigurationProperties} classes must be explicitly listed or
 * annotated with {@code @Component}, which pollutes the record with
 * framework concerns.
 *
 * <p><b>Startup sequence</b><br>
 * After the application context is ready, the {@link CommandLineRunner} bean
 * declared below calls {@link IngestService#ensureSchema()} to create the
 * Turso tables and vector index if they do not already exist.  This is
 * equivalent to a schema migration step — safe to run on every startup because
 * all DDL statements use {@code IF NOT EXISTS}.
 */
@Slf4j
@SpringBootApplication
@EnableConfigurationProperties(RagConfig.class)
public class RagApplication {

    /**
     * JVM entry point.
     *
     * <p>Spring Boot's {@link SpringApplication#run} bootstraps the IoC
     * container, wires all beans, starts the embedded Tomcat server, and then
     * invokes any {@link CommandLineRunner} beans in the order they are defined.
     *
     * @param args command-line arguments (passed through to Spring Environment
     *             so {@code --server.port=9090} style overrides work)
     */
    public static void main(String[] args) {
        SpringApplication.run(RagApplication.class, args);
    }

    /**
     * Schema bootstrap runner — executed once, immediately after the application
     * context finishes starting.
     *
     * <p>We use a {@link CommandLineRunner} rather than calling
     * {@code ensureSchema()} in a {@code @PostConstruct} method because
     * CommandLineRunner runs <em>after</em> the web server is listening, which
     * means health-check endpoints can respond even if the schema creation takes
     * a moment (e.g., on a slow network to Turso).
     *
     * <p>If schema creation fails (e.g., because Turso is unreachable) the
     * application logs the error and continues rather than crashing, so that
     * development can proceed with a local mock or the error can be diagnosed
     * via the logs.
     *
     * @param ingestService the IngestService bean (injected by Spring)
     * @return a CommandLineRunner that bootstraps the database schema
     */
    @Bean
    CommandLineRunner schemaBootstrap(IngestService ingestService) {
        return args -> {
            log.info("=== RAG Application starting — bootstrapping schema ===");
            try {
                ingestService.ensureSchema();
                log.info("=== Schema ready — RAG Application is fully operational ===");
            } catch (Exception e) {
                log.error("Schema bootstrap failed — check Turso connectivity: {}", e.getMessage());
                log.warn("Application will continue but /api/ingest and /api/chat may fail.");
            }
        };
    }
}
