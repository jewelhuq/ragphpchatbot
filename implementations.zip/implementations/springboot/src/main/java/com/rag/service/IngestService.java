package com.rag.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.rag.client.OllamaClient;
import com.rag.client.TursoClient;
import com.rag.config.RagConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * IngestService is the pipeline that transforms a raw file on disk into a set of
 * searchable vector embeddings stored in Turso.
 *
 * <p>The pipeline has four stages:
 * <ol>
 *   <li><b>Schema bootstrap</b> — create the {@code chunks} table and its
 *       libsql vector index if they do not already exist.  This is idempotent so
 *       it is safe to call on every startup.</li>
 *   <li><b>Hash check</b> — compute the SHA-256 fingerprint of the file.  If a
 *       row with the same hash exists in {@code documents} we skip re-ingesting
 *       the file.  This makes the endpoint idempotent: uploading the same PDF
 *       twice does nothing on the second call.</li>
 *   <li><b>Parse → Chunk → Embed</b> — read the file as UTF-8 text, split it
 *       with {@link ChunkerService}, and call Ollama's embed endpoint for each
 *       chunk.  Each embedding is a 768-element float array.</li>
 *   <li><b>Store</b> — insert each chunk and its embedding into Turso.  The
 *       embedding is stored using Turso's {@code vector32()} syntax which enables
 *       the {@code vector_top_k()} ANN search function.</li>
 * </ol>
 *
 * <p><b>Why not batch embed?</b><br>
 * Ollama's {@code /api/embed} supports batching (sending multiple texts at once).
 * We call it once per chunk for clarity — a production system would batch for
 * throughput.
 *
 * <p><b>Schema design note</b><br>
 * We keep two tables:
 * <ul>
 *   <li>{@code documents} — one row per file; stores the hash, filename, and
 *       ingest timestamp.  Used for the duplicate check and the
 *       {@code /api/documents} listing endpoint.</li>
 *   <li>{@code chunks} — one row per text chunk; stores the text, the
 *       embedding, and a foreign key back to the document.</li>
 * </ul>
 * This separation makes it cheap to list documents without loading embeddings,
 * and easy to delete all chunks for a document if re-ingest is needed.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class IngestService {

    private final RagConfig config;
    private final TursoClient turso;
    private final OllamaClient ollama;
    private final ChunkerService chunker;

    // -------------------------------------------------------------------------
    //  Public API
    // -------------------------------------------------------------------------

    /**
     * Ingest a single file into the vector store.
     *
     * <p>Steps:
     * <ol>
     *   <li>Ensure the database schema exists (idempotent).</li>
     *   <li>Compute SHA-256 hash of the file bytes.</li>
     *   <li>Return early if the hash is already in the {@code documents} table.</li>
     *   <li>Parse, chunk, embed, and store each chunk.</li>
     *   <li>Insert a row into {@code documents} so future calls can skip this file.</li>
     * </ol>
     *
     * @param filePath absolute path to the file to ingest
     * @return a summary of what happened (new chunks added, or skipped)
     * @throws IOException if the file cannot be read
     */
    public IngestResult ingest(Path filePath) throws IOException {
        ensureSchema();

        String filename = filePath.getFileName().toString();
        byte[] bytes = Files.readAllBytes(filePath);
        String hash = sha256(bytes);

        // --- Idempotency check -----------------------------------------------
        if (isAlreadyIngested(hash)) {
            log.info("File '{}' already ingested (hash {}), skipping.", filename, hash);
            return new IngestResult(filename, 0, true);
        }

        // --- Parse -----------------------------------------------------------
        String text = new String(bytes);
        log.info("Ingesting '{}' ({} chars)", filename, text.length());

        // --- Chunk -----------------------------------------------------------
        List<String> chunks = chunker.chunk(text, filename);
        log.info("Split into {} chunks", chunks.size());

        // --- Record the document first so we can FK from chunks ---------------
        String docId = UUID.randomUUID().toString();
        insertDocument(docId, filename, hash, chunks.size());

        // --- Embed and store each chunk --------------------------------------
        int stored = 0;
        for (int i = 0; i < chunks.size(); i++) {
            String chunkText = chunks.get(i);
            try {
                List<Double> embedding = ollama.embed(chunkText);
                String vectorLiteral = toVectorLiteral(embedding);
                insertChunk(docId, filename, chunkText, vectorLiteral, i);
                stored++;
                log.debug("Stored chunk {}/{}", stored, chunks.size());
            } catch (Exception e) {
                log.error("Failed to embed/store chunk {} of '{}': {}", i, filename, e.getMessage());
            }
        }

        log.info("Ingest complete: '{}' → {} chunks stored", filename, stored);
        return new IngestResult(filename, stored, false);
    }

    // -------------------------------------------------------------------------
    //  Schema bootstrap
    // -------------------------------------------------------------------------

    /**
     * Create all required database objects if they do not yet exist.
     *
     * <p>We use {@code CREATE TABLE IF NOT EXISTS} and {@code CREATE INDEX IF
     * NOT EXISTS} so this method is safe to call on every application startup
     * without checking version state.
     *
     * <p>The {@code embedding} column uses Turso's {@code F32_BLOB(768)} type
     * (a fixed-length binary blob interpreted as 768 32-bit floats).  The
     * accompanying vector index uses the {@code libsql_vector_idx} virtual table
     * which powers the {@code vector_top_k()} function.
     *
     * <p>Note: Turso's /v2/pipeline does not support multiple statements in a
     * single request body (it does support multiple request objects in the
     * {@code requests} array, which is what {@link TursoClient} sends — one
     * execute + one close per call).  We therefore make two separate calls.
     */
    public void ensureSchema() {
        log.info("Ensuring database schema...");

        // Documents table: one row per ingested file.
        turso.execute("""
                CREATE TABLE IF NOT EXISTS documents (
                    id        TEXT PRIMARY KEY,
                    filename  TEXT NOT NULL,
                    hash      TEXT NOT NULL UNIQUE,
                    chunks    INTEGER,
                    ingested_at TEXT DEFAULT (datetime('now'))
                )
                """, List.of());

        // Chunks table: one row per text chunk; the embedding column is a
        // binary blob that Turso's ANN index can search efficiently.
        turso.execute("""
                CREATE TABLE IF NOT EXISTS chunks (
                    id          TEXT PRIMARY KEY,
                    doc_id      TEXT NOT NULL,
                    source      TEXT NOT NULL,
                    content     TEXT NOT NULL,
                    embedding   F32_BLOB(%d),
                    chunk_index INTEGER
                )
                """.formatted(config.embeddingDims()), List.of());

        // Vector index on the embedding column.
        // libsql_vector_idx builds an HNSW (Hierarchical Navigable Small World)
        // graph that supports sub-linear ANN queries via vector_top_k().
        turso.execute("""
                CREATE INDEX IF NOT EXISTS chunks_embedding_idx
                ON chunks (libsql_vector_idx(embedding))
                """, List.of());

        log.info("Schema ready.");
    }

    // -------------------------------------------------------------------------
    //  Database helpers
    // -------------------------------------------------------------------------

    /**
     * Check whether a document with the given hash has already been ingested.
     *
     * @param hash SHA-256 hex string
     * @return {@code true} if a document with this hash exists in Turso
     */
    private boolean isAlreadyIngested(String hash) {
        List<JsonNode> rows = turso.fetchAll(
                "SELECT id FROM documents WHERE hash = ?",
                List.of(Map.of("type", "text", "value", hash))
        );
        return !rows.isEmpty();
    }

    /**
     * Insert a row into the {@code documents} table.
     *
     * @param docId    UUID for this document
     * @param filename original file name
     * @param hash     SHA-256 hex
     * @param numChunks how many chunks were produced (stored for dashboard use)
     */
    private void insertDocument(String docId, String filename, String hash, int numChunks) {
        turso.execute(
                "INSERT INTO documents (id, filename, hash, chunks) VALUES (?, ?, ?, ?)",
                List.of(
                        Map.of("type", "text",    "value", docId),
                        Map.of("type", "text",    "value", filename),
                        Map.of("type", "text",    "value", hash),
                        Map.of("type", "integer", "value", String.valueOf(numChunks))
                )
        );
    }

    /**
     * Insert a single chunk and its embedding into the {@code chunks} table.
     *
     * <p>The embedding is passed as a {@code vector32()} literal — a special
     * Turso SQL function that converts a JSON float array string into the
     * internal {@code F32_BLOB} binary format:
     * <pre>
     *   INSERT INTO chunks (..., embedding, ...) VALUES (..., vector32('[0.1,0.2,...]'), ...)
     * </pre>
     * We embed the float array directly in the SQL string rather than binding
     * it as a parameter because Turso's parameter protocol does not yet have a
     * dedicated blob type for vector literals — the {@code vector32()} function
     * call must appear in the SQL text itself.
     *
     * @param docId        parent document UUID
     * @param source       document filename (denormalised for query convenience)
     * @param content      the raw chunk text
     * @param vectorLiteral the {@code '[f1,f2,...]'} string for {@code vector32()}
     * @param index        zero-based chunk sequence number within the document
     */
    private void insertChunk(String docId, String source, String content,
                             String vectorLiteral, int index) {
        String chunkId = UUID.randomUUID().toString();
        // We use string interpolation for the vector32() call because it is a
        // SQL function, not a bind parameter.  The content, source, and IDs
        // are properly parameterised to prevent injection.
        String sql = """
                INSERT INTO chunks (id, doc_id, source, content, embedding, chunk_index)
                VALUES (?, ?, ?, ?, vector32('%s'), ?)
                """.formatted(vectorLiteral);

        turso.execute(sql, List.of(
                Map.of("type", "text",    "value", chunkId),
                Map.of("type", "text",    "value", docId),
                Map.of("type", "text",    "value", source),
                Map.of("type", "text",    "value", content),
                Map.of("type", "integer", "value", String.valueOf(index))
        ));
    }

    // -------------------------------------------------------------------------
    //  Utilities
    // -------------------------------------------------------------------------

    /**
     * Convert a list of doubles into the {@code '[f1,f2,...]'} string format
     * expected by Turso's {@code vector32()} SQL function.
     *
     * @param embedding the floating-point vector
     * @return a JSON array string, e.g. {@code "[0.12,-0.34,...]"}
     */
    private String toVectorLiteral(List<Double> embedding) {
        return embedding.stream()
                .map(d -> String.format("%.8f", d))
                .collect(Collectors.joining(",", "[", "]"));
    }

    /**
     * Compute the SHA-256 hash of a byte array and return it as a lowercase
     * hex string.  Used to deduplicate documents on re-upload.
     *
     * @param bytes raw file bytes
     * @return 64-character hex string
     */
    private String sha256(byte[] bytes) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(bytes);
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 unavailable", e);
        }
    }

    // -------------------------------------------------------------------------
    //  Result DTO
    // -------------------------------------------------------------------------

    /**
     * Simple value object returned to the controller so it can form a useful
     * HTTP response without coupling to the service's internal state.
     *
     * @param filename   the ingested file name
     * @param chunksStored number of chunks written to Turso (0 if skipped)
     * @param skipped    {@code true} if the file was already in the store
     */
    public record IngestResult(String filename, int chunksStored, boolean skipped) {}
}
