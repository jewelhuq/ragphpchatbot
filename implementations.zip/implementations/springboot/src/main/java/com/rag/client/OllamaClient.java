package com.rag.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.rag.config.RagConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.function.Consumer;

/**
 * OllamaClient wraps Ollama's REST API for two distinct use-cases:
 * <ol>
 *   <li><b>Embedding</b> — a synchronous round-trip that converts text into a
 *       floating-point vector.  Used during ingest and at query time.</li>
 *   <li><b>Streaming chat</b> — an asynchronous NDJSON stream where each line
 *       carries the next generated token.  Used by the SSE chat endpoint so the
 *       user sees words appear as they are produced, rather than waiting for the
 *       full answer.</li>
 * </ol>
 *
 * <p><b>Why two different interaction styles?</b><br>
 * Embedding is inherently request-response: we send text and get back an array.
 * Chat generation is inherently streaming: the model emits tokens one-by-one
 * and can take several seconds to complete.  Buffering the entire chat response
 * before returning would feel unresponsive.  Streaming each token via SSE gives
 * an interactive feel even on a small local model like {@code gemma3:1b}.
 *
 * <p><b>NDJSON streaming</b><br>
 * Ollama's {@code /api/chat} endpoint returns newline-delimited JSON, not the
 * {@code text/event-stream} format.  Each line is a complete JSON object:
 * <pre>
 *   {"model":"gemma3:1b","message":{"role":"assistant","content":"Hello"},"done":false}
 *   {"model":"gemma3:1b","message":{"role":"assistant","content":"!"},"done":true}
 * </pre>
 * We read this as a {@code Flux<String>} of raw lines using WebClient's
 * {@code bodyToFlux(String.class)}, parse each line individually, and forward
 * the {@code content} fragment to the caller via a {@link Consumer}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OllamaClient {

    private final RagConfig config;
    private final ObjectMapper objectMapper;

    /** A message in the multi-turn conversation history. */
    public record Message(String role, String content) {}

    /** Lazily built WebClient for Ollama calls. */
    private volatile WebClient webClient;

    // -------------------------------------------------------------------------
    //  Public API
    // -------------------------------------------------------------------------

    /**
     * Embed a single piece of text into a dense floating-point vector.
     *
     * <p>The vector dimensionality is determined by the embedding model
     * ({@code nomic-embed-text} → 768 dimensions).  The caller stores these
     * vectors verbatim in Turso and later passes them back for ANN (approximate
     * nearest-neighbour) search via {@code vector_top_k()}.
     *
     * <p>This call <em>blocks</em> the calling thread.  That is acceptable here
     * because embedding is fast (sub-second on CPU) and we only embed one chunk
     * at a time during ingest.  If throughput became a bottleneck we could
     * switch to a reactive pipeline.
     *
     * @param text the text to embed; should be roughly chunk-sized (~500 chars)
     * @return a list of floats representing the semantic position of the text
     * @throws RuntimeException if Ollama is unreachable or returns an error
     */
    public List<Double> embed(String text) {
        log.debug("Embedding {} chars with model {}", text.length(), config.embeddingModel());
        try {
            ObjectNode body = objectMapper.createObjectNode();
            body.put("model", config.embeddingModel());
            body.put("input", text);

            String response = client()
                    .post()
                    .uri("/api/embed")
                    .bodyValue(objectMapper.writeValueAsString(body))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            JsonNode root = objectMapper.readTree(response);
            // Ollama /api/embed returns { "embeddings": [[...]] }
            JsonNode embeddings = root.path("embeddings");
            if (embeddings.isArray() && !embeddings.isEmpty()) {
                JsonNode vector = embeddings.get(0);
                List<Double> result = new java.util.ArrayList<>();
                for (JsonNode val : vector) {
                    result.add(val.asDouble());
                }
                log.debug("Got embedding vector of {} dims", result.size());
                return result;
            }
            throw new RuntimeException("Ollama embed returned unexpected shape: " + response);
        } catch (RuntimeException re) {
            throw re;
        } catch (Exception e) {
            throw new RuntimeException("Failed to embed text", e);
        }
    }

    /**
     * Stream a chat completion token-by-token.
     *
     * <p>This method is deliberately <em>synchronous from the caller's
     * perspective</em> — it blocks until the stream is fully consumed.  The
     * reactive magic is hidden inside: WebClient reads the NDJSON stream
     * reactively and we subscribe to it, invoking {@code onChunk} for each
     * non-empty content fragment.  The controller layer converts those callbacks
     * into SSE events on its own {@link org.springframework.web.servlet.mvc.method.annotation.SseEmitter}.
     *
     * <p>Why a {@link Consumer} callback instead of returning a {@link Flux}?
     * Returning a Flux would leak the reactive model into the service layer,
     * making testing harder and coupling the service to WebFlux.  A Consumer
     * keeps the service layer plain Java and lets the controller decide how to
     * propagate tokens (SSE today, WebSocket tomorrow).
     *
     * @param messages conversation history including the current user message
     * @param onChunk  called once per generated token fragment; must be
     *                 thread-safe as Reactor may deliver chunks on its own threads
     * @throws RuntimeException if Ollama is unreachable or the stream breaks
     */
    public void chatStream(List<Message> messages, Consumer<String> onChunk) {
        log.debug("Starting streaming chat with {} messages, model {}",
                messages.size(), config.chatModel());
        try {
            String body = buildChatBody(messages, true);

            // bodyToFlux(String.class) gives us one String per newline-delimited
            // chunk as they arrive from Ollama.  We parse each fragment and
            // forward the text content to the caller.
            client()
                    .post()
                    .uri("/api/chat")
                    .bodyValue(body)
                    .retrieve()
                    .bodyToFlux(String.class)
                    .doOnNext(line -> handleChatLine(line, onChunk))
                    .doOnError(e -> log.error("Error in chat stream", e))
                    .blockLast();   // blocks until Ollama sends the final "done":true line

        } catch (Exception e) {
            throw new RuntimeException("Chat stream failed", e);
        }
    }

    /**
     * Non-streaming chat — useful for building prompts internally where we need
     * the complete answer as a string (e.g., document summarisation during ingest).
     *
     * @param messages conversation history
     * @return the complete assistant response text
     */
    public String chat(List<Message> messages) {
        log.debug("Non-streaming chat with {} messages", messages.size());
        try {
            String body = buildChatBody(messages, false);
            String response = client()
                    .post()
                    .uri("/api/chat")
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            JsonNode root = objectMapper.readTree(response);
            return root.path("message").path("content").asText();
        } catch (Exception e) {
            throw new RuntimeException("Chat request failed", e);
        }
    }

    // -------------------------------------------------------------------------
    //  Internal helpers
    // -------------------------------------------------------------------------

    /**
     * Build the JSON body for an Ollama /api/chat request.
     *
     * <p>The body shape is:
     * <pre>
     * {
     *   "model": "gemma3:1b",
     *   "messages": [
     *     { "role": "system",    "content": "..." },
     *     { "role": "user",      "content": "..." },
     *     { "role": "assistant", "content": "..." }
     *   ],
     *   "stream": true
     * }
     * </pre>
     *
     * @param messages conversation turns
     * @param stream   whether Ollama should stream the response
     * @return serialised JSON
     */
    private String buildChatBody(List<Message> messages, boolean stream) {
        try {
            ObjectNode root = objectMapper.createObjectNode();
            root.put("model", config.chatModel());
            root.put("stream", stream);

            ArrayNode msgs = root.putArray("messages");
            for (Message m : messages) {
                ObjectNode msg = msgs.addObject();
                msg.put("role", m.role());
                msg.put("content", m.content());
            }
            return objectMapper.writeValueAsString(root);
        } catch (Exception e) {
            throw new RuntimeException("Failed to build chat body", e);
        }
    }

    /**
     * Parse a single NDJSON line from the chat stream and forward the content
     * fragment to the consumer.
     *
     * <p>We silently skip malformed lines (e.g., keep-alive newlines or
     * partial chunks Reactor might emit) so that one bad line doesn't abort
     * an otherwise healthy stream.
     *
     * @param line    a raw line from the NDJSON stream
     * @param onChunk the consumer to call with non-empty content fragments
     */
    private void handleChatLine(String line, Consumer<String> onChunk) {
        if (line == null || line.isBlank()) return;
        try {
            JsonNode node = objectMapper.readTree(line);
            String content = node.path("message").path("content").asText("");
            if (!content.isEmpty()) {
                onChunk.accept(content);
            }
        } catch (Exception e) {
            log.trace("Skipping malformed chat line: {}", line);
        }
    }

    /**
     * Return (or lazily create) the {@link WebClient} for Ollama.
     *
     * <p>We increase the in-memory buffer size to 10 MB because large
     * documents and long chat responses can exceed WebClient's default
     * 256 KB limit, causing a {@code DataBufferLimitException}.
     *
     * @return configured WebClient
     */
    private WebClient client() {
        if (webClient == null) {
            synchronized (this) {
                if (webClient == null) {
                    webClient = WebClient.builder()
                            .baseUrl(config.ollamaUrl())
                            .defaultHeader("Content-Type", "application/json")
                            .codecs(c -> c.defaultCodecs()
                                    .maxInMemorySize(10 * 1024 * 1024)) // 10 MB
                            .build();
                }
            }
        }
        return webClient;
    }
}
