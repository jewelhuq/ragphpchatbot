﻿package com.rag.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * RagConfig is the single source of truth for every tuneable in this application.
 *
 * <p>Why a record?  Records are immutable by construction, which means there is
 * no risk of a service accidentally mutating the config after startup.  Spring
 * Boot 3.x supports {@code @ConfigurationProperties} on records natively — it
 * uses the canonical constructor, so every field is validated at boot time.
 *
 * <p>Why {@code @ConfigurationProperties} rather than {@code @Value}?
 * {@code @Value} scatters magic strings across the codebase and makes
 * refactoring error-prone.  A single bound record lets us rename a property in
 * {@code application.properties} and have the IDE catch every usage.
 *
 * <p>The {@code "rag"} prefix means the key {@code rag.turso.url} in
 * {@code application.properties} maps to the {@code tursoUrl} field here —
 * Spring Boot performs the camel-case / kebab-case conversion automatically.
 */
@ConfigurationProperties(prefix = "rag")
public record RagConfig(

        /**
         * Base URL of the Turso LibSQL HTTP endpoint.
         * Example: {@code https://your-db-name.turso.io}
         */
        String tursoUrl,

        /**
         * Bearer token used to authenticate every request to Turso.
         * Keep this out of version control — pass it via an environment
         * variable ({@code RAG_TURSO_TOKEN}) in production.
         */
        String tursoToken,

        /**
         * Base URL of the local Ollama server.
         * Default matches the Ollama installer's default binding.
         */
        @DefaultValue("http://127.0.0.1:11434")
        String ollamaUrl,

        /**
         * The chat / completion model to use when answering questions.
         * Must already be pulled: {@code ollama pull gemma3:1b}.
         */
        @DefaultValue("gemma3:1b")
        String chatModel,

        /**
         * The embedding model.  Must produce vectors whose dimensionality
         * matches {@link #embeddingDims()}.
         * Pull with: {@code ollama pull nomic-embed-text}.
         */
        @DefaultValue("nomic-embed-text")
        String embeddingModel,

        /**
         * The number of dimensions produced by {@link #embeddingModel()}.
         * Turso's vector index is created with this value, so changing it
         * after the first ingest requires dropping and recreating the table.
         */
        @DefaultValue("768")
        int embeddingDims,

        /**
         * How many nearest-neighbour chunks to retrieve for each query.
         * Larger values provide more context but may exceed the chat model's
         * context window or dilute relevance.
         */
        @DefaultValue("5")
        int topK,

        /**
         * Directory where uploaded documents are stored before parsing.
         * The IngestService creates this directory if it does not exist.
         */
        @DefaultValue("./docs")
        String docsDir,

        /**
         * Target character length of each text chunk produced by the
         * ChunkerService.  ~500 chars ≈ ~120 tokens, well within
         * nomic-embed-text's 8192-token limit.
         */
        @DefaultValue("500")
        int chunkSize

) {}
