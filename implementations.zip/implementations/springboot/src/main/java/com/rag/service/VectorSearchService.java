package com.rag.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.rag.client.OllamaClient;
import com.rag.client.TursoClient;
import com.rag.config.RagConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * VectorSearchService is the bridge between a natural-language question and the
 * relevant document chunks stored in Turso.
 *
 * <p><b>How approximate nearest-neighbour search works here</b><br>
 * When we ingest a chunk we store its embedding — a 768-element float vector —
 * in Turso's {@code F32_BLOB} column.  At query time we:
 * <ol>
 *   <li>Embed the user's question using the same model ({@code nomic-embed-text})
 *       so that semantically similar texts end up near each other in 768-D
 *       space.</li>
 *   <li>Call Turso's {@code vector_top_k()} function, which uses the pre-built
 *       HNSW index to find the {@code k} stored embeddings closest (by cosine
 *       similarity) to the query vector — without scanning every row.</li>
 *   <li>Join the result back to the {@code chunks} table to retrieve the actual
 *       text and metadata.</li>
 * </ol>
 *
 * <p><b>Why cosine similarity?</b><br>
 * Cosine similarity measures the angle between two vectors, not their
 * magnitude.  That is the right metric for semantic embeddings because the
 * models are trained to encode meaning as direction, not length.  Turso's
 * {@code vector_top_k()} uses cosine similarity by default for this index type.
 *
 * <p><b>Why not raw SQL {@code ORDER BY … LIMIT ?}?</b><br>
 * A full table scan computing the distance to every stored vector is O(n).
 * {@code vector_top_k()} uses the HNSW graph to answer approximate queries in
 * O(log n) time.  For a small corpus the difference is unnoticeable, but it
 * scales gracefully to millions of chunks.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class VectorSearchService {

    private final RagConfig config;
    private final TursoClient turso;
    private final OllamaClient ollama;

    // -------------------------------------------------------------------------
    //  Public API
    // -------------------------------------------------------------------------

    /**
     * Find the most semantically relevant chunks for a given query.
     *
     * <p>The returned list is ordered by relevance (closest vector first) and
     * contains at most {@link RagConfig#topK()} results.  Each result includes
     * the chunk text and the source document name so the LLM can cite its
     * sources.
     *
     * @param query the user's natural-language question
     * @return ranked list of matching chunks; empty if the corpus is empty or
     *         no chunks match the top-k threshold
     */
    public List<ChunkResult> search(String query) {
        log.debug("Searching for: {}", query);

        // Step 1 — embed the query.
        List<Double> queryEmbedding = ollama.embed(query);
        String vectorLiteral = toVectorLiteral(queryEmbedding);

        // Step 2 — ANN search via vector_top_k().
        //
        // vector_top_k(table_name, query_vector, k) is a Turso table-valued
        // function that returns a result set with columns (id, distance).
        // We join that to `chunks` to get the actual text.
        //
        // The query vector must be passed as a vector32() literal embedded
        // directly in the SQL, similar to how we insert embeddings.
        String sql = """
                SELECT c.id, c.source, c.content, v.distance
                FROM vector_top_k('chunks_embedding_idx', vector32('%s'), %d) AS v
                JOIN chunks AS c ON c.id = v.id
                ORDER BY v.distance ASC
                """.formatted(vectorLiteral, config.topK());

        List<JsonNode> rows = turso.fetchAll(sql, List.of());
        log.debug("vector_top_k returned {} rows", rows.size());

        // Step 3 — convert rows to ChunkResult records.
        List<ChunkResult> results = new ArrayList<>();
        for (JsonNode row : rows) {
            // Each row is a JSON array: [id, source, content, distance]
            String id      = cellText(row, 0);
            String source  = cellText(row, 1);
            String content = cellText(row, 2);
            double distance = cellDouble(row, 3);
            results.add(new ChunkResult(id, source, content, distance));
        }

        return results;
    }

    // -------------------------------------------------------------------------
    //  Helpers
    // -------------------------------------------------------------------------

    /**
     * Convert a list of doubles into the {@code '[f1,f2,...]'} format expected
     * by Turso's {@code vector32()} SQL function.
     *
     * <p>We use 8 decimal places of precision.  IEEE 754 single-precision floats
     * have about 7 significant digits, so 8 decimal places is more than enough
     * and avoids rounding artefacts that could shift the ANN result.
     *
     * @param embedding the query embedding
     * @return a JSON float array string
     */
    private String toVectorLiteral(List<Double> embedding) {
        return embedding.stream()
                .map(d -> String.format("%.8f", d))
                .collect(Collectors.joining(",", "[", "]"));
    }

    /**
     * Safely extract the text value of a cell from a Turso row array.
     *
     * <p>Turso row cells are JSON objects like {@code {"type":"text","value":"foo"}}.
     * We navigate to the {@code value} key, defaulting to an empty string so
     * that a null cell does not cause a NullPointerException downstream.
     *
     * @param row   the row array node
     * @param index zero-based column index
     * @return text value or empty string
     */
    private String cellText(JsonNode row, int index) {
        if (row.isArray() && row.size() > index) {
            return row.get(index).path("value").asText("");
        }
        return "";
    }

    /**
     * Safely extract the numeric (double) value of a cell from a Turso row array.
     *
     * @param row   the row array node
     * @param index zero-based column index
     * @return double value or 0.0 if absent
     */
    private double cellDouble(JsonNode row, int index) {
        if (row.isArray() && row.size() > index) {
            return row.get(index).path("value").asDouble(0.0);
        }
        return 0.0;
    }

    // -------------------------------------------------------------------------
    //  Result type
    // -------------------------------------------------------------------------

    /**
     * A single search result: the chunk text, where it came from, and how close
     * it was to the query in vector space.
     *
     * <p>{@code distance} is the cosine distance (0 = identical, 2 = maximally
     * dissimilar) from Turso's HNSW index.  A lower distance means higher
     * relevance.  We expose it so the controller can include it in the JSON
     * response for debugging and UI relevance indicators.
     *
     * @param id       chunk UUID (useful for deduplication)
     * @param source   document filename the chunk came from
     * @param content  the raw chunk text (including the {@code [Source:]} prefix)
     * @param distance cosine distance from the query vector
     */
    public record ChunkResult(String id, String source, String content, double distance) {}
}
